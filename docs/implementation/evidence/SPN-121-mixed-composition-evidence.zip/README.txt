SPN-121 fixed mixed-operation observations, 2026-10-29.

This is rejected-candidate evidence, not a passing test. The unrestricted balanced association preserved all56 applied complete snapshots in the fixed18 original/candidate pairs, but changed120 own undefined-property presences across10 complete publication pairs. The raw action counterexamples are retained; no normalization is used to accept them.

The first restricted launch failed process monitoring before any case record. No task process remained. The identical collector/fixture/plan was then run once outside that restriction with fail-closed monitor cleanup. All18 raw observations were collected in0.764s, observedpeak121.21MiB, with no resource/monitor abort.

The next candidate restricts balancing to qualified single-character insert folds and retains the original reducer for other inputs. This archive does not establish that later candidate or browser timing acceptance.

Raw files use Nodev8 serialization under26.12.1. Absolute paths in the frozen source describe this run; future execution needs a new reviewed plan. The frozen full test sources from both earlier control failures are retained with local validation evidence.
