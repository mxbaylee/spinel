// SPN-121: one fixed observations-only collection. No unit/production changes,
// instrumentation, normalization, performance assertion or automatic retry.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { isDeepStrictEqual } from 'node:util';
import { serialize } from 'node:v8';
import type { State, Request } from './fixture.ts';

const directory = import.meta.dirname;
const plan = JSON.parse(readFileSync(join(directory, 'plan.json'), 'utf8'));
assert.equal(process.version, plan.runtime);
assert.equal(plan.formats.length * plan.scenarios.length, 18);
const sha256 = (value: Uint8Array | string) => createHash('sha256').update(value).digest('hex');
const startedAt = new Date().toISOString();
writeFileSync(join(directory, 'execution-started.json'), JSON.stringify({ startedAt, runtime: process.version }), { flag: 'wx' });
mkdirSync(join(directory, 'raw'), { recursive: true });
const hashes: Record<string, string> = {};
for (const [path, expected] of Object.entries(plan.knownSources)) {
  hashes[path] = sha256(readFileSync(path));
  assert.equal(hashes[path], expected, `Reviewed source mismatch: ${path}`);
}
for (const name of ['fixture.ts', 'collector.ts', 'plan.json'])
  hashes[name] = sha256(readFileSync(join(directory, name)));
const result: any = { purpose: plan.purpose, startedAt, runtime: process.version, hashes, status: 'collecting-observations-only', cases: [] };
const persist = () => writeFileSync(join(directory, 'observations.json'), JSON.stringify(result, null, 2));
persist();
const { managerFixture, sequence, mixed, apply, readBuild, prepareDocsPatch, unitId } = await import('./fixture.ts');
const errorInfo = (error: unknown) => error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : { message: String(error) };

function collectPublication(source: string, history: State[], collaboration: State[]) {
  const captured: any = { errors: [] };
  const f = managerFixture(source);
  const cache = structuredClone({ history: [...history], collaboration: [...collaboration] });
  captured.input = structuredClone(cache);
  const retained = [...cache.history, ...cache.collaboration];
  const before = structuredClone(retained);
  try {
    f.manager.setStateCache(unitId, cache);
    try { f.manager.flushPendingChanges(unitId); }
    catch (error) { captured.errors.push({ phase: 'flush', ...errorInfo(error) }); }
    captured.output = { history: f.history, changes: f.changes, publication: f.publication };
    captured.cacheAfter = structuredClone(f.manager.getStateCache(unitId));
    captured.statesAfter = structuredClone(retained);
    captured.inputStatesUnchanged = isDeepStrictEqual(before, retained);
    captured.cachesEmpty = captured.cacheAfter.history.length === 0 && captured.cacheAfter.collaboration.length === 0;
  } finally {
    try { f.close(); }
    catch (error) { captured.errors.push({ phase: 'cleanup', ...errorInfo(error) }); }
  }
  return captured;
}

function requests(name: string): Request[] {
  switch (name) {
    case 'empty': return [];
    case 'noop': return [() => null];
    case 'one': return mixed.slice(0, 1);
    case 'surrounded': return [() => null, mixed[0], () => null];
    case 'five': return mixed.slice(0, 5);
    case 'eleven': return mixed;
    default: throw new Error(`Undeclared request case: ${name}`);
  }
}

try {
  for (const format of plan.formats) {
    const builds = prepareDocsPatch(await readBuild(format), format);
    hashes[`${format}/original-docs`] = sha256(builds.original);
    hashes[`${format}/patched-docs`] = sha256(builds.patched);
    for (const item of plan.scenarios) {
      const context = { format, scenario: item.id, historyStart: item.historyStart };
      const raw: any = { context, errors: [], arms: {} };
      const summary: any = { ...context, status: 'collecting-observations', errors: [] };
      result.cases.push(summary);
      persist();
      try {
        const data = sequence(requests(item.requests));
        raw.sequence = data;
        const history = item.history ? data.states.slice(item.historyStart) : [];
        const collaboration = item.collaboration ? data.states : [];
        raw.cacheCounts = { history: history.length, collaboration: collaboration.length };
        const after = data.snapshots.at(-1)!;
        for (const arm of ['original', 'patched'] as const) {
          try {
            const publication = collectPublication(builds[arm], history, collaboration);
            const observations: any = raw.arms[arm] = { publication, directions: {} };
            const entry = publication.output?.history[0];
            const change = publication.output?.changes[0];
            const directions = {
              historyRedo: { present: Boolean(entry), actions: entry?.redoMutations[0]?.params.actions, base: data.snapshots[item.historyStart], expected: after },
              historyUndo: { present: Boolean(entry), actions: entry?.undoMutations[0]?.params.actions, base: after, expected: data.undoSnapshots[item.historyStart] },
              collaborationRedo: { present: Boolean(change), actions: change?.redoState.actions, base: data.snapshots[0], expected: after },
              collaborationUndo: { present: Boolean(change), actions: change?.undoState.actions, base: after, expected: data.undoSnapshots[0] },
            };
            for (const [direction, input] of Object.entries(directions)) {
              const observed: any = observations.directions[direction] = { present: input.present, expectedSequential: input.expected };
              if (!input.present) continue;
              try {
                observed.snapshot = apply(input.base, input.actions);
                observed.exactSequential = isDeepStrictEqual(observed.snapshot, input.expected);
              } catch (error) {
                observed.error = { ...context, arm, direction, ...errorInfo(error) };
              }
            }
          } catch (error) {
            raw.errors.push({ ...context, arm, phase: 'collect-arm', ...errorInfo(error) });
          }
        }
        const original = raw.arms.original;
        const patched = raw.arms.patched;
        if (original && patched) {
          summary.exactRawPublication = isDeepStrictEqual(original.publication.output, patched.publication.output);
          summary.exactFinalCaches = isDeepStrictEqual(original.publication.cacheAfter, patched.publication.cacheAfter);
          summary.arms = Object.fromEntries(['original', 'patched'].map((arm) => [arm, {
            inputStatesUnchanged: raw.arms[arm].publication.inputStatesUnchanged,
            cachesEmpty: raw.arms[arm].publication.cachesEmpty,
            errors: raw.arms[arm].publication.errors,
          }]));
          summary.directions = Object.fromEntries(Object.keys(original.directions).map((direction) => {
            const left = original.directions[direction];
            const right = patched.directions[direction];
            return [direction, {
              originalPresent: left.present, patchedPresent: right.present,
              exactCandidateControl: left.snapshot && right.snapshot ? isDeepStrictEqual(left.snapshot, right.snapshot) : null,
              originalExactSequential: left.exactSequential ?? null,
              patchedExactSequential: right.exactSequential ?? null,
              originalError: left.error, patchedError: right.error,
            }];
          }));
        }
      } catch (error) {
        raw.errors.push({ ...context, phase: 'case', ...errorInfo(error) });
      } finally {
        summary.errors = raw.errors;
        const bytes = serialize(raw);
        const file = `raw/${format}-${item.id}.bin`;
        writeFileSync(join(directory, file), bytes);
        summary.raw = { file, bytes: bytes.length, sha256: sha256(bytes), format: 'node:v8 serialize; Node26.12.1' };
        summary.status = 'observations-recorded-not-a-pass';
        persist();
        process.stdout.write(JSON.stringify(summary) + '\n');
      }
    }
  }
} finally {
  result.finishedAt = new Date().toISOString();
  result.recordedPairs = result.cases.filter((item: any) => item.status === 'observations-recorded-not-a-pass').length;
  result.status = result.recordedPairs === 18 ? 'observations-complete-not-a-pass' : 'incomplete-observations-not-a-pass';
  result.conclusionLimit = 'Raw evidence only. No semantic normalization, production/test expectation change, timing pass, historical-spike attribution or browser acceptance.';
  persist();
  if (result.recordedPairs !== 18) process.exitCode = 1;
}
