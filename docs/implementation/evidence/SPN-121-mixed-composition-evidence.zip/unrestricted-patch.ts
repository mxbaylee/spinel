/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Modified for Spinel: compose each native Doc cache in an order-preserving
 * balanced tree, avoiding repeated traversal and cloning of a growing prefix.
 * Only the four composition folds change. Native grouping, metadata, cache
 * ownership, publication order and timers remain in the pinned SDK service.
 * Source: packages/docs/src/services/doc-state-change-manager.service.ts,
 * dream-num/univer v1.1.0 (Apache-2.0). No Pro code is read or modified.
 * Temporary: SPN-122 removes this after a suitable upstream release. SPN-121
 * retains the source, semantic and browser acceptance evidence.
 */
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const formats = {
  es: '84349b3374cafabaf0baee661b97b4a76a2ac47d1bc68e73cef34f9b8c58e145',
  cjs: '8a3191dee7f9f21c2a2cbb7bb0a7c93af624ef58f2fb8a96af71b27f6cbf5642',
} as const;

export function prepareDocsPatch(source: string, format: keyof typeof formats) {
  const json = format === 'cjs' ? '_univerjs_core.JSONX' : 'JSONX';
  const anchor = 'const DEBOUNCE_DELAY = 300;';
  const helper = `${anchor}
// Modified for Spinel: preserve operation order without repeatedly composing
// the entire accumulated prefix. Each native cache is still folded separately.
function composeDocStateActions(states, key) {
\tfunction composeRange(start, end) {
\t\tconst length = end - start;
\t\tif (length === 0) return null;
\t\tif (length === 1) return states[start][key].actions;
\t\tconst middle = start + Math.floor(length / 2);
\t\treturn ${json}.compose(composeRange(start, middle), composeRange(middle, end));
\t}
\t// Retain native validation/identity semantics for a singleton cache.
\treturn states.length === 1 ? ${json}.compose(null, states[0][key].actions) : composeRange(0, states.length);
}`;
  const replacements = [
    { before: anchor, after: helper, count: 1 },
    {
      before: `cacheStates.reduce((acc, cur) => ${json}.compose(acc, cur.redoState.actions), null)`,
      after: 'composeDocStateActions(cacheStates, "redoState")',
      count: 2,
    },
    {
      before: `cacheStates.reverse().reduce((acc, cur) => ${json}.compose(acc, cur.undoState.actions), null)`,
      after: 'composeDocStateActions(cacheStates.reverse(), "undoState")',
      count: 2,
    },
  ];
  // Recover only these exact substitutions, then verify the complete upstream
  // file. The recovered original also supplies an executable negative control.
  const original = replacements.reduce(
    (text, { before, after }) => text.replaceAll(after, before),
    source,
  );
  if (createHash('sha256').update(original).digest('hex') !== formats[format])
    throw new Error(`Unrecognized @univerjs/docs ${format} build; review native composition.`);
  const patched = replacements.reduce((text, { before, after, count }) => {
    if (text.split(before).length !== count + 1)
      throw new Error('Docs composition patch target count changed.');
    return text.replaceAll(before, after);
  }, original);
  if (source !== original && source !== patched)
    throw new Error(
      `Partially modified @univerjs/docs ${format} build; restore the pinned package.`,
    );
  return { original, patched };
}

export async function patchInstalledDocs(root: string) {
  const directory = resolve(root, 'node_modules/@univerjs/docs');
  const metadata = JSON.parse(await readFile(resolve(directory, 'package.json'), 'utf8'));
  if (metadata.name !== '@univerjs/docs' || metadata.version !== '1.1.0')
    throw new Error('Upgrading @univerjs/docs: review native composition and SPN-122 first.');
  // Fail closed on either unknown build before writing either format.
  const updates = await Promise.all(
    (Object.keys(formats) as (keyof typeof formats)[]).map(async (format) => {
      const path = resolve(directory, 'lib', format, 'index.js');
      const source = await readFile(path, 'utf8');
      return { path, source, patched: prepareDocsPatch(source, format).patched };
    }),
  );
  for (const { path, source, patched } of updates)
    if (source !== patched) await writeFile(path, patched);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url))
  await patchInstalledDocs(resolve(import.meta.dirname, '../..'));
