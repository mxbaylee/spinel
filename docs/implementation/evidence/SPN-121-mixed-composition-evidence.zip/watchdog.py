import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path('/workspace/scratch/5386d318a310')
directory = root / 'spn121-mixed-observation'
node = root / 'node-v26.12.1-linux-x64/bin/node'
command = [str(node), '--max-old-space-size=1024', str(directory / 'collector.ts')]
current = Path('/sys/fs/cgroup/memory.current')
limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
initial = int(current.read_text())
environment = dict(os.environ)
environment['PATH'] = str(node.parent) + os.pathsep + environment['PATH']
started = time.monotonic()
peak = 0
reason = None
child = None
status = None
try:
 if initial > limit * 0.8:
  raise RuntimeError('Elevated starting cgroup memory')
 with (directory / 'collector.log').open('w') as log:
  child = subprocess.Popen(command, cwd=directory, env=environment, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
  while child.poll() is None:
   rows = [tuple(map(int, line.split())) for line in subprocess.check_output(['ps', '-eo', 'pid,ppid,rss', '--no-headers'], text=True).splitlines()]
   owned = {child.pid}
   while True:
    expanded = owned | {pid for pid, parent, _ in rows if parent in owned}
    if expanded == owned: break
    owned = expanded
   rss = sum(rss for pid, _, rss in rows if pid in owned)
   peak = max(peak, rss)
   if rss > 2 * 1024 * 1024: raise RuntimeError('2 GiB process-tree RSS limit exceeded')
   if int(current.read_text()) > limit * 0.9: raise RuntimeError('Elevated cgroup memory')
   if time.monotonic() - started > 180: raise RuntimeError('180-second deadline exceeded')
   time.sleep(0.25)
except Exception as error:
 reason = f'{type(error).__name__}: {error}'
finally:
 if child is not None:
  if reason and child.poll() is None:
   try: os.killpg(child.pid, signal.SIGKILL)
   except ProcessLookupError: pass
  status = child.wait()
result = {'command':command,'exitCode':status,'resourceOrMonitorAborted':reason is not None,'reason':reason,'elapsedSeconds':time.monotonic()-started,'peakProcessTreeRssKiB':peak,'initialCgroupBytes':initial,'cgroupLimitBytes':limit,'pressureAvailability':'Linux cgroup polling; PSI unavailable','failClosedCleanup':True}
(directory/'watchdog-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
raise SystemExit(124 if reason else status)
