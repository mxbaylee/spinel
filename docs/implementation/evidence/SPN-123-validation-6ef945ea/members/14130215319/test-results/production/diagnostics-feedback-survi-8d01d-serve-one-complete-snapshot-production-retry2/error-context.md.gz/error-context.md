# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: diagnostics.spec.ts >> feedback survives a lost acknowledgment and paired user/system downloads preserve one complete snapshot
- Location: e2e/diagnostics.spec.ts:189:1

# Error details

```
ReferenceError: writeFile is not defined
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e4]:
    - banner [ref=e5]:
      - generic [ref=e6]:
        - link [aria-hidden] [ref=e7] [cursor=pointer]:
          - /url: /
          - generic: Your docs
        - generic [ref=e34]:
          - status "Connection status" [ref=e35]: Online
          - button [aria-hidden] [ref=e36] [cursor=pointer]
      - navigation [aria-hidden] [ref=e39]:
        - link [ref=e40] [cursor=pointer]:
          - /url: /admin
          - generic [aria-hidden] [ref=e41]: ▦
          - generic: Admin
      - generic [aria-hidden] [ref=e42]:
        - radiogroup [ref=e44]:
          - radio [checked] [ref=e45] [cursor=pointer]
          - radio [checked] [aria-hidden] [ref=e48]
          - radio [ref=e49] [cursor=pointer]
          - radio [aria-hidden] [ref=e52]
          - radio [ref=e53] [cursor=pointer]
          - radio [aria-hidden] [ref=e56]
        - link [ref=e57] [cursor=pointer]:
          - /url: /profile
          - generic: Private Operator Name
    - main [ref=e63]:
      - generic [ref=e64]:
        - generic [ref=e65]:
          - paragraph [ref=e66]: SERVER OPERATOR
          - heading [level=1] [ref=e67]: Administration
        - generic [ref=e68]:
          - navigation [ref=e69]:
            - link [ref=e70] [cursor=pointer]:
              - /url: "#people"
              - text: People
            - link [ref=e71] [cursor=pointer]:
              - /url: "#invites"
              - text: Invites
            - link [ref=e72] [cursor=pointer]:
              - /url: "#connections"
              - text: Connections
            - link [ref=e73] [cursor=pointer]:
              - /url: "#health"
              - text: Backups & health
          - region [ref=e75]:
            - generic [ref=e76]:
              - heading [level=2] [ref=e77]: People
              - button [ref=e78] [cursor=pointer]: Refresh users
            - paragraph [ref=e79]: Manage the instance. Document content stays private.
            - list [ref=e80]:
              - listitem [ref=e81]:
                - region [ref=e82]:
                  - generic [ref=e83]:
                    - generic [ref=e84]:
                      - heading [level=3] [ref=e85]: Feedback collaborator
                      - paragraph [ref=e86]: Member · Active
                      - paragraph [ref=e87]: 0 passkeys
                      - generic [ref=e88]:
                        - generic [ref=e89]: Feedback available
                        - button [ref=e92] [cursor=pointer]: ···
                    - button [ref=e93] [cursor=pointer]: ···
              - listitem [ref=e94]:
                - region [ref=e95]:
                  - generic [ref=e96]:
                    - generic [ref=e97]:
                      - heading [level=3] [ref=e98]: Private Document Owner
                      - paragraph [ref=e99]: Member · Active
                      - paragraph [ref=e100]: 0 passkeys
                      - generic [ref=e101]:
                        - generic [ref=e102]: Feedback available
                        - button [ref=e105] [cursor=pointer]: ···
                    - button [ref=e106] [cursor=pointer]: ···
              - listitem [ref=e107]:
                - region [ref=e108]:
                  - generic [ref=e109]:
                    - generic [ref=e110]:
                      - heading [level=3] [ref=e111]: Private Operator Name (you)
                      - paragraph [ref=e112]: Operator · Active
                      - paragraph [ref=e113]: 0 passkeys
                    - button [ref=e114] [cursor=pointer]: ···
                  - paragraph [ref=e115]: This is your admin account. It cannot disable itself.
  - dialog [ref=e119]:
    - generic [ref=e120]:
      - heading "Feedback diagnostics" [level=2] [ref=e121]
      - button "Close dialog" [ref=e127] [cursor=pointer]: ×
    - generic [ref=e128]:
      - paragraph [ref=e129]:
        - strong [ref=e130]: Private Document Owner
      - paragraph [ref=e131]: User metrics include all retained records attributed to this account. System metrics include everyone’s records in the same time span. Submitted feedback is included when present.
      - generic "Shared time span" [ref=e132]:
        - strong [ref=e133]: Shared time span · server receipt time
        - time [ref=e134]: 11/14/2026, 7:50:18 PM
        - generic [ref=e135]: through
        - time [ref=e136]: 11/14/2026, 7:50:20 PM
        - generic [ref=e137]: 9 user records · 10 system records
      - paragraph [ref=e138]: Available until 7:55:21 PM. Both downloads keep this snapshot even if new activity arrives.
      - group [ref=e139]:
        - generic "Collection limits" [ref=e140] [cursor=pointer]
      - status [ref=e141]: System metrics sent to your browser. Check your downloads.
      - generic [ref=e142]:
        - button "Download user metrics" [ref=e143] [cursor=pointer]
        - button "Download system metrics" [ref=e144] [cursor=pointer]
      - button "Close" [ref=e146] [cursor=pointer]
```

# Test source

```ts
  268 |       expect(stored.actor_id).toBe(f.owner.id);
  269 |       expect(stored.file_id).toBe(file.id);
  270 |       expect(stored.message).toBe(message);
  271 |       expect(stored.route).toBe('/files/:id');
  272 | 
  273 |       await page.clock.install();
  274 |       await page.goto(`${f.origin}/admin`);
  275 |       const account = page.getByRole('region', { name: `${f.owner.name} account`, exact: true });
  276 |       await expect(account.getByText('Feedback available', { exact: true })).toBeVisible();
  277 |       await expect(page.getByText(message, { exact: true })).toHaveCount(0);
  278 |       await expect(page.getByText(file.name, { exact: true })).toHaveCount(0);
  279 |       let preparations = 0;
  280 |       page.on('request', (request) => {
  281 |         if (
  282 |           request.url().endsWith('/api/admin/diagnostics/feedback/prepare') &&
  283 |           request.method() === 'POST'
  284 |         )
  285 |           preparations++;
  286 |       });
  287 |       const pairResponse = page.waitForResponse(
  288 |         (value) =>
  289 |           value.url().endsWith('/api/admin/diagnostics/feedback/prepare') &&
  290 |           value.request().method() === 'POST',
  291 |       );
  292 |       const user = await feedbackArtifact(
  293 |         page,
  294 |         join(f.directory, 'feedback-user.sqlite'),
  295 |         async () => {
  296 |           await account
  297 |             .getByRole('button', { name: `Feedback downloads for ${f.owner.name}`, exact: true })
  298 |             .click();
  299 |           await page.getByRole('menuitem', { name: 'Download user metrics', exact: true }).click();
  300 |           expect((await pairResponse).status()).toBe(200);
  301 |         },
  302 |       );
  303 |       // Development StrictMode must not send an aborted mount's preparation:
  304 |       // it can still hold the server lease when the surviving mount starts.
  305 |       expect(preparations).toBe(1);
  306 |       const pair = (await (await pairResponse).json()) as FeedbackPair;
  307 |       const downloads = page.getByRole('dialog', { name: 'Feedback diagnostics', exact: true });
  308 |       await expect(downloads.getByLabel('Shared time span', { exact: true })).toBeVisible();
  309 |       expect(user.manifest).toMatchObject({
  310 |         snapshotId: pair.id,
  311 |         generation: pair.generation,
  312 |         selectedActorId: f.owner.id,
  313 |         scope: 'user',
  314 |         window: pair.window,
  315 |         completeRetainedSelection: true,
  316 |         historicalCompleteness: 'unknown',
  317 |         rowCount: pair.counts.user,
  318 |       });
  319 |       const expectedUser = live
  320 |         .prepare(
  321 |           'SELECT * FROM events WHERE actor_id=? AND received_at BETWEEN ? AND ? ORDER BY id',
  322 |         )
  323 |         .all(f.owner.id, pair.window.start, pair.window.end);
  324 |       const expectedSystem = live
  325 |         .prepare('SELECT * FROM events WHERE received_at BETWEEN ? AND ? ORDER BY id')
  326 |         .all(pair.window.start, pair.window.end);
  327 |       expect(user.rows).toEqual(expectedUser);
  328 |       expect(user.rows.some((row) => row.id === first.id)).toBe(true);
  329 |       expect(user.rows.some((row) => row.id === last.id)).toBe(true);
  330 |       expect(user.rows.every((row) => row.actor_id === f.owner.id)).toBe(true);
  331 | 
  332 |       // New real activity between the buttons must never alter the prepared pair.
  333 |       const boundary = await (
  334 |         await f.member.request.get(`${f.origin}/api/diagnostics/feedback-context`, {
  335 |           headers: { 'X-Spinel-Diagnostic-Account': f.owner.id },
  336 |         })
  337 |       ).json();
  338 |       const laterId = randomUUID();
  339 |       const later = await f.member.request.post(`${f.origin}/api/diagnostics/feedback`, {
  340 |         headers: { ...f.headers, 'X-Spinel-Diagnostic-Account': f.owner.id },
  341 |         data: {
  342 |           id: laterId,
  343 |           generation: boundary.generation,
  344 |           binding: boundary.binding,
  345 |           message: 'This report arrives after the frozen snapshot.',
  346 |           context: { route: '/files' },
  347 |         },
  348 |       });
  349 |       expect(later.status()).toBe(200);
  350 |       const system = await feedbackArtifact(page, join(f.directory, 'feedback-system.sqlite'), () =>
  351 |         downloads.getByRole('button', { name: 'Download system metrics', exact: true }).click(),
  352 |       );
  353 |       expect(system.manifest).toMatchObject({
  354 |         snapshotId: user.manifest.snapshotId,
  355 |         generation: user.manifest.generation,
  356 |         window: user.manifest.window,
  357 |         scope: 'system',
  358 |         rowCount: pair.counts.system,
  359 |       });
  360 |       expect(system.rows).toEqual(expectedSystem);
  361 |       expect(
  362 |         system.rows.some((row) => row.id === middle.id && row.actor_id === collaborator.id),
  363 |       ).toBe(true);
  364 |       expect(system.rows.some((row) => row.id === laterId)).toBe(false);
  365 |       expect(system.manifest.counts).toEqual(user.manifest.counts);
  366 |       // Retain the exact synthetic rows/window after fixture cleanup, so review
  367 |       // can inspect completeness without exporting credentials or a live store.
> 368 |       await writeFile(
      |       ^ ReferenceError: writeFile is not defined
  369 |         info.outputPath('spn098-feedback-pair.json'),
  370 |         JSON.stringify(
  371 |           {
  372 |             project: info.project.name,
  373 |             attempt: info.retry,
  374 |             initialPreparations: preparations,
  375 |             pairedMembershipVerified: true,
  376 |             user,
  377 |             system,
  378 |             excludedLaterReportId: laterId,
  379 |           },
  380 |           null,
  381 |           2,
  382 |         ) + '\n',
  383 |       );
  384 |       const denied = await other.request.post(
  385 |         `${f.origin}/api/admin/diagnostics/feedback/${pair.id}/download`,
  386 |         { headers: f.headers, data: { scope: 'system' } },
  387 |       );
  388 |       expect(denied.status()).toBe(404);
  389 |       // Exercise the actual expiry UI without keeping a fixture alive for five minutes.
  390 |       // Store/HTTP tests separately advance the server clock and prove server expiry.
  391 |       await page.clock.fastForward(Math.max(0, pair.expiresAt - Date.now()) + 1000);
  392 |       await expect(
  393 |         downloads.getByText('This pair is no longer available.', { exact: false }),
  394 |       ).toBeVisible();
  395 |       await expect(
  396 |         downloads.getByRole('button', { name: 'Download system metrics', exact: true }),
  397 |       ).toBeDisabled();
  398 |       await expect(
  399 |         downloads.getByRole('button', { name: 'Prepare both downloads', exact: true }),
  400 |       ).toBeEnabled();
  401 |     } finally {
  402 |       live.close();
  403 |     }
  404 |   } finally {
  405 |     try {
  406 |       await other.close();
  407 |     } finally {
  408 |       await f.close();
  409 |     }
  410 |   }
  411 | });
  412 | 
  413 | test('truncation clears feedback flags and an unconfirmed old report needs deliberate new submission', async ({
  414 |   page,
  415 |   context,
  416 |   browser,
  417 | }, info) => {
  418 |   test.setTimeout(120_000);
  419 |   const f = await fixture(browser, context, info);
  420 |   const memberPage = await f.member.newPage();
  421 |   try {
  422 |     await memberPage.goto(f.origin);
  423 |     let drop = true;
  424 |     await memberPage.route('**/api/diagnostics/feedback', async (route) => {
  425 |       if (drop) {
  426 |         drop = false;
  427 |         expect((await route.fetch()).status()).toBe(200);
  428 |         await route.abort('failed');
  429 |       } else await route.continue();
  430 |     });
  431 |     const composer = await feedbackComposer(
  432 |       memberPage,
  433 |       'Retain this draft across a failed acknowledgment.',
  434 |     );
  435 |     await composer.getByRole('button', { name: 'Send feedback', exact: true }).click();
  436 |     await expect(composer.getByRole('alert')).toContainText('Sending could not be confirmed.');
  437 |     await page.goto(`${f.origin}/admin`);
  438 |     const owner = page.getByRole('region', { name: `${f.owner.name} account`, exact: true });
  439 |     await expect(owner.getByText('Feedback available', { exact: true })).toBeVisible();
  440 |     await page.getByRole('link', { name: 'Backups & health', exact: true }).click();
  441 |     const cancelled = await openClear(page);
  442 |     await expect(cancelled).toContainText('submitted feedback');
  443 |     await cancelled.getByRole('button', { name: 'Cancel', exact: true }).click();
  444 |     const before = await (
  445 |       await context.request.get(`${f.origin}/api/admin/diagnostics/feedback`)
  446 |     ).json();
  447 |     expect(before.actors).toContain(f.owner.id);
  448 |     const confirmation = await openClear(page);
  449 |     const cleared = page.waitForResponse(
  450 |       (value) =>
  451 |         value.url().endsWith('/api/admin/diagnostics/truncate') &&
  452 |         value.request().method() === 'POST',
  453 |     );
  454 |     await confirmation.getByRole('button', { name: 'Truncate diagnostics', exact: true }).click();
  455 |     expect((await cleared).status()).toBe(200);
  456 |     await page.getByRole('link', { name: 'People', exact: true }).click();
  457 |     await expect(page.getByText('Checking feedback…', { exact: true })).toHaveCount(0);
  458 |     await expect(owner.getByText('Feedback available', { exact: true })).toHaveCount(0);
  459 |     const oldRetry = memberPage.waitForResponse(
  460 |       (value) =>
  461 |         value.url().endsWith('/api/diagnostics/feedback') && value.request().method() === 'POST',
  462 |     );
  463 |     await composer.getByRole('button', { name: 'Retry feedback', exact: true }).click();
  464 |     expect((await oldRetry).status()).toBe(409);
  465 |     await expect(composer.getByRole('alert')).toContainText('will not be sent again automatically');
  466 |     expect(
  467 |       (await (await context.request.get(`${f.origin}/api/admin/diagnostics/feedback`)).json())
  468 |         .actors,
```