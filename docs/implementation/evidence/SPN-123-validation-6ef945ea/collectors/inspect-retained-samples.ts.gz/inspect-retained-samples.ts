import {readFileSync,readdirSync,statSync,createReadStream} from 'node:fs';import {join} from 'node:path';import {createGunzip,gunzipSync} from 'node:zlib';
const root='/tmp/spn123-terminal-6ef945ea/archive/members';
const files:string[]=[];function walk(p:string){for(const n of readdirSync(p)){const q=join(p,n);statSync(q).isDirectory()?walk(q):files.push(q);}}walk(root);
for(const p of files.filter(p=>/spn144-derived\.json.gz$/.test(p)).slice(0,1)){
 const r=createReadStream(p),z=r.pipe(createGunzip());let s='';for await(const b of z){s+=b.toString();if(s.length>4000){z.destroy();r.destroy();break;}}console.log(JSON.stringify({file:p,initialJSON:s.slice(0,4000)}));
}
for(const p of files.filter(p=>/spn113-evidence.json.gz$|spn113-comparison-.*json.gz$|spn134-progress.json.gz$|spn144-conversion.json.gz$/.test(p))){const v=JSON.parse(gunzipSync(readFileSync(p)).toString());const schema=Object.fromEntries(Object.entries(v).map(([k,x])=>[k,Array.isArray(x)?{type:'array',length:x.length,firstKeys:typeof x[0]==='object'&&x[0]?Object.keys(x[0]):undefined}:typeof x==='object'&&x?{type:'object',keys:Object.keys(x).slice(0,24)}:x]));console.log(JSON.stringify({file:p,schema}));}
