from pathlib import Path
import json,gzip,subprocess,hashlib,concurrent.futures,zipfile
root=Path('/tmp/spn123-publication-6ef945ea/snapshot-4-43633378605');out=root/'preserved-artifacts';out.mkdir();selected=[]
for name in ['ci']:
 for page in json.loads(gzip.decompress((root/f'artifacts-{name}.json.gz').read_bytes())):
  for a in page['artifacts']:
   if a['name']=='theme-screenshots-production-1':selected.append(a)
def fetch(a):
 p=out/f"artifact-{a['id']}.zip";r=None
 try:
  with p.open('xb') as f:r=subprocess.run(['gh','api','--method','GET',f"repos/mxbaylee/spinel/actions/artifacts/{a['id']}/zip",'--allow-escape-sequences'],stdout=f,stderr=subprocess.PIPE,timeout=90)
  digest=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();result={'id':a['id'],'name':a['name'],'file':p.name,'bytes':p.stat().st_size,'sha256':digest,'apiDigest':a.get('digest'),'expired':a['expired'],'code':r.returncode,'error':r.stderr.decode()}
  assert r.returncode==0,result;assert result['bytes']==a['size_in_bytes'];assert a.get('digest') in [None,'sha256:'+digest]
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None
   result['members']=[{'name':i.filename,'bytes':i.file_size,'compressedBytes':i.compress_size,'crc32':i.CRC} for i in z.infolist()]
  return result
 except Exception as e:return {'id':a['id'],'name':a['name'],'error':str(e),'partialFile':str(p)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:records=list(pool.map(fetch,selected))
(out/'manifest.json').write_text(json.dumps({'source':'6ef945eae3168da7f3706088dc7c2b78fad39cd5','attempt':1,'records':records},indent=2)+'\n')
for r in records:print({k:v for k,v in r.items() if k!='members'})
