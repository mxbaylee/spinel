import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';
const runFile = promisify(execFile);
const source = '6ef945eae3168da7f3706088dc7c2b78fad39cd5';
const base = 'ec42f0741415e4e712395fb47c30b911bc4e64ea';
const root = process.argv[2];
if (!root) throw Error('New output directory required');
mkdirSync(root); mkdirSync(join(root,'original-zips'));
const repo='mxbaylee/spinel';
const files: any[]=[]; const errors: any[]=[]; const workflows: any[]=[]; const plans:any[]=[];
const hash=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
function save(name:string, raw:Buffer) { const bytes=gzipSync(raw);writeFileSync(join(root,name+'.gz'),bytes,{flag:'wx'});files.push({path:name+'.gz',sha256:hash(bytes),rawSha256:hash(raw),rawBytes:raw.length}); }
async function raw(endpoint:string) {const r=await runFile('gh',['api','--method','GET',endpoint,'--allow-escape-sequences'],{encoding:'buffer',maxBuffer:64*1024*1024,timeout:45000});return r.stdout;}
async function get(endpoint:string,name:string,paginated=false) {try {const r=await runFile('gh',['api','--method','GET',endpoint,...(paginated?['--paginate','--slurp']:[])],{encoding:'buffer',maxBuffer:64*1024*1024,timeout:45000});save(name+'.json',r.stdout);return JSON.parse(r.stdout.toString());}catch(e){errors.push({name,error:String(e)});return undefined;}}
try {
 const [pr,sourceCommit,baseCommit]=await Promise.all([
 get(`repos/${repo}/pulls/220`,'pr'),get(`repos/${repo}/commits/${source}`,'source-commit'),get(`repos/${repo}/commits/${base}`,'base-commit'),
 get(`repos/${repo}/actions/runs?head_sha=${source}&per_page=100`,'all-source-runs',true),get(`repos/${repo}/commits/${source}/check-runs?per_page=100`,'source-check-runs',true)]);
 if(pr?.head.sha!==source||pr?.base.sha!==base)throw Error('Observed source/base differs');
 save('observed-pr-body.md',Buffer.from(pr.body??''));
 if(pr.merge_commit_sha)await get(`repos/${repo}/commits/${pr.merge_commit_sha}`,'observed-merge-commit');
 await Promise.all([['ci',43633378605],['storybook',43633378587],['desktop',43633378724],['spaces',43633378630]].map(async ([kind,id])=>{
  const [run,jobPages,artifactPages]=await Promise.all([get(`repos/${repo}/actions/runs/${id}`,`run-${kind}`),get(`repos/${repo}/actions/runs/${id}/attempts/1/jobs?per_page=100`,`jobs-${kind}-attempt-1`,true),get(`repos/${repo}/actions/runs/${id}/artifacts?per_page=100`,`artifacts-${kind}`,true)]);
  if(!run||!jobPages||!artifactPages)return;
  if(run.head_sha!==source||run.run_attempt!==1||run.event!=='pull_request'){errors.push({kind,error:'Source/attempt/event mismatch'});return;}
  const jobs=jobPages.flatMap((p:any)=>p.jobs);const artifacts=artifactPages.flatMap((p:any)=>p.artifacts);
  if(new Set(jobs.map((j:any)=>j.id)).size!==jobs.length)throw Error('Duplicate jobs');
  workflows.push({kind,id,attempt:1,status:run.status,conclusion:run.conclusion,head:run.head_sha,jobs:jobs.map((j:any)=>({id:j.id,name:j.name,status:j.status,conclusion:j.conclusion})),artifacts:artifacts.map((a:any)=>({id:a.id,name:a.name,digest:a.digest,size:a.size_in_bytes,expired:a.expired}))});
  // Initial bounded collection retains every completed non-skipped job log;
  // later snapshots never overwrite these original-attempt receipts.
  for(const job of jobs.filter((j:any)=>j.status==='completed'&&j.conclusion!=='skipped')) {
   if ([132564755608,132564755743,132564755827,132564756107,132565004312,132565004389].includes(job.id)) continue;
   try{save(`job-${job.id}.log`,await raw(`repos/${repo}/actions/jobs/${job.id}/logs`));}catch(e){errors.push({job:job.id,error:String(e)});}
  }
  for(const a of artifacts.filter((a:any)=>a.name==='ci-plan'||a.name.startsWith('ci-results-'))){
   try{const bytes=await raw(`repos/${repo}/actions/artifacts/${a.id}/zip`);const path=`original-zips/artifact-${a.id}.zip`;writeFileSync(join(root,path),bytes,{flag:'wx'});const digest=hash(bytes);files.push({path,sha256:digest,bytes:bytes.length});plans.push({kind,id:a.id,name:a.name,path,githubDigest:a.digest,sha256:digest,bytes:bytes.length,expired:a.expired});if(a.digest&&a.digest!=='sha256:'+digest)throw Error('Artifact digest mismatch');if(a.size_in_bytes!==bytes.length)throw Error('Artifact size mismatch');}catch(e){errors.push({artifact:a.id,error:String(e)});}
  }
 }));
} catch(e){errors.push({error:String(e)});} finally {
 writeFileSync(join(root,'collection-summary.json'),JSON.stringify({observedAt:new Date().toISOString(),source,base,pr:220,workflows,plans,errors,readOnly:true,acceptance:false,ordering:'Root observed no old-head metadata-triggered run through19:40:10 after metadata19:39:18, then normal fast-forward19:40:38. No cancellation claimed. Old conflicting PR state may explain absence, but remains inference only. Preserve actual-main CI43630998048. No rerun/cancel/dispatch/metadata/merge.'},null,2)+'\n');
 writeFileSync(join(root,'raw-manifest.json'),JSON.stringify({files},null,2)+'\n');
 console.log(JSON.stringify({root,workflows,plans,errors}));
}
