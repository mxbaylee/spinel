import { spawn } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, readdirSync, existsSync, openSync, closeSync, createReadStream, statSync } from 'node:fs';
import { join } from 'node:path';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
const publication='/tmp/spn123-publication-6ef945ea';
const snapshot=join(publication,'snapshot-6-43633378605');
const destination='/tmp/spn123-terminal-6ef945ea';
mkdirSync(destination); mkdirSync(join(destination,'raw-artifacts'));
const artifacts:any[]=[];
for(const name of ['ci','storybook','desktop','spaces'])for(const page of JSON.parse(gunzipSync(readFileSync(join(snapshot,`artifacts-${name}.json.gz`))).toString()))for(const a of page.artifacts)artifacts.push({...a,kind:name});
const known=new Map<number,string>();
for(const dir of readdirSync(publication).filter(x=>/^(initial-|snapshot-)/.test(x)))for(const leaf of ['original-zips','preserved-artifacts']){
 const folder=join(publication,dir,leaf);if(!existsSync(folder))continue;
 for(const file of readdirSync(folder)){const match=/^artifact-(\d+)\.zip$/.exec(file);if(match)known.set(Number(match[1]),join(folder,file));}
}
const results:any[]=[];let index=0;
async function checksum(path:string){const hash=createHash('sha256');for await(const chunk of createReadStream(path))hash.update(chunk);return hash.digest('hex');}
async function download(a:any){
 const existing=known.get(a.id);const path=existing??join(destination,'raw-artifacts',`artifact-${a.id}.zip`);
 const result:any={id:a.id,name:a.name,kind:a.kind,source:'6ef945eae3168da7f3706088dc7c2b78fad39cd5',path,reused:!!existing,apiDigest:a.digest,apiBytes:a.size_in_bytes,expired:a.expired};results.push(result);
 try{
  if(a.expired)throw Error('Expired artifact');
  if(!existing){
   const fd=openSync(path,'wx');try{await new Promise<void>((resolve,reject)=>{const child=spawn('gh',['api','--method','GET',`repos/mxbaylee/spinel/actions/artifacts/${a.id}/zip`,'--allow-escape-sequences'],{stdio:['ignore',fd,'pipe']});let error='';child.stderr.on('data',x=>error+=x);const timeout=setTimeout(()=>child.kill('SIGTERM'),120000);child.on('error',reject);child.on('close',code=>{clearTimeout(timeout);code===0?resolve():reject(Error(`GET exit${code}: ${error}`));});});}finally{closeSync(fd);}
  }
  result.bytes=statSync(path).size;result.sha256=await checksum(path);
  if(result.bytes!==a.size_in_bytes||a.digest&&a.digest!=='sha256:'+result.sha256)throw Error('Artifact digest/size mismatch');result.complete=true;
 }catch(error){result.error=String(error);result.complete=false;}
 console.log(JSON.stringify({id:a.id,name:a.name,bytes:result.bytes,complete:result.complete,error:result.error}));
 writeFileSync(join(destination,'artifact-downloads.json'),JSON.stringify({snapshot,observedAt:new Date().toISOString(),artifacts:results},null,2)+'\n');
}
await Promise.all([0,1].map(async()=>{while(index<artifacts.length){const a=artifacts[index++];await download(a);}}));
console.log(JSON.stringify({destination,artifacts:results.length,failures:results.filter(x=>!x.complete).length}));
