import {readFileSync,writeFileSync,mkdirSync,readdirSync,statSync,copyFileSync} from 'node:fs';
import {join,dirname,relative} from 'node:path';
import {createHash} from 'node:crypto';
import {gunzipSync,gzipSync,inflateRawSync,crc32} from 'node:zlib';
const publication='/tmp/spn123-publication-6ef945ea';
const root='/tmp/spn123-terminal-6ef945ea';
const out=join(root,'archive');mkdirSync(out,{recursive:true});
const hash=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
function put(name:string,b:Buffer){const p=join(out,name);mkdirSync(dirname(p),{recursive:true});writeFileSync(p,b);return name;}
function json(name:string,v:any){return put(name,Buffer.from(JSON.stringify(v,null,2)+'\n'));}
const artifacts=JSON.parse(readFileSync(join(root,'artifact-downloads.json'),'utf8')).artifacts;
const terminal=join(publication,'terminal-43633378605');
const finalArtifacts=['ci','storybook','desktop','spaces'].flatMap(k=>JSON.parse(gunzipSync(readFileSync(join(terminal,`artifacts-${k}.json.gz`))).toString()).flatMap((p:any)=>p.artifacts.map((a:any)=>({...a,kind:k}))));
for(const a of finalArtifacts)if(!artifacts.some((x:any)=>x.id===a.id))artifacts.push({id:a.id,name:a.name,kind:a.kind,path:join(terminal,'original-zips',`artifact-${a.id}.zip`),apiBytes:a.size_in_bytes,apiDigest:a.digest,complete:true});
const inventories:any[]=[];const observations:any[]=[];
for(const a of artifacts){
 const b=readFileSync(a.path);if(hash(b)!==a.apiDigest?.replace('sha256:','')||b.length!==a.apiBytes)throw Error('ZIP identity '+a.id);
 let e=b.length-22;while(e>=Math.max(0,b.length-65557)&&b.readUInt32LE(e)!==0x06054b50)e--;if(e<0)throw Error('EOCD');
 const count=b.readUInt16LE(e+10);let c=b.readUInt32LE(e+16);const members:any[]=[];
 const whole=a.kind==='desktop'||a.kind==='spaces'||/^ci-(plan|results-)/.test(a.name)||a.name==='sized-restore-acceptance';
 const wholePath=whole?put(`original-artifacts/artifact-${a.id}.zip`,b):null;
 for(let i=0;i<count;i++){
  if(b.readUInt32LE(c)!==0x02014b50)throw Error('central');
  const method=b.readUInt16LE(c+10),crc=b.readUInt32LE(c+16),compressed=b.readUInt32LE(c+20),size=b.readUInt32LE(c+24),n=b.readUInt16LE(c+28),extra=b.readUInt16LE(c+30),comment=b.readUInt16LE(c+32),offset=b.readUInt32LE(c+42);
  const name=b.subarray(c+46,c+46+n).toString();c+=46+n+extra+comment;
  if(name.endsWith('/'))continue;if(name.startsWith('/')||name.split('/').includes('..'))throw Error('unsafe path');
  const start=offset+30+b.readUInt16LE(offset+26)+b.readUInt16LE(offset+28);const packed=b.subarray(start,start+compressed);const content=method===8?inflateRawSync(packed):method===0?packed:(()=>{throw Error('method');})();
  if(content.length!==size||crc32(content)!==crc)throw Error('CRC '+name);
  const failure=/diagnostics-feedback-survi/.test(name);
  const numeric=/\.(?:json(?:\.gz)?|cpuprofile)$/.test(name);
  const text=/\.(?:log|txt|md)$/.test(name);
  const retain=whole||failure||numeric||text;
  let retainedPath=wholePath;
  if(retain&&!whole){const compressedAlready=/\.(?:gz|zip|png|webm|jpg)$/.test(name);retainedPath=put(`members/${a.id}/${name}${compressedAlready?'':'.gz'}`,compressedAlready?content:gzipSync(content,{level:6}));}
  members.push({name,bytes:size,compressedBytes:compressed,crc32:crc.toString(16).padStart(8,'0'),sha256:hash(content),retainedPath,retention:whole?'complete original ZIP':retain?'complete original member (gzip wrapper only where noted)':'private complete ZIP and expiring supplementary artifact; passing binary/source/visual omitted from durable copy'});
  if(name.endsWith('.json')&&(name.includes('comparison')||name.startsWith('playwright-report/')||name==='evidence.json'||/acceptance/.test(name))){const v=JSON.parse(content.toString());const o:any={artifactId:a.id,name};for(const k of ['status','passed','accepted','timingValid','candidateIntegrity','failures','stats','scope','sourceCommit','source','testedCommit','checks','cleanup'])if(k in v)o[k]=v[k];observations.push(o);}
 }
 inventories.push({id:a.id,name:a.name,kind:a.kind,source:'6ef945eae3168da7f3706088dc7c2b78fad39cd5',privateOriginalPath:a.path,bytes:b.length,sha256:hash(b),apiDigest:a.apiDigest,crcVerified:true,members});
 console.log(JSON.stringify({id:a.id,members:members.length,retained:members.filter(x=>x.retainedPath).length}));
}
json('artifact-inventory.json',inventories);json('original-outcome-observations.json',observations);
const snapshots=readdirSync(publication).filter(n=>/^(initial-|snapshot-|status-|terminal-)/.test(n)&&statSync(join(publication,n)).isDirectory());
const rawBindings:any[]=[];
function visit(folder:string,base:string){for(const n of readdirSync(folder)){const p=join(folder,n),s=statSync(p);if(s.isDirectory()){if(['original-zips','preserved-artifacts','decoded-outcomes'].includes(n))continue;visit(p,base);}else{if(n.endsWith('.zip'))continue;const b=readFileSync(p),r=relative(base,p);const dest=put('collection/'+r,b);rawBindings.push({original:p,path:dest,sha256:hash(b),bytes:b.length});}}}
for(const s of snapshots)visit(join(publication,s),publication);
for(const n of readdirSync(publication))if(/\.(ts|py|log)$/.test(n)||['source-plan-first-failure.json','initial-checkpoint-manifest.json','pr-after-metadata.json'].includes(n)){const b=readFileSync(join(publication,n));const dest=put('collectors/'+n+'.gz',gzipSync(b));rawBindings.push({original:join(publication,n),path:dest,sha256:hash(b),bytes:b.length,encoding:'gzip original bytes; archival, not maintained executable'});}
for(const p of ['/tmp/spn123-root-publication-audit-6ef945ea.json','/tmp/spn123-root-review-archive-c270973a.json']){const b=readFileSync(p);put('root-receipts/'+p.split('/').at(-1),b);}
json('collection-bindings.json',rawBindings);
const runs=['ci','storybook','desktop','spaces'].map(k=>{const r=JSON.parse(gunzipSync(readFileSync(join(terminal,`run-${k}.json.gz`))).toString());const pages=JSON.parse(gunzipSync(readFileSync(join(terminal,`jobs-${k}-attempt-1.json.gz`))).toString());return {kind:k,id:r.id,attempt:r.run_attempt,head:r.head_sha,status:r.status,conclusion:r.conclusion,htmlUrl:r.html_url,jobs:pages.flatMap((p:any)=>p.jobs).map((j:any)=>({id:j.id,name:j.name,status:j.status,conclusion:j.conclusion,startedAt:j.started_at,completedAt:j.completed_at}))};});
json('terminal-outcomes.json',{observedAt:new Date().toISOString(),runs,artifactCount:inventories.length,source:'6ef945eae3168da7f3706088dc7c2b78fad39cd5',base:'ec42f0741415e4e712395fb47c30b911bc4e64ea',testedMerge:'c2a51b55e790dce6bed6c0059f40c07288f71a4c',testedTree:'6f99fb105dbbb33cb50f6ea5ec9c0e3814dc9a49'});
console.log(JSON.stringify({out,artifacts:inventories.length,members:inventories.reduce((n,a)=>n+a.members.length,0),rawBindings:rawBindings.length}));
