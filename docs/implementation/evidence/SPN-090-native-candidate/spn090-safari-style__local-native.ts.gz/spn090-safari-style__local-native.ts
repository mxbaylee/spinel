import assert from 'node:assert/strict';
import {mkdtemp,writeFile,rm,readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const root=process.cwd();
const {chromium}=await import(pathToFileURL(root+'/node_modules/playwright/index.mjs').href);
const {createBrowserstackFixture}=await import(pathToFileURL(root+'/scripts/ci/browserstack-fixture.ts').href);
const {phoneNativeSnapshotScript,contentDifferences}=await import(pathToFileURL(root+'/scripts/ci/browserstack-acceptance.ts').href);
const {comparable}=await import(pathToFileURL(root+'/e2e/offline-fixture.ts').href);
const report:any={kind:'local-Chromium-mobile-native-Sheet-style',source:'29b465b42f5616a1c3e18007cd9561b6a008e211',providerRequests:0,sessionsAllocated:0,complete:false,cleanup:[]};
let fixture:any,browser:any,context:any,page:any,primary:any;
const directory=await mkdtemp('/tmp/spn090-sheet-local-');
try{
 const build=JSON.parse(await readFile('artifacts/browserstack-build-result.json','utf8'));assert.equal(build.source,report.source);assert.equal(build.complete,true);
 fixture=await createBrowserstackFixture(directory);
 const item=fixture.items.find((v:any)=>v.kind==='sheet'&&v.outcome==='normal');assert.ok(item);
 browser=await chromium.launch({headless:true,args:['--host-resolver-rules=MAP bs-local.com 127.0.0.1']});
 context=await browser.newContext({ignoreHTTPSErrors:true,viewport:{width:390,height:844},isMobile:true,hasTouch:true,deviceScaleFactor:1});
 page=await context.newPage();page.setDefaultTimeout(10000);page.setDefaultNavigationTimeout(15000);
 await page.goto(fixture.loginURL,{waitUntil:'domcontentloaded'});
 await page.goto(fixture.origin+'/?item='+item.id,{waitUntil:'domcontentloaded'});
 const canvas=page.locator('[aria-label="Sheet document"] canvas[aria-label="Spreadsheet grid"]');await canvas.waitFor({state:'visible'});
 const read=()=>page.evaluate(({script,id}:any)=>Function(script)(id),{script:phoneNativeSnapshotScript,id:item.unitId});
 await page.waitForFunction(id=>{let found=false;const listener=(e:any)=>{if(e.detail?.unitId===id&&e.detail?.snapshot)found=true;};addEventListener('spinel-sync-native-snapshot',listener);dispatchEvent(new CustomEvent('spinel-sync-native-snapshot-read',{detail:{unitId:id}}));removeEventListener('spinel-sync-native-snapshot',listener);return found;},item.unitId);
 const before=await read();report.initialDifferences=contentDifferences(comparable(before.snapshot),comparable(item.baseline.snapshot));
 const box=await canvas.boundingBox();assert.ok(box&&box.width>100&&box.height>100);
 await page.touchscreen.tap(box.x+80,box.y+40);await page.touchscreen.tap(box.x+80,box.y+40);
 const bar=page.locator('[data-u-comp="mobile-formula-bar"]');await bar.waitFor({state:'visible'});
 await page.keyboard.type('731');await bar.getByRole('button',{name:'OK',exact:true}).click();
 await page.waitForFunction(id=>{let value:any;const listener=(e:any)=>{if(e.detail?.unitId===id)value=e.detail?.snapshot;};addEventListener('spinel-sync-native-snapshot',listener);dispatchEvent(new CustomEvent('spinel-sync-native-snapshot-read',{detail:{unitId:id}}));removeEventListener('spinel-sync-native-snapshot',listener);return value?.sheets?.tab?.cellData?.[0]?.[0]?.v===731;},item.unitId);
 const after=await read(),beforeComparable=comparable(before.snapshot),afterComparable=comparable(after.snapshot);
 report.beforeA1=beforeComparable.sheets.tab.cellData?.[0]?.[0]??null;report.afterA1=afterComparable.sheets.tab.cellData[0][0];
 const expected=structuredClone(before.snapshot);expected.sheets.tab.cellData[0]??={};expected.sheets.tab.cellData[0][0]={v:731,t:2};
 report.differences=contentDifferences(afterComparable,comparable(expected));report.complete=true;
}catch(error){primary=error;report.failure={name:error?.name,message:String(error?.message??error).replace(/https?:\/\/[^\s)]+/g,'[url]').slice(0,500)};if(page)try{await page.screenshot({path:'/tmp/spn090-safari-style/local-native-failure.png'});}catch{report.screenshotFailure=true;}}
finally{for(const [name,fn]of [['context',()=>context?.close()],['browser',()=>browser?.close()],['fixture',()=>fixture?.close()],['directory',()=>rm(directory,{recursive:true,force:true})]] as const){try{await fn();report.cleanup.push({name,status:'passed'});}catch(error){report.cleanup.push({name,status:'failed'});primary??=error;report.complete=false;}}await writeFile('/tmp/spn090-safari-style/local-native-result.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});}
console.log(JSON.stringify(report));if(primary)process.exitCode=1;
