# 🍎 Completed Safari style read — pre-execution review A

**Hold the one GET pending the concrete parser/source-binding repairs below.** The question remains useful; no provider request, source edit or test execution was performed by this reviewer. Inspected reader SHA-256 `8f02c8a78a6a26dba7bd782fe627da9425ce2530c1f8cdbff2ec5f7f8d49cc19`, parser `9e4a4351e96ac93f0db12b6e7a5768e155319ce1a7560bb8e5e7fab4d2052c81`, tests `777fce9c82114bf62cb2e687984abf5803f1aa46b060e223994971781a0d7379`. Three retained controls passed (266 ms / 90,608 KiB); I did not duplicate them.

## ⛔ Concrete findings

**P2: mixed complete/incomplete evidence can falsely become available.** After one qualifying checkpoint, a second fully target-bound response can fail `interpret` or `style`. The catch sets `bound-response-interpretation-unavailable`, but the final `found.size === 1` branch deletes that reason and marks the result available. Similarly, a recognized truncated response increments malformedResponses but does not stop a favorable result from another line. Existing tests check these cases alone, not alongside a favorable record. This contradicts the declared incomplete/ambiguous evidence boundary.

Use a sticky unavailable condition that cannot be overwritten by a favorable result. At minimum, a failure after the account/item/bundle/outbox binding must prevent availability; given the stated strict truncation policy, conservatively do the same for recognized malformed/truncated response records whose target cannot be excluded. Add valid-plus-failed-bound and valid-plus-truncated controls, preserving the legitimate identical-complete-checkpoint deduplication. Do not count an invalid earlier non-checkpoint observation as a distinct complete edit, but keep its coverage explicit.

**P2 provenance precondition:** actual imported helper bytes are not bound to the reviewed commit. `git rev-parse HEAD` alone permits a dirty working tree; the reader imports current `browserstack-acceptance.ts` and `offline-fixture.ts` before checking HEAD. Other source work is proceeding in this checkout. Before GET, verify the relevant actual helper/dependency source closure against exact29 Git blobs (or a narrow documented source-binding check sufficient for those interpreters), record it and reject mismatch. No full build or clean-install repeat is needed. Preserve setup failure before any network operation.

## ✅ Appropriate existing boundaries

The fixed completed session/run/source, one create-once result, explicit 10-second/2 MiB GET, redirect refusal, strict UTF-8, exact response-prefix/task parsing and account/item/canonical-bundle/outbox unit binding are substantially narrower than a raw log search. The byte/hash receipt permits binding the newly observed log; it does not invent a preknown whole-log digest. Raw log and credential bytes remain in memory only.

The target is the synthetic numeric A1 value731/type2 and a bounded style object. Known native style keys and strict numeric/string limits reduce exposure; unknown fields fail, arbitrary strings are redacted. No arbitrary whole response, request arguments, auth token or unrelated cells are retained. The exact bundle hash binds the known fixture identity rather than a nearest-request association. An absent or unparseable response must stay unavailable, not justify a new device or second GET.

Explicit elapsed checks follow headers, each read and analysis; the timer aborts the network, cancellation is bounded to one second, and cleanup/final receipt failures remain separate from a prior primary failure. Execute only through the existing finite serial/watchdog wrapper so synchronous setup/analysis and file finalization also have an external resource/time bound. Do not put credentials into argv or echoed shell commands.

## 🚦 Outcome scope

After repairs and readback, this can support one read-only retained-evidence observation, not a paid retry. A recovered style object can guide a lower-layer semantic test; it does not establish that the original assertion was wrong or authorize deleting `.s` from comparisons. Missing/truncated/ambiguous data closes the read as unavailable. The failed physical allowance remains consumed, its exact-content failure remains blocking, and SPN-090 remains incomplete.

## 🔁 First repair readback

Read back reader `6064c95eab7ce3f306f7df85eadde96d430c21721626bda95e4e23e8682be37b`, parser `9a615d3cb1bee77065c5c310e57614f95515972a6d42dec8f043e04af6b7ab1b`, tests `a13929b9a82193c38a1c4dc49d39576acd4b3ee421e1cd2d677e3a3bd2cdde0e`. Four controls passed in the retained receipt (270 ms / 90,528 KiB). No replay by reviewer.

The sticky condition now closes recognized malformed/truncated responses and thrown fully bound interpretation/style failures, including the two new mixed controls. The reader also checks actual acceptance/fixture/recovery helper bytes against exact29 before GET and records those bindings. These repair the reported concrete examples; setup/import failure still occurs before any request and must retain its external log.

One same-class case remains before execution: a fully bound response that successfully interprets A1 as value731/type2 but has absent/non-object `.s` is silently skipped by the combined cell condition. A different valid styled checkpoint can still produce available, hiding that conflicting target-value checkpoint. Make that target schema mismatch sticky unavailable (or inventory its identity before filtering style), and add a mixed styled+unstyled731 negative. Earlier non731 observations may remain excluded from the target authored-value question. Until this last ambiguity path is closed, GET remains held.

## ✅ Final repair admission

Final static readback: parser SHA-256 `8fdf58cf38ff025d97d94c89a5838a45b456d57e87d9d9576c5acd8d28fbc233`; unchanged repaired reader `6064c95eab7ce3f306f7df85eadde96d430c21721626bda95e4e23e8682be37b`; tests `8191c45bafe3cd76063505a2d67701265df4d6f3cd8a5a11c8a8ed6fd417f114`. Bound value731 with wrong type or absent/non-object style now sets the sticky unavailable flag. The mixed good/unstyled731 negative is present; all five retained controls pass (280 ms / 90,080 KiB), with no reviewer rerun.

Both reported ambiguity paths and the helper-byte provenance precondition are resolved. **Admit the one fixed completed-session GET on these bytes once the shared serial/watchdog slot is free**, under the previously stated 10-second/2 MiB request, one-second reader cancellation, finite outer guard, create-once receipt and no raw/credential retention. No GET has been performed by this reviewer. Preserve all first failures and unavailable results; this admission does not renew the phone allowance, permit another GET, waive the authored-content failure or approve merge.

## 📭 Completed single-read disposition

The one admitted read has now completed on the reviewed parser/reader hashes: HTTP200, **1,303,109 bytes**, SHA-256 `844d345647884ae5e1021e8fb41438a9bab8f1a3fae6bf09155614cb417bf799`, approximately1,064.6ms, one request and zero allocated sessions. Actual helper bindings match the recorded source guard. The parser found **zero recognized response-prefix records** among7,713 lines; result is **unavailable / no-complete-bound-response**. This is a parser/evidence availability limit, not proof that the provider never logged a response or that the style object was absent. Raw bytes were not retained and no style value was recovered. The allowance is closed; no reread, broadened parser replay against refetched bytes, or device run follows from this disposition. The original exact-content failure remains unresolved.
