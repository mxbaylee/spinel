import { createHash } from 'node:crypto';
export const identity={account:'cda2660a-cbbc-4f88-bb4a-d9a30fd18474',item:'a1984e83-9f7a-49b0-b50c-2befe135a4ad',bundle:'15b8a87a1947807706a7742d74e9b3bc22d385e90c9902ee1a0affcd73c26a2a'};
const hash=(v:string)=>createHash('sha256').update(v).digest('hex');
const object=(v:any)=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const canonical=(v:any):any=>Array.isArray(v)?v.map(canonical):object(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v;
function bounded(v:any){let nodes=0;const walk=(x:any,d:number)=>{if(++nodes>20000||d>40)throw Error('structure-limit');if(x&&typeof x==='object')for(const y of Object.values(x))walk(y,d+1);};walk(v,0);}
// Values are limited to native style enums, known fonts, colors and number patterns.
export function style(v:any):any {
 let nodes=0;
 const visit=(x:any,depth:number):any=>{
  if(++nodes>96||depth>5)throw Error('style-limit');
  if(x===null||typeof x==='boolean')return x;
  if(typeof x==='number'&&Number.isFinite(x)&&Math.abs(x)<=100000)return x;
  if(typeof x==='string')return /^(?:#[0-9a-fA-F]{3,8}|Arial|Calibri|Helvetica|Times New Roman|General|0|0\.00|0%)$/.test(x)?x:{stringValue:'omitted',length:x.length};
  if(!object(x))throw Error('style-shape');
  const allowed=new Set(['ff','fs','bl','it','ul','st','ol','cl','bg','bd','ht','vt','tb','tr','td','pd','n','rgb','theme','tint','s','color','t','b','l','r','tl_br','bl_tr','a','v','pattern','angle','vertical']);
  const answer:any={};for(const [key,value] of Object.entries(x)){if(!allowed.has(key))throw Error('style-key-unavailable');answer[key]=visit(value,depth+1);}return answer;
 };return visit(v,0);
}
export function analyze(text:string, interpret:(copy:any)=>any, expected=identity){
 const report:any={lines:0,responseLines:0,malformedResponses:0,targetResponses:0,qualifyingResponses:0,uniqueCheckpoints:0,status:'unavailable',reason:'no-complete-bound-response'};
 const found=new Map<string,any>();let incomplete=false;
 for(const raw of text.split(/\r\n|\n|\r/)){
  report.lines++;
  const line=raw.replace(/^\d{4}-\d{1,2}-\d{1,2}[ T]\d{2}:\d{2}:\d{2}(?:[.:]\d{1,6})?(?:Z)?\s+-?\s*/,'');
  const match=/^(?:\[debug\]\s*)?\[(?:XCUITestDriver|BaseDriver|AppiumDriver)(?:@[a-f0-9]+)?\]\s*Responding to client with driver\.(?:execute|executeAsync)\(\) result: (.*)$/.exec(line);
  if(!match)continue;
  report.responseLines++;
  let response:any;try{response=JSON.parse(match[1]);bounded(response);}catch{report.malformedResponses++;incomplete=true;continue;}
  // Only the actual completed read-only task result, never a script/request argument.
  const task=object(response)&&response.phase===undefined&&Object.keys(response).length===1?response.value:response;
  if(task?.phase!=='fulfilled'||!object(task.value))continue;
  const copy=task.value, bundle=copy.record?.bundle,outbox=copy.record?.outbox;
  if(copy.account!==expected.account||bundle?.itemId!==expected.item)continue;
  report.targetResponses++;
  if(bundle.accountId!==expected.account||bundle.kind!=='sheet'||bundle.readOnly!==false||hash(JSON.stringify(canonical(bundle)))!==expected.bundle||outbox?.account!==expected.account||outbox.item!==expected.item||outbox.unitId!==bundle.unitId||outbox.checkpoint?.unitId!==bundle.unitId)continue;
  try {
   const snapshot=interpret(copy),cell=snapshot?.sheets?.tab?.cellData?.[0]?.[0];
   if(cell?.v!==731)continue;
   if(cell.t!==2||!object(cell.s)){incomplete=true;continue;}
   const checkpointSha256=hash(JSON.stringify(canonical(outbox.checkpoint)));
   found.set(checkpointSha256,{checkpointSha256,unitId:bundle.unitId,cell:{v:731,t:2,s:style(cell.s)},responseLine:report.lines});
   report.qualifyingResponses++;
  }catch{incomplete=true;report.reason='bound-response-interpretation-unavailable';}
 }
 report.uniqueCheckpoints=found.size;
 if(found.size===1&&!incomplete){report.status='available';delete report.reason;report.result=[...found.values()][0];}
 else if(found.size>1)report.reason='ambiguous-checkpoints';
 else if(incomplete)report.reason='incomplete-response-coverage';
 return report;
}
