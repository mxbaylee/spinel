import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import {analyze} from './parser.ts';
import {pathToFileURL} from 'node:url';
const {verifyRetainedEdit}=await import(pathToFileURL(process.cwd()+'/scripts/ci/browserstack-acceptance.ts').href);
const {comparable}=await import(pathToFileURL(process.cwd()+'/e2e/offline-fixture.ts').href);
const output='/tmp/spn090-safari-style/result.json';
const sha=(value:Buffer|string)=>createHash('sha256').update(value).digest('hex');
const report:any={operation:'one-completed-Safari-Appium-log-GET',providerSessionsAllocated:0,
 session:'8cbaa0c791c99215220d2651e9925315fe38e0a5', historicalRun:'42105769919',
 maximumBytes:2*1024*1024,deadlineMilliseconds:10000,
 source:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),
 parserSha256:sha(await readFile('/tmp/spn090-safari-style/parser.ts')),
 readerSha256:sha(await readFile('/tmp/spn090-safari-style/read.ts')),
 status:'prepared',bytes:0,requests:0,rawResponseRetained:false,authenticationRetained:false};
assert.equal(report.source,'29b465b42f5616a1c3e18007cd9561b6a008e211');
report.sourceBindings=[];
for(const path of ['scripts/ci/browserstack-acceptance.ts','e2e/offline-fixture.ts','web/offline/recovery.ts']){const actual=await readFile(path);const committed=execFileSync('git',['show',report.source+':'+path]);assert.equal(sha(actual),sha(committed));report.sourceBindings.push({path,sha256:sha(actual)});}
await writeFile(output,JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600});
const started=performance.now(), controller=new AbortController();
const timer=setTimeout(()=>controller.abort(),10000);
let reader:ReadableStreamDefaultReader<Uint8Array>|undefined;
const check=()=>{if(performance.now()-started>=10000)throw new Error('request-deadline');};
try {
 check();
 const username=process.env.SPINEL_BS_USERNAME,key=process.env.SPINEL_BS_ACCESS_KEY;
 if(!username||!key)throw new Error('missing-credentials');
 report.requests=1;
 await writeFile(output,JSON.stringify(report,null,2)+'\n',{mode:0o600});
 const url=`https://api.browserstack.com/automate/sessions/${report.session}/appiumlogs`;
 const response=await fetch(url,{method:'GET',redirect:'error',signal:controller.signal,
 headers:{Authorization:'Basic '+Buffer.from(username+':'+key).toString('base64'),Accept:'text/plain'}});
 check();report.httpStatus=response.status;
 if(response.status!==200||response.url!==url)throw new Error('response-refused');
 const declared=response.headers.get('content-length');
 if(declared&&Number(declared)>2*1024*1024)throw new Error('response-too-large');
 reader=response.body?.getReader();if(!reader)throw new Error('response-empty');
 const chunks:Uint8Array[]=[];
 for(;;){const chunk=await reader.read();check();if(chunk.done)break;report.bytes+=chunk.value.byteLength;
 if(report.bytes>2*1024*1024)throw new Error('response-too-large');chunks.push(chunk.value);}
 const bytes=Buffer.concat(chunks);report.sha256=sha(bytes);
 const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
 report.analysis=analyze(text,copy=>comparable(verifyRetainedEdit(copy,{account:copy.account,item:copy.record.bundle.itemId,unitId:copy.record.bundle.unitId,kind:'sheet'})));check();report.status=report.analysis.status;
} catch(error) {
 report.status='failed';
 const message=error instanceof Error?error.message:'';
 report.failure=['request-deadline','missing-credentials','response-refused','response-too-large','response-empty','retained-log-identity-changed'].includes(message)?message:'request-or-analysis-failed';
 process.exitCode=1;
} finally {
 clearTimeout(timer);controller.abort();
 if(reader){
  let cleanupTimer:ReturnType<typeof setTimeout>|undefined;
  try { await Promise.race([reader.cancel(),new Promise((_,reject)=>{cleanupTimer=setTimeout(()=>reject(new Error('cleanup-timeout')),1000);})]); }
  catch { report.cleanupFailure='reader-cancel-unavailable';if(report.status!=='failed'){report.status='failed';report.failure='reader-cancel-unavailable';process.exitCode=1;} }
  finally {clearTimeout(cleanupTimer);}
 }
 report.elapsedMs=performance.now()-started;
 try {await writeFile(output,JSON.stringify(report,null,2)+'\n',{mode:0o600});} catch {report.finalizationFailure='receipt-write-failed';if(report.status!=='failed'){report.status='failed';report.failure='receipt-write-failed';process.exitCode=1;}}
}
console.log(JSON.stringify({status:report.status,requests:report.requests,bytes:report.bytes,sha256:report.sha256,
 analysisStatus:report.analysis?.status,responseLines:report.analysis?.responseLines,failure:report.failure,cleanupFailure:report.cleanupFailure,finalizationFailure:report.finalizationFailure,providerSessionsAllocated:0}));
