import assert from 'node:assert/strict';
import {test} from 'node:test';
import {createHash} from 'node:crypto';
import {analyze,style} from './parser.ts';
const bundle={accountId:'account',itemId:'item',kind:'sheet',readOnly:false,unitId:'unit'};
const expected={account:'account',item:'item',bundle:createHash('sha256').update(JSON.stringify(bundle)).digest('hex')};
const value={account:'account',record:{bundle,outbox:{account:'account',item:'item',unitId:'unit',checkpoint:{unitId:'unit'}}}};
const line=(v:any)=>'[XCUITestDriver@123abc] Responding to client with driver.execute() result: '+JSON.stringify({phase:'fulfilled',value:v});
const snapshot=()=>({sheets:{tab:{cellData:{0:{0:{v:731,t:2,s:{n:{pattern:'0'}}}}}}}});
test('actual fulfilled response binds bundle and checkpoint, retaining only synthetic A1',()=>{const r=analyze(line(value),snapshot,expected);assert.equal(r.status,'available');assert.deepEqual(r.result.cell,{v:731,t:2,s:{n:{pattern:'0'}}});assert.equal(analyze(line(value)+'\n'+line(value),snapshot,expected).uniqueCheckpoints,1);});
test('requests, truncation, wrong bindings and ambiguous checkpoints cannot succeed',()=>{
 for(const input of ['[HTTP] '+JSON.stringify({args:[value]}),line(value).slice(0,-12),line({...value,account:'other'}),line({...value,record:{...value.record,bundle:{...bundle,readOnly:true}}})])assert.equal(analyze(input,snapshot,expected).status,'unavailable');
 const second=structuredClone(value) as any;second.record.outbox.checkpoint.revision=1;assert.equal(analyze(line(value)+'\n'+line(second),snapshot,expected).reason,'ambiguous-checkpoints');
 assert.equal(analyze(line(value),()=>{throw Error('private');},expected).status,'unavailable');
});
test('style strings are allowlisted and unknown fields cannot be exported',()=>{assert.deepEqual(style({ff:'private-secret'}),{ff:{stringValue:'omitted',length:14}});assert.throws(()=>style({secret:'private'}));assert.throws(()=>style({fs:Infinity}));});

test("a good response cannot hide failed or truncated response coverage",()=>{assert.equal(analyze(line(value)+"\n"+line(value).slice(0,-3),snapshot,expected).status,"unavailable");let count=0;assert.equal(analyze(line(value)+"\n"+line(value),()=>{if(++count===2)throw Error("private");return snapshot();},expected).status,"unavailable");});

test("conflicting authored731 schema remains unavailable",()=>{let count=0;assert.equal(analyze(line(value)+"\n"+line(value),()=>{const result=snapshot();if(++count===2)delete (result.sheets.tab.cellData[0][0] as any).s;return result;},expected).status,"unavailable");});
