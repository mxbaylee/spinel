# 🤖 Chrome reattachment: preserve the existing app-data directory

Prospective November5. Existing historicalChrome run41969903466 failed retained
cookie/account/IDB/cache checks after native termination/relaunch. The bounded
local Appium-log read matches exact original bytes and shows existingCHROMIUM
reinitialization/new downstream ChromeDriver session after native termination;
coverage128retained/71omitted/1malformed remains partial and nearest requests are
uncorrelated. It did not extract keep-data. No actual clear-data action or causal
proof of the old failure is claimed.

## 🔎 Supported mechanism

Official Chromium152.0.7977.54 source matches the retained ChromeDriver version.
`androidKeepAppDataDir` defaultsfalse, is parsed asBoolean, and suppresses
`ClearAppData` on the normal non-running-app setup route when true. It still lets
Chrome launch after termination; it does not guarantee same-profile selection or
suppress other provider resets. No running-app/noReset/fullReset/prefs/profile
option is added. Exact source identities are in keep-data-source-review-a.md.

BrowserStack supports ChromeOptions through `goog:chromeOptions` in non-SDK W3C
sessions: https://www.browserstack.com/docs/automate/selenium/chrome-options .
Its documented cleanup removes user data/settings aftereachtest:
https://www.browserstack.com/support/faq/mobile/test-session-mobile/how-do-you-ensure-clean-devices .
These are provider contracts, not proof of this reservation's actualreset.
Installed Appium/wrapper version remainsunknown; direct downstream evidence is
required for the proposed forwarding claim.

## 🛠️ Narrow candidate and initial isolation

Only `chrome-acceptance` on Chrome adds
`goog:chromeOptions: {androidKeepAppDataDir:true}` to the existing single
alwaysMatch object. Do not change Safari, Firefox, tab scopes ordiagnostics.
No configurable merge/override path is needed: construction must haveone root,
one Boolean and no competing appium/legacy options. Deterministic controls
inspect the actual allocation payload via the existing fakeclientfixture and
reject cross-lane leakage; no device allocation by those controls.

After existing anonymous secure-context readiness and BEFORE login/download,
read once: account-marker presence, any Spinel offline database names counted
withoutretainingnames, the existing boundary-cookie presence, and known download
cache presence. Require no prior account/offline DB/boundary; the app may have
already installed its own shell, so distinguish its current shell from an old
account/download rather than demand zero caches. Never clear or reseed browser
storage afterfirstdownload. Keep unique random fixtureaccount/content IDs, the
providerfresh-session/reset contract and actual same-profile storagewitnesses.
A missing or invalid precondition stops the run; it cannotrepairitself.

## 🧪 Future one-attempt evidence

After exactsource review/localchecks and currentordinarygates, a separately
recorded singlechanged-source Chrome attempt may retain thefulloriginalinstalled
journey. Capture the exact requestoption and bounded returnedoption ifpresent;
absence of returnedoption is not forwarding proof. Completed-session Appium
logs, fetched locally once under explicit bounds, must retain the actual
reinitialization/newsession option and version with strict static redaction.
If forwarding cannotbeobserved, report unknown; no matrix/automaticretry.
Preserve initialfailure, nativeHomeScreenlanding, cookies/account/IDB/cache,
Doc/Sheet/images, actualedits, secondrestart, reconnect/serverstate andallcleanup.
No replacementnavigation, syntheticinput, timeoutincrease or deletedassertion.

Outcomecategories: rejectedcapability, initialisolationfailed, forwardingunknown,
retentionfailed, wronglandingcontext, laterauthoredfailure, orcompleteacceptance.
A pass supports changedharnessconfiguration only, not retrospectiveproof ofthe
oldclear-data cause. No request is dispatched by this plan. Safari's separately
running29b attempt42105769919 remainsindependent, andFirefox's ownerdisposition
isunchanged. Operator gets isolated reproducibleevidence;Owner/Collaborator keep
realpersistedcontent;Linkguest remains excluded. XLscope090+146thenstop.
