import { defineConfig } from '@playwright/test';
import config from '../playwright.config.ts';
export default defineConfig({
  ...config,
  testDir: '../e2e',
  outputDir: './spn098-browser',
  reporter: [['line'], ['json', { outputFile: 'playwright-report/spn098-production.json' }]],
  projects: config.projects?.filter((project) => project.name === 'production'),
  // Every selected diagnostics case starts its own real private application.
  webServer: [],
});
