import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  docImagePaste,
  ImagePasteError,
  imageResponseFailure,
  isStoredImageUrl,
  normalizePastedImages,
  hasPastedImages,
} from '../../web/docImagePaste.ts';
import type { ImageSourceType } from '@univerjs/core';

const image = { source: '/api/items/doc/images/hash', imageSourceType: 'URL' as ImageSourceType };
const file = new File(['image'], 'image.png', { type: 'image/png' });
function fixture() {
  const lifetime = new AbortController();
  let selection = 'caret:1';
  let available = true;
  const busy = vi.fn();
  const error = vi.fn();
  const cancelNative = vi.fn();
  const upload = vi.fn(async (_file: File, _signal: AbortSignal) => image);
  const paste = docImagePaste({
    unitId: 'doc',
    selection: () => selection,
    available: () => available,
    upload,
    busy,
    error,
    cancelNative,
    signal: lifetime.signal,
  });
  return {
    paste,
    lifetime,
    busy,
    error,
    cancelNative,
    upload,
    move: (next = 'caret:2') => {
      selection = next;
    },
    revoke: () => {
      available = false;
    },
  };
}
afterEach(() => vi.useRealTimers());
describe('image paste owns the full native operation', () => {
  it('contains malformed image preparation before admission and permits a later valid paste', async () => {
    const f = fixture();
    expect(
      await f.paste.runImage(async () => {
        throw new Error('raw malformed data URL');
      }),
    ).toBe(false);
    expect(f.error.mock.calls).toEqual([['invalid']]);
    expect(f.busy).not.toHaveBeenCalled();
    expect(f.upload).not.toHaveBeenCalled();
    expect(
      await f.paste.runImage(async () => {
        await f.paste.image(file);
        f.paste.beforePaste('doc');
        return true;
      }),
    ).toBe(true);
    expect(f.busy.mock.calls).toEqual([[true], [false]]);
    expect(f.upload).toHaveBeenCalledOnce();
  });
  it('keeps native denied image returns and retired preparation silent', async () => {
    const f = fixture();
    expect(await f.paste.runImage(async () => false)).toBe(false);
    expect(f.error).not.toHaveBeenCalled();
    let reject!: (error: Error) => void;
    const pending = new Promise<boolean>((_, no) => {
      reject = no;
    });
    const result = f.paste.runImage(() => pending);
    f.lifetime.abort();
    expect(await result).toBe(false);
    reject(new Error('late raw preparation failure'));
    await Promise.resolve();
    expect(f.error).not.toHaveBeenCalled();
    expect(f.busy).not.toHaveBeenCalled();
  });
  it('admits a cached image only across its exact one-use native history transition', async () => {
    const f = fixture();
    const history = {};
    const state = {};
    expect(
      await f.paste.run(
        async () => {
          f.paste.beforeHistoryUndo(history, state);
          f.move();
          f.paste.afterHistoryUndo(history, state);
          expect(f.paste.beforePaste('doc', true)).toBe(true);
          expect(() => f.paste.beforePaste('doc', true)).toThrow(ImagePasteError);
          return true;
        },
        { history, state },
      ),
    ).toBe(true);
    expect(f.upload).not.toHaveBeenCalled();
    expect(f.busy.mock.calls).toEqual([[true], [false]]);
  });
  it.each([
    'history',
    'state',
    'external undo',
    'reentrant undo',
    'later selection',
    'access',
  ] as const)('rejects cached image replay after %s without allowing mutation', async (change) => {
    const f = fixture();
    const history = {};
    const state = {};
    let mutated = false;
    expect(
      await f.paste.run(
        async () => {
          f.paste.beforeHistoryUndo(
            change === 'history' ? {} : history,
            change === 'state' ? {} : state,
          );
          f.move();
          if (change === 'reentrant undo') f.paste.beforeHistoryUndo(history, state);
          f.paste.afterHistoryUndo(history, change === 'external undo' ? null : state);
          if (change === 'later selection') f.move('caret:3');
          if (change === 'access') f.revoke();
          f.paste.beforePaste('doc', true);
          mutated = true;
          return true;
        },
        { history, state },
      ),
    ).toBe(false);
    expect(mutated).toBe(false);
    expect(f.error).toHaveBeenCalledWith(change === 'access' ? 'access' : 'changed');
  });
  it('does not apply image replay guards to ordinary text or HTML', async () => {
    const f = fixture();
    expect(
      await f.paste.run(
        async () => {
          f.paste.beforeHistoryUndo({}, null);
          f.move();
          f.paste.afterHistoryUndo({}, null);
          expect(f.paste.beforePaste('doc', false)).toBe(false);
          return true;
        },
        { history: {}, state: {} },
      ),
    ).toBe(true);
    expect(f.error).not.toHaveBeenCalled();
    expect(f.busy).not.toHaveBeenCalled();
  });
  it('does not admit a late cached image after disposal or restart busy state', async () => {
    const f = fixture();
    let finish!: (value: boolean) => void;
    const pending = new Promise<boolean>((resolve) => {
      finish = resolve;
    });
    const result = f.paste.run(() => pending, { history: {}, state: {} });
    f.lifetime.abort();
    expect(await result).toBe(false);
    expect(() => f.paste.beforePaste('doc', true)).toThrow(ImagePasteError);
    expect(f.busy).not.toHaveBeenCalled();
    finish(false);
  });
  it('identifies native cached images without treating ordinary URL-looking text as an image', () => {
    expect(
      hasPastedImages({
        body: { dataStream: 'https://spinel.test/image' },
        customData: { source: 'image' },
      }),
    ).toBe(false);
    expect(hasPastedImages({ drawings: { one: { source: '/api/items/doc/images/hash' } } })).toBe(
      true,
    );
  });
  it('leaves nonimage menu results, permission warnings and errors to the native handler', async () => {
    vi.useFakeTimers();
    const f = fixture();
    f.revoke();
    const denied = vi.fn(async () => false);
    expect(await f.paste.run(denied)).toBe(false);
    expect(denied).toHaveBeenCalledOnce();
    expect(f.error).not.toHaveBeenCalled();
    expect(f.busy).not.toHaveBeenCalled();
    let finish!: (value: boolean) => void;
    const native = new Promise<boolean>((resolve) => {
      finish = resolve;
    });
    const result = f.paste.run(() => native);
    f.move();
    await vi.advanceTimersByTimeAsync(31_000);
    expect(f.cancelNative).not.toHaveBeenCalled();
    finish(true);
    expect(await result).toBe(true);
    await expect(
      f.paste.run(async () => {
        throw new Error('native text failure');
      }),
    ).rejects.toThrow('native text failure');
    expect(f.error).not.toHaveBeenCalled();
  });
  it('stays busy after upload until sizing and insertion finish', async () => {
    const f = fixture();
    let finish!: (value: boolean) => void;
    const native = new Promise<boolean>((resolve) => {
      finish = resolve;
    });
    const result = f.paste.run(async () => {
      await f.paste.image(file);
      return native;
    });
    await vi.waitFor(() => expect(f.upload).toHaveBeenCalledOnce());
    expect(f.busy.mock.calls).toEqual([[true]]);
    f.paste.beforePaste('doc');
    finish(true);
    expect(await result).toBe(true);
    expect(f.busy.mock.calls).toEqual([[true], [false]]);
    expect(f.error).not.toHaveBeenCalled();
  });
  it.each(['selection', 'access', 'unit'] as const)(
    'refuses changed %s before the mutation',
    async (change) => {
      const f = fixture();
      let mutated = false;
      const result = await f.paste.run(async () => {
        await f.paste.image(file);
        if (change === 'selection') f.move();
        if (change === 'access') f.revoke();
        f.paste.beforePaste(change === 'unit' ? 'other' : 'doc');
        mutated = true;
        return true;
      });
      expect(result).toBe(false);
      expect(mutated).toBe(false);
      expect(f.cancelNative).toHaveBeenCalledOnce();
      expect(f.busy.mock.calls).toEqual([[true], [false]]);
      expect(f.error).toHaveBeenCalledWith(change === 'access' ? 'access' : 'changed');
    },
  );
  it('preserves a denied upload reason when the native command catches rejection', async () => {
    const f = fixture();
    f.upload.mockRejectedValue(new ImagePasteError('session'));
    expect(
      await f.paste.run(async () => {
        try {
          await f.paste.image(file);
          return true;
        } catch {
          return false;
        }
      }),
    ).toBe(false);
    expect(f.error).toHaveBeenCalledWith('session');
  });
  it('retiring an editor cancels a pending upload without publishing into its successor', async () => {
    const f = fixture();
    f.upload.mockImplementation(
      async (_file, signal) =>
        new Promise((_, reject) =>
          signal.addEventListener('abort', () => reject(new Error('raw network secret')), {
            once: true,
          }),
        ),
    );
    const result = f.paste.run(async () => {
      await f.paste.image(file);
      return true;
    });
    f.lifetime.abort();
    expect(await result).toBe(false);
    expect(f.error).not.toHaveBeenCalled();
    expect(f.cancelNative).toHaveBeenCalled();
    expect(f.busy.mock.calls).toEqual([[true], [false]]);
  });
  it('cancels hung native sizing and releases busy state once', async () => {
    vi.useFakeTimers();
    const f = fixture();
    const result = f.paste.run(async () => {
      await f.paste.image(file);
      return new Promise<boolean>(() => {});
    });
    await vi.advanceTimersByTimeAsync(30_000);
    expect(await result).toBe(false);
    expect(f.error).toHaveBeenCalledWith('insert');
    expect(f.busy.mock.calls).toEqual([[true], [false]]);
    expect(f.cancelNative).toHaveBeenCalled();
  });
  it.each(['timeout', 'disposal'] as const)(
    'fences late native completion after %s without rebinding to a new paste',
    async (reason) => {
      vi.useFakeTimers();
      const f = fixture();
      let finish!: (value: boolean) => void;
      const pending = new Promise<boolean>((resolve) => {
        finish = resolve;
      });
      const result = f.paste.run(async () => {
        await f.paste.image(file);
        return pending;
      });
      await vi.advanceTimersByTimeAsync(0);
      if (reason === 'timeout') await vi.advanceTimersByTimeAsync(30_000);
      else f.lifetime.abort();
      expect(await result).toBe(false);
      const next = vi.fn(async () => true);
      expect(await f.paste.run(next)).toBe(false);
      expect(next).not.toHaveBeenCalled();
      // Model native dimension loading completing after our bounded wait ended.
      // Its final hook must still see the cancelled operation, never a new one.
      expect(() => f.paste.beforePaste('doc')).toThrow(ImagePasteError);
      expect(f.busy.mock.calls).toEqual([[true], [false]]);
      finish(false);
      await vi.advanceTimersByTimeAsync(0);
      if (reason === 'timeout') {
        expect(await f.paste.run(next)).toBe(true);
        expect(next).toHaveBeenCalledOnce();
      }
    },
  );
  it('does not start a second native paste while the first owns selection', async () => {
    const f = fixture();
    let finish!: (value: boolean) => void;
    const result = f.paste.run(async () => {
      await f.paste.image(file);
      return new Promise<boolean>((resolve) => {
        finish = resolve;
      });
    });
    await vi.waitFor(() => expect(f.upload).toHaveBeenCalledOnce());
    const duplicate = vi.fn(async () => true);
    expect(await f.paste.run(duplicate)).toBe(false);
    expect(duplicate).not.toHaveBeenCalled();
    finish(true);
    expect(await result).toBe(true);
  });
  it('accepts only this item’s canonical storage URL, independently of the upload namespace', () => {
    const canonical = `/api/items/child/images/${'a'.repeat(64)}`;
    expect(isStoredImageUrl('child', canonical)).toBe(true);
    for (const invalid of [
      canonical.replace('/child/', '/other/'),
      canonical + '?secret',
      canonical + '/extra',
      canonical.replace('/api/items/', '/api/guest/'),
      'data:image/png;base64,x',
      undefined,
    ])
      expect(isStoredImageUrl('child', invalid)).toBe(false);
  });
  it('normalizes only this origin’s stored image fields and leaves URL-looking text intact', () => {
    const path = `/api/items/child/images/${'b'.repeat(64)}`;
    const absolute = `https://spinel.test${path}`;
    const doc = {
      body: { dataStream: absolute + '\r\n' },
      drawings: { image: { source: absolute, imageSourceType: 'URL' } },
      customData: { source: absolute },
    };
    normalizePastedImages(doc, 'child', 'https://spinel.test');
    expect(doc.drawings.image.source).toBe(path);
    expect(doc.body.dataStream).toBe(absolute + '\r\n');
    expect(doc.customData.source).toBe(absolute);
    for (const source of [
      `https://foreign.test${path}`,
      absolute.replace('/child/', '/other/'),
      absolute + '?query',
      'data:image/png;base64,x',
      'blob:https://spinel.test/unverified',
    ]) {
      expect(() =>
        normalizePastedImages({ drawings: { image: { source } } }, 'child', 'https://spinel.test'),
      ).toThrow(ImagePasteError);
    }
  });
  it('maps only finite status classes and never server response text', () => {
    expect([401, 403, 404, 400, 413, 429, 500].map(imageResponseFailure)).toEqual([
      'session',
      'access',
      'access',
      'invalid',
      'capacity',
      'uploadBusy',
      'upload',
    ]);
  });
});
