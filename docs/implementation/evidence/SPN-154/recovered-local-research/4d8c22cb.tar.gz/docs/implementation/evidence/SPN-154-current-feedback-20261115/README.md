# 🎨 SPN-154 current feedback evidence

Source/product: `48aebd85b849cafb9928f9a9f2f64d034973025a`. [Exact originals, guards, source/config/build hashes and capture inventory](manifest.json). This private research branch must not be published; create a clean candidate without its database-bearing ancestry first.

## 📱 Actual current application

Ordinary production Chromium 156.0.8078.4; desktop 1440×1100, phone Chromium mobile/touch emulation 390×844 with desktop browser keyboard paste. Synthetic journal and real trusted clipboard PNG, controlled upload failure. These are not physical Pixel/Home Screen observations. Full document/revision and original canvas/window remained unchanged. Both themes passed the alert's own width/height bounds.

![Phone emulation dark — actual current upload failure](015-image-paste-phone-emulation-dark.png)

![Phone emulation light — actual current upload failure](016-image-paste-phone-emulation-light.png)

![Desktop dark — actual current upload failure](025-image-paste-desktop-dark.png)

![Desktop light — actual current upload failure](026-image-paste-desktop-light.png)

## 🧩 All proposed production feedback states

Thirteen production EditorHelp stories, real editorFrame/theme CSS, 390×900 component renders. Each light/dark invocation passed the actual story play checks for exact text, visibility, nowrap and the alert’s own horizontal/vertical bounds. These component captures are distinct from the full Doc views above. This is execution evidence, not independent visual approval; agent review remains pending. The earlier full-catalogue heap OOM remains preserved and is not relabeled as a pass.

### upload failed

![docs-image-paste-feedback--upload-failed — light, production component at 390×900](056-docs-image-paste-feedback--upload-failed-phone.png)

![docs-image-paste-feedback--upload-failed — dark, production component at 390×900](062-docs-image-paste-feedback--upload-failed-phone-dark.png)

### offline

![docs-image-paste-feedback--offline — light, production component at 390×900](068-docs-image-paste-feedback--offline-phone.png)

![docs-image-paste-feedback--offline — dark, production component at 390×900](074-docs-image-paste-feedback--offline-phone-dark.png)

### signed out

![docs-image-paste-feedback--signed-out — light, production component at 390×900](080-docs-image-paste-feedback--signed-out-phone.png)

![docs-image-paste-feedback--signed-out — dark, production component at 390×900](086-docs-image-paste-feedback--signed-out-phone-dark.png)

### access changed

![docs-image-paste-feedback--access-changed — light, production component at 390×900](092-docs-image-paste-feedback--access-changed-phone.png)

![docs-image-paste-feedback--access-changed — dark, production component at 390×900](098-docs-image-paste-feedback--access-changed-phone-dark.png)

### selection changed

![docs-image-paste-feedback--selection-changed — light, production component at 390×900](104-docs-image-paste-feedback--selection-changed-phone.png)

![docs-image-paste-feedback--selection-changed — dark, production component at 390×900](110-docs-image-paste-feedback--selection-changed-phone-dark.png)

### insertion failed

![docs-image-paste-feedback--insertion-failed — light, production component at 390×900](116-docs-image-paste-feedback--insertion-failed-phone.png)

![docs-image-paste-feedback--insertion-failed — dark, production component at 390×900](122-docs-image-paste-feedback--insertion-failed-phone-dark.png)

### busy

![docs-image-paste-feedback--busy — light, production component at 390×900](128-docs-image-paste-feedback--busy-phone.png)

![docs-image-paste-feedback--busy — dark, production component at 390×900](134-docs-image-paste-feedback--busy-phone-dark.png)

### unsupported format

![docs-image-paste-feedback--unsupported-format — light, production component at 390×900](140-docs-image-paste-feedback--unsupported-format-phone.png)

![docs-image-paste-feedback--unsupported-format — dark, production component at 390×900](146-docs-image-paste-feedback--unsupported-format-phone-dark.png)

### invalid image

![docs-image-paste-feedback--invalid-image — light, production component at 390×900](152-docs-image-paste-feedback--invalid-image-phone.png)

![docs-image-paste-feedback--invalid-image — dark, production component at 390×900](158-docs-image-paste-feedback--invalid-image-phone-dark.png)

### too large

![docs-image-paste-feedback--too-large — light, production component at 390×900](164-docs-image-paste-feedback--too-large-phone.png)

![docs-image-paste-feedback--too-large — dark, production component at 390×900](170-docs-image-paste-feedback--too-large-phone-dark.png)

### earlier paste stalled

![docs-image-paste-feedback--earlier-paste-stalled — light, production component at 390×900](176-docs-image-paste-feedback--earlier-paste-stalled-phone.png)

![docs-image-paste-feedback--earlier-paste-stalled — dark, production component at 390×900](182-docs-image-paste-feedback--earlier-paste-stalled-phone-dark.png)

### storage limit

![docs-image-paste-feedback--storage-limit — light, production component at 390×900](188-docs-image-paste-feedback--storage-limit-phone.png)

![docs-image-paste-feedback--storage-limit — dark, production component at 390×900](194-docs-image-paste-feedback--storage-limit-phone-dark.png)

### uploads busy

![docs-image-paste-feedback--uploads-busy — light, production component at 390×900](200-docs-image-paste-feedback--uploads-busy-phone.png)

![docs-image-paste-feedback--uploads-busy — dark, production component at 390×900](206-docs-image-paste-feedback--uploads-busy-phone-dark.png)

