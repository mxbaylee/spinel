import type { ReactNode } from 'react';

/** Keep a local editor failure in the existing help slot. */
export function EditorHelp({ error, children }: { error?: string; children?: ReactNode }) {
  return (
    <p className="editor-help" role={error ? 'alert' : undefined}>
      {error || children}
    </p>
  );
}
