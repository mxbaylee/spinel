import type { ImageSourceType } from '@univerjs/core';
import { mapNativeImageSources } from '../src/shared/nativeImageSources.ts';

export type ImageFailure =
  | 'offline'
  | 'session'
  | 'access'
  | 'format'
  | 'size'
  | 'invalid'
  | 'busy'
  | 'changed'
  | 'upload'
  | 'insert'
  | 'stalled'
  | 'capacity'
  | 'uploadBusy';
export const imageFailureMessages: Record<ImageFailure, string> = {
  offline: 'Go online before inserting an image.',
  session: 'Sign in again to insert an image.',
  access: 'Access changed. Reopen to check it.',
  format: 'Use a PNG, JPEG or WebP image.',
  size: 'Choose an image up to 5 MiB.',
  invalid: 'Use a valid static image up to 16 megapixels.',
  busy: 'Image in progress. Wait before pasting.',
  changed: 'Edit changed. Place the cursor and paste again.',
  upload: 'Upload failed. Check connection and try again.',
  insert: 'Insertion failed. Place cursor and paste again.',
  capacity: 'Image limit reached. Try smaller or another Doc.',
  uploadBusy: 'Image service busy. Try again shortly.',
  stalled: 'Paste stalled. Reopen the Doc and try again.',
};
export class ImagePasteError extends Error {
  readonly reason: ImageFailure;
  constructor(reason: ImageFailure) {
    super(imageFailureMessages[reason]);
    this.reason = reason;
  }
}
export function imageResponseFailure(status: number): ImageFailure {
  if (status === 401) return 'session';
  if (status === 403 || status === 404) return 'access';
  if (status === 413) return 'capacity';
  if (status === 429) return 'uploadBusy';
  if (status === 400) return 'invalid';
  return 'upload';
}

/** Storage identity stays item-scoped even for Space and guest request routes. */
export function isStoredImageUrl(itemId: string, value: unknown): value is string {
  const prefix = `/api/items/${encodeURIComponent(itemId)}/images/`;
  return (
    typeof value === 'string' &&
    value.startsWith(prefix) &&
    /^[a-f0-9]{64}$/.test(value.slice(prefix.length))
  );
}

/** Native HTML parsing expands relative image URLs; storage keeps exact item paths. */
export function normalizePastedImages<T>(value: T, itemId: string, origin: string): T {
  return mapNativeImageSources(
    value,
    (source) => {
      const path = source.startsWith(origin + '/') ? source.slice(origin.length) : source;
      if (!isStoredImageUrl(itemId, path)) throw new ImagePasteError('insert');
      return path;
    },
    { updateSourceType: true },
  );
}

export function hasPastedImages(value: unknown): boolean {
  let found = false;
  mapNativeImageSources(value, (source) => {
    found = true;
    return source;
  });
  return found;
}

type Replay = { state: object; history: object };

/** Own one public native paste promise, including sizing and the final mutation. */
export function docImagePaste(options: {
  unitId: string;
  selection: () => string;
  available: () => boolean;
  upload: (
    file: File,
    signal: AbortSignal,
  ) => Promise<{ source: string; imageSourceType: ImageSourceType }>;
  cancelNative: () => void;
  busy: (busy: boolean) => void;
  error: (reason: ImageFailure) => void;
  signal: AbortSignal;
}) {
  type Operation = {
    selection: string;
    abort: AbortController;
    image: boolean;
    finished: boolean;
    nativeSettled: boolean;
    failure?: ImageFailure;
    deadline?: ReturnType<typeof setTimeout>;
    cancel: () => void;
    replay?: Replay & {
      undoSeen: boolean;
      undoPending: boolean;
      invalid: boolean;
      selection?: string;
      consumed: boolean;
    };
  };
  let active: Operation | undefined;
  const verify = (operation: Operation) => {
    if (operation.abort.signal.aborted || options.signal.aborted || !options.available())
      throw new ImagePasteError('access');
    if (
      operation.replay?.invalid ||
      (operation.replay?.selection ?? operation.selection) !== options.selection()
    )
      throw new ImagePasteError('changed');
  };
  const finish = (operation: Operation) => {
    if (operation.finished) return;
    operation.finished = true;
    if (operation.nativeSettled && active === operation) active = undefined;
    if (operation.image) options.busy(false);
  };
  const admitImage = () => {
    const operation = active;
    if (!operation) {
      options.error('insert');
      throw new ImagePasteError('insert');
    }
    if (operation.finished || operation.abort.signal.aborted || options.signal.aborted)
      throw new ImagePasteError('access');
    if (!operation.image) {
      operation.image = true;
      operation.deadline = setTimeout(operation.cancel, 30_000);
      options.busy(true);
    }
    return operation;
  };
  const controller = {
    async run(paste: () => Promise<boolean>, replay?: Replay) {
      if (options.signal.aborted) return false;
      if (active) {
        options.error(active.finished ? 'stalled' : 'busy');
        return false;
      }
      const operation: Operation = {
        selection: options.selection(),
        abort: new AbortController(),
        image: false,
        finished: false,
        nativeSettled: false,
        cancel: () => {},
        replay: replay
          ? { ...replay, undoSeen: false, undoPending: false, invalid: false, consumed: false }
          : undefined,
      };
      active = operation;
      const cancel = (operation.cancel = () => {
        operation.abort.abort();
        if (operation.image) options.cancelNative();
      });
      options.signal.addEventListener('abort', cancel, { once: true });
      let stopAbort: (() => void) | undefined;
      const aborted = new Promise<never>((_, reject) => {
        const stop = () => reject(new ImagePasteError('insert'));
        operation.abort.signal.addEventListener('abort', stop, { once: true });
        stopAbort = () => operation.abort.signal.removeEventListener('abort', stop);
      });
      try {
        const native = (async () => paste())().finally(() => {
          operation.nativeSettled = true;
          if (operation.finished && active === operation) active = undefined;
        });
        const result = await Promise.race([native, aborted]);
        if (!result && operation.image) throw new ImagePasteError(operation.failure ?? 'changed');
        return result;
      } catch (error) {
        if (!operation.image) {
          if (options.signal.aborted) return false;
          throw error;
        }
        cancel();
        if (!options.signal.aborted)
          options.error(error instanceof ImagePasteError ? error.reason : 'insert');
        return false;
      } finally {
        clearTimeout(operation.deadline);
        options.signal.removeEventListener('abort', cancel);
        stopAbort?.();
        finish(operation);
      }
    },
    async runImage(paste: () => Promise<boolean>): Promise<boolean> {
      try {
        return await controller.run(paste);
      } catch {
        // Only the native event adapter calls this after classifying image input.
        // Malformed data URLs can fail before the SDK invokes its image hook.
        if (!options.signal.aborted) options.error('invalid');
        return false;
      }
    },
    async image(file: File) {
      const operation = admitImage();
      try {
        verify(operation);
        const image = await options.upload(file, operation.abort.signal);
        verify(operation);
        return image;
      } catch (error) {
        operation.failure = error instanceof ImagePasteError ? error.reason : 'upload';
        throw new ImagePasteError(operation.failure);
      }
    },
    beforePaste(targetUnitId: string, images = active?.image ?? false) {
      if (!images) return false;
      const operation = admitImage();
      verify(operation);
      if (targetUnitId !== options.unitId) throw new ImagePasteError('changed');
      if (operation.replay) {
        if (!operation.replay.selection || operation.replay.consumed)
          throw new ImagePasteError('changed');
        operation.replay.consumed = true;
      }
      return true;
    },
    beforeHistoryUndo(history: unknown, state: unknown) {
      const operation = active;
      const replay = operation?.replay;
      if (!operation || !replay) return;
      if (
        operation.finished ||
        replay.undoSeen ||
        history !== replay.history ||
        state !== replay.state ||
        operation.selection !== options.selection() ||
        operation.abort.signal.aborted ||
        !options.available()
      ) {
        replay.invalid = true;
        return;
      }
      replay.undoSeen = true;
      replay.undoPending = true;
    },
    afterHistoryUndo(history: unknown, state: unknown) {
      const operation = active;
      const replay = operation?.replay;
      if (!operation || !replay) return;
      if (
        operation.finished ||
        !replay.undoPending ||
        replay.invalid ||
        history !== replay.history ||
        state !== replay.state ||
        operation.abort.signal.aborted ||
        !options.available()
      ) {
        replay.invalid = true;
        return;
      }
      replay.undoPending = false;
      replay.selection = options.selection();
    },
  };
  return controller;
}
