import type { Meta, StoryObj } from '@storybook/react-vite';
import { expect, within } from 'storybook/test';
import { EditorHelp } from './EditorHelp.tsx';
import { imageFailureMessages } from './docImagePaste.ts';
import './editorFrame.css';

const meta = {
  id: 'docs-image-paste-feedback',
  title: 'Current production/Docs/Image paste feedback',
  component: EditorHelp,
  parameters: { shell: 'none' },
  play: async ({ canvasElement, args }) => {
    const alert = within(canvasElement).getByRole('alert');
    await expect(alert).toBeVisible();
    await expect(alert).toHaveTextContent(args.error!);
    await expect(alert).toHaveClass('editor-help');
    await expect(getComputedStyle(alert).whiteSpace).toBe('nowrap');
    await expect(alert.scrollWidth).toBeLessThanOrEqual(alert.clientWidth);
    await expect(alert.scrollHeight).toBeLessThanOrEqual(alert.clientHeight);
  },
  decorators: [
    (Story) => (
      <div className="editor-frame">
        <section className="sheet-editor">
          <Story />
        </section>
      </div>
    ),
  ],
} satisfies Meta<typeof EditorHelp>;
export default meta;
type Story = StoryObj<typeof meta>;
export const UploadFailed: Story = { args: { error: imageFailureMessages.upload } };
export const Offline: Story = { args: { error: imageFailureMessages.offline } };
export const SignedOut: Story = { args: { error: imageFailureMessages.session } };
export const AccessChanged: Story = { args: { error: imageFailureMessages.access } };
export const SelectionChanged: Story = { args: { error: imageFailureMessages.changed } };
export const InsertionFailed: Story = { args: { error: imageFailureMessages.insert } };
export const Busy: Story = { args: { error: imageFailureMessages.busy } };
export const UnsupportedFormat: Story = { args: { error: imageFailureMessages.format } };
export const InvalidImage: Story = { args: { error: imageFailureMessages.invalid } };
export const TooLarge: Story = { args: { error: imageFailureMessages.size } };

export const EarlierPasteStalled: Story = { args: { error: imageFailureMessages.stalled } };

export const StorageLimit: Story = { args: { error: imageFailureMessages.capacity } };
export const UploadsBusy: Story = { args: { error: imageFailureMessages.uploadBusy } };
