import sharp from 'sharp';
import { createHash } from 'node:crypto';
import { withFixtureCleanup } from './app-process.ts';
import { expect, test } from '@playwright/test';
import type { APIRequestContext, BrowserContext, Page, TestInfo } from '@playwright/test';
import {
  createParagraphId,
  createSectionId,
  validateDocumentStructure,
  DocumentFlavor,
  getDocsEmptySnapshot,
} from '@univerjs/core';
import { DocumentStore } from '../src/server/workspace/documents.ts';
import { beginWriting } from './doc-touch.ts';
import { interruptibleNetwork } from './live-network.ts';
import { openDatabase } from '../server/database.ts';
import { AuthStore, COOKIE_NAME } from '../src/server/auth/store.ts';
import { WorkspaceStore } from '../src/server/workspace/store.ts';

test('document UI preserves rich text and embedded images through reload and offline recovery', async ({
  page,
  context,
  baseURL,
}, testInfo) => {
  test.setTimeout(90_000);
  const network = await interruptibleNetwork(context);
  page.setDefaultTimeout(10000);
  await page.setViewportSize({ width: 1440, height: 1100 });
  const db = openDatabase(
    testInfo.project.name === 'development'
      ? 'test-results/development/app.sqlite'
      : 'test-results/production/app.sqlite',
  );
  const auth = new AuthStore(db);
  const user = auth.createUser('Docs ' + testInfo.testId);
  const item = new WorkspaceStore(auth).create(user.id, {
    name: 'Journal',
    kind: 'doc',
    parentId: null,
  });
  await context.addCookies([
    {
      name: COOKIE_NAME,
      value: auth.createSession(user.id).token,
      url: baseURL!.replace('http:', 'https:'),
      secure: true,
      httpOnly: true,
      sameSite: 'Strict',
    },
  ]);
  const errors: string[] = [];
  let releaseImage = () => {};
  page.on('pageerror', (error) => errors.push(error.message));
  const read = async () =>
    (await (await context.request.get(`/api/items/${item.id}/doc`)).json()).snapshot;
  try {
    await page.goto(`/?item=${item.id}`);
    const editor = page.getByRole('region', { name: 'Doc document', exact: true });
    await expect(editor.getByRole('status', { name: 'Save status' })).toHaveText(
      'All changes saved.',
      { timeout: 20000 },
    );
    await expect(editor.getByRole('button', { name: 'Bold', exact: true })).toBeEnabled();
    await editor.locator('.univer-container').click({ position: { x: 130, y: 200 } });
    await page.keyboard.type('/');
    await expect(page.getByText('Insert Image', { exact: true })).toBeVisible();
    await expect(page.getByText('Insert Shape', { exact: true })).not.toBeVisible();
    await page.keyboard.press('Escape');
    await page.keyboard.press('Backspace');
    await page.keyboard.type('My journal');
    await expect
      .poll(
        async () =>
          (await (await context.request.get(`/api/items/${item.id}/doc`)).json()).snapshot.body
            .dataStream,
      )
      .toContain('My journal');
    await editor
      .getByRole('toolbar', { name: 'Start' })
      .getByText('Normal', { exact: true })
      .click();
    await page.getByRole('menuitem', { name: 'Heading 1', exact: true }).click();
    await page.keyboard.press('End');
    await page.keyboard.press('Enter');
    await page.keyboard.type('First item');
    await page.keyboard.press('Control+Shift+8');
    await page.keyboard.press('Enter');
    await page.keyboard.type('Second item');
    await page.keyboard.press('Enter');
    await page.keyboard.press('Enter');
    await page.keyboard.type('Reference link');
    // Finish the text edit before selecting a different toolbar. A pending editor
    // update can otherwise restore Start after the test has already clicked Insert.
    await expect.poll(async () => (await read()).body.dataStream).toContain('Reference link');
    await expect(editor.getByRole('status', { name: 'Save status' })).toHaveText(
      'All changes saved.',
    );
    await page.keyboard.press('Shift+Home');
    const insertTab = editor.getByRole('tab', { name: 'Insert', exact: true });
    await insertTab.click();
    await expect(insertTab).toHaveAttribute('aria-selected', 'true');
    await editor.getByRole('button', { name: 'Add link', exact: true }).click();
    const linkInput = page.getByRole('textbox', { name: '', exact: true });
    await linkInput.fill('https://example.com/journal');
    await page.getByRole('button', { name: 'Confirm', exact: true }).click();
    await expect(page.getByRole('button', { name: 'Confirm', exact: true })).not.toBeVisible();
    await page.keyboard.press('ArrowRight');
    await page.keyboard.press('End');
    await page.keyboard.press('Enter');
    await expect(editor.getByRole('button', { name: 'Image', exact: true })).toBeEnabled();
    let imageRequested = false;
    const delayedImage = new Promise<void>((resolve) => {
      releaseImage = resolve;
    });
    await page.route(`**/api/items/${item.id}/images/*`, async (route) => {
      imageRequested = true;
      await delayedImage;
      await route.continue();
    });
    const chooser = page.waitForEvent('filechooser', { timeout: 10000 });
    await editor.getByRole('button', { name: 'Image', exact: true }).click();
    await (
      await chooser
    ).setFiles({
      name: 'orange.png',
      mimeType: 'image/png',
      buffer: await sharp({ create: { width: 20, height: 10, channels: 4, background: '#ff9900' } })
        .png()
        .toBuffer(),
    });
    await expect.poll(() => imageRequested).toBe(true);
    await expect(editor.getByRole('status', { name: 'Save status' })).toContainText(
      'Inserting image',
    );
    const navigationWarning = page.waitForEvent('dialog');
    page.once('dialog', (dialog) => dialog.dismiss());
    await page.getByRole('button', { name: 'Back to files', exact: true }).click();
    await navigationWarning;
    await expect(page).toHaveURL(new RegExp(item.id));
    releaseImage();
    await expect
      .poll(
        async () =>
          (await (await context.request.get(`/api/items/${item.id}/doc`)).json()).snapshot
            .drawingsOrder.length,
      )
      .toBe(1);
    await page.unroute(`**/api/items/${item.id}/images/*`);

    const surface = editor.locator('.univer-container');
    // The document is canvas-rendered; click the visible heading to restore text focus.
    await surface.click({ position: { x: 130, y: 200 } });
    await page.keyboard.press('Control+End');
    await page.keyboard.press('Enter');
    await editor.getByRole('button', { name: 'Table', exact: true }).click();
    await page.getByRole('menuitem', { name: 'Insert Table', exact: true }).click();
    const tableDialog = page.getByRole('dialog', { name: 'Insert Table' });
    await tableDialog.getByRole('textbox').nth(0).fill('2');
    await tableDialog.getByRole('textbox').nth(1).fill('2');
    await tableDialog.getByRole('button', { name: 'ok', exact: true }).click();
    await expect(tableDialog).not.toBeVisible();
    await surface.click({ position: { x: 115, y: 350 } });
    await page.keyboard.type('Table cell');
    await expect(editor.getByRole('status', { name: 'Save status' })).toHaveText(
      'All changes saved.',
    );
    await page.keyboard.press('Control+End');
    await page.keyboard.press('ArrowDown');

    await expect.poll(async () => (await read()).body.dataStream).toContain('Table cell');
    const before = await read();
    expect(before.body.paragraphs[0].paragraphStyle.namedStyleType).toBe(4);
    expect(
      before.body.paragraphs.filter((paragraph: { bullet?: unknown }) => paragraph.bullet),
    ).toHaveLength(2);
    expect(before.body.customRanges[0].properties.url).toBe('https://example.com/journal');
    expect(before.body.tables).toHaveLength(1);
    expect(Object.keys(before.tableSource)).toHaveLength(1);
    expect(before.drawingsOrder).toHaveLength(1);
    const imageUrl = before.drawings[before.drawingsOrder[0]].source;
    const imageResponse = await context.request.get(imageUrl);
    expect(imageResponse.ok()).toBe(true);
    expect((await sharp(await imageResponse.body()).metadata()).width).toBe(20);
    await page.reload();
    await expect(editor.getByRole('status', { name: 'Save status' })).toHaveText(
      'All changes saved.',
      { timeout: 20000 },
    );
    await expect(editor.getByRole('button', { name: 'Bold', exact: true })).toBeVisible();
    await editor.getByRole('tab', { name: 'Insert', exact: true }).click();
    const after = await read();
    for (const key of ['body', 'tableSource', 'drawings', 'drawingsOrder', 'resources'])
      expect(after[key]).toEqual(before[key]);
    await page.screenshot({ path: testInfo.outputPath('document-reloaded.png') });
    await surface.click({ position: { x: 130, y: 200 } });
    await page.keyboard.press('Home');
    await network.setOffline(true);
    await page.keyboard.type('Offline ');
    await expect(editor.getByRole('status', { name: 'Save status' })).toContainText('not saved');
    // Theatre resizes the existing editor; unsaved work must survive both toggles.
    const mountedCanvas = await surface.elementHandle();
    await expect(page.getByRole('searchbox', { name: 'Search files' })).toHaveCount(0);
    await page.getByRole('button', { name: 'Enter theatre mode', exact: true }).click();
    await expect(editor).toBeVisible();
    expect(await mountedCanvas!.evaluate((node) => node.isConnected)).toBe(true);
    await page.screenshot({
      path: testInfo.outputPath('unsaved-editor-theatre.png'),
      fullPage: true,
    });
    await page.getByRole('button', { name: 'Exit theatre mode', exact: true }).click();
    await expect(editor.getByRole('status', { name: 'Save status' })).toContainText('not saved');
    page.once('dialog', (dialog) => dialog.dismiss());
    await page.getByRole('button', { name: 'Back to files', exact: true }).click();
    await expect(page).toHaveURL(new RegExp(item.id));
    expect(await mountedCanvas!.evaluate((node) => node.isConnected)).toBe(true);
    await network.setOffline(false);
    await expect(editor.getByRole('status', { name: 'Save status' })).toHaveText(
      'All changes saved.',
      { timeout: 20000 },
    );
    await expect.poll(async () => (await read()).body.dataStream).toContain('Offline ');
    await page.reload();
    await expect(editor.getByRole('status', { name: 'Save status' })).toHaveText(
      'All changes saved.',
      { timeout: 20000 },
    );
    expect((await read()).body.dataStream).toContain('Offline ');
    expect(errors).toEqual([]);
  } finally {
    releaseImage();
    await network.setOffline(false);
    db.prepare('DELETE FROM workspace_items WHERE owner_id=?').run(user.id);
    db.prepare('DELETE FROM auth_users WHERE id=?').run(user.id);
    db.close();
  }
});

// The real browser clipboard is the regression boundary: dispatching a synthetic
// ClipboardEvent would miss Chromium's normalized PNG and trusted native input.
type ClipboardOutcome =
  | 'saved'
  | 'upload failed'
  | 'session ended'
  | 'offline'
  | 'selection changed'
  | 'malformed image'
  | 'access changed';
type ClipboardEntry =
  'keyboard' | 'dropdown' | 'replay' | 'mixed replay' | 'text-first' | 'ordinary text';
for (const outcome of [
  'saved',
  'upload failed',
  'session ended',
  'offline',
  'selection changed',
  'malformed image',
  'access changed',
] as const) {
  test(`native clipboard image ${outcome} preserves existing text and the mounted editor`, ({
    page,
    context,
    baseURL,
    request,
  }, info) => nativeClipboardCase({ page, context, baseURL, request }, info, outcome));
}
for (const entry of [
  'dropdown',
  'replay',
  'mixed replay',
  'text-first',
  'ordinary text',
] as const) {
  test(`native clipboard image ${entry} preserves canonical content and the mounted editor`, ({
    page,
    context,
    baseURL,
    request,
  }, info) =>
    nativeClipboardCase({ page, context, baseURL, request }, info, 'saved', false, entry));
}
test.describe('phone image paste feedback', () => {
  test.use({
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
    reducedMotion: 'reduce',
    colorScheme: 'light',
  });
  test('native clipboard image upload failure fits the phone editor', ({
    page,
    context,
    baseURL,
    request,
  }, info) =>
    nativeClipboardCase({ page, context, baseURL, request }, info, 'upload failed', true));
});

async function nativeClipboardCase(
  {
    page,
    context,
    baseURL,
    request,
  }: {
    page: Page;
    context: BrowserContext;
    baseURL: string | undefined;
    request: APIRequestContext;
  },
  info: TestInfo,
  outcome: ClipboardOutcome,
  phone = false,
  entry: ClipboardEntry = 'keyboard',
) {
  const textFirst = entry === 'text-first';
  const mixed = entry === 'mixed replay' || textFirst;
  const malformed = outcome === 'malformed image';
  const authority = outcome === 'access changed';
  const htmlInput = mixed || malformed;
  const caption = 'Clipboard caption.';
  const expectedText = 'Keep these journal notes.' + (mixed ? caption : '');
  const db = openDatabase(
    info.project.name === 'development'
      ? 'test-results/development/app.sqlite'
      : 'test-results/production/app.sqlite',
  );
  const auth = new AuthStore(db);
  const owner = auth.createUser(`Image paste ${info.testId}`);
  const item = new WorkspaceStore(auth).create(owner.id, {
    name: 'Clipboard journal',
    kind: 'doc',
    parentId: null,
  });
  const collaborator = authority ? auth.createUser(`Image collaborator ${info.testId}`) : null;
  if (collaborator) new WorkspaceStore(auth).share(owner.id, item.id, collaborator.id, 'editor');
  if (phone) {
    const snapshot = getDocsEmptySnapshot(item.id, undefined, item.name, DocumentFlavor.MODERN);
    snapshot.body = {
      ...snapshot.body,
      dataStream: 'Phone journal\r\n',
      paragraphs: [{ startIndex: 13, paragraphId: createParagraphId(new Set()) }],
      sectionBreaks: [{ startIndex: 14, sectionId: createSectionId(new Set()) }],
    };
    expect(validateDocumentStructure(snapshot)).toEqual([]);
    new DocumentStore(new WorkspaceStore(auth)).save(owner.id, item.id, {
      snapshot,
      revision: 0,
      writeId: crypto.randomUUID(),
    });
  }
  const session = auth.createSession(owner.id);
  const browserSession = collaborator ? auth.createSession(collaborator.id) : session;
  const requests: Array<{ method: string; path: string }> = [];
  const responses: Array<{ method: string; path: string; status: number }> = [];
  const errors: string[] = [];
  const frames: unknown[] = [];
  // Use the same canonical document API as the existing Doc case. Native
  // collaboration commits to its current generation, not legacy doc_snapshots.
  // This separate authenticated observer survives removal of browser cookies.
  const read = async () => {
    const response = await request.get(`/api/items/${item.id}/doc`, {
      headers: { Cookie: `${COOKIE_NAME}=${session.token}` },
    });
    expect(response.ok()).toBe(true);
    return response.json();
  };
  let before: unknown;
  let beforeReopen: unknown;
  let deliberateReopen: unknown;
  let clipboardInput: unknown;
  const nonimageEvidence: unknown[] = [];
  const authorityEvidence: unknown[] = [];
  let authorityBeforeCleanup: unknown;
  let uploadedImage: { url: string } | undefined;
  let uploadStatus: number | undefined;
  let submitsBeforePaste = 0;
  let deliberateReloadStarted = false;
  const stages: Array<{ stage: string; document: unknown; paint?: unknown }> = [];
  let release = () => {};
  let pending = false;
  let canvas: Awaited<ReturnType<ReturnType<typeof page.locator>['elementHandle']>> | undefined;
  await context.grantPermissions(['clipboard-read', 'clipboard-write']);
  await context.addCookies([
    {
      name: COOKIE_NAME,
      value: browserSession.token,
      url: baseURL!.replace('http:', 'https:'),
      secure: true,
      httpOnly: true,
      sameSite: 'Strict',
    },
  ]);
  await page.addInitScript(() => {
    const observation = {
      marker: crypto.randomUUID(),
      pastes: [] as Array<{ trusted: boolean; files: Array<{ type: string; bytes: number }> }>,
    };
    Object.assign(window, { imagePasteObservation: observation });
    document.addEventListener(
      'paste',
      (event) =>
        observation.pastes.push({
          trusted: event.isTrusted,
          files: [...(event.clipboardData?.files ?? [])].map((file) => ({
            type: file.type,
            bytes: file.size,
          })),
        }),
      true,
    );
  });
  page.on('request', (request) => {
    const path = new URL(request.url()).pathname;
    if (path.includes(`/api/items/${item.id}/images`))
      requests.push({ method: request.method(), path });
  });
  page.on('response', (response) => {
    const path = new URL(response.url()).pathname;
    if (path.includes(`/api/items/${item.id}/images`))
      responses.push({ method: response.request().method(), path, status: response.status() });
  });
  page.on('pageerror', (error) => errors.push(error.message));
  page.on('websocket', (socket) => {
    const recordFrame = (direction: string, payload: string | Buffer) => {
      try {
        const message = JSON.parse(String(payload));
        if (['submit', 'resync', 'ack'].includes(message.type)) frames.push({ direction, message });
      } catch {
        /* Non-JSON frames are irrelevant to this contract. */
      }
    };
    socket.on('framesent', ({ payload }) => recordFrame('framesent', payload));
    socket.on('framereceived', ({ payload }) => recordFrame('framereceived', payload));
  });
  await withFixtureCleanup(
    async () => {
      if (!phone) await page.setViewportSize({ width: 1440, height: 1100 });
      await page.goto(`/?item=${item.id}`);
      const editor = page.getByRole('region', { name: 'Doc document', exact: true });
      const status = editor.getByRole('status', { name: 'Save status' });
      await expect(status).toHaveText('All changes saved.', { timeout: 20_000 });
      if (phone) {
        await beginWriting(page);
        await page.keyboard.press('Control+End');
      } else await editor.locator('.univer-container').click({ position: { x: 130, y: 200 } });
      await page.keyboard.type('Keep these journal notes.');
      await expect
        .poll(async () => (await read()).snapshot?.body?.dataStream)
        .toContain('Keep these journal notes.');
      await expect(status).toHaveText('All changes saved.');
      before = await read();
      submitsBeforePaste = frames.filter(
        (frame) => (frame as { message: { type: string } }).message.type === 'submit',
      ).length;
      canvas = await editor.getByLabel('Document canvas', { exact: true }).elementHandle();
      expect(canvas).not.toBeNull();
      const paintedImage = async () => {
        // Inspect current native pixels, not the fetched image or persisted drawing.
        // The fixture's only orange content is its 20x10 PNG; the pre-paste raster
        // must contain none. A toolbar icon cannot satisfy this canvas-only witness.
        const { data, info: raster } = await sharp(await canvas!.screenshot())
          .removeAlpha()
          .raw()
          .toBuffer({ resolveWithObject: true });
        let pixels = 0;
        let left = raster.width;
        let right = -1;
        let top = raster.height;
        let bottom = -1;
        for (let y = 0; y < raster.height; y++)
          for (let x = 0; x < raster.width; x++) {
            const offset = (y * raster.width + x) * raster.channels;
            if (
              data[offset]! >= 240 &&
              data[offset + 1]! >= 140 &&
              data[offset + 1]! <= 165 &&
              data[offset + 2]! <= 15
            ) {
              pixels++;
              left = Math.min(left, x);
              right = Math.max(right, x);
              top = Math.min(top, y);
              bottom = Math.max(bottom, y);
            }
          }
        const width = Math.max(0, right - left + 1);
        const height = Math.max(0, bottom - top + 1);
        return {
          pixels,
          box: { left, top, width, height },
          visible:
            pixels >= 12 &&
            width / height >= 1.5 &&
            width / height <= 2.5 &&
            pixels / (width * height) >= 0.6,
        };
      };
      if (outcome === 'saved') {
        const paint = await paintedImage();
        stages.push({ stage: 'before paste', document: before, paint });
        expect(paint.pixels).toBe(0);
      }
      const marker = await page.evaluate(
        () =>
          (window as unknown as { imagePasteObservation: { marker: string } }).imagePasteObservation
            .marker,
      );
      if (entry === 'ordinary text') {
        const plain = 'Plain clipboard.';
        const formatted = 'Formatted clipboard.';
        const prefix = 'Keep these journal notes.' + plain;
        const textOf = (document: { snapshot: { body: { dataStream: string } } }) =>
          document.snapshot.body.dataStream.replaceAll('\r', '').replaceAll('\n', '');
        const boldAt = (
          document: {
            snapshot: {
              body: { textRuns?: Array<{ st: number; ed: number; ts?: { bl?: number } }> };
            };
          },
          start: number,
          length: number,
        ) =>
          Array.from({ length }, (_, offset) =>
            (document.snapshot.body.textRuns ?? []).some(
              (run) => run.st <= start + offset && run.ed > start + offset && run.ts?.bl === 1,
            ),
          );
        const write = async (text: string, html?: string) => {
          const input = await page.evaluate(
            async ({ text, html }) => {
              await navigator.clipboard.write([
                new ClipboardItem({
                  'text/plain': new Blob([text], { type: 'text/plain' }),
                  ...(html ? { 'text/html': new Blob([html], { type: 'text/html' }) } : {}),
                }),
              ]);
              const [item] = await navigator.clipboard.read();
              return {
                flavors: item.types,
                text: await (await item.getType('text/plain')).text(),
                html: html ? await (await item.getType('text/html')).text() : null,
              };
            },
            { text, html },
          );
          expect(input.text).toBe(text);
          expect([...input.flavors].sort()).toEqual(
            html ? ['text/html', 'text/plain'] : ['text/plain'],
          );
          if (html) expect(input.html).toContain('<b>');
          nonimageEvidence.push({ clipboard: input });
        };
        const saved = async (stage: string, text: string) => {
          await expect.poll(async () => textOf(await read())).toBe(text);
          await expect(status).toHaveText('All changes saved.');
          const document = await read();
          expect(document.snapshot.drawingsOrder).toHaveLength(0);
          expect(requests).toEqual([]);
          await expect(editor.getByRole('alert')).toHaveCount(0);
          expect(await canvas!.evaluate((node) => node.isConnected)).toBe(true);
          stages.push({ stage, document });
          return document;
        };
        await write(plain);
        await page.keyboard.press('ControlOrMeta+V');
        const plainSaved = await saved('ordinary plain keyboard paste', prefix);
        await write(formatted, `<p><b>${formatted}</b></p>`);
        await editor.getByRole('button', { name: 'Paste special', exact: true }).click();
        await page.getByText('Keep source formatting', { exact: true }).click();
        const htmlSaved = await saved('ordinary HTML source paste', prefix + formatted);
        expect(boldAt(htmlSaved, prefix.length, formatted.length)).toEqual(
          Array(formatted.length).fill(true),
        );
        expect(boldAt(htmlSaved, 0, prefix.length)).toEqual(boldAt(plainSaved, 0, prefix.length));
        await page.getByRole('button', { name: 'Paste options', exact: true }).click();
        await page.getByRole('menuitemcheckbox', { name: 'Keep text only', exact: true }).click();
        await expect.poll(async () => (await read()).revision).toBeGreaterThan(htmlSaved.revision);
        const textSaved = await saved('ordinary HTML text mode', prefix + formatted);
        expect(boldAt(textSaved, prefix.length, formatted.length)).toEqual(
          Array(formatted.length).fill(false),
        );
        expect(boldAt(textSaved, 0, prefix.length)).toEqual(boldAt(plainSaved, 0, prefix.length));
        await editor.getByRole('button', { name: 'Undo', exact: true }).click();
        await saved('ordinary HTML Undo', prefix);
        await editor.getByRole('button', { name: 'Redo', exact: true }).click();
        const beforeDenial = await saved('ordinary HTML Redo', prefix + formatted);
        const cdp = await context.newCDPSession(page);
        try {
          const { targetInfo } = await cdp.send('Target.getTargetInfo');
          expect(targetInfo.browserContextId).toBeTruthy();
          await cdp.send('Browser.setPermission', {
            permission: { name: 'clipboard-read' },
            setting: 'denied',
            origin: new URL(baseURL!).origin,
            browserContextId: targetInfo.browserContextId,
          });
          const permission = await page.evaluate(
            async () =>
              (await navigator.permissions.query({ name: 'clipboard-read' as PermissionName }))
                .state,
          );
          nonimageEvidence.push({ clipboardReadPermission: permission });
          expect(permission).toBe('denied');
          await editor.getByRole('button', { name: 'Paste special', exact: true }).click();
          await page.getByText('Keep source formatting', { exact: true }).click();
          const guidance = page.getByText(/^Clipboard access is unavailable\..*Paste options\.$/);
          await expect(guidance).toBeVisible();
          nonimageEvidence.push({ nativeReadDenialGuidance: await guidance.textContent() });
          expect(await read()).toEqual(beforeDenial);
        } finally {
          await withFixtureCleanup(
            () => context.grantPermissions(['clipboard-read', 'clipboard-write']),
            () => cdp.detach(),
          );
        }
        expect(requests).toEqual([]);
        expect(errors).toEqual([]);
        expect(
          frames.some(
            (frame) => (frame as { message: { type: string } }).message.type === 'resync',
          ),
        ).toBe(false);
        expect(await canvas!.evaluate((node) => node.isConnected)).toBe(true);
        const observed = await page.evaluate(
          () =>
            (window as unknown as { imagePasteObservation: { marker: string; pastes: unknown[] } })
              .imagePasteObservation,
        );
        expect(observed).toEqual({ marker, pastes: [{ trusted: true, files: [] }] });
        return;
      }
      const png = await sharp({
        create: { width: 20, height: 10, channels: 4, background: '#ff9900' },
      })
        .png()
        .toBuffer();
      const clipboard = await page.evaluate(
        async ({ bytes, htmlInput, malformed, caption }) => {
          const png = new Uint8Array(bytes);
          const imageData = malformed ? '%not-valid-base64' : btoa(String.fromCharCode(...png));
          const html = `<p>${caption}<img width="20" height="10" src="data:image/png;base64,${imageData}"></p>`;
          await navigator.clipboard.write([
            new ClipboardItem(
              htmlInput
                ? {
                    'text/html': new Blob([html], { type: 'text/html' }),
                    'text/plain': new Blob([caption], { type: 'text/plain' }),
                  }
                : { 'image/png': new Blob([png], { type: 'image/png' }) },
            ),
          ]);
          const items = await navigator.clipboard.read();
          const input = await items[0].getType(htmlInput ? 'text/html' : 'image/png');
          return {
            type: input.type,
            bytes: input.size,
            flavors: items[0].types,
            html: htmlInput ? await input.text() : undefined,
            text: htmlInput ? await (await items[0].getType('text/plain')).text() : undefined,
          };
        },
        { bytes: [...png], htmlInput, malformed, caption },
      );
      expect(clipboard.type).toBe(htmlInput ? 'text/html' : 'image/png');
      expect([...clipboard.flavors].sort()).toEqual(
        htmlInput ? ['text/html', 'text/plain'] : ['image/png'],
      );
      clipboardInput = clipboard;
      if (htmlInput) {
        expect(clipboard.text).toBe(caption);
        expect(clipboard.html).toContain(caption);
        expect(clipboard.html).toContain('data:image/png;base64,');
        expect(clipboard.html).toContain('width="20"');
        expect(clipboard.html).toContain('height="10"');
        if (malformed) expect(clipboard.html).toContain('data:image/png;base64,%not-valid-base64');
      }
      expect(clipboard.bytes).toBeGreaterThan(0);
      const endpoint = `**/api/items/${item.id}/images`;
      if (outcome === 'upload failed')
        await page.route(endpoint, (route) =>
          route.fulfill({
            status: 500,
            contentType: 'text/html',
            body: '<html>RAW server detail must never appear</html>',
          }),
        );
      if (outcome === 'session ended') await context.clearCookies();
      if (outcome === 'offline') await context.setOffline(true);
      if (outcome === 'selection changed') {
        const held = new Promise<void>((resolve) => {
          release = resolve;
        });
        await page.route(endpoint, async (route) => {
          pending = true;
          await held;
          await route.continue();
        });
      }
      if (authority) {
        const held = new Promise<void>((resolve) => {
          release = resolve;
        });
        await page.route(endpoint, async (route) => {
          const response = await route.fetch();
          try {
            uploadStatus = response.status();
            uploadedImage = await response.json();
            authorityEvidence.push({
              stage: 'server upload completed; response held',
              status: uploadStatus,
              image: uploadedImage,
            });
            pending = true;
            await held;
            await route.fulfill({ response });
            authorityEvidence.push({ stage: 'original upload response fulfilled' });
          } catch (error) {
            authorityEvidence.push({
              stage: 'original upload response delivery failed',
              error: String(error),
            });
          } finally {
            await response.dispose();
          }
        });
      }
      if (entry === 'dropdown' || textFirst) {
        await editor.getByRole('button', { name: 'Paste special', exact: true }).click();
        await page
          .getByText(textFirst ? 'Keep text only' : 'Keep source formatting', { exact: true })
          .click();
      } else await page.keyboard.press('ControlOrMeta+V');
      if (textFirst) {
        await expect
          .poll(async () => (await read()).revision)
          .toBeGreaterThan((before as { revision: number }).revision);
        await expect(status).toHaveText('All changes saved.');
        const text = await read();
        expect(
          text.snapshot.body.dataStream
            .replaceAll('\u0008', '')
            .replaceAll('\r', '')
            .replaceAll('\n', ''),
        ).toBe(expectedText);
        expect(text.snapshot.drawingsOrder).toHaveLength(0);
        expect(requests.filter((request) => request.method === 'POST')).toHaveLength(0);
        const paint = await paintedImage();
        expect(paint.pixels).toBe(0);
        stages.push({
          stage: 'initial text-only paste saved without upload',
          document: text,
          paint,
        });
        expect(await canvas!.evaluate((node) => node.isConnected)).toBe(true);
        await page.getByRole('button', { name: 'Paste options', exact: true }).click();
        await expect(
          page.getByRole('menuitemcheckbox', { name: 'Keep text only', exact: true }),
        ).toHaveAttribute('aria-checked', 'true');
        await page
          .getByRole('menuitemcheckbox', { name: 'Keep source formatting', exact: true })
          .click();
        await expect.poll(async () => (await read()).revision).toBeGreaterThan(text.revision);
      }
      if (outcome === 'selection changed') {
        await expect.poll(() => pending).toBe(true);
        await expect(status).toContainText('Inserting image');
        await page.keyboard.press('ArrowLeft');
        release();
      }
      if (authority) {
        await expect.poll(() => pending).toBe(true);
        expect(uploadStatus).toBe(201);
        expect(uploadedImage?.url).toMatch(
          new RegExp(`^/api/items/${item.id}/images/[a-f0-9]{64}$`),
        );
        await expect(status).toContainText('Inserting image');
        const downgrade = await request.put(`/api/items/${item.id}/sharing`, {
          headers: { Cookie: `${COOKIE_NAME}=${session.token}`, Origin: baseURL! },
          data: { userId: collaborator!.id, role: 'viewer' },
        });
        expect(downgrade.ok()).toBe(true);
        // Busy copy intentionally hides Access changed until the upload settles.
        // Native disabled controls prove readonly() installed its edit fence.
        await expect(editor.getByRole('button', { name: 'Bold', exact: true })).toBeDisabled();
        await expect(
          editor.getByRole('button', { name: 'Paste special', exact: true }),
        ).toBeDisabled();
        expect(await canvas!.evaluate((node) => node.isConnected)).toBe(true);
        expect(await read()).toEqual(before);
        authorityEvidence.push({
          stage: 'native edit fence installed before response release',
          status: await status.textContent(),
          document: await read(),
        });
        release();
      }
      if (outcome === 'saved') {
        await expect.poll(async () => (await read()).snapshot.drawingsOrder.length).toBe(1);
        await expect(status).toHaveText('All changes saved.');
        const after = (await read()).snapshot;
        expect(
          after.body.dataStream.replaceAll('\u0008', '').replaceAll('\r', '').replaceAll('\n', ''),
        ).toBe(expectedText);
        const drawing = after.drawings[after.drawingsOrder[0]];
        expect(drawing.imageSourceType).toBe('URL');
        expect(drawing.source).toMatch(new RegExp(`^/api/items/${item.id}/images/[a-f0-9]{64}$`));
        const response = await context.request.get(drawing.source);
        expect(response.ok()).toBe(true);
        expect((await sharp(await response.body()).metadata()).width).toBe(20);
        expect(requests.filter((request) => request.method === 'POST')).toHaveLength(1);
        if (textFirst) await expect.poll(async () => (await paintedImage()).visible).toBe(true);
        stages.push({
          stage: 'initial paste saved',
          document: await read(),
          paint: await paintedImage(),
        });
        await page.screenshot({
          path: info.outputPath('image-pasted-before-native-mode-change.png'),
        });
        if (entry === 'replay' || mixed) {
          if (!textFirst) {
            const initial = await read();
            await page.getByRole('button', { name: 'Paste options', exact: true }).click();
            await page
              .getByRole('menuitemcheckbox', { name: 'Match destination formatting', exact: true })
              .click();
            await expect
              .poll(async () => (await read()).revision)
              .toBeGreaterThan(initial.revision);
            await expect(status).toHaveText('All changes saved.');
            const replayed = await read();
            stages.push({
              stage: 'destination replay saved',
              document: replayed,
              paint: await paintedImage(),
            });
            expect(replayed.snapshot.drawingsOrder).toHaveLength(1);
            const replayedImage = replayed.snapshot.drawings[replayed.snapshot.drawingsOrder[0]];
            expect(replayedImage.source).toBe(drawing.source);
            expect(replayedImage.imageSourceType).toBe('URL');
            expect(replayed.snapshot.body.dataStream).toBe(after.body.dataStream);
            expect(requests.filter((request) => request.method === 'POST')).toHaveLength(1);
            for (const [label, images] of [
              ['Keep source formatting', 1],
              ['Keep text only', 0],
              ['Keep source formatting', 1],
            ] as const) {
              const previous = await read();
              const submits = frames.filter(
                (frame) => (frame as { message: { type: string } }).message.type === 'submit',
              ).length;
              await page.getByRole('button', { name: 'Paste options', exact: true }).click();
              await page.getByRole('menuitemcheckbox', { name: label, exact: true }).click();
              if (images === 0 && !mixed) {
                // PNG-only clipboard has no plain text. Native text mode returns
                // false before Undo and retains source mode; observe UI completion,
                // then prove no mutation rather than requiring invented behavior.
                const options = page.getByRole('button', { name: 'Paste options', exact: true });
                await expect(options).toBeEnabled();
                await options.click();
                await expect(
                  page.getByRole('menuitemcheckbox', {
                    name: 'Keep source formatting',
                    exact: true,
                  }),
                ).toHaveAttribute('aria-checked', 'true');
                await expect(
                  page.getByRole('menuitemcheckbox', { name: label, exact: true }),
                ).toHaveAttribute('aria-checked', 'false');
                expect(await read()).toEqual(previous);
                expect(
                  frames.filter(
                    (frame) => (frame as { message: { type: string } }).message.type === 'submit',
                  ),
                ).toHaveLength(submits);
                stages.push({
                  stage: 'empty text mode retained source',
                  document: await read(),
                  paint: await paintedImage(),
                });
                await page.keyboard.press('Escape');
                break;
              }
              await expect
                .poll(async () => (await read()).revision)
                .toBeGreaterThan(previous.revision);
              await expect(status).toHaveText('All changes saved.');
              const current = await read();
              stages.push({ stage: label, document: current, paint: await paintedImage() });
              expect(current.snapshot.drawingsOrder).toHaveLength(images);
              expect(
                current.snapshot.body.dataStream
                  .replaceAll('\u0008', '')
                  .replaceAll('\r', '')
                  .replaceAll('\n', ''),
              ).toBe(expectedText);
              if (images) {
                const image = current.snapshot.drawings[current.snapshot.drawingsOrder[0]];
                expect(image.source).toBe(drawing.source);
                expect(image.imageSourceType).toBe('URL');
              }
              expect(requests.filter((request) => request.method === 'POST')).toHaveLength(1);
            }
          }
          for (const [action, images] of [
            ['Undo', 0],
            ['Redo', 1],
          ] as const) {
            const previous = await read();
            await editor.getByRole('button', { name: action, exact: true }).click();
            await expect
              .poll(async () => (await read()).revision)
              .toBeGreaterThan(previous.revision);
            await expect(status).toHaveText('All changes saved.');
            const current = await read();
            stages.push({ stage: action, document: current, paint: await paintedImage() });
            expect(current.snapshot.drawingsOrder).toHaveLength(images);
            expect(
              current.snapshot.body.dataStream
                .replaceAll('\u0008', '')
                .replaceAll('\r', '')
                .replaceAll('\n', ''),
            ).toBe(images ? expectedText : 'Keep these journal notes.');
            if (images)
              expect(current.snapshot.drawings[current.snapshot.drawingsOrder[0]].source).toBe(
                drawing.source,
              );
            expect(requests.filter((request) => request.method === 'POST')).toHaveLength(1);
          }
        }
        // The persistence/entry boundary is observed first; this separate assertion
        // proves native painting before any deliberate reload can mask a defect.
        await expect.poll(async () => (await paintedImage()).visible).toBe(true);
        stages.push({
          stage: 'image visibly painted',
          document: await read(),
          paint: await paintedImage(),
        });
      } else {
        const expected =
          outcome === 'upload failed'
            ? 'Upload failed. Check connection and try again.'
            : outcome === 'session ended'
              ? 'Sign in again to insert an image.'
              : outcome === 'offline'
                ? 'Go online before inserting an image.'
                : malformed
                  ? 'Use a valid static image up to 16 megapixels.'
                  : authority
                    ? 'Access changed. Reopen to check it.'
                    : 'Edit changed. Place the cursor and paste again.';
        await expect(editor.getByRole('alert')).toHaveText(expected);
        expect(await read()).toEqual(before);
        await expect(status).not.toContainText('Inserting image');
        if (outcome === 'upload failed' || outcome === 'session ended')
          expect(
            responses.some(
              (response) =>
                response.method === 'POST' &&
                response.status === (outcome === 'upload failed' ? 500 : 401),
            ),
          ).toBe(true);
        if (outcome === 'offline' || malformed)
          expect(requests.filter((request) => request.method === 'POST')).toHaveLength(0);
        if (authority) {
          expect(
            responses.some((response) => response.method === 'POST' && response.status === 201),
          ).toBe(true);
          expect(
            frames.filter(
              (frame) => (frame as { message: { type: string } }).message.type === 'submit',
            ),
          ).toHaveLength(submitsBeforePaste);
          authorityEvidence.push({
            stage: 'late successful upload refused',
            document: await read(),
            alert: await editor.getByRole('alert').textContent(),
          });
          const stored = await request.get(uploadedImage!.url, {
            headers: { Cookie: `${COOKIE_NAME}=${session.token}` },
          });
          expect(stored.status()).toBe(200);
          authorityEvidence.push({
            stage: 'unreferenced upload remains server-stored',
            status: stored.status(),
            bytes: (await stored.body()).length,
          });
          // Native _pasteWithOptions refuses read-only targets before preparation;
          // this real event and disabled command state exercise that early fence.
          await page.keyboard.press('ControlOrMeta+V');
          await expect
            .poll(() =>
              page.evaluate(
                () =>
                  (window as unknown as { imagePasteObservation: { pastes: unknown[] } })
                    .imagePasteObservation.pastes.length,
              ),
            )
            .toBe(2);
          await expect(status).not.toContainText('Inserting image');
          expect(requests.filter((request) => request.method === 'POST')).toHaveLength(1);
          expect(
            frames.filter(
              (frame) => (frame as { message: { type: string } }).message.type === 'submit',
            ),
          ).toHaveLength(submitsBeforePaste);
          expect(await read()).toEqual(before);
          authorityEvidence.push({
            stage: 'read-only native paste denied without another upload',
            document: await read(),
          });
        }
      }
      expect(await canvas!.evaluate((node) => node.isConnected)).toBe(true);
      const observation = await page.evaluate(
        () =>
          (
            window as unknown as {
              imagePasteObservation: {
                marker: string;
                pastes: Array<{
                  trusted: boolean;
                  files: Array<{ type: string; bytes: number }>;
                }>;
              };
            }
          ).imagePasteObservation,
      );
      expect(observation.marker).toBe(marker);
      expect(observation.pastes).toEqual(
        entry === 'dropdown' || textFirst
          ? [] // Native dropdown reads ClipboardItems; it does not emit a paste event.
          : Array.from({ length: authority ? 2 : 1 }, () => ({
              trusted: true,
              files: htmlInput ? [] : [{ type: 'image/png', bytes: clipboard.bytes }],
            })),
      );
      expect(
        frames.some((frame) => (frame as { message: { type: string } }).message.type === 'resync'),
      ).toBe(false);
      expect(errors).toEqual([]);
      if (outcome === 'upload failed') {
        for (const theme of ['light', 'dark'] as const) {
          await page.emulateMedia({ colorScheme: theme });
          await expect(page.locator('html')).toHaveAttribute('data-theme', theme);
          await expect(editor.getByRole('alert')).toBeVisible();
          expect(
            await editor.getByRole('alert').evaluate((alert) => ({
              horizontal: alert.scrollWidth <= alert.clientWidth,
              vertical: alert.scrollHeight <= alert.clientHeight,
            })),
          ).toEqual({ horizontal: true, vertical: true });
          expect(
            await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth),
          ).toBe(true);
          await page.screenshot({
            path: info.outputPath(
              `image-paste-${phone ? 'phone-emulation' : 'desktop'}-${theme}.png`,
            ),
            animations: 'disabled',
            fullPage: true,
          });
        }
      }
      if (outcome === 'saved' && entry === 'keyboard') {
        beforeReopen = {
          snapshot: await read(),
          marker: observation.marker,
          pasteObservation: observation,
          originalCanvasConnected: await canvas!.evaluate((node) => node.isConnected),
        };
        await page.screenshot({
          path: info.outputPath('image-pasted-before-deliberate-reopen.png'),
        });
        const committed = await read();
        const source = committed.snapshot.drawings[committed.snapshot.drawingsOrder[0]]
          .source as string;
        const imageAfterReload = page.waitForResponse(
          (response) =>
            new URL(response.url()).pathname === source && response.request().method() === 'GET',
        );
        deliberateReloadStarted = true;
        const [, imageResponse] = await Promise.all([page.reload(), imageAfterReload]);
        await expect(status).toHaveText('All changes saved.', { timeout: 20_000 });
        await expect(editor.getByLabel('Document canvas', { exact: true })).toBeVisible();
        const reopened = await read();
        expect(reopened).toEqual(committed);
        expect(imageResponse.status()).toBe(200);
        const bytes = await imageResponse.body();
        const decoded = await sharp(bytes).raw().toBuffer({ resolveWithObject: true });
        expect({ width: decoded.info.width, height: decoded.info.height }).toEqual({
          width: 20,
          height: 10,
        });
        const hash = createHash('sha256').update(bytes).digest('hex');
        expect(source.endsWith('/' + hash)).toBe(true);
        const newMarker = await page.evaluate(
          () =>
            (window as unknown as { imagePasteObservation: { marker: string } })
              .imagePasteObservation.marker,
        );
        expect(newMarker).not.toBe(observation.marker);
        const currentCanvasConnected = await editor
          .getByLabel('Document canvas', { exact: true })
          .evaluate((node) => node.isConnected);
        expect(currentCanvasConnected).toBe(true);
        deliberateReopen = {
          snapshot: reopened,
          originalDocument: 'retired by deliberate reload; its ElementHandle is not evaluated',
          currentCanvasConnected,
          marker: newMarker,
          image: {
            source,
            status: imageResponse.status(),
            bytes: bytes.length,
            sha256: hash,
            width: decoded.info.width,
            height: decoded.info.height,
          },
        };
        await page.screenshot({
          path: info.outputPath('image-pasted-after-deliberate-reopen.png'),
        });
        expect(errors).toEqual([]);
      }
    },
    async () => {
      let authorityCaptureError: unknown;
      if (authority) {
        try {
          authorityBeforeCleanup = {
            evidence: structuredClone(authorityEvidence),
            document: await read(),
            requests: structuredClone(requests),
            responses: structuredClone(responses),
            frames: structuredClone(frames),
            originalCanvasConnected: await canvas?.evaluate((node) => node.isConnected),
          };
        } catch (error) {
          authorityCaptureError = error;
          authorityBeforeCleanup = {
            captureFailed: String(error),
            evidence: structuredClone(authorityEvidence),
          };
        }
      }
      release();
      await withFixtureCleanup(
        async () => {
          await page.screenshot({ path: info.outputPath('native-image-paste.png') });
          await info.attach('native-image-paste', {
            body: JSON.stringify({
              outcome,
              entry,
              clipboardInput,
              nonimageEvidence,
              authorityEvidence,
              authorityBeforeCleanup,
              submitsBeforePaste,
              stages,
              browser: page.context().browser()?.version(),
              retry: info.retry,
              requests,
              responses,
              frames,
              errors,
              before,
              beforeReopen,
              deliberateReopen,
              phoneEmulation: phone,
              after: await read(),
              page: await page.evaluate(() => ({
                observation: (window as unknown as { imagePasteObservation: unknown })
                  .imagePasteObservation,
                online: navigator.onLine,
                help: document.querySelector('.editor-help')?.textContent,
              })),
              originalCanvasNotQueriedAfterDeliberateReload: deliberateReloadStarted,
              originalCanvasConnectedAtFinalObservation: deliberateReloadStarted
                ? undefined
                : await canvas?.evaluate((node) => node.isConnected),
            }),
            contentType: 'application/json',
          });
        },
        async () => {
          await withFixtureCleanup(
            async () => {
              await context.setOffline(false);
              await page.close();
            },
            async () => {
              try {
                db.prepare('DELETE FROM workspace_items WHERE owner_id=?').run(owner.id);
                db.prepare('DELETE FROM auth_users WHERE id=?').run(owner.id);
                if (collaborator)
                  db.prepare('DELETE FROM auth_users WHERE id=?').run(collaborator.id);
              } finally {
                db.close();
              }
            },
          );
        },
      );
      if (authorityCaptureError) throw authorityCaptureError;
    },
  );
}
