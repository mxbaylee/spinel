import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { expect, test } from '@playwright/test';
import type { BrowserContext, ElementHandle } from '@playwright/test';
import sharp from 'sharp';
import { startApp, withFixtureCleanup } from './app-process.ts';
import type { OwnedAppProcess } from './app-process.ts';
import { openDatabase } from '../server/database.ts';
import { AuthStore, COOKIE_NAME } from '../src/server/auth/store.ts';
import { WorkspaceStore } from '../src/server/workspace/store.ts';

// One predeclared native clipboard observation; no synthetic paste event,
// product patch, intercepted upload, retry or alternate input on failure.
test('SPN-154 native PNG clipboard paste preserves the mounted Doc and saved text', async ({
  browser,
}, info) => {
  const directory = await mkdtemp(join(tmpdir(), 'spinel-spn154-'));
  const origin = 'http://localhost:33154';
  const evidence: Record<string, unknown> = {
    source: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
    browser: browser.version(),
    origin,
    viewport: { width: 1440, height: 1100 },
    physicalDevice: false,
    installedHomeScreen: false,
    ordinaryProduction: true,
    attempt: info.retry,
  };
  let app: OwnedAppProcess | undefined;
  let db: ReturnType<typeof openDatabase> | undefined;
  let context: BrowserContext | undefined;
  const network: unknown[] = [];
  const frames: unknown[] = [];
  const navigations: string[] = [];
  const pageErrors: string[] = [];
  const responseReads: Promise<void>[] = [];
  await withFixtureCleanup(
    async () => {
      app = await startApp({
        databasePath: join(directory, 'app.sqlite'),
        origin,
        development: false,
      });
      db = openDatabase(join(directory, 'app.sqlite'));
      const auth = new AuthStore(db);
      const owner = auth.createUser('Clipboard reproduction Owner');
      const item = new WorkspaceStore(auth).create(owner.id, {
        name: 'Clipboard reproduction',
        kind: 'doc',
        parentId: null,
      });
      context = await browser.newContext({
        baseURL: origin,
        viewport: { width: 1440, height: 1100 },
      });
      await context.grantPermissions(['clipboard-read', 'clipboard-write']);
      await context.addCookies([
        {
          name: COOKIE_NAME,
          value: auth.createSession(owner.id).token,
          url: origin.replace('http:', 'https:'),
          secure: true,
          httpOnly: true,
          sameSite: 'Strict',
        },
      ]);
      const page = await context.newPage();
      await page.addInitScript(() => {
        const state = { marker: crypto.randomUUID(), pastes: [] as unknown[] };
        Object.assign(window, { spinel154Observation: state });
        document.addEventListener(
          'paste',
          (event) =>
            state.pastes.push({
              trusted: event.isTrusted,
              types: [...(event.clipboardData?.types ?? [])],
              files: [...(event.clipboardData?.files ?? [])].map((file) => ({
                type: file.type,
                bytes: file.size,
              })),
            }),
          true,
        );
      });
      page.on('pageerror', (error) => pageErrors.push(error.message));
      page.on('framenavigated', (frame) => {
        if (frame === page.mainFrame()) navigations.push(new URL(frame.url()).pathname);
      });
      page.on('requestfailed', (request) =>
        network.push({
          path: new URL(request.url()).pathname,
          method: request.method(),
          failure: request.failure()?.errorText,
        }),
      );
      page.on('response', (response) => {
        const address = new URL(response.url());
        if (!address.pathname.includes('/images') && response.status() < 400) return;
        const request = response.request();
        const row: Record<string, unknown> = {
          path: address.pathname,
          method: request.method(),
          status: response.status(),
          contentType: request.headers()['content-type'],
          bytes: request.postDataBuffer()?.length,
        };
        network.push(row);
        if (response.status() >= 400)
          responseReads.push(
            response
              .text()
              .then((body) => {
                row.body = body;
              })
              .catch(() => {}),
          );
      });
      page.on('websocket', (socket) => {
        for (const [event, direction] of [
          ['framesent', 'sent'],
          ['framereceived', 'received'],
        ] as const) {
          socket.on(event, ({ payload }) => {
            try {
              const frame = JSON.parse(String(payload));
              if (['submit', 'verify', 'ack', 'edit', 'resume', 'resync'].includes(frame.type))
                frames.push({ direction, frame });
            } catch {
              /* Other sockets may carry binary frames. */
            }
          });
        }
      });
      const read = async () => {
        const response = await context!.request.get(`/api/items/${item.id}/doc`);
        expect(response.ok()).toBe(true);
        return response.json();
      };
      let beforeCanvas: ElementHandle<SVGElement | HTMLElement> | null = null;
      try {
        await page.goto(`/?item=${item.id}`);
        const editor = page.getByRole('region', { name: 'Doc document', exact: true });
        const status = editor.getByRole('status', { name: 'Save status' });
        await expect(status).toHaveText('All changes saved.', { timeout: 20_000 });
        const surface = editor.locator('.univer-container');
        await surface.click({ position: { x: 130, y: 200 } });
        const text = 'Clipboard sentinel 154';
        await page.keyboard.type(text);
        await expect.poll(async () => (await read()).snapshot.body.dataStream).toContain(text);
        await expect(status).toHaveText('All changes saved.');
        beforeCanvas = await surface.locator('canvas').first().elementHandle();
        expect(beforeCanvas).not.toBeNull();
        evidence.before = await read();
        evidence.beforePage = await page.evaluate(() => ({
          state: (window as unknown as { spinel154Observation: unknown }).spinel154Observation,
          online: navigator.onLine,
        }));
        const png = await sharp({
          create: { width: 20, height: 10, channels: 4, background: '#ff9900' },
        })
          .png()
          .toBuffer();
        evidence.image = {
          mime: 'image/png',
          bytes: png.length,
          sha256: createHash('sha256').update(png).digest('hex'),
          width: 20,
          height: 10,
        };
        await page.bringToFront();
        evidence.clipboard = await page.evaluate(
          async (bytes) => {
            await navigator.clipboard.write([
              new ClipboardItem({
                'image/png': new Blob([new Uint8Array(bytes)], { type: 'image/png' }),
              }),
            ]);
            const items = await navigator.clipboard.read();
            const blob = await items[0].getType('image/png');
            const digest = new Uint8Array(
              await crypto.subtle.digest('SHA-256', await blob.arrayBuffer()),
            );
            return {
              types: items.map((item) => item.types),
              bytes: blob.size,
              sha256: [...digest].map((n) => n.toString(16).padStart(2, '0')).join(''),
            };
          },
          [...png],
        );
        evidence.pasteStartedAt = new Date().toISOString();
        const beforeFrames = frames.length;
        await page.keyboard.press('ControlOrMeta+V');
        // Poll observation only; never repeat the paste or manufacture a refusal.
        await expect
          .poll(
            async () => {
              const after = await read();
              return (
                (after.snapshot.drawingsOrder?.length ?? 0) > 0 ||
                !(await beforeCanvas!.evaluate((node) => node.isConnected)) ||
                frames.slice(beforeFrames).some((value) => {
                  const row = value as { direction: string; frame: { type: string } };
                  return row.direction === 'received' && row.frame.type === 'resync';
                })
              );
            },
            {
              timeout: 20_000,
              message: 'Observe original image persistence or refusal/remount boundary',
            },
          )
          .toBe(true);
        evidence.after = await read();
        const after = evidence.after as {
          snapshot: { body: { dataStream: string }; drawingsOrder?: string[] };
        };
        expect(after.snapshot.drawingsOrder).toHaveLength(1);
        expect(after.snapshot.body.dataStream).toContain(text);
        expect(await beforeCanvas!.evaluate((node) => node.isConnected)).toBe(true);
        await expect(status).toHaveText('All changes saved.');
      } finally {
        evidence.after = await read().catch((error: Error) => ({ error: error.message }));
        evidence.imageRows = db
          .prepare('SELECT id,mime,length(data) AS bytes FROM doc_images WHERE item_id=?')
          .all(item.id);
        evidence.afterPage = await page
          .evaluate(() => ({
            state: (window as unknown as { spinel154Observation: unknown }).spinel154Observation,
            online: navigator.onLine,
            text: document.querySelector('.editor-help')?.textContent,
            status: document.querySelector('[role="status"][aria-label="Save status"]')
              ?.textContent,
          }))
          .catch((error: Error) => ({ error: error.message }));
        evidence.originalCanvasConnected = beforeCanvas
          ? await beforeCanvas.evaluate((node) => node.isConnected).catch(() => false)
          : null;
        evidence.network = network;
        evidence.frames = frames;
        evidence.navigations = navigations;
        evidence.pageErrors = pageErrors;
        await Promise.all(responseReads);
        await page
          .screenshot({ path: info.outputPath('observed-paste.png'), fullPage: true })
          .catch(() => {});
        await writeFile(
          info.outputPath('observation.json'),
          JSON.stringify(evidence, null, 2) + '\n',
        );
      }
    },
    () =>
      withFixtureCleanup(
        async () => {
          await context?.close();
        },
        () =>
          withFixtureCleanup(
            async () => {
              db?.close();
            },
            () =>
              withFixtureCleanup(
                async () => {
                  await app?.close();
                },
                () => rm(directory, { recursive: true, force: true }),
              ),
          ),
      ),
  );
});
