# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: admin.spec.ts >> operator removes a passkey from an open editor, then disables the account without deleting its document
- Location: e2e/admin.spec.ts:6:1

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e4]:
    - banner [ref=e5]:
      - generic [ref=e6]:
        - link [aria-hidden] [ref=e7] [cursor=pointer]:
          - /url: /
          - generic: Your docs
        - generic [ref=e34]:
          - status "Connection status" [ref=e35]: Online
          - button [aria-hidden] [ref=e36] [cursor=pointer]
      - navigation [aria-hidden] [ref=e39]:
        - link [ref=e40] [cursor=pointer]:
          - /url: /admin
          - generic [aria-hidden] [ref=e41]: ▦
          - generic: Admin
      - generic [aria-hidden] [ref=e42]:
        - radiogroup [ref=e44]:
          - radio [checked] [ref=e45] [cursor=pointer]
          - radio [checked] [aria-hidden] [ref=e48]
          - radio [ref=e49] [cursor=pointer]
          - radio [aria-hidden] [ref=e52]
          - radio [ref=e53] [cursor=pointer]
          - radio [aria-hidden] [ref=e56]
        - link [ref=e57] [cursor=pointer]:
          - /url: /profile
          - generic: Device operator d4043a9dd1ab94463227-dbea057afd529989b81f-0
    - main [ref=e63]:
      - generic [ref=e64]:
        - generic [ref=e65]:
          - paragraph [ref=e66]: SERVER OPERATOR
          - heading [level=1] [ref=e67]: Administration
        - generic [ref=e68]:
          - navigation [ref=e69]:
            - link [ref=e70] [cursor=pointer]:
              - /url: "#people"
              - text: People
            - link [ref=e71] [cursor=pointer]:
              - /url: "#invites"
              - text: Invites
            - link [ref=e72] [cursor=pointer]:
              - /url: "#connections"
              - text: Connections
            - link [ref=e73] [cursor=pointer]:
              - /url: "#health"
              - text: Backups & health
          - region [ref=e75]:
            - generic [ref=e76]:
              - heading [level=2] [ref=e77]: People
              - button [ref=e78] [cursor=pointer]: Refresh users
            - paragraph [ref=e79]: Manage the instance. Document content stays private.
            - status [ref=e80]: Passkey removed and its sessions ended.
            - list [ref=e81]:
              - listitem [ref=e82]:
                - region [ref=e83]:
                  - generic [ref=e84]:
                    - generic [ref=e85]:
                      - heading [level=3] [ref=e86]: Assistant operator
                      - paragraph [ref=e87]: Operator · Active
                      - paragraph [ref=e88]: 0 passkeys
                    - button [ref=e89] [cursor=pointer]: ···
              - listitem [ref=e90]:
                - region [ref=e91]:
                  - generic [ref=e92]:
                    - generic [ref=e93]:
                      - heading [level=3] [ref=e94]: Assistant owner
                      - paragraph [ref=e95]: Member · Active
                      - paragraph [ref=e96]: 0 passkeys
                    - button [ref=e97] [cursor=pointer]: ···
              - listitem [ref=e98]:
                - region [ref=e99]:
                  - generic [ref=e100]:
                    - generic [ref=e101]:
                      - heading [level=3] [ref=e102]: Departed collaborator 236df15a
                      - paragraph [ref=e103]: Member · Active
                      - paragraph [ref=e104]: 1 passkey
                    - button [ref=e105] [cursor=pointer]: ···
              - listitem [ref=e106]:
                - region [ref=e107]:
                  - generic [ref=e108]:
                    - generic [ref=e109]:
                      - heading [level=3] [ref=e110]: Device operator d4043a9dd1ab94463227-dbea057afd529989b81f-0 (you)
                      - paragraph [ref=e111]: Operator · Active
                      - paragraph [ref=e112]: 0 passkeys
                    - button [ref=e113] [cursor=pointer]: ···
                  - paragraph [ref=e114]: This is your admin account. It cannot disable itself.
              - listitem [ref=e115]:
                - region [ref=e116]:
                  - generic [ref=e117]:
                    - generic [ref=e118]:
                      - heading [level=3] [ref=e119]: Device owner d4043a9dd1ab94463227-dbea057afd529989b81f-0
                      - paragraph [ref=e120]: Member · Active
                      - paragraph [ref=e121]: 1 passkey
                    - button [ref=e122] [cursor=pointer]: ···
              - listitem [ref=e123]:
                - region [ref=e124]:
                  - generic [ref=e125]:
                    - generic [ref=e126]:
                      - heading [level=3] [ref=e127]: Everyday recipient 236df15a
                      - paragraph [ref=e128]: Member · Active
                      - paragraph [ref=e129]: 0 passkeys
                    - button [ref=e130] [cursor=pointer]: ···
              - listitem [ref=e131]:
                - region [ref=e132]:
                  - generic [ref=e133]:
                    - generic [ref=e134]:
                      - heading [level=3] [ref=e135]: Invite layout d247d1107d58feeba083-518f29cc69d9fac6cad2-0
                      - paragraph [ref=e136]: Operator · Active
                      - paragraph [ref=e137]: 0 passkeys
                    - button [ref=e138] [cursor=pointer]: ···
              - listitem [ref=e139]:
                - region [ref=e140]:
                  - generic [ref=e141]:
                    - generic [ref=e142]:
                      - heading [level=3] [ref=e143]: Layout member d247d1107d58feeba083-179967ed126f266d274a-0
                      - paragraph [ref=e144]: Member · Active
                      - paragraph [ref=e145]: 0 passkeys
                    - button [ref=e146] [cursor=pointer]: ···
              - listitem [ref=e147]:
                - region [ref=e148]:
                  - generic [ref=e149]:
                    - generic [ref=e150]:
                      - heading [level=3] [ref=e151]: Layout member d247d1107d58feeba083-969142e64f8c02707dbb-0
                      - paragraph [ref=e152]: Member · Active
                      - paragraph [ref=e153]: 0 passkeys
                    - button [ref=e154] [cursor=pointer]: ···
              - listitem [ref=e155]:
                - region [ref=e156]:
                  - generic [ref=e157]:
                    - generic [ref=e158]:
                      - heading [level=3] [ref=e159]: Layout operator d247d1107d58feeba083-179967ed126f266d274a-0
                      - paragraph [ref=e160]: Operator · Active
                      - paragraph [ref=e161]: 1 passkey
                    - button [ref=e162] [cursor=pointer]: ···
              - listitem [ref=e163]:
                - region [ref=e164]:
                  - generic [ref=e165]:
                    - generic [ref=e166]:
                      - heading [level=3] [ref=e167]: Layout operator d247d1107d58feeba083-969142e64f8c02707dbb-0
                      - paragraph [ref=e168]: Operator · Active
                      - paragraph [ref=e169]: 1 passkey
                    - button [ref=e170] [cursor=pointer]: ···
              - listitem [ref=e171]:
                - region [ref=e172]:
                  - generic [ref=e173]:
                    - generic [ref=e174]:
                      - heading [level=3] [ref=e175]: Recovery Operator 236df15a
                      - paragraph [ref=e176]: Operator · Active
                      - paragraph [ref=e177]: 0 passkeys
                    - button [ref=e178] [cursor=pointer]: ···
              - listitem [ref=e179]:
                - region [ref=e180]:
                  - generic [ref=e181]:
                    - generic [ref=e182]:
                      - heading [level=3] [ref=e183]: Retained collaborator 236df15a
                      - paragraph [ref=e184]: Member · Active
                      - paragraph [ref=e185]: 0 passkeys
                    - button [ref=e186] [cursor=pointer]: ···
              - listitem [ref=e187]:
                - region [ref=e188]:
                  - generic [ref=e189]:
                    - generic [ref=e190]:
                      - heading [level=3] [ref=e191]: Retained collaborator d4043a9dd1ab94463227-dbea057afd529989b81f-0
                      - paragraph [ref=e192]: Member · Active
                      - paragraph [ref=e193]: 0 passkeys
                    - button [ref=e194] [cursor=pointer]: ···
              - listitem [ref=e195]:
                - region [ref=e196]:
                  - generic [ref=e197]:
                    - generic [ref=e198]:
                      - heading [level=3] [ref=e199]: Stale layout d247d1107d58feeba083-c1910ddf820064a39b5c-0
                      - paragraph [ref=e200]: Operator · Active
                      - paragraph [ref=e201]: 0 passkeys
                    - button [ref=e202] [cursor=pointer]: ···
              - listitem [ref=e203]:
                - region [ref=e204]:
                  - generic [ref=e205]:
                    - generic [ref=e206]:
                      - heading [level=3] [ref=e207]: Unavailable recipient 236df15a
                      - paragraph [ref=e208]: Member · Disabled
                      - paragraph [ref=e209]: 0 passkeys
                    - button [ref=e210] [cursor=pointer]: ···
                  - paragraph [ref=e211]: Reactivate this account before creating a recovery invite.
              - listitem [ref=e212]:
                - region [ref=e213]:
                  - generic [ref=e214]:
                    - generic [ref=e215]:
                      - heading [level=3] [ref=e216]: Upgrade owner 43b259fe2228301dd04c-6d3997068d07551a59c3
                      - paragraph [ref=e217]: Member · Active
                      - paragraph [ref=e218]: 0 passkeys
                    - button [ref=e219] [cursor=pointer]: ···
              - listitem [ref=e220]:
                - region [ref=e221]:
                  - generic [ref=e222]:
                    - generic [ref=e223]:
                      - heading [level=3] [ref=e224]: Upgrade owner 43b259fe2228301dd04c-bab019f729f241ba82c1
                      - paragraph [ref=e225]: Member · Active
                      - paragraph [ref=e226]: 0 passkeys
                    - button [ref=e227] [cursor=pointer]: ···
              - listitem [ref=e228]:
                - region [ref=e229]:
                  - generic [ref=e230]:
                    - generic [ref=e231]:
                      - heading [level=3] [ref=e232]: Upgrade viewer 43b259fe2228301dd04c-6d3997068d07551a59c3
                      - paragraph [ref=e233]: Member · Active
                      - paragraph [ref=e234]: 0 passkeys
                    - button [ref=e235] [cursor=pointer]: ···
              - listitem [ref=e236]:
                - region [ref=e237]:
                  - generic [ref=e238]:
                    - generic [ref=e239]:
                      - heading [level=3] [ref=e240]: Upgrade viewer 43b259fe2228301dd04c-bab019f729f241ba82c1
                      - paragraph [ref=e241]: Member · Active
                      - paragraph [ref=e242]: 0 passkeys
                    - button [ref=e243] [cursor=pointer]: ···
  - dialog [ref=e247]:
    - generic [ref=e248]:
      - heading "Passkeys for Device owner d4043a9dd1ab94463227-dbea057afd529989b81f-0" [level=2] [ref=e249]
      - button "Close dialog" [ref=e255] [cursor=pointer]: ×
    - generic [ref=e256]:
      - list "Device owner d4043a9dd1ab94463227-dbea057afd529989b81f-0 passkeys" [ref=e257]:
        - listitem [ref=e258]:
          - generic [ref=e259]:
            - strong [ref=e260]: Backup passkey
            - paragraph [ref=e261]: Browser
            - paragraph [ref=e262]: Added 11/20/2026, 11:05:01 PM · Last used Never
          - button "Actions for passkey Backup passkey" [ref=e263] [cursor=pointer]: ···
      - button "Done" [ref=e264] [cursor=pointer]
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test';
  2   | import { openDatabase } from '../server/database.ts';
  3   | import { AuthStore, COOKIE_NAME } from '../src/server/auth/store.ts';
  4   | import { WorkspaceStore } from '../src/server/workspace/store.ts';
  5   | 
  6   | test('operator removes a passkey from an open editor, then disables the account without deleting its document', async ({
  7   |   page,
  8   |   context,
  9   |   browser,
  10  |   baseURL,
  11  | }, info) => {
  12  |   test.setTimeout(90_000);
  13  |   const db = openDatabase(`test-results/${info.project.name}/app.sqlite`),
  14  |     auth = new AuthStore(db),
  15  |     workspace = new WorkspaceStore(auth);
  16  |   const runId = `${info.testId}-${info.retry}`;
  17  |   const operator = auth.createUser('Device operator ' + runId, true),
  18  |     user = auth.createUser('Device owner ' + runId),
  19  |     collaborator = auth.createUser('Retained collaborator ' + runId);
  20  |   const item = workspace.create(user.id, {
  21  |     name: 'Preserved budget',
  22  |     kind: 'sheet',
  23  |     parentId: null,
  24  |   });
  25  |   workspace.share(user.id, item.id, collaborator.id, 'editor');
  26  |   for (const key of ['Lost browser', 'Backup passkey'])
  27  |     db.prepare('INSERT INTO auth_passkeys VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(
  28  |       `${runId}-${key}`,
  29  |       user.id,
  30  |       Buffer.from([1]),
  31  |       0,
  32  |       '[]',
  33  |       key,
  34  |       'Browser',
  35  |       auth.now(),
  36  |       null,
  37  |       0,
  38  |       'singleDevice',
  39  |     );
  40  |   const adminSession = auth.createSession(operator.id),
  41  |     device = auth.createSession(user.id, undefined, `${runId}-Lost browser`),
  42  |     kept = auth.createSession(user.id, undefined, `${runId}-Backup passkey`),
  43  |     collaboratorSession = auth.createSession(collaborator.id);
  44  |   const editorContext = await browser.newContext({ viewport: { width: 1440, height: 1100 } }),
  45  |     editor = await editorContext.newPage();
  46  |   const cookie = (token: string) => ({
  47  |     name: COOKIE_NAME,
  48  |     value: token,
  49  |     url: baseURL!.replace('http:', 'https:'),
  50  |     secure: true,
  51  |     httpOnly: true,
  52  |     sameSite: 'Strict' as const,
  53  |   });
  54  |   await context.addCookies([cookie(adminSession.token)]);
  55  |   await editorContext.addCookies([cookie(device.token)]);
  56  |   let closed = 0;
  57  |   editor.on('websocket', (socket) => {
  58  |     if (new URL(socket.url()).pathname !== `/sync-api/items/${item.id}/socket`) return;
  59  |     socket.on('close', () => {
  60  |       closed++;
  61  |     });
  62  |   });
  63  |   const saved = editor.getByRole('status', { name: 'Save status' });
  64  |   const expectRevoked = async (closedBefore: number) => {
> 65  |     await expect.poll(() => closed).toBeGreaterThan(closedBefore);
      |                                     ^ Error: expect(received).toBeGreaterThan(expected)
  66  |     // Native sync fences the editor; another authenticated request may already
  67  |     // have redirected to sign-in. Both are valid, unlike a generic page error.
  68  |     await expect(
  69  |       saved
  70  |         .filter({ hasText: /^Access changed\./ })
  71  |         .or(editor.getByRole('button', { name: 'Sign in with a passkey', exact: true })),
  72  |     ).toBeVisible({ timeout: 10_000 });
  73  |     expect(
  74  |       (await editorContext.request.get(`${baseURL}/api/items/${item.id}/sheet`)).status(),
  75  |     ).toBe(401);
  76  |   };
  77  |   const failures: unknown[] = [];
  78  |   try {
  79  |     await editor.goto(`${baseURL}/?item=${item.id}`);
  80  |     await expect(saved).toHaveText('All changes saved.', { timeout: 30_000 });
  81  |     const box = editor
  82  |       .getByRole('region', { name: 'Sheet document', exact: true })
  83  |       .getByRole('textbox')
  84  |       .nth(2);
  85  |     await box.fill('A1');
  86  |     await box.press('Enter');
  87  |     await editor.keyboard.type('Keep this');
  88  |     await editor.keyboard.press('Enter');
  89  |     await expect
  90  |       .poll(async () =>
  91  |         JSON.stringify(
  92  |           (await (await editorContext.request.get(`${baseURL}/api/items/${item.id}/sheet`)).json())
  93  |             .snapshot,
  94  |         ),
  95  |       )
  96  |       .toContain('Keep this');
  97  |     await expect(saved).toHaveText('All changes saved.');
  98  |     await page.goto('/admin');
  99  |     const account = page.getByRole('region', { name: `${user.name} account`, exact: true });
  100 |     await expect(account.getByText('Member · Active', { exact: true })).toBeVisible();
  101 |     await account.getByRole('button', { name: `Actions for ${user.name}`, exact: true }).click();
  102 |     await page.getByRole('menuitem', { name: 'Manage passkeys' }).click();
  103 |     const passkeys = page.getByRole('dialog', { name: `Passkeys for ${user.name}`, exact: true });
  104 |     await expect(passkeys.getByText(/Last used Never/)).toHaveCount(2);
  105 |     await passkeys
  106 |       .getByRole('button', { name: 'Actions for passkey Lost browser', exact: true })
  107 |       .click();
  108 |     await page.getByRole('menuitem', { name: 'Remove passkey…' }).click();
  109 |     const dialog = page.getByRole('dialog', { name: 'Remove Lost browser?', exact: true });
  110 |     await dialog.getByRole('button', { name: 'Cancel', exact: true }).click();
  111 |     expect(auth.session(device.token)).toBeDefined();
  112 |     await passkeys
  113 |       .getByRole('button', { name: 'Actions for passkey Lost browser', exact: true })
  114 |       .click();
  115 |     await page.getByRole('menuitem', { name: 'Remove passkey…' }).click();
  116 |     const closedBeforeRemoval = closed;
  117 |     await dialog.getByRole('button', { name: 'Confirm removal' }).click();
  118 |     await expect(passkeys.getByText('Lost browser', { exact: true })).toHaveCount(0);
  119 |     await expectRevoked(closedBeforeRemoval);
  120 |     expect(auth.session(device.token)).toBeUndefined();
  121 |     expect(auth.session(kept.token)?.user_id).toBe(user.id);
  122 |     // A revoked page can navigate to sign-in. Start the retained device at the
  123 |     // actual item address after unloading its old session's pending work.
  124 |     await editor.goto('about:blank');
  125 |     await editorContext.clearCookies();
  126 |     await editorContext.addCookies([cookie(kept.token)]);
  127 |     await editor.goto(`${baseURL}/?item=${item.id}`);
  128 |     await expect(saved).toHaveText('All changes saved.', { timeout: 30_000 });
  129 |     const keptCopy = await editorContext.request.get(`${baseURL}/api/items/${item.id}/sheet`);
  130 |     expect(keptCopy.status()).toBe(200);
  131 |     expect(JSON.stringify((await keptCopy.json()).snapshot)).toContain('Keep this');
  132 |     await passkeys.getByRole('button', { name: 'Done', exact: true }).click();
  133 |     await account.getByRole('button', { name: `Actions for ${user.name}`, exact: true }).click();
  134 |     await page.getByRole('menuitem', { name: 'Disable account…' }).click();
  135 |     const closedBeforeDisable = closed;
  136 |     await page
  137 |       .getByRole('dialog', { name: `Disable ${user.name}?`, exact: true })
  138 |       .getByRole('button', { name: 'Confirm removal' })
  139 |       .click();
  140 |     await expect(account.getByText('Member · Disabled', { exact: true })).toBeVisible();
  141 |     await expectRevoked(closedBeforeDisable);
  142 |     expect(auth.session(kept.token)).toBeUndefined();
  143 |     expect(workspace.get(collaborator.id, item.id, 'edit').access).toBe('editor');
  144 |     const sharedCopy = await context.request.get(`/api/items/${item.id}/sheet`, {
  145 |       headers: { Cookie: `${COOKIE_NAME}=${collaboratorSession.token}` },
  146 |     });
  147 |     expect(sharedCopy.status()).toBe(200);
  148 |     expect(JSON.stringify((await sharedCopy.json()).snapshot)).toContain('Keep this');
  149 |     expect(
  150 |       db.prepare('SELECT owner_id FROM workspace_items WHERE id=?').get(item.id)?.owner_id,
  151 |     ).toBe(user.id);
  152 |     expect((await context.request.get(`/api/items/${item.id}/sheet`)).status()).toBe(403);
  153 |     expect((await context.request.get('/api/auth/invites')).status()).toBe(200);
  154 |   } catch (error) {
  155 |     failures.push(error);
  156 |   }
  157 |   try {
  158 |     await editorContext.close();
  159 |   } catch (error) {
  160 |     failures.push(error);
  161 |   }
  162 |   try {
  163 |     db.close();
  164 |   } catch (error) {
  165 |     failures.push(error);
```