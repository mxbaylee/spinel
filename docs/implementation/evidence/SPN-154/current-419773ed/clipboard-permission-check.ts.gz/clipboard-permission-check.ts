import { createServer } from 'node:http';
import assert from 'node:assert/strict';
import { chromium } from '/Users/mxbaylee/projects/spinel-spn-154-completion-20261122/node_modules/playwright/index.mjs';
const server = createServer((_request, response) => response.end('<!doctype html><title>Clipboard permission fixture</title>'));
await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
const address = server.address();
assert.ok(address && typeof address === 'object');
const origin = `http://127.0.0.1:${address.port}`;
const browser = await chromium.launch();
try {
  const context = await browser.newContext({ permissions: ['clipboard-read', 'clipboard-write'] });
  const page = await context.newPage();
  await page.goto(origin);
  const cdp = await context.newCDPSession(page);
  const { targetInfo } = await cdp.send('Target.getTargetInfo');
  assert.ok(targetInfo.browserContextId);
  await cdp.send('Browser.setPermission', { permission: { name: 'clipboard-read' }, setting: 'denied', origin, browserContextId: targetInfo.browserContextId });
  const outcome = await page.evaluate(async () => ({
    permission: (await navigator.permissions.query({ name: 'clipboard-read' as PermissionName })).state,
    read: await navigator.clipboard.read().then(() => 'unexpected success', error => error.name),
  }));
  assert.deepEqual(outcome, { permission: 'denied', read: 'NotAllowedError' });
  console.log(JSON.stringify({ browser: browser.version(), outcome, scope: 'Real browser permission fixture only; not application or phone acceptance' }));
  await context.close();
} finally {
  await browser.close();
  await new Promise<void>(resolve => server.close(() => resolve()));
}
