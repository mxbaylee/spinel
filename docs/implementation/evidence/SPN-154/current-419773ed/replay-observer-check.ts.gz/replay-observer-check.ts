import { readFileSync } from 'node:fs';
import { stripTypeScriptTypes } from 'node:module';
import { runInNewContext } from 'node:vm';
import assert from 'node:assert/strict';
import { expect } from '/Users/mxbaylee/projects/spinel-spn-154-completion-20261122/node_modules/@playwright/test/index.mjs';
const root = '/Users/mxbaylee/projects/spinel-spn-154-completion-20261122';
const source = readFileSync(`${root}/e2e/documents.spec.ts`, 'utf8');
const code = source.slice(source.indexOf('function expectOriginalBodyAfterImage('), source.indexOf('type ImagePostEvidence'));
const check = runInNewContext(`${stripTypeScriptTypes(code)}; expectOriginalBodyAfterImage`, { expect, structuredClone });
const evidence = JSON.parse(readFileSync('/private/tmp/spn154-completion/menu-first-failure-evidence.json', 'utf8'));
const original = evidence.stages[0].saved;
const firstPaste = evidence.stages[1].saved;
const replay = evidence.stages[2].saved;
check(firstPaste, original);
check(replay, original);
for (const [name, mutate] of [
  ['text', (s) => { s.body.dataStream = s.body.dataStream.replace('Phone', 'Wrong'); }],
  ['bold', (s) => { s.body.textRuns.at(-1).ts.bl = 0; }],
  ['paragraph identity', (s) => { s.body.paragraphs[1].paragraphId = 'changed'; }],
  ['paragraph formatting', (s) => { s.body.paragraphs[1].paragraphStyle = { spaceAbove: { v: 99 } }; }],
  ['section identity', (s) => { s.body.sectionBreaks[0].sectionId = 'changed'; }],
  ['image linkage', (s) => { s.body.customBlocks[0].blockId = 'missing'; }],
] as const) {
  const changed = structuredClone(replay);
  mutate(changed);
  assert.throws(() => check(changed, original), `must reject changed ${name}`);
}
console.log('PASS: retained first paste/replay accepted; six original-content/linkage mutations rejected.');
