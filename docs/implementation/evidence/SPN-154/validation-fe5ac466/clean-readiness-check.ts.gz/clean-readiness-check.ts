// Existing deterministic fixtures copied unchanged from src/ui/offlineStoreProtection.test.ts.
import assert from 'node:assert/strict';
import { hasStoredEdits } from '/Users/mxbaylee/projects/spinel-spn-154-completion-20261122/web/offline/offlineStore.ts';
import type { StoredItem, OfflineOutbox } from '/Users/mxbaylee/projects/spinel-spn-154-completion-20261122/web/offline/offlineStore.ts';
const account = 'protected-account'; const itemId = 'protected-document';
function cleanCopy(): StoredItem {
  return {
    itemId,
    name: 'Protected notes',
    kind: 'doc',
    readOnly: false,
    revision: 3,
    downloadedAt: 1,
    bundle: {
      version: 1,
      accountId: account,
      itemId,
      unitId: itemId,
      name: 'Protected notes',
      kind: 'doc',
      access: 'owner',
      readOnly: false,
      revision: 3,
      revisionOffset: 0,
      sdkVersion: '1.3.1',
      images: [],
      snapshot: { id: itemId, body: { dataStream: 'Original notes\r\n' }, documentStyle: {} },
    },
  };
}

function cleanOutbox(): OfflineOutbox {
  return {
    version: 1,
    account,
    item: itemId,
    unitId: itemId,
    revisionOffset: 0,
    checkpoint: {
      version: 1,
      unitId: itemId,
      revision: 3,
      snapshot: cleanCopy().bundle.snapshot,
      sent: null,
      inflight: [],
      buffer: [],
    },
  };
}

function pendingCopy() {
  const outbox = cleanOutbox();
  outbox.checkpoint.buffer = [
    [{ id: 'doc.mutation.rich-text-editing', params: { unitId: itemId, text: 'Keep this work' } }],
  ];
  return { ...cleanCopy(), outbox };
}


assert.equal(hasStoredEdits(cleanCopy()), false);
assert.equal(hasStoredEdits({...cleanCopy(), outbox:cleanOutbox()}), false);
assert.equal(hasStoredEdits(pendingCopy()), true);
const failed = cleanOutbox(); failed.checkpoint.failure = 'stale';
assert.equal(hasStoredEdits({...cleanCopy(),outbox:failed}),true);
assert.equal(hasStoredEdits({...cleanCopy(),recovery:{}}),true);
assert.equal(hasStoredEdits({...cleanCopy(),outbox:{}}),true);
assert.equal(hasStoredEdits(null),true);
console.log('PASS: two clean representations; pending/failure/recovery/malformed/missing retained.');
