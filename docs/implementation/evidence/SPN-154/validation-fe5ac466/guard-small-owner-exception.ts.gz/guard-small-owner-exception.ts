// SPN-154-only owner-authorized tiny workloads: pressure 1/2, cap256MiB.
// Child remains in serial runner group so its 15-second kill reaches the test.
import { spawn, execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
const [label, command, ...args] = process.argv.slice(2);
const start = Date.now();
const child = spawn(command, args, { stdio: 'inherit', detached: false });
const tracked = new Set<number>();
let peakKiB = 0;
let aborted: string | null = null;
const stop = (reason: string) => {
  aborted ??= reason;
  for (const pid of tracked) { try { process.kill(pid, 'SIGTERM'); } catch {} }
  setTimeout(() => { for (const pid of tracked) { try { process.kill(pid, 'SIGKILL'); } catch {} } }, 5500).unref();
};
const sample = () => {
  try {
    const rows = execFileSync('ps', ['-axo', 'pid=,ppid=,pgid=,rss='], { encoding: 'utf8' }).trim().split('\n').map(line => line.trim().split(/\s+/).map(Number));
    const owned = new Set([child.pid, ...tracked]);
    for (let size = -1; size !== owned.size;) {
      size = owned.size;
      for (const [pid, parent, group] of rows) if (owned.has(parent) || group === child.pid) owned.add(pid);
    }
    for (const pid of owned) if (pid) tracked.add(pid);
    const rss = rows.reduce((sum, [pid, , , value]) => sum + (owned.has(pid) ? value : 0), 0);
    peakKiB = Math.max(peakKiB, rss);
    const pressure = process.platform === 'darwin' ? execFileSync('sysctl', ['-n', 'kern.memorystatus_vm_pressure_level'], { encoding: 'utf8' }).trim() : '1';
    if ((pressure !== '1' && pressure !== '2') || rss > 256 * 1024) stop(`pressure=${pressure}, rssKiB=${rss}`);
  } catch (error) { stop(`watchdog observation failed: ${error}`); }
};
const timer = setInterval(sample, 250);
for (const signal of ['SIGTERM', 'SIGINT', 'SIGHUP'] as const) process.on(signal, () => stop(signal));
child.on('error', error => stop(String(error)));
child.on('exit', (code, signal) => {
  clearInterval(timer);
  const result = { label, command, args, code, signal, aborted, elapsedMs: Date.now() - start, peakKiB };
  writeFileSync(`/tmp/spn154-completion/${label}.json`, JSON.stringify(result, null, 2) + '\n');
  console.log('WATCHDOG', JSON.stringify(result));
  process.exit(aborted ? 75 : code ?? 1);
});
