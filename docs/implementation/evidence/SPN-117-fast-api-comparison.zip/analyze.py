import hashlib
import json
from pathlib import Path
import re

root = Path('/tmp/spn117-fast-api-comparison')
summary = {'scope': 'Compiled fast API path exclusion and bounded UTF-8/HTTP equality; no rare-abort reproduction.', 'modes': {}}
results = {}
for mode in ['baseline', 'disabled']:
    result = json.loads((root / mode / 'result.json').read_text())
    results[mode] = result
    paths = list((root / mode / 'graphs').glob('*.json'))
    assert len(paths) == 1
    graph = json.loads(paths[0].read_text())
    assert graph['function']['functionName'] == 'spn117ByteLength'
    disassembly = next(phase['data'] for phase in graph['phases'] if phase['type'] == 'disassembly')
    assert 'kind = TURBOFAN_JS' in disassembly
    assert 'compiler = turbofan' in disassembly
    assert re.search(r'Instructions \(size = [1-9][0-9]*\)', disassembly)
    assert result['statusBefore'] == 41 and result['statusAfter'] == 41
    stdout = (root / mode / 'stdout.log').read_text()
    assert 'Finished compiling method spn117ByteLength using TurboFan' in stdout
    assert not any('bailout' in line and 'spn117ByteLength' in line for line in stdout.splitlines())
    graph_phases = [phase for phase in graph['phases'] if phase['type'] == 'graph']
    final = graph_phases[-1]
    assert final['name'] == 'V8.TFEarlyOptimization'
    nodes = final['data']['nodes']
    end_ids = {node['id'] for node in nodes if node['opcode'] == 'End'}
    assert end_ids
    reachable = set(end_ids)
    while True:
        upstream = {edge['source'] for edge in final['data']['edges'] if edge['target'] in reachable}
        if upstream <= reachable:
            break
        reachable.update(upstream)
    fast_nodes = [node for node in nodes if node.get('opcode') == 'FastApiCall']
    decoded = []
    for node in fast_nodes:
        assert node['live'] and node['id'] in reachable
        source = graph['sources']['0']
        assert source['sourceName'] == 'node:buffer' and source['functionName'] == 'byteLength'
        offset = node['sourcePosition']['scriptOffset'] - source['startPosition']
        snippet = source['sourceText'][max(0, offset - 60):offset + 80]
        address = int(re.search(r'FastApiCall\[(\d+):', node['label']).group(1))
        lines = disassembly.splitlines()
        matching = [index for index, line in enumerate(lines) if hex(address) in line]
        assert matching
        decoded.append({
            'node_id': node['id'], 'type': node['type'], 'live': True,
            'reachable_from_end': True, 'source_snippet': snippet,
            'c_function_address': hex(address),
            'emitted_instruction_context': [lines[max(0, index - 1):index + 3] for index in matching],
        })
    any_phase_fast = any(
        node.get('opcode') == 'FastApiCall'
        for phase in graph_phases for node in phase['data']['nodes']
    )
    if mode == 'baseline':
        utf8 = [node for node in decoded if node['type'] == 'Unsigned32' and 'byteLengthUtf8(string)' in node['source_snippet']]
        assert len(utf8) == 1 and any_phase_fast
    else:
        assert not fast_nodes and not any_phase_fast
    summary['modes'][mode] = {
        'graph_file': str(paths[0].relative_to(root)),
        'graph_sha256': hashlib.sha256(paths[0].read_bytes()).hexdigest(),
        'completed_turbofan_compilation': True,
        'status_before_and_after': [result['statusBefore'], result['statusAfter']],
        'final_tf_graph_phase': final['name'],
        'live_fast_api_nodes': decoded,
        'final_disassembly_instruction_bytes': int(re.search(r'Instructions \(size = (\d+)\)', disassembly).group(1)),
        'length_cases': len(result['lengths']), 'http_requests': result['served'],
        'liveness_before_close': result['livenessBeforeClose'],
    }
assert results['baseline']['lengths'] == results['disabled']['lengths']
assert results['baseline']['http'] == results['disabled']['http']
summary['identical_expected_and_actual_utf8_lengths'] = True
summary['identical_http_bytes_content_length_and_sha256'] = True
summary['passes'] = True
(root / 'analysis.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
