import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { writeFileSync } from 'node:fs';
import { createServer, request } from 'node:http';
import type { AddressInfo } from 'node:net';
import { join } from 'node:path';

// One bounded mechanism comparison, not a reproducer of the rare CI abort.
// The paired runner changes only --no-turbo-fast-api-calls between processes.
const [mode, outputDirectory] = process.argv.slice(2);
assert.ok(mode === 'baseline' || mode === 'disabled');
assert.ok(outputDirectory);
assert.equal(process.version, 'v26.12.1');
assert.equal(process.execArgv.includes('--no-turbo-fast-api-calls'), mode === 'disabled');

const encoder = new TextEncoder();
const largeUnits = 4_880_691;
const small = [
  { name: 'ascii', value: 'hello', bytes: 5 },
  { name: 'latin1', value: 'café', bytes: 5 },
  { name: 'two-byte-bmp', value: '文書', bytes: 6 },
  { name: 'astral', value: 'a😀b', bytes: 6 },
  { name: 'lone-high-surrogate', value: '\ud800', bytes: 3 },
  { name: 'lone-low-surrogate', value: '\udc00', bytes: 3 },
];
const large = [
  { name: 'large-ascii', unit: 'x', bytes: 1 },
  { name: 'large-latin1', unit: 'é', bytes: 2 },
  { name: 'large-two-byte-bmp', unit: '字', bytes: 3 },
  { name: 'large-mixed-surrogates', unit: '😀\ud800a\udc00字', bytes: 14 },
];

function makeLarge(index: number) {
  const pattern = large[index];
  const tail = `\n//# sourceMappingURL=data:application/json;base64,e30=;case${index}`;
  const prefixUnits = largeUnits - tail.length;
  const repeats = Math.floor(prefixUnits / pattern.unit.length);
  const remainder = pattern.unit.slice(0, prefixUnits % pattern.unit.length);
  const expectedBytes = repeats * pattern.bytes + encoder.encode(remainder).length + tail.length;
  // Only .length is inspected before the target call: do not pre-flatten value.
  const value = pattern.unit.repeat(repeats) + remainder + tail;
  assert.equal(value.length, largeUnits);
  return { name: pattern.name, value, bytes: expectedBytes };
}

function spn117ByteLength(value: string) {
  return Buffer.byteLength(value);
}

// These diagnostics are intentionally confined to this temporary probe.
const prepare = new Function('target', '%PrepareFunctionForOptimization(target);');
const optimize = new Function('target', '%OptimizeFunctionOnNextCall(target);');
const optimizationStatus = new Function('target', 'return %GetOptimizationStatus(target);');
// Official pinned Node/V8 runtime.h, commit bc2e01d, lines 1117 onward:
// kOptimized = 1 << 3, kTurboFanned = 1 << 5.
const optimizedAndTurboFanned = (1 << 3) | (1 << 5);
prepare(spn117ByteLength);
for (let index = 0; index < 64; index += 1) {
  const item = small[index % small.length];
  assert.equal(spn117ByteLength(item.value), item.bytes);
}
optimize(spn117ByteLength);
assert.equal(spn117ByteLength(small[0].value), small[0].bytes);
const statusBefore = optimizationStatus(spn117ByteLength) as number;
assert.equal(statusBefore & optimizedAndTurboFanned, optimizedAndTurboFanned);

const lengths = [];
for (const item of small) {
  const actual = spn117ByteLength(item.value);
  assert.equal(actual, item.bytes, item.name);
  lengths.push({ name: item.name, codeUnits: item.value.length, expectedBytes: item.bytes, actual });
}
for (let index = 0; index < large.length; index += 1) {
  const item = makeLarge(index);
  const actual = spn117ByteLength(item.value);
  assert.equal(actual, item.bytes, item.name);
  lengths.push({ name: item.name, codeUnits: item.value.length, expectedBytes: item.bytes, actual });
}
const statusAfter = optimizationStatus(spn117ByteLength) as number;
assert.equal(statusAfter & optimizedAndTurboFanned, optimizedAndTurboFanned);
console.log(JSON.stringify({ stage: 'lengths-complete', mode, statusBefore, statusAfter, lengths }));

// Exactly eight HTTP requests: six GETs and two HEADs, no retries.
const httpCases = [
  { method: 'GET', create: () => small[1] },
  { method: 'GET', create: () => small[3] },
  { method: 'GET', create: () => makeLarge(0) },
  { method: 'GET', create: () => makeLarge(1) },
  { method: 'GET', create: () => makeLarge(2) },
  { method: 'GET', create: () => makeLarge(3) },
  { method: 'HEAD', create: () => small[2] },
  { method: 'HEAD', create: () => makeLarge(2) },
];
let served = 0;
const httpResults: unknown[] = [];
const server = createServer((req, res) => {
  const index = Number(req.url?.slice(1));
  assert.ok(Number.isInteger(index) && index >= 0 && index < httpCases.length);
  const item = httpCases[index].create();
  assert.equal(req.method, httpCases[index].method);
  assert.equal(res.headersSent, false);
  res.sendDate = false;
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  served += 1;
  // Preserve the failing API shape: end(string), implicit headers, no encoding.
  res.end(item.value);
});
server.listen(0, '127.0.0.1');
await new Promise<void>((resolve, reject) => {
  server.once('listening', resolve);
  server.once('error', reject);
});
const port = (server.address() as AddressInfo).port;
try {
  for (let index = 0; index < httpCases.length; index += 1) {
    const testCase = httpCases[index];
    const response = await new Promise<{ status: number | undefined; length: string | undefined; data: Buffer }>(
      (resolve, reject) => {
        const req = request({ host: '127.0.0.1', port, path: `/${index}`, method: testCase.method }, (res) => {
          const chunks: Buffer[] = [];
          res.on('data', (chunk: Buffer) => chunks.push(chunk));
          res.once('error', reject);
          res.once('end', () => resolve({
            status: res.statusCode,
            length: res.headers['content-length'],
            data: Buffer.concat(chunks),
          }));
        });
        req.once('error', reject);
        req.end();
      },
    );
    // Build the independent expected value after the server has already sent it.
    const expected = testCase.create();
    const expectedData = testCase.method === 'HEAD' ? new Uint8Array() : encoder.encode(expected.value);
    assert.equal(response.status, 200);
    assert.equal(response.data.length, expectedData.length, expected.name);
    assert.ok(response.data.equals(expectedData), expected.name);
    if (testCase.method === 'GET') assert.equal(response.length, String(expected.bytes));
    if (response.length !== undefined) assert.equal(response.length, String(expected.bytes));
    httpResults.push({
      name: expected.name,
      method: testCase.method,
      status: response.status,
      contentLength: response.length ?? null,
      receivedBytes: response.data.length,
      sha256: createHash('sha256').update(response.data).digest('hex'),
    });
  }
  assert.equal(served, 8);
  assert.equal(server.listening, true);
} finally {
  await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
}

const result = {
  mode,
  node: process.version,
  v8: process.versions.v8,
  platform: process.platform,
  arch: process.arch,
  argv: process.execArgv,
  warmupCalls: 64,
  forcedOptimizationCalls: 1,
  statusBefore,
  statusAfter,
  lengths,
  http: httpResults,
  served,
  livenessBeforeClose: true,
};
writeFileSync(join(outputDirectory, 'result.json'), `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify({ stage: 'complete', mode, lengthCases: lengths.length, httpRequests: served }));
