import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/tmp/spn117-fast-api-comparison')
node = '/tmp/node-v26.12.1-linux-x64/bin/node'
manifest = {
    'description': 'One fixed baseline/disabled comparison; not rare-abort reproduction.',
    'timeout_seconds_per_child': 45,
    'runs': [],
}
for mode in ['baseline', 'disabled']:
    out = root / mode
    out.mkdir(exist_ok=False)
    graphs = out / 'graphs'
    graphs.mkdir()
    command = [node, '--max-old-space-size=512', '--max-semi-space-size=8',
               '--allow-natives-syntax', '--no-concurrent-recompilation',
               '--trace-opt', '--trace-deopt', '--trace-turbo',
               '--trace-turbo-filter=spn117ByteLength', f'--trace-turbo-path={graphs}']
    if mode == 'disabled':
        command.append('--no-turbo-fast-api-calls')
    command += [str(root / 'probe.ts'), mode, str(out)]
    (out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
    entry = {'mode': mode, 'command': command, 'started_unix': time.time()}
    manifest['runs'].append(entry)
    (root / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    started = time.monotonic()
    print(f'SPN117 comparison: starting {mode}', flush=True)
    with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        try:
            completed = subprocess.run(command, cwd=out, stdout=stdout, stderr=stderr, timeout=45)
            entry['exit_code'] = completed.returncode
            entry['timed_out'] = False
        except subprocess.TimeoutExpired:
            entry['exit_code'] = None
            entry['timed_out'] = True
    entry['elapsed_seconds'] = round(time.monotonic() - started, 3)
    entry['finished_unix'] = time.time()
    (root / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: value for key, value in entry.items() if key != 'command'}), flush=True)
sys.exit(0 if all(run.get('exit_code') == 0 for run in manifest['runs']) else 1)
