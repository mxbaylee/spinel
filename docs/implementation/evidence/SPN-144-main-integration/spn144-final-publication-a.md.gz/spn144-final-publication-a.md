# 📦 SPN-144 independent publication verification

Verified published archive commit `02541cea2c28adadb988394be84515effa205b22`, remote tag `archive/spn-144-acceptance-7b06d751`, under `docs/review-assets/spn-144-acceptance-7b06d751`.

## 🔎 Integrity and completeness

The remote ref resolves to the exact archive commit. Its tree has exactly **305 regular blobs**: **304 payloads totaling 640,487,657 bytes**, plus `SHA256SUMS`. Manifest SHA256 is `f7980c7d12c6f32b11c16f0e8582f23ca0f93455f32a25953ac58d2d8a30977c`.

Independently streamed every Git blob, recomputed both its Git SHA1 identity and manifest SHA256, and compared its bytes/hash with the frozen local input. The exact selected file set matches, with no unlisted tree files. All checks passed. Frozen inputs were not modified.

Both callback archives retain all **81 non-SQLite members each**, exactly matching the original member proofs, byte lengths and hashes. Both roles retain original protobuf gzip and derived JSON gzip; complete source/maps, summaries, receipts and cleanup evidence remain present. Each original ZIP had 93 members; the 12 disposable SQLite members per ZIP have their original names, bytes, CRC and hashes recorded. Oversized callback ZIP containers are excluded from Git, with their original container identities and full member proofs preserved. No trace/source member is omitted. Both responsiveness archives retain all **18 members each**, and their complete ZIP identities also match.

The archived identity binds source `7b06d7516c4c386f5a23044e74d0c09b95a5a929`, base `1045e729c391c47a9b6a895782a2fa69dc6fa044`, tested merge `eb91917064bd9d7665683fade860cd82457fbca4`, and equal source/tested tree `d451532408b37f1cb5da12511c6fca38520599e2`. Terminal CI `41959231289` attempt 1 retains all 33 successful jobs and the exact seven successful gates. Storybook `41959231266` is successful on the same source. Both final independent acceptance reports and all four owner reports are archived.

## 🧪 Verification execution and limits

The first helper pass completed all blob/local hashes, then rejected its own obsolete expected derived-trace name `spn113-trace.json.gz`. The actual reviewed output is `spn144-derived.json.gz`. This was a verification-script naming error, not an archive discrepancy. The original helper, log and watchdog are preserved outside the frozen root. Correcting only that assertion produced a complete passing proof in **8,172 ms**, sampled peak **300,512 KiB**, normal pressure. The first attempt was 8,403 ms / 304,880 KiB. The script structure repeated streaming integrity checks; no application, converter, browser or benchmark execution was repeated.

Proof: `/tmp/spn144-final-publication-a.json`; corrected script/log/watchdog: `/tmp/spn144-publication-check-a.ts`, `/tmp/spn144-final-publication-a.log`, `/tmp/spn144-final-publication-a-watchdog.json`. First-attempt files use `publication-check-first-a` and `final-publication-first-a` names. All outputs remain outside the frozen archive root.

Publication integrity and complete owner acceptance are satisfied. Historical failures remain failures; this evidence does not establish a unique historical cause, broad protobuf semantic fidelity, or future timing guarantees. Concrete final receipt URL readback and fresh merge guards remain to be reconciled separately. No merge or cleanup has been claimed here.

## 🔗 Concrete receipt readback

Read `/tmp/spn144-final-body.md` after URL substitution. The commit-pinned archive URL names the exact verified commit and prefix. Inventory, manifest hash, publication result and preserved helper-failure disposition match the proof. Current owner timings and limits remain consistent with the accepted reports; historical SPN-141 failure remains unaccepted. Only `PENDING_MERGE_CLEANUP` remains, accurately reserving future actions. Receipt SHA256: `50fc4880ff6d518026e84e723898f9f8ee859ed4bef988bc797adbded98225a8`. Publication and concrete receipt-link conditions are now satisfied; fresh merge guards, actual squash/readback, canonical posted receipt and scoped cleanup remain the landing steps. No source or acceptance blocker was found.
