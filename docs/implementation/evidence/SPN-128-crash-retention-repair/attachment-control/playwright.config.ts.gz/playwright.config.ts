import { defineConfig } from '@playwright/test';
export default defineConfig({ testDir: '/tmp/spn128-attachment-control', testMatch: 'attachments.spec.ts', outputDir: '/tmp/spn128-attachment-control/results', workers: 1, retries: 0, timeout: 30000, reporter: [['list'], ['json', { outputFile: '/tmp/spn128-attachment-control/results.json' }]], use: { headless: true } });
