// SPN-121: one finite native composition discriminator. This is a scratch-only
// experiment; it changes no repository or installed dependency file. Root must
// review this file and plan.json before the single watchdog-controlled execution.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { mkdirSync, readFileSync, readdirSync, realpathSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { serialize } from 'node:v8';
import { isDeepStrictEqual } from 'node:util';

const directory = import.meta.dirname;
const sharedRoot = '/workspace/scratch/8b32f70083c2/spinel';
const currentRoot = '/workspace/scratch/5386d318a310/spinel';
const plan = JSON.parse(readFileSync(join(directory, 'plan.json'), 'utf8'));
assert.equal(process.version, plan.runtime, 'Use the independently verified pinned Node binary.');
assert.equal(plan.groupLimit, 32);
assert.equal(plan.historyRetention, 100);
assert.equal(plan.cases.length, 11);
const sha256 = (value: string | Uint8Array) => createHash('sha256').update(value).digest('hex');
const startedAt = new Date().toISOString();
// Deliberately refuse a silent second execution of this predeclared series.
writeFileSync(join(directory, 'execution-started.json'), JSON.stringify({ startedAt, runtime: process.version }), { flag: 'wx' });
mkdirSync(join(directory, 'inputs'), { recursive: true });

const knownHashes: Record<string, string> = {
  'node_modules/@univerjs/core/lib/es/index.js': 'a019e7eb8b2ba235c7cfd54a19c262377a90c25aca13e5c2e0671a43b709e434',
  'node_modules/@univerjs/docs/lib/es/index.js': '84349b3374cafabaf0baee661b97b4a76a2ac47d1bc68e73cef34f9b8c58e145',
  'node_modules/@univerjs/engine-render/lib/es/index.js': '39b925ac3dd9d280d86781da6860fdcb64b9a97064c3f22912512aa269e1a3ce',
};
const historicalHashes = {
  purpose: 'Reference hashes from the retained SPN-121 proof, not a claim that unused docs-ui in the shared checkout is identical.',
  core: knownHashes['node_modules/@univerjs/core/lib/es/index.js'],
  docs: knownHashes['node_modules/@univerjs/docs/lib/es/index.js'],
  docsUi: '635dced08421d4f9710af399cd84224678d1fbd3cb11ac7bd37510d9d99d40bc',
  unusedSharedDocsUi: '82ff8f5bb6a16cb52a0d7b10de81cebf5a1e004bb4c7fd629ddfc993d55913cf',
  sharedNativeReplica: 'f601bee290b8a6fa918ca4cc31af74b2c0111f82dc90929c5a64c264dd11f7e9',
  sharedLockfile: '41e2038a701a37f6c78c4ce5574ddb7227575bd2392c08aa619c33c09bb8fbca',
  currentNativeReplica: 'b2bd700b7ffbcfcf370c504d5d56d4de73e91fffd12e4f74f8a91cc298aa4cc3',
  boundedDocHistory: 'ad444fa91d457837557104ccd57981a650b01d1bd208172ef29ab9797230397b',
  currentLockfile: 'ba87bb0cd0388b11a06eb9e3375acae584e70f5f267da03e6bd5803bc492aeb7',
};
const hashes: Record<string, string> = {};
for (const [path, expected] of Object.entries(knownHashes)) {
  const actual = sha256(readFileSync(join(sharedRoot, path)));
  hashes[`shared/${path}`] = actual;
  assert.equal(actual, expected, `Pinned public source changed: ${path}`);
}
function recordTree(root: string, path: string, label: string) {
  for (const entry of readdirSync(join(root, path), { withFileTypes: true })) {
    const child = join(path, entry.name);
    if (entry.isDirectory()) recordTree(root, child, label);
    else if (entry.isFile() && /\.(?:ts|json)$/.test(entry.name))
      hashes[`${label}/${child}`] = sha256(readFileSync(join(root, child)));
  }
}
for (const path of ['lib/sync-client/src', 'lib/sync-transform/src']) recordTree(currentRoot, path, 'current');
for (const path of ['package.json', 'package-lock.json', 'node_modules/@univerjs/core/package.json', 'node_modules/@univerjs/docs/package.json', 'node_modules/@univerjs/engine-render/package.json', 'node_modules/ot-json1/dist/json1.js'])
  hashes[`shared/${path}`] = sha256(readFileSync(join(sharedRoot, path)));
for (const path of ['package.json', 'package-lock.json', 'src/ui/boundedDocHistory.ts', 'lib/sync-client/package.json', 'lib/sync-transform/package.json', 'e2e/doc-responsiveness.spec.ts'])
  hashes[`current/${path}`] = sha256(readFileSync(join(currentRoot, path)));
assert.equal(hashes['current/package-lock.json'], historicalHashes.currentLockfile);
assert.equal(hashes['current/src/ui/boundedDocHistory.ts'], historicalHashes.boundedDocHistory);
assert.equal(hashes['current/lib/sync-client/src/native.ts'], historicalHashes.currentNativeReplica);
assert.equal(hashes['shared/package-lock.json'], historicalHashes.sharedLockfile);
const nativeEntry = plan.nativeEntry;
assert.equal(nativeEntry, join(currentRoot, 'lib/sync-client/src/native.ts'), 'Use current NativeReplica directly, with its current relative imports.');
const externalPackages = ['core', 'docs', 'docs-drawing', 'docs-hyper-link', 'drawing', 'engine-render', 'sheets', 'sheets-drawing', 'sheets-formula', 'sheets-numfmt', 'protocol', 'rpc', 'themes'];
const externalRealpaths: Record<string, string> = {};
for (const name of externalPackages) {
  for (const suffix of ['package.json', 'lib/es/index.js']) {
    const path = `node_modules/@univerjs/${name}/${suffix}`;
    assert.equal(realpathSync(join(currentRoot, path)), realpathSync(join(sharedRoot, path)), `External package must resolve to the recorded reused installation: ${path}`);
    hashes[`current/${path}`] = sha256(readFileSync(join(currentRoot, path)));
    externalRealpaths[path] = realpathSync(join(currentRoot, path));
  }
}
assert.equal(realpathSync(join(currentRoot, 'node_modules/@spinel/sync-transform')), realpathSync(join(currentRoot, 'lib/sync-transform')), 'Workspace alias must resolve to current source.');
hashes['diagnostic/proof.ts'] = sha256(readFileSync(import.meta.filename));
hashes['diagnostic/plan.json'] = sha256(readFileSync(join(directory, 'plan.json')));

const result: any = {
  purpose: plan.purpose,
  startedAt,
  runtime: process.version,
  currentSource: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: currentRoot, encoding: 'utf8' }).trim(),
  sharedSource: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: sharedRoot, encoding: 'utf8' }).trim(),
  hashes,
  nativeEntry,
  externalRealpaths,
  fixtureProvenance: plan.fixtureProvenance,
  historicalHashes,
  limitations: plan.limitations,
  counterDefinitions: plan.counterDefinitions,
  cases: [],
};
const persist = () => writeFileSync(join(directory, 'results.json'), JSON.stringify(result, null, 2));
persist();
assert.equal(result.currentSource, plan.sourceCommit, 'Current source commit differs from the reviewed diagnostic plan.');

const core: any = await import(pathToFileURL(join(currentRoot, 'node_modules/@univerjs/core/lib/es/index.js')).href);
const docs: any = await import(pathToFileURL(join(currentRoot, 'node_modules/@univerjs/docs/lib/es/index.js')).href);
const render: any = await import(pathToFileURL(join(currentRoot, 'node_modules/@univerjs/engine-render/lib/es/index.js')).href);
const { NativeReplica }: any = await import(pathToFileURL(nativeEntry).href);
const { ActionIterator, DocumentDataModel, DocumentFlavor, getDocsEmptySnapshot, ICommandService, IUndoRedoService, IUniverInstanceService, JSONX, LocaleType, TextX, Tools, UniverInstanceType } = core;
const { DocSelectionManagerService, DocStateChangeManagerService } = docs;
const { NORMAL_TEXT_SELECTION_PLUGIN_STYLE } = render;

type Counts = Record<string, number>;
const emptyCounts = (): Counts => ({ jsonCompose: 0, jsonIdentityCompose: 0, textCompose: 0, textOperandActions: 0, iteratorNext: 0, bodySliceBranches: 0, textPush: 0, deepCloneVisits: 0, cloneAllocations: 0, clonedObjects: 0, clonedArrays: 0, clonedDates: 0, clonedRegExps: 0 });
const totals = (items: Counts[]): Counts => {
  const answer = emptyCounts();
  for (const item of items) for (const key of Object.keys(answer)) answer[key] += item[key];
  return answer;
};
let active: Counts | null = null;
const saved = {
  json: JSONX.compose,
  text: TextX.compose,
  next: ActionIterator.prototype.next,
  push: TextX.prototype.push,
  clone: Tools.deepClone,
};
JSONX.compose = function (this: any, ...args: any[]) {
  if (active) {
    active.jsonCompose++;
    if (args[0] == null || args[1] == null) active.jsonIdentityCompose++;
  }
  return Reflect.apply(saved.json, this, args);
};
TextX.compose = function (this: any, ...args: any[]) {
  if (active) {
    active.textCompose++;
    active.textOperandActions += args[0].length + args[1].length;
  }
  return Reflect.apply(saved.text, this, args);
};
ActionIterator.prototype.next = function (this: any, ...args: any[]) {
  if (active) active.iteratorNext++;
  const value = Reflect.apply(saved.next, this, args);
  // On these hash-pinned sources this return shape identifies the actual body
  // slice branch. A DELETE with a body follows the non-slicing branch.
  if (active && (value.t === 'i' || (value.t === 'r' && value.body != null))) active.bodySliceBranches++;
  return value;
};
TextX.prototype.push = function (this: any, ...args: any[]) {
  if (active) active.textPush++;
  return Reflect.apply(saved.push, this, args);
};
Tools.deepClone = function (this: any, value: any) {
  if (active) {
    active.deepCloneVisits++;
    if (this.isDefine(value)) {
      // Match the original's mutually exclusive allocation predicates. These
      // counters observe recursive visits, including primitives and undefined.
      if (this.isRegExp(value)) active.clonedRegExps++;
      else if (this.isDate(value)) active.clonedDates++;
      else if (this.isArray(value)) active.clonedArrays++;
      else if (this.isObject(value)) active.clonedObjects++;
      active.cloneAllocations = active.clonedObjects + active.clonedArrays + active.clonedDates + active.clonedRegExps;
    }
  }
  return Reflect.apply(saved.clone, this, [value]);
};
function restoreInstrumentation() {
  active = null;
  JSONX.compose = saved.json;
  TextX.compose = saved.text;
  ActionIterator.prototype.next = saved.next;
  TextX.prototype.push = saved.push;
  Tools.deepClone = saved.clone;
}

function fold(operations: any[], arm: 'original' | 'balanced') {
  const inputs = structuredClone(operations);
  const before = structuredClone(inputs);
  const counts = emptyCounts();
  let actions: any = null;
  assert.equal(active, null, 'Composition measurements must be serial and unnested.');
  active = counts;
  try {
    if (arm === 'original') actions = inputs.reduce((acc, value) => JSONX.compose(acc, value), null);
    else {
      const range = (start: number, end: number): any => {
        const length = end - start;
        if (length === 0) return null;
        if (length === 1) return inputs[start];
        const middle = start + Math.floor(length / 2);
        return JSONX.compose(range(start, middle), range(middle, end));
      };
      // Preserve the native singleton validation/identity behavior. Nontrivial
      // leaves are validated by their containing JSONX.compose call.
      actions = inputs.length === 1 ? JSONX.compose(null, inputs[0]) : range(0, inputs.length);
    }
  } finally {
    active = null;
  }
  assert.deepEqual(inputs, before, `${arm} composition changed its native input arrays/objects.`);
  if (inputs.length > 1) {
    for (const key of ['textCompose', 'iteratorNext', 'deepCloneVisits'])
      assert.ok(counts[key] > 0, `${arm}: unobserved ${key} counter; diagnostic coverage unsupported, not zero work.`);
  }
  return { actions, counts };
}
function independent(snapshot: any, actions: any) {
  const model = new DocumentDataModel(structuredClone(snapshot));
  try {
    model.apply(structuredClone(actions));
    return structuredClone(model.getSnapshot());
  } finally {
    model.dispose();
  }
}
const range = (at: number) => ({ startOffset: at, endOffset: at, collapsed: true, segmentId: '' });
function fixture(id: string, source?: any, selected?: any[]) {
  const seed = source ?? getDocsEmptySnapshot(id, LocaleType.EN_US, id, DocumentFlavor.MODERN);
  const replica = new NativeReplica(structuredClone(seed), 'doc', { undoRedoHistoryLimit: 100 });
  const injector = replica.univer.__getInjector();
  injector.get(IUniverInstanceService).focusUnit(id);
  const commands = injector.get(ICommandService);
  const history = injector.get(IUndoRedoService);
  const manager = injector.get(DocStateChangeManagerService);
  const selections = injector.get(DocSelectionManagerService);
  const model = injector.get(IUniverInstanceService).getUnit(id, UniverInstanceType.UNIVER_DOC);
  selections.replaceSelectionInfoWithoutRefresh({
    textRanges: structuredClone(selected ?? [{ ...range(0), isActive: true }]),
    rectRanges: [], segmentId: '', segmentPage: 0, isEditing: true,
    style: NORMAL_TEXT_SELECTION_PLUGIN_STYLE,
  }, { unitId: id, subUnitId: id });
  const emissions: any[] = [];
  const subscription = manager.docStateChange$.subscribe((state: any) => {
    if (state) emissions.push(structuredClone(state));
  });
  return {
    id, replica, commands, history, manager, model, emissions,
    snapshot: () => structuredClone(model.getSnapshot()),
    selection: () => structuredClone(selections.getTextRanges({ unitId: id, subUnitId: id }) ?? []),
    insert(body: any) {
      const at = model.getBody().dataStream.length - 2;
      const end = at + body.dataStream.length;
      assert.equal(commands.syncExecuteCommand('doc.command.insert-text', {
        unitId: id, segmentId: '', range: range(at), body: structuredClone(body),
        textRanges: [range(end)], debounce: true,
      }), true);
    },
    historyCommand(kind: 'undo' | 'redo') {
      assert.equal(commands.syncExecuteCommand(`univer.command.${kind}`, { unitId: id }), true);
    },
    close() {
      subscription.unsubscribe();
      replica.dispose();
    },
  };
}
function bodyFor(shape: string, index: number, character = String.fromCharCode(97 + (index % 26))) {
  const paragraph = shape === 'styled-paragraphs' && [5, 20].includes(index);
  const dataStream = paragraph ? '\r' : character;
  if (shape === 'minimal') return { dataStream };
  const alternate = shape === 'mixed-styles' && Math.floor(index / 4) % 2 === 1;
  const body: any = {
    dataStream,
    textRuns: [{ st: 0, ed: dataStream.length, ts: { cl: { rgb: alternate ? '#8d205a' : '#1f1f1f' }, ...(shape === 'mixed-styles' ? { bl: alternate ? 1 : 0 } : {}) } }],
    customRanges: [], customDecorations: [],
  };
  if (paragraph || character === '\r') body.paragraphs = [{ startIndex: 0 }];
  return body;
}
function candidateEntry(template: any, output: any) {
  const entry = structuredClone(template);
  assert.equal(entry.undoMutations.length, 1);
  assert.equal(entry.redoMutations.length, 1);
  entry.undoMutations[0].params.actions = structuredClone(output.historyUndo.actions);
  entry.redoMutations[0].params.actions = structuredClone(output.historyRedo.actions);
  return entry;
}
let inProgressGroup: any = null;
let diagnosticPhase = 'not-started';
function observeGroup(f: ReturnType<typeof fixture>, before: any, beforeSelection: any[], historyBefore = before, historyBeforeSelection = beforeSelection) {
  diagnosticPhase = 'capture-native-caches';
  const caches = f.manager.getStateCache(f.id);
  const identityMirrored = caches.history.length === caches.collaboration.length && caches.history.every((state: any, index: number) => state === caches.collaboration[index]);
  const states = structuredClone({ history: caches.history, collaboration: caches.collaboration });
  const after = f.snapshot();
  const afterSelection = f.selection();
  const raw: any = { before, historyBefore, after, beforeSelection, historyBeforeSelection, afterSelection, states, identityMirrored, arms: {} };
  inProgressGroup = raw;
  const inputs = {
    historyRedo: states.history.map((state: any) => state.redoState.actions),
    historyUndo: states.history.toReversed().map((state: any) => state.undoState.actions),
    collaborationRedo: states.collaboration.map((state: any) => state.redoState.actions),
    collaborationUndo: states.collaboration.toReversed().map((state: any) => state.undoState.actions),
  };
  for (const arm of ['original', 'balanced'] as const) {
    const output: any = raw.arms[arm] = {};
    for (const [direction, ops] of Object.entries(inputs)) {
      diagnosticPhase = `${arm}-${direction}-composition`;
      output[direction] = fold(ops, arm);
    }
    diagnosticPhase = `${arm}-independent-snapshot-application`;
    assert.deepEqual(independent(historyBefore, output.historyRedo.actions), after, `${arm}: history redo lost native body or metadata.`);
    assert.deepEqual(independent(after, output.historyUndo.actions), historyBefore, `${arm}: history undo lost native body or metadata.`);
    assert.deepEqual(independent(before, output.collaborationRedo.actions), after, `${arm}: collaboration redo used the history cache's different baseline.`);
    assert.deepEqual(independent(after, output.collaborationUndo.actions), before, `${arm}: collaboration undo lost native body or metadata.`);
  }
  // The unmodified native manager remains the oracle for parameter metadata,
  // cache behavior, native history publication and collaboration publication.
  diagnosticPhase = 'original-native-flush-oracle';
  const emittedBefore = f.emissions.length;
  f.manager.flushPendingChanges(f.id);
  assert.deepEqual(f.manager.getStateCache(f.id), { history: [], collaboration: [] });
  if (states.history.length) {
    raw.oracleHistory = structuredClone(f.history.pitchTopUndoElement());
    assert.ok(raw.oracleHistory);
    assert.deepEqual(raw.arms.original.historyRedo.actions, raw.oracleHistory.redoMutations[0].params.actions);
    assert.deepEqual(raw.arms.original.historyUndo.actions, raw.oracleHistory.undoMutations[0].params.actions);
  }
  if (states.collaboration.length) {
    assert.equal(f.emissions.length, emittedBefore + 1);
    raw.oracleCollaboration = f.emissions.at(-1);
    assert.deepEqual(raw.arms.original.collaborationRedo.actions, raw.oracleCollaboration.redoState.actions);
    assert.deepEqual(raw.arms.original.collaborationUndo.actions, raw.oracleCollaboration.undoState.actions);
  } else assert.equal(f.emissions.length, emittedBefore);
  return raw;
}
function replay(f: ReturnType<typeof fixture>, groups: any[]) {
  assert.deepEqual(f.history.getUndoRedoStatus(f.id), { undos: groups.length, redos: 0 });
  for (let index = groups.length - 1; index >= 0; index--) {
    f.historyCommand('undo');
    assert.deepEqual(f.snapshot(), groups[index].historyBefore, `Undo group ${index + 1}: exact snapshot`);
    assert.deepEqual(f.selection(), groups[index].historyBeforeSelection, `Undo group ${index + 1}: logical ranges`);
    assert.deepEqual(f.history.getUndoRedoStatus(f.id), { undos: index, redos: groups.length - index });
  }
  for (let index = 0; index < groups.length; index++) {
    f.historyCommand('redo');
    assert.deepEqual(f.snapshot(), groups[index].after, `Redo group ${index + 1}: exact snapshot`);
    assert.deepEqual(f.selection(), groups[index].afterSelection, `Redo group ${index + 1}: logical ranges`);
    assert.deepEqual(f.history.getUndoRedoStatus(f.id), { undos: index + 1, redos: groups.length - index - 1 });
  }
  assert.deepEqual(f.manager.getStateCache(f.id), { history: [], collaboration: [] });
}
function summarizeGroups(groups: any[]) {
  const armCounts: Record<string, Counts> = {};
  const directionCounts: any = {};
  for (const arm of ['original', 'balanced']) {
    directionCounts[arm] = Object.fromEntries(['historyRedo', 'historyUndo', 'collaborationRedo', 'collaborationUndo'].map((key) => [key, totals(groups.map((group) => group.arms[arm][key].counts))]));
    armCounts[arm] = totals(Object.values(directionCounts[arm]));
  }
  const workReduced = ['bodySliceBranches', 'deepCloneVisits', 'cloneAllocations'].every((key) => armCounts.balanced[key] < armCounts.original[key]);
  const redoReduced = ['historyRedo', 'collaborationRedo'].every((direction) => ['bodySliceBranches', 'deepCloneVisits'].every((key) => directionCounts.balanced[direction][key] < directionCounts.original[direction][key]));
  return {
    groups: groups.length,
    states: groups.map((group) => ({ history: group.states.history.length, collaboration: group.states.collaboration.length, identityMirrored: group.identityMirrored })),
    armCounts, directionCounts, workReduced, redoReduced,
    actionRepresentationsEqual: groups.every((group) => Object.keys(group.arms.original).every((key) => isDeepStrictEqual(group.arms.original[key].actions, group.arms.balanced[key].actions))),
  };
}
function saveRaw(id: string, raw: any) {
  // V8 serialization retains own undefined keys, sparse arrays and shared-object
  // identity that JSON would omit. It is synthetic input, never user content.
  const bytes = serialize(raw);
  const file = `inputs/${id}.bin`;
  writeFileSync(join(directory, file), bytes);
  return { file, bytes: bytes.length, sha256: sha256(bytes), format: 'node:v8 serialize; pinned Node 26.12.1' };
}

try {
  for (const item of plan.cases) {
    const record: any = { id: item.id, startedAt: new Date().toISOString(), status: 'running' };
    result.cases.push(record);
    persist();
    process.stdout.write(`${item.id}: start\n`);
    let f: ReturnType<typeof fixture> | undefined;
    let candidate: ReturnType<typeof fixture> | undefined;
    const groups: any[] = [];
    inProgressGroup = null;
    diagnosticPhase = 'fixture';
    try {
      f = fixture(`spn121-${item.id}`);
      const initial = f.snapshot();
      const initialSelection = f.selection();
      if (item.kind === 'workload') {
        const text = Array.from({ length: 16 }, (_, index) => `Line ${index + 1}: Read the whole paragraph, including the far right edge. Keep the original page size and all of this text when navigating.`).join('\r');
        assert.equal(text.length, 2086);
        let before = initial;
        let selected = initialSelection;
        for (const [index, character] of [...text].entries()) {
          diagnosticPhase = 'native-insert-command';
          f.insert(bodyFor('same-style', index, character));
          if ((index + 1) % 32 === 0 || index + 1 === text.length) {
            groups.push(observeGroup(f, before, selected));
            before = f.snapshot();
            selected = f.selection();
          }
        }
        assert.equal(groups.length, 66);
        assert.equal(f.model.getBody().dataStream, text + '\r\n');
      } else {
        let historyBefore = initial;
        let historyBeforeSelection = initialSelection;
        for (let index = 0; index < item.states; index++) {
          diagnosticPhase = 'native-insert-command';
          f.insert(bodyFor(item.shape, index));
          if (item.clearHistoryAfter === index + 1) {
            historyBefore = f.snapshot();
            historyBeforeSelection = f.selection();
            f.manager.clearHistory(f.id);
          }
        }
        if (item.states === 0) {
          const empty = observeGroup(f, initial, initialSelection);
          assert.equal(f.history.getUndoRedoStatus(f.id).undos, 0);
          record.identityOutputs = Object.fromEntries(Object.entries(empty.arms).map(([arm, value]: any) => [arm, Object.values(value).every((entry: any) => entry.actions === null)]));
          assert.deepEqual(record.identityOutputs, { original: true, balanced: true }, 'Empty folds must preserve null identity.');
          record.raw = saveRaw(item.id, empty);
        } else {
          groups.push(observeGroup(f, initial, initialSelection, historyBefore, historyBeforeSelection));
          assert.equal(groups[0].states.history.length, item.clearHistoryAfter ? 20 : item.states);
          assert.equal(groups[0].states.collaboration.length, item.states);
          if (item.states === 1)
            for (const key of Object.keys(groups[0].arms.original))
              assert.deepEqual(groups[0].arms.balanced[key].actions, groups[0].arms.original[key].actions, 'Singleton fold must preserve the original action representation.');
        }
      }
      if (groups.length) {
        const final = f.snapshot();
        const finalSelection = f.selection();
        diagnosticPhase = 'original-native-undo-redo';
        replay(f, groups);
        diagnosticPhase = 'balanced-native-fixture-and-history-metadata';
        candidate = fixture(f.id, final, finalSelection);
        for (const group of groups) candidate.history.pushUndoRedo(candidateEntry(group.oracleHistory, group.arms.balanced));
        diagnosticPhase = 'balanced-native-undo-redo';
        replay(candidate, groups);
        record.raw = saveRaw(item.id, { groups, final, finalSelection });
        record.summary = summarizeGroups(groups);
        record.nativeReplay = { original: 'every actual group passed Undo and Redo', balanced: 'every actual group passed Undo and Redo', snapshot: 'complete native snapshot deep equality, including all body metadata', selection: 'exact public logical range arrays', divergentCaches: item.clearHistoryAfter ? 'history returns to state12; collaboration independently returns to initial' : 'independently folded even when source state identities match' };
        if (item.requireWorkReduction) {
          diagnosticPhase = 'work-reduction-discriminator';
          assert.equal(record.summary.workReduced, true, 'No demonstrated paired slice/clone allocation reduction.');
          assert.equal(record.summary.redoReduced, true, 'No demonstrated redo slice/clone reduction for both caches.');
        }
      }
      record.status = 'passed';
    } catch (error) {
      record.status = 'failed';
      record.failurePhase = diagnosticPhase;
      record.failureInterpretation = 'No pass or attribution. Review this phase and raw inputs to distinguish a harness/oracle defect from a balanced-composition rejection; do not weaken assertions or silently retry.';
      record.error = error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : String(error);
      if (!record.raw) record.raw = saveRaw(item.id, { partialGroups: groups, inProgressGroup: groups.includes(inProgressGroup) ? undefined : inProgressGroup });
      process.exitCode = 1;
    } finally {
      for (const item of [candidate, f]) {
        try { item?.close(); }
        catch (error) {
          record.status = 'failed';
          record.cleanupErrors ??= [];
          record.cleanupErrors.push(error instanceof Error ? { message: error.message, stack: error.stack } : String(error));
          process.exitCode = 1;
        }
      }
      record.finishedAt = new Date().toISOString();
      persist();
      process.stdout.write(JSON.stringify({ id: item.id, status: record.status, groups: record.summary?.groups, workReduced: record.summary?.workReduced, counts: record.summary?.armCounts, error: record.error?.message }) + '\n');
    }
  }
} finally {
  restoreInstrumentation();
  result.instrumentationRestored = JSONX.compose === saved.json && TextX.compose === saved.text && ActionIterator.prototype.next === saved.next && TextX.prototype.push === saved.push && Tools.deepClone === saved.clone;
  result.finishedAt = new Date().toISOString();
  result.completedCases = result.cases.length;
  result.status = result.cases.length === 11 && result.cases.every((item: any) => item.status === 'passed') && result.instrumentationRestored ? 'passed-mechanism-discriminator-only' : 'failed';
  result.conclusionLimit = 'This series can establish native semantic equivalence and actual primitive-work reduction for the fixed synthetic cases. It cannot attribute the historical unprofiled 102.7 ms spike or satisfy desktop/mobile browser acceptance.';
  persist();
  if (result.status === 'failed') process.exitCode = 1;
}
