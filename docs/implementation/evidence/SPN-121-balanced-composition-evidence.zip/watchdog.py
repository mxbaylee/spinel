import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

root = Path('/workspace/scratch/5386d318a310')
directory = root / 'spn121-diagnostic'
directory.mkdir(exist_ok=True)
node = root / 'node-v26.12.1-linux-x64/bin/node'
limit_kib = 2 * 1024 * 1024
timeout_seconds = 180
memory_current = Path('/sys/fs/cgroup/memory.current')
memory_limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
initial_memory = int(memory_current.read_text())
if initial_memory > memory_limit * 0.8:
    raise SystemExit('Deferred: cgroup memory already exceeds 80% of its limit.')
environment = dict(os.environ)
environment['PATH'] = str(node.parent) + os.pathsep + environment['PATH']
peak_kib = 0
reason = None
started = time.monotonic()
with (directory / 'proof.log').open('w') as log:
    child = subprocess.Popen(
        [str(node), '--max-old-space-size=1024', str(directory / 'proof.ts')],
        cwd=directory,
        env=environment,
        stdout=log,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    while child.poll() is None:
        rows = subprocess.check_output(['ps', '-eo', 'pid,ppid,rss', '--no-headers'], text=True)
        processes = [tuple(map(int, line.split())) for line in rows.splitlines()]
        owned = {child.pid}
        while True:
            expanded = owned | {pid for pid, parent, _ in processes if parent in owned}
            if expanded == owned:
                break
            owned = expanded
        current_kib = sum(rss for pid, _, rss in processes if pid in owned)
        peak_kib = max(peak_kib, current_kib)
        if current_kib > limit_kib:
            reason = 'process-tree RSS exceeded 2 GiB'
        elif int(memory_current.read_text()) > memory_limit * 0.9:
            reason = 'cgroup memory exceeded 90% of its limit'
        elif time.monotonic() - started > timeout_seconds:
            reason = '180-second diagnostic deadline exceeded'
        if reason:
            os.killpg(child.pid, signal.SIGKILL)
            break
        time.sleep(0.25)
    status = child.wait()
result = {
    'command': [str(node), '--max-old-space-size=1024', str(directory / 'proof.ts')],
    'exitCode': status,
    'resourceAborted': reason is not None,
    'reason': reason,
    'elapsedSeconds': time.monotonic() - started,
    'peakProcessTreeRssKiB': peak_kib,
    'initialCgroupBytes': initial_memory,
    'cgroupLimitBytes': memory_limit,
    'pressureAvailability': 'PSI unavailable; cgroup events were zero and memory headroom checked',
}
(directory / 'watchdog-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
raise SystemExit(124 if reason else status)
