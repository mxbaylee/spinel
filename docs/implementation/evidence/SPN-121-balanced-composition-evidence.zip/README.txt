SPN-121 bounded balanced-composition discriminator, 2026-10-29.

The original plan and TypeScript proof are retained byte for byte; their absolute source paths record this execution environment, not a portable new acceptance command. The first sandbox launch stopped at source-provenance collection before native imports or cases. A separately declared single launch outside that child-process restriction completed all 11 cases. No production source was changed for either launch.

All 11 cases passed; all 66 groups in the full textual workload passed actual native Undo and Redo in both arms. The work counters are not CPU time or allocation bytes. The separate passing browser profile cannot attribute the unprofiled failed event. This archive does not provide browser acceptance or merge approval.

Inputs use Node v8 serialization to preserve undefined own properties and shared identities. Use the pinned Node 26.12.1 deserializer for inspection. results.json contains each input member hash. plan.json describes exact cases, guards and limits. watchdog.py is retained temporary execution instrumentation.
