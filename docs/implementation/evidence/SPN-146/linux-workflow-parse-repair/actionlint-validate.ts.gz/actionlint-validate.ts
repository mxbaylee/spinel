import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
const cases=[['original','/tmp/spn146-actionlint/original.yml'],['repaired','.github/workflows/doc-native-runtime.yml']];
const results=cases.map(([name,path])=>{const r=spawnSync('/tmp/spn146-actionlint/actionlint',['-shellcheck=','-pyflakes=',path],{encoding:'utf8'});return{name,status:r.status,stdout:r.stdout,stderr:r.stderr};});
writeFileSync('/tmp/spn146-hosted/linux-workflow-static-validation.json',JSON.stringify(results,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(results));
assert.notEqual(results[0].status,0);assert.match(results[0].stdout+results[0].stderr,/runner/);assert.equal(results[1].status,0);
