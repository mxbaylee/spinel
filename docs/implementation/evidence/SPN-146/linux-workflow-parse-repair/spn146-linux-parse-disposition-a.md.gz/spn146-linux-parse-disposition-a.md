# 🧩 SPN-146 Linux workflow parse failure — review A

**A concrete workflow-expression defect is confirmed. A narrowly reviewed source/trigger repair is admissible; the current head is not merge-ready and this is not permission to rerun an unchanged experiment.** No source mutation, cancellation, publication or runtime execution was performed for this review.

Retained run `42004830910`, attempt 1, records source `7e041c0c7c84bc28c56aeff1bda35b2a93654114`, event `push`, workflow-file name `.github/workflows/doc-native-runtime.yml`, completed/failure. The retained CLI view identifies a likely workflow-file issue and the check-run query is empty. Parent reports no jobs or Linux observations; retain the final jobs response and any available annotation with this disposition. An empty check-run query alone is not a substitute for the jobs record. The push-labelled rejection is workflow validation, not evidence that the declared synchronize observation ran.

## 🔎 Exact defect and narrow repair

Line 21 puts `${{ runner.temp }}` in `jobs.component.env`. GitHub's [context-availability reference](https://docs.github.com/en/actions/reference/workflows-and-actions/contexts#context-availability) excludes `runner` from job-level `env` and permits it in step-level `env`/`run`. The current workflow is therefore invalid independently of any unknown runtime behavior. I missed this restriction in my previous 98/100 pre-push source review; retain that review and this corrective disposition rather than retroactively presenting the workflow as validated.

Move the converter destination construction into a supported executed step using `$RUNNER_TEMP`, then persist it through `$GITHUB_ENV` for later steps. If the same step invokes the installer, also set/export the local shell value: writing to `$GITHUB_ENV` only supplies subsequent steps. Equivalent valid step-level environment declarations at both consumers are acceptable. Keep the pinned converter and all other identity/ownership/effect requirements unchanged. Add a meaningful static context/placement regression check or supported workflow validation; prior TypeScript/lint controls do not validate GitHub expressions.

## 🚦 Explicit repair admission

The `1eeb90f1` transition has occurred and cannot be reused honestly. After the raw failure/no-job evidence is retained, expressly revise the prospective trigger to the first synchronization away from published `7e041c0c`. This is a diagnosed workflow-source repair before any measured Linux case, not selecting another sample after an unfavorable result. Preserve the rejected run as failed, the local resource abort as closed, and the original hosted trace failure as failed.

The repair must retain exactly the same four inputs, native implementations, counterbalanced 32 observations, all 16 effect thresholds, complete trace/GC/clock and output/journal requirements, resource/time bounds and no-retry policy. The corrected complete commit requires feasible local validation and both new qualifying exact-head reviews before publication. Actual hosted execution and fresh selected CI still remain pending. Do not rewind the branch to regain the old event, invoke a rerun, or call the failed parse an accepted observation.

Other source-7e workflows currently queued/running are separate records. Any supersession cancellations need their own terminal reconciliation; this read-only disposition neither performs nor declares those cancellations complete.
