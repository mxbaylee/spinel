import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
const root='/tmp/spn146-hosted/diagnostic/test-results/doc-responsiveness/doc-responsiveness-mobile-sustained-native-typing-profile-doc-responsiveness';
const read=(name:string)=>JSON.parse(readFileSync(join(root,name),'utf8'));
const metrics=read('spn108-metrics.json'), capture=read('spn146-native-caches.json');
const summary={
 metrics:Object.fromEntries(Object.entries(metrics).filter(([k])=>['source','role','completed','timingComplete','primaryFailure','summary','nativeDiagnosticObserver','nativeDiagnosticCleanup','nativeDiagnosticTraceFailure','nativeDiagnosticInterrupted','errors','nativeDiagnosticBuild'].includes(k))),
 capture:{...Object.fromEntries(Object.entries(capture).filter(([k])=>!['captures','calls'].includes(k))),phases:capture.captures.length,calls:capture.calls.length},
 nativeKeys:Object.keys(metrics.native??{}),
 slowPairs:metrics.native?.flushes?.filter((x:any)=>x.durationMs>=80),
 longestPhases:capture.captures.map((x:any)=>({sequence:x.sequence,phase:x.phase,count:x.count,captureStartedAt:x.captureStartedAt,captureEndedAt:x.captureEndedAt,returnedAt:x.returnedAt,encodingMs:x.captureEndedAt-x.captureStartedAt,nativeMs:x.returnedAt-x.captureEndedAt,outcome:x.outcome})).sort((a:any,b:any)=>b.nativeMs-a.nativeMs).slice(0,12),
 callsExample:capture.calls.slice(0,3),metricsKeys:Object.keys(metrics)
};
writeFileSync('/tmp/spn146-hosted/diagnostic-summary.json',JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify(summary,null,2));
