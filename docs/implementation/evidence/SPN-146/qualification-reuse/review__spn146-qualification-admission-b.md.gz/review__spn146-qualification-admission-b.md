# 🔎 SPN-146 qualification-reuse prototype — admission review B

**Plan SHA-256:** `99cd605b191c7f7faa81da469f48bf10371e2a192802fbbcd6295d3fe4b44296`  
**Initially inspected generated probe SHA-256:** `3dfba9a7977df23364053563a4bab5df766af0a5f562404d431a24fbd24bc266`  
**Body:** `f6651fb71edd0d463808f74bfa183952ab518d9238d7753844a108938e2f82e9`  
**Builder:** `638dc0d228295d5df907827eeb471beac97f65e35448f3a9e3886077879927aa`.

Read-only static inspection of the plan, complete prototype body, builder and relevant generated actual-manager fixture. No execution, native/browser/converter work, input parsing or project edit was performed.

## Decision

The finite 16-flush question and prototype are appropriately narrow. **Hold execution of the initial probe until primary-error preservation is repaired as below.** No production admission is implied. The original Linux analysis failure and eight-of-sixteen timing criterion remain unchanged.

## Primary-error preservation findings

1. The report `finally` performs an awaited `readFile(qualification.ts)` before entering its persistence `try`. A script-identity read failure can replace an earlier semantic/cleanup error and skip report publication. Bind the probe identity before executing flushes, or catch this failure as a secondary while still attempting publication and preserving the original cause.
2. The inherited `flush()` performs unguarded `fixture.close()` in `finally`. A cleanup assertion/error can replace an earlier input/parity/cache failure. The plan expressly requires preservation of the primary error, so the derived diagnostic needs to retain that original error and record cleanup failure separately, while still attempting cleanup. This is diagnostic ownership repair, not a reason to broaden the algorithm hypothesis or execute extra cases.

Both were reported to the parent before any execution. An unsuccessful identity/setup repair does not consume or renew the runtime matrix; the exact repaired source must be statically revalidated before admission.

## Prototype and instrumentation assessment

The transformation is guarded by one exact old-source occurrence and replaces only the successful Enter branch's two recursive generic-composer calls. It does not alter the full `isPlainDocDeleteData(states)` traversal, supported Enter metadata, scope/offset checks, final-tail qualification, undo path or unsupported fallback.

For prefix lengths below four it reproduces the original head's initial-null sequential composition through Enter. For larger prefixes it uses the same balanced prefix range followed by Enter once. The tail uses the same existing balanced `composeRange` over its already-qualified final range; the last head/tail join remains once. The function declaration is hoisted, so use before its textual declaration is valid. This is local same-call reuse; it introduces no cached authority, persistent state, externally supplied trust flag or weakened guard.

The actual retained input prefix positions do not cover all tiny prefixes. That is acceptable for this explicitly limited work diagnostic, provided no comprehensive semantic/production claim is made. Prefix 0/1/2 and the wider unsupported/accessor/metadata matrix remain mandatory maintained candidate validation after proposal, as the plan states.

Counters are inserted once at exact function-entry anchors for both variants and at the plain-data descriptor lookup. They distinguish repeated delete/prefix calls and descriptor visits from native composition/iterator/clone work. The VM callback changes process-local counting only; it does not patch installed package files. Equal instrumentation and the exact current implementation supply a meaningful control. Keeping `canComposeDocParagraphTail` call count equal checks that the same full-admission gate remains involved, while static transformation inspection establishes that its body is unchanged. Strict count reduction is required for every fixed format/cache comparison, not only an aggregate.

The generated fixture uses actual guarded native manager regions and real pinned Core bytes. Native source, fixture, patch, captured entry and selected pair hashes are asserted. The builder only changes declared imports, input unit, donor path and the counter hook; it does not execute the fixture during generation. The sixteen observations are fixed four actual retained history/collaboration pairs × ES/CJS × current/prototype, with fresh decode per variant. No synthetic initial document snapshot is invented.

The fixture checks exact raw publications/order, own keys/descriptors/prototype shape, input nonmutation, emptied queues and timer/listener disposal. `measuredFlush` restores its process-local Core instrumentation. The primary-cause caveat above concerns error precedence when cleanup itself fails, not omission of its normal cleanup attempt.

Raw equality is checked before output hashes; own-undefined encoding therefore supplements rather than replaces the actual semantic assertion. Primitive work must be identical; prefix/delete qualification and descriptor visits must strictly decrease. A mismatch stops the experiment with partial preceding rows retained. These counts are mechanical work evidence, not milliseconds, all V8 allocations or proof that qualification caused the prior native slowdowns.

## Bounds and pending evidence

The declared serial/normal-pressure/two-GiB/60-second parent watchdog must cover imports, generation-derived fixture loading, all flushes, output serialization and cleanup. Internal elapsed checks do not enforce a bound while synchronous work is in progress. Original source and retained inputs remain unchanged; exclusive output creation prevents replacement of an earlier result. Any first semantic/resource failure stops with no retry or extra cases.

A successful repaired probe could admit a production proposal for this specific deduplication only. It would still require the full existing semantic/fallback/ownership matrix, exact-source independent reviews, supported fresh runtime evidence and unchanged application latency/content/history/access acceptance. Neither this diagnostic nor its potential success can make the old native result pass, establish historical pause causality or justify narrowing the full-graph guard.

## ✅ Static repair revalidation

The generated probe is now SHA-256 `d885c7f9e50a8e5279f72c8e973e3c2df3e5183d0bc93131522f9f5fc82772ad`; the fixed plan is unchanged. I reread the revised builder/body and generated call sites and independently confirmed the new script hash.

The script identity read now occurs inside the protected setup try before any flush, so it cannot replace an earlier work error during publication. The derived fixture records its original failure, attempts cleanup and records a cleanup error separately, rethrowing cleanup only when there was no earlier failure. Both specific first-cause findings above are closed for the actual Error/assertion failure paths used here. In addition, the actual imported Core entry is realpath-bound to the checked donor ES file, and a returned variant's source/count/output identity is retained with `verified:false` before parity assertions, improving first-failure evidence. These changes do not alter the proposed qualification algorithm or the sixteen fixed observations.

**The repaired exact probe is admitted for the one declared bounded lower-layer execution after the other independent review and parent watchdog guards are satisfied.** No further concrete static admission blocker found. No execution or heavy input parsing was performed by this reviewer. Full unsupported/tiny-prefix semantic validation and current-source native/application acceptance still belong to a later production candidate; neither production approval nor a new native/browser allowance follows from this admission.
