// Regression verification of changed analyzer code only. No new observations,
// converter execution, thresholds or replacement acceptance result.
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {analyzeRuntime} from '/Users/mxbaylee/projects/spinel-spn-146/scripts/ci/doc-native-runtime/analysis.ts';
const base='/tmp/spn146-linux-hosted',dir=base+'/component';
const hash=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const report:any={purpose:'Changed-reader regression only; original failed analysis and mixed experiment unchanged.',complete:false};let failure:unknown;
try{
 const observation=await readFile(dir+'/observation.json');assert.equal(hash(observation),'16864ca6e286f9a0d04323ea7f511f3461a89fb71308a0ce8e64315d1d7f79f8');
 const stored=await readFile(dir+'/runtime.trace.json.gz');assert.equal(hash(stored),'e14d443c234ce22b4315e59bc650495348da02d34007e22eca99351ed65b59b8');
 const decoded=gunzipSync(stored,{maxOutputLength:128*1024**2});assert.equal(hash(decoded),'695842e63a4ebfa242429955a29b6a8b7588740d1fa708f7ecdcd12366c57d0e');
 report.analyzerSha256=hash(await readFile('/Users/mxbaylee/projects/spinel-spn-146/scripts/ci/doc-native-runtime/analysis.ts'));
 report.result=analyzeRuntime(JSON.parse(observation.toString()),JSON.parse(decoded.toString()).traceEvents);
 assert.equal(report.result.disposition,'inconclusive');assert.equal(report.result.comparisons.filter((p:any)=>p.meetsCriterion).length,8);assert.equal(report.result.intervals.length,96);assert.ok(report.result.gcDurationUnknown.length>0);assert.ok(report.result.gcControl.length>0);
 report.complete=true;
}catch(error){failure=error;report.failure=String(error);}
finally{try{await writeFile(base+'/trace-reader-regression.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});}catch(error){failure??=error;console.error(JSON.stringify({primary:String(failure),persistence:String(error)}));}}
if(failure)throw failure;
console.log(JSON.stringify({complete:true,disposition:report.result.disposition,meets:8,context:report.result.gcDurationUnknown.length,intervals:96}));
