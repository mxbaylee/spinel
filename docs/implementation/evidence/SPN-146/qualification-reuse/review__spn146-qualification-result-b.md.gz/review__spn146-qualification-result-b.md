# ✅ SPN-146 qualification-reuse result — independent review B

Reviewed retained `/tmp/spn146-linux-hosted/qualification-result.json`, watchdog and log for the single admitted probe `d885c7f9e50a8e5279f72c8e973e3c2df3e5183d0bc93131522f9f5fc82772ad`. Read-only evidence assessment; no additional execution, production edit, browser or converter run.

## Decision

**The result supports integrating this exact narrow qualification-reuse proposal for maintained semantic validation.** It proves removal of duplicate qualification work on the four fixed real cache pairs in both manager formats while preserving the tested raw outcomes and native primitive work. It does not prove faster Chromium execution, explain the five slower component cases, satisfy the original runtime-benefit criterion, or authorize another browser experiment.

The original Linux result remains failed/inconclusive. No samples or thresholds are changed by this admission. A committed production candidate still requires complete semantic controls, two independent exact-head reviews, supported runtime disposition and fresh selected application acceptance.

## Result checked

All eight format/cache comparisons retain two verified variants, totaling exactly sixteen flushes. Formats are ES/CJS; completed inputs are 544, 672, 1440 and 1984 with sequence pairs 32/33, 40/41, 88/89 and 122/123. Current source hashes match the exact earlier production candidate. The prototype bytes are:

- ES `110890e889ac362b22a4c38bafd1ebb4e7cf82e8107d4524bdb86ff7fe6bd7c3`.
- CJS `58edceea5e1fb66ff1a83ec0a92707cf6f8d741aab87eb922d9c7e021f99207d`.

For every comparison, output hashes match after raw deep equality; primitive TextX composition, iterator steps, body slices, clone visits and counted allocations are identical. Delete-prefix and insert-prefix function entries each fall from eight to four. Key-shape checks decrease by 644, recursive plain-data entries by 112 and descriptor visits by 108. Full structural-admission calls remain two. This is the expected mechanical effect of removing repeated generic head/tail qualification, while preserving the initial full graph check. It is not evidence that the full graph traversal is cheap or that its coverage can be narrowed.

The exact-source fixture's nonmutation/descriptor/cache/cleanup assertions completed, and the result contains no recorded cleanup failure. The Core import resolves to the checked donor ES entry. Both manager-format labels use that real shared Core runtime; this is not separate ES-versus-CJS Core runtime qualification.

The parent watchdog passed at 833 ms, peak 270,224 KiB, normal pressure. Internal elapsed time is 338.156 ms for the whole probe body, including identity reads, preparation/instrumentation, flushes and assertions. It must not be reported as isolated native flush time or a performance benchmark. This reviewer inspected the retained small records and did not rerun the probe or independently replay its raw outputs.

## Required semantic validation before candidate approval

The implementation should preserve the admitted exact transformation, with the former candidate retained as a hash-bound install-upgrade source and duplicate-work negative. Do not bundle a narrower whole-graph guard, new cache, broader shape support or unrelated composition refactor into this proposal.

Extend the existing maintained manager suite to establish:

1. **All paragraph positions and both cover modes.** Exercise prefix 0/1/2/3 explicitly, odd/even balanced prefixes, the minimum eligible tail and the adjacent ineligible boundary. The actual retained probe covers only four real shapes; it is not the complete positional proof. Short heads must preserve the initial-null sequential fold through Enter, while larger heads preserve exactly the old balanced prefix plus one Enter composition.
2. **Raw output and operand authority.** Compare against the exact prior candidate, not only a normalized document. Preserve own-undefined metadata, body/old-body variants, publication order, selection state, accumulator behavior and original right operands. Verify complete applied snapshots where a genuine initial snapshot exists, and preserve the missing-snapshot limit for retained browser captures.
3. **Output/input ownership.** Check no result aliases source state objects, output mutation cannot mutate inputs or a later result, both unequal queues retain their own semantics, and input keys/descriptors/prototypes remain unchanged. Fixture sink cloning must not be mistaken for direct-helper ownership proof.
4. **Unsupported fallback parity.** Existing accessor/read-count and exception/call-order controls must remain valid for malformed shapes, unknown keys/symbols, prototypes/depth, second structural edit, unsupported attributes, wrong scopes and offset gaps. The prior generic path must remain the owner whenever full admission fails. Undo and ordinary nonstructural paths must remain unchanged.
5. **Regression detection for the actual work change.** Retain direct counters for qualifier calls/descriptor visits so the old exact candidate fails the work expectation while preserving the same semantic oracle. Primitive-count equality is distinct from qualification-work reduction. Installer hash guards, known-upgrade handling, idempotence and unknown-edit rejection must include the retained old candidate and new exact build identities.

These are the missing candidate-validation obligations, not permission for another large diagnostic matrix beyond the planned maintained suite. Any counterexample should stop integration and be retained as the first failure. The already completed sixteen observations should not be repeated to seek a better result.

## Remaining causal boundary

The static redundancy and this mechanical count reduction are sufficient to motivate a smaller source proposal. They cannot convert count reductions into milliseconds or establish the cause of historical mobile maxima. The mixed previous native timing result, observed GC overlaps, missing dynamic source attribution, 80 negative profile deltas and startup-clock uncertainty remain part of the final record. If a later runtime question is necessary, it must be separately justified for substantive changed source with fixed bounds and criteria; this report supplies no automatic renewal.

All persona contracts remain intact: Owner/Collaborator content, history and peer publications; Link guest access/revocation boundaries; Operator resource ownership, finite execution and retained first causes. No merge approval or claim of complete SPN-146 acceptance is given.
