/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Modified for Spinel: execute the pinned public Doc state manager region
 * against real JSONX/TextX operations and controlled service endpoints/timers.
 * Original bundle bytes are semantic and primitive-work negative controls.
 * Source: packages/docs/src/services/doc-state-change-manager.service.ts,
 * dream-num/univer v1.1.0. No Pro package is read or modified.
 */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { resolve } from 'node:path';
import { test } from 'node:test';
import { runInNewContext } from 'node:vm';
import { gunzipSync } from 'node:zlib';
import * as core from '@univerjs/core';
import type { IDocumentData, JSONXActions } from '@univerjs/core';
import type {
  DocStateChangeManagerService,
  IDocStateChangeInfo,
  IDocStateChangeParams,
} from '@univerjs/docs';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { patchInstalledDocs, prepareDocsPatch } from '/Users/mxbaylee/projects/spinel-spn-146/scripts/dependencies/patch-univer-docs.ts';
import { observeNativeDocComposition } from '/Users/mxbaylee/projects/spinel-spn-146/src/ui/nativeDocFlushDiagnostic.ts';
import type { DiagnosticManager } from '/Users/mxbaylee/projects/spinel-spn-146/src/ui/nativeDocFlushDiagnostic.ts';
import type {
  NativeDocFlushManager,
  NativeDocFlushObservation,
} from '/Users/mxbaylee/projects/spinel-spn-146/src/ui/nativeDocFlush.ts';

type Format = 'es' | 'cjs';
type State = IDocStateChangeParams;
type Side = State['redoState'] & { unitId: string; segmentId?: string; trigger?: string };
type Entry = {
  unitID: string;
  undoMutations: { id: string; params: Side }[];
  redoMutations: { id: string; params: Side }[];
};
type Manager = Pick<
  DocStateChangeManagerService,
  | 'getStateCache'
  | 'setStateCache'
  | 'clearHistory'
  | 'flushPendingChanges'
  | 'docStateChange$'
  | 'dispose'
>;
type Request = (snapshot: IDocumentData) => JSONXActions;
const unitId = '7d029bbc-97ab-496a-b5f4-cc9454e282e1';
const readBuild = (format: Format) =>
  readFile(
    new URL(`file:///Users/mxbaylee/projects/spinel/node_modules/@univerjs/docs/lib/${format}/index.js`, import.meta.url),
    'utf8',
  );

// Lossless native capture encoding preserves own undefined fields and arrays.
function decodeCapture(value: any): any {
  if (value.kind === 'undefined') return undefined;
  if (value.kind === 'value') return value.value;
  assert.ok(value.kind === 'array' || value.kind === 'object');
  const result: any = value.kind === 'array' ? [] : {};
  for (const [key, child] of value.entries) {
    if (Array.isArray(result) && key === 'length') result.length = decodeCapture(child);
    else
      Object.defineProperty(result, key, {
        value: decodeCapture(child),
        writable: true,
        enumerable: true,
        configurable: true,
      });
  }
  return result;
}

function clock() {
  let now = 0;
  let nextId = 1;
  const pending = new Map<number, { at: number; callback: () => void }>();
  return {
    count: () => pending.size,
    now: () => now,
    elapse(milliseconds: number) {
      now += milliseconds;
    },
    setTimeout(callback: () => void, delay: number) {
      const id = nextId++;
      pending.set(id, { at: now + delay, callback });
      return id;
    },
    clearTimeout(id: number) {
      pending.delete(id);
    },
    tick(milliseconds: number) {
      now += milliseconds;
      for (const [id, task] of pending) {
        if (task.at > now) continue;
        pending.delete(id);
        task.callback();
      }
    },
  };
}

function managerFixture(
  source: string,
  costs: {
    history?: number;
    historyError?: Error;
    collaboration?: number;
    listEvaluation?: () => void;
  } = {},
) {
  const marker = '//#region src/services/doc-state-change-manager.service.ts\n';
  const start = source.indexOf(marker);
  const end = source.indexOf('//#endregion', start);
  assert.ok(start >= 0 && end > start, 'Execute the actual hash-verified manager region.');
  const timers = clock();
  const contextCore = { ...core, Inject: () => () => {}, Optional: () => () => {} };
  const ManagerClass = runInNewContext(
    `${source.slice(start + marker.length, end)}\nDocStateChangeManagerService;`,
    {
      __spn142List: <T>(value: T): T => {
        costs.listEvaluation?.();
        return value;
      },
      __qualificationTick: (name:string) => { qualification[name]=(qualification[name]??0)+1; },
      ...contextCore,
      Object,
      Array,
      performance: { now: timers.now },
      ...timers,
      BehaviorSubject,
      takeUntil,
      _univerjs_core: contextCore,
      rxjs: { BehaviorSubject, takeUntil },
      DocStateEmitService: {},
      _defineProperty: (object: Record<string, unknown>, key: string, value: unknown) => {
        object[key] = value;
        return object;
      },
      __decorate: (_decorators: unknown, constructor: unknown) => constructor,
      __decorateParam: () => () => {},
    },
    { filename: 'docs.installed-state-manager.js', timeout: 1000 },
  );
  const input = new Subject<IDocStateChangeInfo>();
  const history: Entry[] = [];
  const changes: State[] = [];
  const publication: { kind: string; history: number; collaboration: number }[] = [];
  const commands = new Set<(command: { id: string }) => void>();
  let manager: Manager;
  const observe = (kind: string) => {
    const cache = manager.getStateCache(unitId);
    publication.push({
      kind,
      history: cache.history.length,
      collaboration: cache.collaboration.length,
    });
  };
  manager = new ManagerClass(
    {
      pushUndoRedo(entry: Entry) {
        timers.elapse(costs.history ?? 0);
        if (costs.historyError) throw costs.historyError;
        observe('history');
        history.push(structuredClone(entry));
      },
    },
    {
      beforeCommandExecuted(listener: (command: { id: string }) => void) {
        commands.add(listener);
        return { dispose: () => commands.delete(listener) };
      },
    },
    { getCurrentUnitOfType: () => ({ getUnitId: () => unitId }) },
    { docStateChangeParams$: input },
  ) as Manager;
  const subscription = manager.docStateChange$.subscribe((state) => {
    if (!state) return;
    timers.elapse(costs.collaboration ?? 0);
    observe('collaboration');
    changes.push(structuredClone(state));
  });
  return {
    manager,
    input,
    timers,
    history,
    changes,
    publication,
    beforeCommand(id: string) {
      for (const listener of commands) listener({ id });
    },
    close() {
      subscription.unsubscribe();
      manager.dispose();
      input.complete();
      assert.equal(commands.size, 0);
      assert.equal(timers.count(), 0);
    },
  };
}

function apply(snapshot: IDocumentData, actions: JSONXActions) {
  const model = new core.DocumentDataModel(structuredClone(snapshot));
  try {
    model.apply(structuredClone(actions));
    return structuredClone(model.getSnapshot());
  } finally {
    model.dispose();
  }
}

function seed(text = 'alpha\rbravo\r\n') {
  const snapshot = core.getDocsEmptySnapshot(
    unitId,
    core.LocaleType.EN_US,
    'Composition',
    core.DocumentFlavor.MODERN,
  );
  snapshot.body = {
    dataStream: text,
    textRuns:
      text.length > 2
        ? [{ st: 0, ed: text.length - 2, ts: { bl: 1, cl: { rgb: '#123456' } } }]
        : [],
    paragraphs: [...text].flatMap((character, index) =>
      character === '\r'
        ? [
            {
              startIndex: index,
              // Native split replay preserves only IDs with the para_ prefix.
              paragraphId: `para_seed_${index}`,
              paragraphStyle: { outlineLevel: 1 },
            },
          ]
        : [],
    ),
    sectionBreaks: [{ startIndex: text.length - 1, sectionId: 'section_seed' }],
    customRanges:
      text.length > 6
        ? [
            {
              rangeId: 'link',
              rangeType: core.CustomRangeType.HYPERLINK,
              startIndex: 1,
              endIndex: 3,
              properties: { url: 'https://example.test/old' },
            },
          ]
        : [],
    customDecorations: [],
  };
  return apply(snapshot, null);
}

function sequence(requests: Request[], initial = seed()) {
  const snapshots = [initial];
  const states = requests.map((request, index): State => {
    const before = snapshots.at(-1)!;
    const actions = request(structuredClone(before));
    // This is the native mutation's inverse/apply order. Inversion realizes
    // inserted paragraph identities before the same actions are applied.
    const inverse = core.JSONX.invertWithDoc(actions, before);
    snapshots.push(apply(before, actions));
    return {
      commandId: 'doc.mutation.rich-text-editing',
      unitId,
      trigger: 'doc.command.insert-text',
      segmentId: '',
      noHistory: false,
      debounce: true,
      redoState: {
        actions,
        textRanges: [{ startOffset: index + 1, endOffset: index + 1, collapsed: true }],
        options: { restoreSelection: index % 2 === 0 },
        isEditing: index % 2 !== 0,
        layoutState: { step: index + 1, nested: ['redo', index] },
      },
      undoState: {
        actions: inverse,
        textRanges: [{ startOffset: index, endOffset: index, collapsed: true }],
        options: { restoreSelection: index % 2 !== 0 },
        isEditing: index % 2 === 0,
        layoutState: { step: index, nested: ['undo', index] },
      },
    };
  });
  // A native inverse need not recreate the seed's original representation:
  // deleting an insertion retains split style runs and initializes empty block
  // metadata. Derive the reverse oracle by applying the captured inverses one
  // at a time, with no composition and no metadata normalization in the test.
  const undoSnapshots: IDocumentData[] = [];
  undoSnapshots[states.length] = snapshots.at(-1)!;
  for (let index = states.length - 1; index >= 0; index--)
    undoSnapshots[index] = apply(undoSnapshots[index + 1], states[index].undoState.actions);
  return { states, snapshots, undoSnapshots };
}

const edit = (text: core.TextX) => core.JSONX.getInstance().editOp(text.serialize());
// Public DocInputController's collapsed input, after sync capture marks inserts
// before native apply. Captured browser caches in SPN-132 exposed this field.
function keyboardBody(index = 0): core.IDocumentBody {
  const body: core.IDocumentBody & { __textXPreserveParagraphIds: true } = {
    __textXPreserveParagraphIds: true,
    dataStream: 'x',
    textRuns: [{ st: 0, ed: 1, ts: { bl: index % 2 === 0 ? 1 : 0, cl: { rgb: '#123456' } } }],
    customRanges: [],
    customDecorations: [],
  };
  return body;
}
const insertAt =
  (offset: number, body = keyboardBody()): Request =>
  () =>
    edit(new core.TextX().retain(offset).insert(body.dataStream.length, body));

function paragraphSequence(
  position: number,
  length = 32,
  coverType = core.UpdateDocsAttributeType.COVER,
  offset = 0,
  decorate?: (body: core.IDocumentBody, isEnter: boolean) => void,
) {
  return sequence(
    Array.from({ length }, (_, index) => {
      const body = keyboardBody(index);
      decorate?.(body, index === position);
      if (index !== position) return insertAt(offset + index, body);
      return () =>
        edit(
          new core.TextX()
            .retain(offset + index)
            .insert(1, {
              ...body,
              dataStream: '\r',
              paragraphs: [
                { startIndex: 0, paragraphId: `para_insert_${position}`, paragraphStyle: {} },
              ],
            })
            .retain(
              1,
              {
                dataStream: '',
                textRuns: [{ st: 0, ed: 1, ts: { cl: { rgb: '#123456' } } }],
              },
              coverType,
            ),
        );
    }),
    seed('z'.repeat(offset + 1) + '\r\n'),
  );
}

const mixed: Request[] = [
  () =>
    edit(
      new core.TextX()
        .retain(2)
        .insert(2, { dataStream: 'XY', textRuns: [{ st: 0, ed: 2, ts: { it: 1 } }] }),
    ),
  () => edit(new core.TextX().retain(3).delete(1)),
  () =>
    edit(
      new core.TextX()
        .retain(8)
        .delete(2)
        .insert(1, { dataStream: 'Z', textRuns: [{ st: 0, ed: 1, ts: { bl: 0 } }] }),
    ),
  () =>
    edit(
      new core.TextX().retain(
        4,
        { dataStream: '', textRuns: [{ st: 0, ed: 4, ts: { bl: 1, it: 1 } }] },
        core.UpdateDocsAttributeType.COVER,
      ),
    ),
  () =>
    edit(
      new core.TextX().retain(
        4,
        { dataStream: '', textRuns: [{ st: 0, ed: 4, ts: { bl: 0 } }] },
        core.UpdateDocsAttributeType.REPLACE,
      ),
    ),
  (snapshot) =>
    edit(
      new core.TextX().retain(snapshot.body!.paragraphs![0].startIndex).retain(
        1,
        {
          dataStream: '',
          paragraphs: [
            {
              startIndex: 0,
              paragraphId: snapshot.body!.paragraphs![0].paragraphId,
              paragraphStyle: {},
            },
          ],
        },
        core.UpdateDocsAttributeType.REPLACE,
      ),
    ),
  (snapshot) => {
    const text = core.BuildTextUtils.customRange.add({
      ranges: [{ startOffset: 0, endOffset: 5, collapsed: false }],
      rangeId: 'replacement-link',
      rangeType: core.CustomRangeType.HYPERLINK,
      properties: { url: 'https://example.test/new' },
      body: snapshot.body!,
    });
    assert.ok(text);
    return edit(text);
  },
  (snapshot) => core.JSONX.getInstance().replaceOp(['title'], snapshot.title, 'Updated title'),
  (snapshot) =>
    edit(
      new core.TextX().retain(snapshot.body!.dataStream.length - 2).insert(1, {
        dataStream: '\r',
        paragraphs: [{ startIndex: 0, paragraphId: 'para_inserted' }],
      }),
    ),
  () => null,
  (snapshot) => edit(new core.TextX().retain(snapshot.body!.paragraphs![0].startIndex).delete(1)),
];

function ownDataShape(value: unknown, seen = new Map<object, number>()): unknown {
  if (value === null || typeof value !== 'object') return value;
  if (seen.has(value)) return { reference: seen.get(value) };
  seen.set(value, seen.size);
  return {
    prototype: Object.getPrototypeOf(value),
    properties: Reflect.ownKeys(value).map((key) => {
      const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
      return [
        key,
        'value' in descriptor
          ? { ...descriptor, value: ownDataShape(descriptor.value, seen) }
          : descriptor,
      ];
    }),
  };
}

function flush(source: string, history: State[], collaboration = history, raw = false) {
  const fixture = managerFixture(source);
  try {
    // Native caches are distinct arrays even when their state objects coincide.
    const inputCache = { history: [...history], collaboration: [...collaboration] };
    const cache = raw ? inputCache : structuredClone(inputCache);
    const retainedStates = [...cache.history, ...cache.collaboration];
    const before = structuredClone(retainedStates);
    const shapeBefore = raw ? ownDataShape(retainedStates) : undefined;
    fixture.manager.setStateCache(unitId, cache);
    fixture.manager.flushPendingChanges(unitId);
    if (raw)
      assert.deepEqual(
        ownDataShape(retainedStates),
        shapeBefore,
        'Own keys, descriptors and prototypes remain unchanged without reading accessors.',
      );
    assert.deepEqual(
      raw ? structuredClone(retainedStates) : retainedStates,
      before,
      'Composition must not mutate native state objects.',
    );
    assert.deepEqual(structuredClone(fixture.manager.getStateCache(unitId)), {
      history: [],
      collaboration: [],
    });
    return { history: fixture.history, changes: fixture.changes, publication: fixture.publication };
  } finally {
    fixture.close();
  }
}

function appliedSnapshots(
  output: ReturnType<typeof flush>,
  { snapshots }: ReturnType<typeof sequence>,
  historyStart = 0,
) {
  const after = snapshots.at(-1)!;
  const [entry] = output.history;
  const [change] = output.changes;
  return {
    history: entry && {
      redo: apply(snapshots[historyStart], entry.redoMutations[0].params.actions),
      undo: apply(after, entry.undoMutations[0].params.actions),
    },
    collaboration: change && {
      redo: apply(snapshots[0], change.redoState.actions),
      undo: apply(after, change.undoState.actions),
    },
  };
}

// The unmodified SDK can partition identical styles differently after aggregate
// versus individual inverse replay. This view is ONLY for that independent
// sequential oracle. Candidate publications and snapshots always compare raw.
function sequentialStyleView(snapshot: IDocumentData, context: string) {
  const otherFields = structuredClone(snapshot);
  const body = otherFields.body!;
  const ownsTextRuns = Object.hasOwn(body, 'textRuns');
  const runs = body.textRuns;
  delete body.textRuns;
  if (runs == null) return { otherFields, ownsTextRuns, runs };
  assert.ok(Array.isArray(runs), `${context}: textRuns must be an array.`);
  const covered: (Record<PropertyKey, unknown> | null)[] = Array.from(
    { length: body.dataStream.length },
    () => null,
  );
  const zeroLength: { at: number; attributes: Record<PropertyKey, unknown> }[] = [];
  let previousEnd = 0;
  for (const run of runs) {
    const { st, ed } = run;
    assert.ok(
      Number.isSafeInteger(st) &&
        Number.isSafeInteger(ed) &&
        st >= previousEnd &&
        ed >= st &&
        ed <= covered.length,
      `${context}: textRuns must be ordered, bounded and nonoverlapping.`,
    );
    const attributes = Object.fromEntries(
      Reflect.ownKeys(run)
        .filter((key) => key !== 'st' && key !== 'ed')
        .map((key) => [key, Reflect.get(run, key)]),
    );
    if (st === ed) zeroLength.push({ at: st, attributes });
    else for (let offset = st; offset < ed; offset++) covered[offset] = attributes;
    previousEnd = ed;
  }
  return { otherFields, ownsTextRuns, runs: { covered, zeroLength } };
}

function assertNativePreservation(
  control: ReturnType<typeof flush>,
  candidate: ReturnType<typeof flush>,
  scenario: ReturnType<typeof sequence>,
  context: string,
  historyStart = 0,
) {
  const label = `${context}, historyStart=${historyStart}`;
  assert.deepEqual(
    candidate,
    control,
    `${label}: complete native publications, including own undefined fields.`,
  );
  const originalSnapshots = appliedSnapshots(control, scenario, historyStart);
  const candidateSnapshots = appliedSnapshots(candidate, scenario, historyStart);
  assert.deepEqual(
    candidateSnapshots,
    originalSnapshots,
    `${label}: all complete applied snapshots.`,
  );
  for (const side of ['history', 'collaboration'] as const) {
    const snapshots = originalSnapshots[side];
    if (!snapshots) continue;
    assert.deepEqual(
      snapshots.redo,
      scenario.snapshots.at(-1),
      `${label}, ${side}/redo: sequential forward oracle.`,
    );
    const reverse = scenario.undoSnapshots[side === 'history' ? historyStart : 0];
    assert.deepEqual(
      sequentialStyleView(snapshots.undo, `${label}, ${side}/undo native`),
      sequentialStyleView(reverse, `${label}, ${side}/undo sequential`),
      `${label}, ${side}/undo: independent sequential authored styles and every other field.`,
    );
  }
}

function measuredFlush(source: string, states: State[], collaboration = states, raw = false) {
  const counts = { textCompose: 0, iteratorNext: 0, bodySlices: 0, cloneVisits: 0, allocations: 0 };
  const compose = core.TextX.compose;
  const next = core.ActionIterator.prototype.next;
  const clone = core.Tools.deepClone;
  core.TextX.compose = function (this: typeof core.TextX, ...args: Parameters<typeof compose>) {
    counts.textCompose++;
    return Reflect.apply(compose, this, args);
  };
  core.ActionIterator.prototype.next = function (
    this: core.ActionIterator,
    ...args: Parameters<typeof next>
  ) {
    counts.iteratorNext++;
    const action = Reflect.apply(next, this, args) as ReturnType<typeof next>;
    if (
      action.t === core.TextXActionType.INSERT ||
      (action.t === core.TextXActionType.RETAIN && action.body != null)
    )
      counts.bodySlices++;
    return action;
  };
  core.Tools.deepClone = function <T>(this: typeof core.Tools, value: T): T {
    counts.cloneVisits++;
    if (
      this.isDefine(value) &&
      (this.isRegExp(value) ||
        Reflect.apply(this.isDate, this, [value]) ||
        this.isArray(value) ||
        this.isObject(value))
    )
      counts.allocations++;
    return Reflect.apply(clone, this, [value]) as T;
  };
  try {
    return { output: flush(source, states, collaboration, raw), counts };
  } finally {
    core.TextX.compose = compose;
    core.ActionIterator.prototype.next = next;
    core.Tools.deepClone = clone;
  }
}


let qualification:Record<string,number>={};
const root='/Users/mxbaylee/projects/spinel-spn-146';
const hash=(b:string|Buffer)=>createHash('sha256').update(b).digest('hex');
const output='/tmp/spn146-linux-hosted/qualification-result.json';
const report:any={diagnosticOnly:true,scope:'Same-call qualification reuse; counts are not CPU time or runtime acceptance.',complete:false,results:[],flushes:0};
let failure:unknown;const began=performance.now();
const encode=(v:any):any=>v===undefined?{kind:'undefined'}:v===null||typeof v!=='object'?{kind:'value',value:v}:{kind:Array.isArray(v)?'array':'object',entries:Reflect.ownKeys(v).map(k=>[k,encode(v[k])])};
const replaceOnce=(s:string,a:string,b:string)=>{assert.equal(s.split(a).length,2,a);return s.replace(a,b);};
function prototype(s:string,format:Format){
 const json=format==='es'?'JSONX':'_univerjs_core.JSONX';
 return replaceOnce(s,`\t\tconst head = composeDocStateActions(states.slice(0, prefix + 1), key);\n\t\tconst tail = composeDocStateActions(states.slice(prefix + 1), key);\n\t\treturn ${json}.compose(head, tail);`,
 `\t\tlet head;\n\t\tif (prefix < 4) {\n\t\t\thead = null;\n\t\t\tfor (let index = 0; index <= prefix; index++) head = ${json}.compose(head, states[index][key].actions);\n\t\t} else head = ${json}.compose(composeRange(0, prefix), states[prefix][key].actions);\n\t\treturn ${json}.compose(head, composeRange(prefix + 1, states.length));`);
}
function instrument(s:string){
 for(const [name,args] of [['hasOnlyDocInsertKeys','value, keys'],['docInsertPrefixLength','states, key'],['docDeletePrefixLength','states, key'],['canComposeDocParagraphTail','states, key, prefix'],['isPlainDocDeleteData','value, depth = 0']])s=replaceOnce(s,`function ${name}(${args}) {`,`function ${name}(${args}) { __qualificationTick(${JSON.stringify(name)});`);
 s=replaceOnce(s,'const descriptor = Object.getOwnPropertyDescriptor(value, key);','__qualificationTick("descriptors"); const descriptor = Object.getOwnPropertyDescriptor(value, key);');
 return s;
}
try{
 assert.equal(hash(await readFile(root+'/scripts/dependencies/patch-univer-docs.test.ts')),'2b6408ad3b8af715c1e2221eef46e43781f3171283e9d6f7ac438c29ba1c28de');
 assert.equal(hash(await readFile(root+'/scripts/dependencies/patch-univer-docs.ts')),'dbc529e75246305a1e12496808e31369dce1b54c9706fdf5e57115dbfa904829');
 const entry=await readFile('/tmp/spn146-linux-hosted/component/source/entry.ts','utf8');assert.equal(hash(entry),'79623afaae1cbc83ac3767f48f2567d90cf343caf0080fc0539d44ec3f6f29c4');
 const match=entry.match(/^const pairs=(.*);$/m);assert.ok(match);const pairs=JSON.parse(match[1]);assert.equal(hash(JSON.stringify(pairs)),'e7768818642407ee6f559e251f49f9f408fb95e1ba317e1e9d92053134e97fb5');assert.deepEqual(pairs.map((p:any)=>[p.completed,p.sequences]),[[544,[32,33]],[672,[40,41]],[1440,[88,89]],[1984,[122,123]]]);
 for(const format of ['es','cjs'] as const){
  assert.equal(hash(await readFile(`/Users/mxbaylee/projects/spinel/node_modules/@univerjs/core/lib/${format}/index.js`)),format==='es'?'a019e7eb8b2ba235c7cfd54a19c262377a90c25aca13e5c2e0671a43b709e434':'ae2326c195fa7aa89be7199dd2a838d8f267f05c9dfee449a33c5ceae4d4a132');
  const current=prepareDocsPatch(await readBuild(format),format).patched;assert.equal(hash(current),format==='es'?'535ff692c3fd37ba10bdcc614720b8d848827c988f75fbbf9109ebf90d8d68c7':'bad73b55afd6b345dc20f78b5f60e799abf8b1a62585ef488bbb8d0c6b2033b7');
  for(const pair of pairs){
   const row:any={format,completed:pair.completed,sequences:pair.sequences,variants:[]};report.results.push(row);let oldOutput:any;
   for(const [variant,native] of [['current',current],['prototype',prototype(current,format)]] as const){
    assert.ok(performance.now()-began<60_000);report.active={format,completed:pair.completed,variant};qualification={};
    const instrumented=instrument(native),history=decodeCapture(pair.history),collaboration=decodeCapture(pair.collaboration);assert.equal(history.length,32);assert.equal(collaboration.length,32);
    const result=measuredFlush(instrumented,history,collaboration,true);report.flushes++;
    assert.equal(result.output.history.length,1);assert.equal(result.output.changes.length,1);
    if(variant==='current')oldOutput=result.output;else assert.deepEqual(result.output,oldOutput,'Complete raw publication/order parity');
    row.variants.push({variant,sourceSha256:hash(native),instrumentedSha256:hash(instrumented),counts:result.counts,qualification:{...qualification},outputSha256:hash(JSON.stringify(encode(result.output)))});
   }
   const [old,next]=row.variants;assert.deepEqual(next.counts,old.counts,'Primitive composition work unchanged');assert.equal(next.outputSha256,old.outputSha256);
   for(const key of ['docInsertPrefixLength','docDeletePrefixLength','descriptors'])assert.ok(next.qualification[key]<old.qualification[key],`${format}/${pair.completed}/${key}: strict reduction`);
   assert.equal(next.qualification.canComposeDocParagraphTail,old.qualification.canComposeDocParagraphTail,'Same full admission count');
  }
 }
 assert.equal(report.flushes,16);assert.equal(report.results.length,8);assert.ok(performance.now()-began<60_000);report.complete=true;
}catch(error){failure=error;report.failure=error instanceof Error?error.stack:String(error);}
finally{
 report.elapsedMs=performance.now()-began;report.scriptSha256=hash(await readFile('/tmp/spn146-investigation/qualification.ts'));
 try{await writeFile(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});}catch(error){failure??=error;console.error(JSON.stringify({primary:String(failure),persistence:String(error)}));}
}
if(failure)throw failure;
console.log(JSON.stringify(report));
