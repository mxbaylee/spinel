import {realpath} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
let qualification:Record<string,number>={};
const root='/Users/mxbaylee/projects/spinel-spn-146';
const hash=(b:string|Buffer)=>createHash('sha256').update(b).digest('hex');
const output='/tmp/spn146-linux-hosted/qualification-result.json';
const report:any={diagnosticOnly:true,scope:'Same-call qualification reuse; counts are not CPU time or runtime acceptance.',complete:false,results:[],flushes:0};
let failure:unknown;const began=performance.now();
const encode=(v:any):any=>v===undefined?{kind:'undefined'}:v===null||typeof v!=='object'?{kind:'value',value:v}:{kind:Array.isArray(v)?'array':'object',entries:Reflect.ownKeys(v).map(k=>[k,encode(v[k])])};
const replaceOnce=(s:string,a:string,b:string)=>{assert.equal(s.split(a).length,2,a);return s.replace(a,b);};
function prototype(s:string,format:Format){
 const json=format==='es'?'JSONX':'_univerjs_core.JSONX';
 return replaceOnce(s,`\t\tconst head = composeDocStateActions(states.slice(0, prefix + 1), key);\n\t\tconst tail = composeDocStateActions(states.slice(prefix + 1), key);\n\t\treturn ${json}.compose(head, tail);`,
 `\t\tlet head;\n\t\tif (prefix < 4) {\n\t\t\thead = null;\n\t\t\tfor (let index = 0; index <= prefix; index++) head = ${json}.compose(head, states[index][key].actions);\n\t\t} else head = ${json}.compose(composeRange(0, prefix), states[prefix][key].actions);\n\t\treturn ${json}.compose(head, composeRange(prefix + 1, states.length));`);
}
function instrument(s:string){
 for(const [name,args] of [['hasOnlyDocInsertKeys','value, keys'],['docInsertPrefixLength','states, key'],['docDeletePrefixLength','states, key'],['canComposeDocParagraphTail','states, key, prefix'],['isPlainDocDeleteData','value, depth = 0']])s=replaceOnce(s,`function ${name}(${args}) {`,`function ${name}(${args}) { __qualificationTick(${JSON.stringify(name)});`);
 s=replaceOnce(s,'const descriptor = Object.getOwnPropertyDescriptor(value, key);','__qualificationTick("descriptors"); const descriptor = Object.getOwnPropertyDescriptor(value, key);');
 return s;
}
try{
 report.scriptSha256=hash(await readFile('/tmp/spn146-investigation/qualification.ts'));
 report.coreImport=await realpath(fileURLToPath(import.meta.resolve('@univerjs/core')));
 assert.equal(report.coreImport,await realpath('/Users/mxbaylee/projects/spinel/node_modules/@univerjs/core/lib/es/index.js'));
 assert.equal(hash(await readFile(root+'/scripts/dependencies/patch-univer-docs.test.ts')),'2b6408ad3b8af715c1e2221eef46e43781f3171283e9d6f7ac438c29ba1c28de');
 assert.equal(hash(await readFile(root+'/scripts/dependencies/patch-univer-docs.ts')),'dbc529e75246305a1e12496808e31369dce1b54c9706fdf5e57115dbfa904829');
 const entry=await readFile('/tmp/spn146-linux-hosted/component/source/entry.ts','utf8');assert.equal(hash(entry),'79623afaae1cbc83ac3767f48f2567d90cf343caf0080fc0539d44ec3f6f29c4');
 const match=entry.match(/^const pairs=(.*);$/m);assert.ok(match);const pairs=JSON.parse(match[1]);assert.equal(hash(JSON.stringify(pairs)),'e7768818642407ee6f559e251f49f9f408fb95e1ba317e1e9d92053134e97fb5');assert.deepEqual(pairs.map((p:any)=>[p.completed,p.sequences]),[[544,[32,33]],[672,[40,41]],[1440,[88,89]],[1984,[122,123]]]);
 for(const format of ['es','cjs'] as const){
  assert.equal(hash(await readFile(`/Users/mxbaylee/projects/spinel/node_modules/@univerjs/core/lib/${format}/index.js`)),format==='es'?'a019e7eb8b2ba235c7cfd54a19c262377a90c25aca13e5c2e0671a43b709e434':'ae2326c195fa7aa89be7199dd2a838d8f267f05c9dfee449a33c5ceae4d4a132');
  const current=prepareDocsPatch(await readBuild(format),format).patched;assert.equal(hash(current),format==='es'?'535ff692c3fd37ba10bdcc614720b8d848827c988f75fbbf9109ebf90d8d68c7':'bad73b55afd6b345dc20f78b5f60e799abf8b1a62585ef488bbb8d0c6b2033b7');
  for(const pair of pairs){
   const row:any={format,completed:pair.completed,sequences:pair.sequences,variants:[]};report.results.push(row);let oldOutput:any;
   for(const [variant,native] of [['current',current],['prototype',prototype(current,format)]] as const){
    assert.ok(performance.now()-began<60_000);report.active={format,completed:pair.completed,variant};qualification={};
    const instrumented=instrument(native),history=decodeCapture(pair.history),collaboration=decodeCapture(pair.collaboration);assert.equal(history.length,32);assert.equal(collaboration.length,32);
    const result=measuredFlush(instrumented,history,collaboration,true);report.flushes++;
    const record={variant,sourceSha256:hash(native),instrumentedSha256:hash(instrumented),counts:result.counts,qualification:{...qualification},outputSha256:hash(JSON.stringify(encode(result.output))),verified:false};row.variants.push(record);
    assert.equal(result.output.history.length,1);assert.equal(result.output.changes.length,1);
    if(variant==='current')oldOutput=result.output;else assert.deepEqual(result.output,oldOutput,'Complete raw publication/order parity');record.verified=true;
   }
   const [old,next]=row.variants;assert.deepEqual(next.counts,old.counts,'Primitive composition work unchanged');assert.equal(next.outputSha256,old.outputSha256);
   for(const key of ['docInsertPrefixLength','docDeletePrefixLength','descriptors'])assert.ok(next.qualification[key]<old.qualification[key],`${format}/${pair.completed}/${key}: strict reduction`);
   assert.equal(next.qualification.canComposeDocParagraphTail,old.qualification.canComposeDocParagraphTail,'Same full admission count');
  }
 }
 assert.equal(report.flushes,16);assert.equal(report.results.length,8);assert.ok(performance.now()-began<60_000);report.complete=true;
}catch(error){failure=error;report.failure=error instanceof Error?error.stack:String(error);}
finally{
 report.elapsedMs=performance.now()-began;
 try{await writeFile(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});}catch(error){failure??=error;console.error(JSON.stringify({primary:String(failure),persistence:String(error)}));}
}
if(failure)throw failure;
console.log(JSON.stringify(report));
