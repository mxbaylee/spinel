# 🔎 SPN-146 qualification-reuse result and proposal — reviewer A

**The retained result supports implementing the exact narrow qualification-reuse proposal for maintained semantic validation. It does not establish runtime benefit, explain the original five slower comparisons, close SPN-146, or renew a browser experiment.** No concrete blocker to preparing that source proposal was found. This is not an exact-head grade or acceptance approval.

## 📦 Inspected evidence

Read the complete small `qualification-result.json`, watchdog, log opening and relevant current patch/fixture source. No flush, test, browser, converter or heavy trace parsing was executed by A. Result SHA-256 is **27d021506da63f636b80dfedffbedc3ac137c5bdb8fd099c4c34064d004b27a3**; watchdog SHA-256 is **b7fb0caabc34d77b7bba23d0c4769de0c218d02624025fcd10526371f9a93462**.

The result binds the reviewed script **d885c7f9e50a8e5279f72c8e973e3c2df3e5183d0bc93131522f9f5fc82772ad**, the resolved donor Core ES import and eight fixed format/window pairs: ES and CJS at completed 544, 672, 1440 and 1984, with recorded phase sequences 32/33, 40/41, 88/89 and 122/123. Both manager formats use the checked shared ES primitive implementation; this is not a separate execution of Core CJS.

All 16 variants returned verified results and the final result is complete. Internal diagnostic elapsed time is **338.156 ms**; the parent watchdog reports **833 ms**, peak observed **270,224 KiB**, pressure **1**, command-passed. These are diagnostic wall/resource observations, not uninstrumented native flush timings. The terminal inventory contains the watchdog and its inspection process, without the completed workload child; its scope is recorded task descendants, not system-wide absence.

## ✅ What the result establishes

Every current/prototype pair has equal raw publication fingerprints and identical retained TextX-compose, iterator, body-slice, clone-visit and allocation counts. Per flush, both delete-prefix and insert-prefix calls fall **8 → 4**; `hasOnlyDocInsertKeys` calls fall by **644**, descriptor visits by **108**, and `isPlainDocDeleteData` invocations by **112**. The full paragraph-tail admission count remains **2**. The distinction matters: these function counts include recursive shape visits; they do not show removal of the single complete graph guard from each admitted phase.

The prototype native identities are ES **110890e889ac362b22a4c38bafd1ebb4e7cf82e8107d4524bdb86ff7fe6bd7c3** and CJS **58edceea5e1fb66ff1a83ec0a92707cf6f8d741aab87eb922d9c7e021f99207d**. The complete-result path requires input value/descriptor nonmutation, emptied manager caches and fixture cleanup. No cleanup-failure field is recorded. These are the checked fixture contracts, not a new independent platform-cleanup journal.

The source mechanism aligns with those observations: after the unchanged full admission succeeds, it avoids invoking the general qualifier again on the already qualified head and tail. For prefix below four, the head retains its original sequential null accumulator through Enter. For larger prefixes, the original balanced prefix is composed with Enter once. The qualified tail uses the same balanced range tree, then joins the non-null head once. No new public bypass, global cache or admitted shape is needed. This is a small, explainable reduction of duplicated work.

## 🧪 Conditions for the production proposal

The proposed maintained validation is necessary and appropriate:

- Cover both COVER and REPLACE modes, ES/CJS, all 32 Enter positions and explicit prefix 0–3 boundaries. Retain the length/admission cutoff and cases that never enter this branch. The four retained inputs exercise prefix 3 and larger, not the full tiny-head matrix.
- Verify actual primitive operand sequence/tree, null-accumulator behavior, Enter/style retain ordering and final head/tail join. Equal total work counts alone cannot prove these stronger properties. Preserve raw fields, own undefined values, paragraph IDs/styles and divergent history/collaboration caches.
- Preserve unsupported-shape/accessor fallback behavior and read/call order. The full graph-descriptor guard and initial admissibility checks must remain intact; do not infer that reduced duplicate checks justify weakening them. Test rejected metadata, offsets, multiple Enter/islands, symbols and malformed states at meaningful positions.
- Retain input and publication ownership checks with actual references, not only cloned sink equality. The diagnostic sinks clone publication values, and its prototype snapshots compare structurally; those limits remain.
- Keep the exact previous candidate as an install-upgrade source and duplicate-work negative, preserve all older accepted upgrade paths, and prove idempotence/unknown-source rejection. The final generated ES/CJS bytes should match the inspected narrow prototype, or any difference needs explicit review.

Prefer these additions in the existing actual-manager fixture and existing patch tests. No separate generalized optimizer or production instrumentation is justified by this result.

## 📏 Remaining disposition

The original hosted component result remains **inconclusive: 8 of 16 threshold comparisons passed, 3 improved insufficiently and 5 slowed**, with the original strict analyzer failure preserved separately. This deterministic experiment establishes a redundant-work mechanism and its removal on actual retained inputs; it supplies no guard-inclusive CPU-time result, no allocation-to-latency conversion and no attribution of historical over-budget maxima. Aggregate anonymous profile symbols remain insufficient for an exact source attribution claim.

Preparing the narrow implementation and meaningful maintained controls is justified. Subsequent exact-source reviews, feasible local checks, selected hosted acceptance and an explicit evidence-supported runtime disposition still remain. No new runtime allowance follows automatically from this admission, and the expired/inconclusive prior allowance must remain retained as such.
