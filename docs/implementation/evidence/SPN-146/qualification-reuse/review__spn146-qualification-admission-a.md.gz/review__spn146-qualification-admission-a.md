# 🔎 SPN-146 qualification-reuse prototype — admission A

**The narrowly scoped lower-layer question is justified and the proposed composition substitution is structurally aligned. Execution admission is pending the small provenance/first-failure repairs below.** No manager flush, tests, browser, converter or other workload was executed by this reviewer.

Independently confirmed plan SHA-256 **99cd605b191c7f7faa81da469f48bf10371e2a192802fbbcd6295d3fe4b44296** and generated script SHA-256 **3dfba9a7977df23364053563a4bab5df766af0a5f562404d431a24fbd24bc266**. Read the builder, prototype/instrumentation body and reused generated fixture/counter code.

## 🛠️ Preparation findings

1. **Preserve primary failure through script-identity retention.** The `finally` block performs an unguarded `await readFile(qualification.ts)` before the protected result write. An identity-read failure can replace an earlier semantic/resource error and prevent its report/log. Read/bind script identity within the protected primary operation or catch an identity-retention error as secondary, retaining the original first cause.
2. **Bind the actual imported Core module.** The script hashes donor ES/CJS files but imports bare `@univerjs/core`. The observed investigation `node_modules` symlink points at the donor, so no contradictory module was found; nevertheless the declared exact primitive binding should assert/record actual import resolution/realpath against the checked ES Core file. Both manager formats use that shared ES Core implementation; hashing CJS bytes does not mean it was executed. No package write or installation is required.
3. **Retain a measured failing variant before assertions.** `row.variants.push` occurs after output-length/parity assertions. If a returned prototype measurement fails parity, its counts/source/output fingerprint are absent even though the flush count increments. Save the returned measurement with identity/counts/fingerprint before post-flush assertions and retain its failed verification status. Do not rerun to recover that evidence. If `measuredFlush` itself throws, preserve its active variant and first cause without claiming a completed measurement.

These fixes change only preparation/evidence ownership, not the fixed 16-flush allowance or hypothesis. Preserve original prepared bytes and rebind the repaired script before execution.

## ✅ Composition and instrumentation assessment

The string replacement is exact-once and limited to the already admitted single-Enter branch. It leaves the complete graph-descriptor predicate, Enter/metadata/offset checks, undo path and fallback implementation unchanged. Prefixes below four retain the original sequential null-accumulator head. Larger prefixes reuse the same balanced prefix, compose Enter once, and join the balanced tail. Reusing `composeRange(prefix+1, states.length)` preserves the shifted tail tree by range length; the nested function declaration remains available at this earlier branch.

Both variants receive identical function-entry and descriptor-visit instrumentation. The comparison separately requires identical existing TextX/iterator/slice/clone/allocation counters, strictly fewer prefix/delete qualification calls and descriptor visits, and the same enclosing admission-call count. These are useful deterministic work witnesses and an exact current-source negative; they do not measure elapsed CPU cost.

The generated fixture executes the hash-verified actual manager region with real primitives, fresh decoded pairs, raw input mode, before/after own-descriptor/nonmutation checks, queue clearing and timer/listener cleanup. `measuredFlush` restores its primitive instrumentation in `finally`. Output equality preserves own undefined values and publication order within the fixture.

## 📏 Scope of any successful result

The four retained pair prefixes include the real prefix-three case and larger prefixes, but not the complete zero/one/two/tiny/unsupported matrix. Full maintained validation remains necessary before a production proposal can qualify: both modes, every position, metadata/accumulator/ownership cases, unchanged fallback call/read order and old-work negative. Matching total primitive counters is **not** proof of exact operand identity/order; the source argument and later meaningful primitive-call controls must cover that stronger claim.

The fixture's sinks `structuredClone` publications. Consequently, this experiment's raw-publication equality does not independently prove original published-object nonaliasing. Its own-data-shape comparison also records prototypes for structural comparison rather than supplying a distinct prototype-reference mutation proof. Preserve those existing limitations; separate maintained ownership assertions remain necessary. Do not relabel this 16-flush diagnostic as the full production semantic suite.

The original Linux result remains mixed/inconclusive. This experiment can demonstrate removal of duplicate qualification while preserving current work/output on real inputs; it cannot assign anonymous profile samples to source, explain five slower comparisons, establish net time improvement, or renew any native experiment. No threshold or product-budget change is proposed.

Run at most the repaired fixed 16 cases under the declared independent 60-second normal-pressure/2-GiB parent watchdog. Synchronous manager work is bounded by that parent, not only the script's elapsed checks. Stop on the first failure and preserve partial evidence. **No execution admission until the three concrete preparation details above are revalidated.**

## ✅ Repaired preparation readback

Independently re-read the final generated script and confirmed SHA-256 **d885c7f9e50a8e5279f72c8e973e3c2df3e5183d0bc93131522f9f5fc82772ad**. The unchanged plan still hashes to **99cd605b191c7f7faa81da469f48bf10371e2a192802fbbcd6295d3fe4b44296**. The separately retained `qualification-before-review-repair.ts` hashes exactly to the original **3dfba9a7977df23364053563a4bab5df766af0a5f562404d431a24fbd24bc266**; it has not been relabeled as the repaired candidate.

All three preparation findings are closed on these inspected bytes. Script identity is read inside the primary protected operation, before any flush. Actual bare Core resolution is canonicalized with the imported `realpath` and `fileURLToPath` helpers and asserted against the hashed donor ES path. A returned variant now records native/instrumented identities, counters and output fingerprint with `verified:false` before output-length/parity assertions; only successful assertions set that flag. Per-row counter assertions and the final complete flag remain separate, so a later work-contract failure cannot become overall success.

The derived fixture also preserves an original flush exception if fixture cleanup fails: cleanup is attempted in `finally`, its error is retained in `report.cleanupFailures`, and it is thrown only when there was no primary failure. This is a preparation repair, not evidence that cleanup or any flush has executed successfully.

**No concrete remaining preparation blocker found. Admit exactly the one fixed 16-flush retained-input diagnostic under the declared independent 60-second, normal-pressure, 2-GiB parent watchdog.** This is narrow diagnostic admission only; all semantic coverage, ownership and runtime-causality limitations above remain. No test, flush, browser, converter or native workload was run by reviewer A. Production edits, a source grade, any new runtime allowance and ticket acceptance are not authorized or established by this review.
