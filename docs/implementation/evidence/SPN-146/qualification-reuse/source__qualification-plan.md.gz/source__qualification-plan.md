# 🔎 Same-call qualification reuse: bounded lower-layer question

2026-11-05, after source483bf8ae's inconclusive Linux experiment. Preserve that
failure and all16 comparisons. No browser, converter, runtime retry, threshold
revision or production edit is authorized by this diagnostic.

The actual source qualifies the whole plain-data graph, leading insert prefix,
one Enter and final append tail, then recursively calls the generic composer
for both already-qualified ranges. This repeats delete/prefix shape scans.
The retained CPU symbols corroborate executed qualifier work but do not bind
dynamic script IDs strongly enough for per-case cost attribution. GC overlap
does not explain every miss. Neither fact establishes the cause of old maxima.

Prototype only the admitted branch: reuse its existing composeRange on the
same prefix/tail. Preserve the initial-null sequential head for prefixes0–3;
otherwise compose the same balanced prefix with Enter once. Keep the exact
whole-graph descriptor guard, supported shape/metadata boundary, undo path and
every fallback unchanged. No persistent cache, new abstraction or weakened guard.

One16-flush diagnostic: four retained real cache pairs544/672/1440/1984 × ES/CJS
× current/prototype. The current exact candidate is the negative for extra work.
Use the existing actual-manager fixture and real pinned Core; controlled sinks,
raw own-undefined publication/order equality, unchanged inputs/descriptors,
queue/timer/listener cleanup. Record every original/prototype source hash and
both instrumented source hashes. Instrument function entries and descriptor
visits identically; do not infer CPU time from counts. Primitive work must be
identical, while prefix/delete qualification calls and descriptor visits must
strictly decrease in every pair. Failure stops; no retry, extra cases or timing
claim. This only admits a production proposal, whose full maintained semantic
matrix, independent exact-head reviews and fresh runtime/app acceptance remain.

Preparation writes a frozen derived fixture without executing it. Review its
exact script before one serial60second/normal-pressure/2GiB parent-watchdog run.
Stop on hash, semantic, cleanup or resource failure; preserve partial results
and primary errors. No post-failure fallback.
