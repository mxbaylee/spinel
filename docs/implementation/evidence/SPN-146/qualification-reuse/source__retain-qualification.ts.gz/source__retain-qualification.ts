import {readFileSync,writeFileSync,mkdirSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
const root='/Users/mxbaylee/projects/spinel-spn-146',receipts='/tmp/spn146-linux-hosted',target=root+'/docs/implementation/evidence/SPN-146/qualification-reuse';
const files:string[][]=[];
for(const name of readdirSync(receipts).filter(n=>/^(qualification-|runtime-repair-|trace-reader-regression|outcome-retention)/.test(n))) files.push(['receipts__'+name,receipts+'/'+name]);
for(const name of ['qualification-plan.md','qualification-before-review-repair.ts','qualification.ts','qualification-body.ts','build-qualification.ts','check-repaired-trace-reader.ts','build-qualification-preparation-bridge.ts','qualification-preparation-bridge.ts','build-verification.ts','verification.test.ts','retain-qualification.ts'])files.push(['source__'+name,'/tmp/spn146-investigation/'+name]);
for(const name of ['spn146-qualification-admission-a.md','spn146-qualification-admission-b.md','spn146-qualification-result-a.md','spn146-qualification-result-b.md']) files.push(['review__'+name,'/tmp/'+name]);
function append(dir:string,prefix:string){for(const item of readdirSync(dir,{withFileTypes:true})){if(item.isDirectory())append(dir+'/'+item.name,prefix+item.name+'__');else files.push([prefix+item.name,dir+'/'+item.name]);}}
append('/tmp/spn146-qualification-preparation','preparation__');
const hash=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
mkdirSync(target);
const payloads=files.map(([name,path])=>{const raw=readFileSync(path),stored=gzipSync(raw);writeFileSync(target+'/'+name+'.gz',stored,{flag:'wx'});return{name:name+'.gz',rawBytes:raw.length,storedBytes:stored.length,rawSha256:hash(raw),storedSha256:hash(stored)};});
const sourceBindings=['scripts/dependencies/patch-univer-docs.ts','scripts/dependencies/patch-univer-docs.test.ts','scripts/ci/doc-native-runtime/build.ts','scripts/ci/doc-native-runtime/analysis.ts','scripts/ci/doc-native-runtime.test.ts','.github/workflows/doc-native-runtime.yml'].map(path=>({path,sha256:hash(readFileSync(root+'/'+path))}));
writeFileSync(target+'/manifest.json',JSON.stringify({baseSource:'483bf8ae4609fa8027485293e6050fe8dca88e1c',disposition:'16-flush qualification-work diagnostic passed once;204 maintained semantic tests and26 runtime controls passed. Exact narrow candidate adopted. Source bindings describe the uncommitted working tree prepared before final review, not acceptance on baseSource. One new explicit runtime plan remains unexecuted/pending exact-head reviews. Original hosted experiment stays failed/inconclusive.',sourceBindings,payloads},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({payloads:payloads.length,storedBytes:payloads.reduce((n,p)=>n+p.storedBytes,0)}));
