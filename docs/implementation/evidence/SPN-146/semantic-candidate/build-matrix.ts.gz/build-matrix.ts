import {readFileSync,writeFileSync} from 'node:fs';
const previous=readFileSync('/tmp/spn146-investigation/tail.ts','utf8');
const marker='// Modified for SPN-146: semantic falsification, not a production transformation.';
if(previous.split(marker).length!==2)throw new Error('Unexpected prior probe');
writeFileSync('/tmp/spn146-investigation/matrix.ts',previous.slice(0,previous.indexOf(marker))+readFileSync('/tmp/spn146-investigation/matrix-body.ts','utf8'));
