import {readFileSync,writeFileSync} from 'node:fs';
const root='/Users/mxbaylee/projects/spinel-spn-146';
let source=readFileSync(root+'/scripts/dependencies/patch-univer-docs.test.ts','utf8');
source=source.replace("from './patch-univer-docs.ts'",`from '${root}/scripts/dependencies/patch-univer-docs.ts'`)
.replace("from '../../src/ui/nativeDocFlush.ts'",`from '${root}/src/ui/nativeDocFlush.ts'`)
.replace('`../../node_modules/@univerjs/docs/lib/${format}/index.js`','`file:///Users/mxbaylee/projects/spinel/node_modules/@univerjs/docs/lib/${format}/index.js`')
.replaceAll("'../../docs/",`'file://${root}/docs/`);
writeFileSync('/tmp/spn146-investigation/verification.test.ts',source);
