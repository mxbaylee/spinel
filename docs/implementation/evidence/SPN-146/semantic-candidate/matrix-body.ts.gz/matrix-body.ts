// Modified for SPN-146: finite existing-capture/Enter oracle matrix, experimental only.
const root='/Users/mxbaylee/projects/spinel-spn-146';
const hash=(b:string|Buffer)=>createHash('sha256').update(b).digest('hex');
const began=performance.now();const results:any[]=[];let failure:string|undefined;let activeCase:any;let flushes=0;
const deadline=setTimeout(()=>{console.error('60 second deadline');process.exit(2);},60_000);
function experimental(patched:string,format:Format){
 const json=format==='es'?'JSONX':'_univerjs_core.JSONX';
 const anchor='function composeDocStateActions(states, key) {';assert.equal(patched.split(anchor).length,2);
 return patched.replace(anchor,`
function composeDocStateActions(states,key) {
 if(key==='redoState') {
  const start=docInsertPrefixLength(states,key)+1;
  const tail=states.slice(start);
  if(tail.length>=4&&docInsertPrefixLength(tail,key)===tail.length)
   return ${json}.compose(composeOriginalDocStateActions(states.slice(0,start),key),composeOriginalDocStateActions(tail,key));
 }
 return composeOriginalDocStateActions(states,key);
}
function composeOriginalDocStateActions(states,key) {`);
}
try{
 const bytes=gunzipSync(await readFile(root+'/docs/implementation/evidence/SPN-142/native-caches.json.gz'));
 assert.equal(hash(bytes),'714376723b3ef6a048796f7a1903a58181098960960cecb111e22e0594a2e7c8');
 const captures=JSON.parse(bytes.toString()).captures.map(decodeCapture);
 for(const format of ['es','cjs'] as const){
  const {original,patched}=prepareDocsPatch(await readBuild(format),format);
  const candidate=experimental(patched,format);
  const first=JSON.parse(await readFile('/tmp/spn146-investigation/tail-results.json','utf8'));
  assert.equal(hash(candidate),first.results.find((r:any)=>r.format===format&&r.variant==='experimental').sha256);
  const check=(name:string,history:State[],collaboration:State[],scenario?:ReturnType<typeof sequence>,historyStart=0)=>{
   activeCase={format,name,historyStart};assert.ok(performance.now()-began<60_000);
   const measured=[original,patched,candidate].map((source,variant)=>{
    activeCase.variant=variant; const value=measuredFlush(source,history,collaboration,true);flushes++;return value;
   });
   assert.deepEqual(measured[1].output,measured[0].output,`${name}: current/upstream raw`);
   assert.deepEqual(measured[2].output,measured[0].output,`${name}: experimental/upstream raw`);
   if(scenario) assertNativePreservation(measured[0].output,measured[2].output,scenario,name,historyStart);
   results.push({format,name,historyStart,counts:measured.map(v=>v.counts)});
  };
  for(const [i,capture] of captures.entries())check(`capture-${i}`,capture.history,capture.collaboration);
  for(let position=0;position<32;position++){
   const scenario=sequence(Array.from({length:32},(_,index)=>{
    if(index!==position)return insertAt(index,keyboardBody(index));
    return ()=>edit(new core.TextX().retain(index).insert(1,{
     ...keyboardBody(index),dataStream:'\r',paragraphs:[{startIndex:0,paragraphId:`para_insert_${position}`,paragraphStyle:{}}]
    }).retain(1,{dataStream:'',textRuns:[{st:0,ed:1,ts:{cl:{rgb:'#123456'}}}]},core.UpdateDocsAttributeType.COVER));
   }),seed('z\r\n'));
   check(`enter-${position}`,scenario.states,scenario.states,scenario);
   if(position===5||position===19)check(`enter-${position}-unequal`,scenario.states.slice(7),scenario.states,scenario,7);
  }
 }
 assert.equal(flushes,252);assert.equal(results.length,84);
}catch(e){failure=e instanceof Error?e.stack:String(e);throw e;}
finally{
 clearTimeout(deadline);
 const result={diagnosticOnly:true,status:failure?'failed':'passed',failure,elapsedMs:performance.now()-began,flushes,activeCase,results,coreSha256:hash(await readFile(new URL(import.meta.resolve('@univerjs/core')))),probeSha256:hash(await readFile('/tmp/spn146-investigation/matrix.ts'))};
 await writeFile('/tmp/spn146-investigation/matrix-results.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:result.status,flushes,completed:results.length,activeCase,failure,elapsedMs:result.elapsedMs}));
}
