# 🔎 SPN-146 candidate inspection A

**Disposition:** the uncommitted candidate is a reasonably narrow implementation of the admitted semantic question, but the inspected version needs a guard repair and targeted admitted-shape verification before exact-head review. This is an early read-only inspection, not a numerical grade, production approval or native acceptance.

Inspected the working diff of `scripts/dependencies/patch-univer-docs.ts` and its maintained tests in `/Users/mxbaylee/projects/spinel-spn-146`, the implementation checkpoint and retained 252-flush matrix source. No execution or source edits. The parent was running the new focused controls; their eventual outcome is not precredited here. Findings refer to the version first inspected during this task; later repairs require explicit disposition.

## 🐛 Required guard repair

**P2 — primitive paragraph styles can throw in the new qualifier instead of taking the old path.** `isDocParagraphBody` ends with `paragraph.paragraphStyle != null && !Array.isArray(paragraph.paragraphStyle) && Reflect.ownKeys(paragraph.paragraphStyle).length === 0`. The preceding recursive plain-data guard permits primitive numbers, booleans and strings. Therefore a primitive style such as `0` reaches `Reflect.ownKeys(0)` and throws a TypeError during qualification. This is a new failure point before the unchanged helper and violates the stated unsupported-shape fallback boundary. Static inspection establishes the new throw; I did not execute the old helper on that case or claim its exact result.

Require an explicit non-null object check before `Reflect.ownKeys`, then compare original and candidate output/error, operand call order and input preservation for primitive paragraph styles. This is a local predicate repair; it does not justify broadening the admitted metadata class. Parent was notified immediately.

## 🧪 Remaining verification needed for the admitted join

**Targeted gap — admitted metadata representations across the structural accumulator.** The guard admits absent/own-undefined/empty body metadata and style values beyond the positive paragraph fixtures currently shown. The all-position fixtures exercise alternating bold styles, fixed color, a fixed following retain and both COVER/REPLACE, and the retained cache provides an additional native shape. That is meaningful evidence. However, old plain-prefix tests for empty/undefined fields do not establish equivalence when those fields cross the new non-null Enter accumulator.

Before a final source review, add a small finite matrix of *accepted* joins covering missing versus own-undefined versus empty relevant body fields; absent/undefined/empty `ts`; marker presence/absence where admitted; and contrasting first/next suffix styles against the Enter's following retain. Compare the complete native raw action/publication result with the exact previous helper, and complete applied snapshots where the authored case is valid. Keep candidate/native comparisons unnormalized. Unsupported metadata tests cannot substitute for positive coverage of shapes the new predicate deliberately accepts.

The shown ownership test checks nested result objects do not alias state objects, checks result prototypes and verifies output mutation leaves the states unchanged. The fallback suite compares raw result or first error, call lists, original right-operand identity, getter count and input descriptors. Those are useful outcomes rather than tests merely restating the predicate. A getter *count* is narrower than an ordered multi-getter read trace: the two current accessor cases have one tracked getter each. Avoid claiming universal accessor order from those cases alone; add an ordered multiple-getter case if that stronger contract is claimed.

## 🧱 Guard and accumulator assessment

The implementation fixes the broad experiment's principal admission flaw: it explicitly recognizes one root-body Enter insertion plus its one-character COVER/REPLACE retain and old body, allows only a default paragraph style and a paragraph identity, checks a fully qualified final plain-insert suffix, and requires contiguous append offsets across the boundary and matching outer unit/segment. Prepend, a second Enter, generic unsupported boundaries, displaced tails and unknown structural fields have explicit fallback controls.

The new branch runs only for redo with at least four trailing states. Undo/delete-prefix handling stays before it, and plain-only groups never enter it. Recursive calls are bounded and understandable: the head ends at its first unsupported state, so cannot qualify for another suffix join; the suffix is entirely plain, so also cannot qualify. The head and tail are composed by the existing implementation and joined once through native JSONX. No mutation of the original actions, metadata normalization, custom concatenation or changed publication point is introduced in the visible transformation.

The central proof remains raw equality between native sequential composition beginning at the structural head and native composition of that head with the grouped suffix. The 252-flush experimental matrix establishes meaningful cases across upstream/current/experimental ES and CJS, all Enter positions, retained captures and unequal caches. It is correctly kept distinct from this narrower implementation's own tests. Explicit COVER versus REPLACE handling repairs the first candidate work-negative failure without pretending that failure was semantic corruption; its retained disposition is appropriate.

## ⚙️ Complexity and resource observations

The change is scoped to the existing package patch rather than introducing a generic composition framework. Exact SPN-142 bytes remain an installer-upgrade source and a deterministic work negative. The new helper's static key lists and short recursive decomposition are proportionate to the narrow shape.

There is one concrete cost to measure before claiming the net mechanism: `isPlainDocDeleteData(states)` traverses every state, including undo actions, selection/layout/options metadata and repeated shared objects, to depth 16. This is conservative for accessors but broader than the fields the new guard actually reads. Its recursion has no visited-set deduplication; rejected deep/cyclic shapes eventually fall back. Current clone/iterator counters do not count this descriptor traversal, `Reflect.ownKeys` arrays, slices or all native allocations. Do not optimize this guard speculatively merely because it looks broad; either show its bounded cost for actual admitted caches and large/rejected metadata, or narrow descriptor checks carefully while preserving the fallback/read contract. Existing primitive reduction alone is not an end-to-end performance result.

The full-state guard rejects ordinary accessors before new field reads once the old prefix qualification has run. It does not prove observational transparency for arbitrary Proxies, whose own-key/prototype/descriptor traps can be observable. Native retained data is plain data; state that actual scope instead of a universal JavaScript-object guarantee.

## 🧭 Outcome still pending

Both setup resource aborts remain failures of local capability, not permission for further installs or browser attempts without resource readiness. Historical slow windows have no recovered failed action caches/profile. Lower deterministic work and passing semantic tests do not establish historical causality or replace the unchanged native 100 ms maximum, full workload, access/persistence/history and all selected current-head checks.

Operator simplicity favors this explicit narrow predicate; Owner and Collaborator need raw content/history/metadata equality; editable Link guests keep unchanged access boundaries. Preserve those requirements, repair the primitive-style qualifier, cover the admitted metadata join, and then obtain exact-source reviews after relevant feasible checks. No grade or acceptance pass is issued here.
