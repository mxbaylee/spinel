import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream} from 'node:fs';
import {readFile,writeFile,lstat,readdir,readlink,realpath,rename} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {resolve,relative} from 'node:path';
import {patchInstalledCore,patchCore} from '/Users/mxbaylee/projects/spinel-spn-146/scripts/dependencies/patch-univer-core.ts';
import {patchInstalledDocs,prepareDocsPatch} from '/Users/mxbaylee/projects/spinel-spn-146/scripts/dependencies/patch-univer-docs.ts';
import {patchInstalledUi,patchUi} from '/Users/mxbaylee/projects/spinel-spn-146/scripts/dependencies/patch-univer-ui.ts';
import {patchInstalledDrawing,patchDrawing} from '/Users/mxbaylee/projects/spinel-spn-146/scripts/dependencies/patch-univer-drawing.ts';
import {patchInstalledDocsUi,prepareDocsUiPatch} from '/Users/mxbaylee/projects/spinel-spn-146/scripts/dependencies/patch-univer-docs-ui.ts';
const donor='/Users/mxbaylee/projects/spinel',owner='/Users/mxbaylee/projects/spinel-spn-146',out='/tmp/spn146-investigation/';
const hash=(v:string|Buffer)=>createHash('sha256').update(v).digest('hex');
const started=Date.now(); const receipt:any={diagnosticOnly:true,started,donor,owner,stage:'identity',packages:0,missingOptional:[],patches:[]};
const deadline=()=>assert.ok(Date.now()-started<360_000,'six minute preparation deadline');
async function fileHash(path:string){const h=createHash('sha256');for await(const part of createReadStream(path))h.update(part);return h.digest('hex');}
async function inventory(root:string){
 const rows:any[]=[];
 async function walk(path:string){
  for(const name of (await readdir(path)).sort()){
   deadline();const file=path+'/'+name,st=await lstat(file),local=relative(root,file);
   if(st.isSymbolicLink())rows.push({path:local,kind:'link',target:await readlink(file)});
   else if(st.isDirectory())await walk(file);
   else {assert.ok(st.isFile(),`unsupported file ${local}`);assert.equal(st.nlink,1,`hard link ${local}`);rows.push({path:local,kind:'file',bytes:st.size,sha256:await fileHash(file),ino:st.ino});}
  }
 }await walk(root);return rows;
}
try{
 const lock=await readFile(owner+'/package-lock.json');assert.deepEqual(await readFile(donor+'/package-lock.json'),lock);
 receipt.lockSha256=hash(lock);receipt.installedLockSha256=await fileHash(donor+'/node_modules/.package-lock.json');
 const packages=JSON.parse(lock.toString()).packages;
 for(const [path,value]of Object.entries(packages) as [string,any][]){
  if(!path.startsWith('node_modules/'))continue;deadline();
  let installed:any;
  try{installed=JSON.parse(await readFile(donor+'/'+path+'/package.json','utf8'));}
  catch(e){if(value.optional&&(e as any).code==='ENOENT'){receipt.missingOptional.push(path);continue;}throw e;}
  if(!value.link)assert.equal(installed.version,value.version,`installed version ${path}`);
  receipt.packages++;
 }
 receipt.stage='snapshot';const before=await inventory(donor+'/node_modules');
 await writeFile(out+'clone-donor-manifest.json',JSON.stringify(before));
 await rename(owner+'/node_modules',out+'aborted-node_modules-2');
 receipt.stage='clone';execFileSync('cp',['-cR',donor+'/node_modules',owner+'/node_modules'],{timeout:120_000});
 receipt.stage='isolation';const copied=await inventory(owner+'/node_modules');
 const content=(rows:any[])=>rows.map(({ino,...row})=>row);
 assert.deepEqual(content(copied),content(before),'complete copied content');
 for(const [index,row]of copied.entries()){
  if(row.kind==='file')assert.notEqual(row.ino,before[index].ino,`independent inode ${row.path}`);
  else{
   const destination=await realpath(owner+'/node_modules/'+row.path);
   assert.ok(destination.startsWith(owner+'/node_modules/')||destination.startsWith(owner+'/lib/'),`escaping link ${row.path}: ${destination}`);
  }
 }
 receipt.files=copied.length;receipt.manifestSha256=hash(JSON.stringify(content(before)));
 const patchers=[['core',patchInstalledCore,patchCore],['docs',patchInstalledDocs,(s:string,f:any)=>prepareDocsPatch(s,f).patched],['ui',patchInstalledUi,patchUi],['drawing',patchInstalledDrawing,patchDrawing],['docs-ui',patchInstalledDocsUi,(s:string,f:any)=>prepareDocsUiPatch(s,f).patched]] as const;
 receipt.stage='patch';
 for(const [name,install,prepare]of patchers){
  const expected=[];
  for(const format of ['es','cjs'] as const){
   const file=`node_modules/@univerjs/${name}/lib/${format}/index.js`;
   assert.equal(await realpath(owner+'/'+file),resolve(owner,file));
   const original=await readFile(owner+'/'+file,'utf8');
   expected.push({file,beforeSha256:hash(original),afterSha256:hash(prepare(original,format))});
  }
  await install(owner);
  for(const row of expected){assert.equal(await fileHash(owner+'/'+row.file),row.afterSha256);receipt.patches.push(row);}
 }
 receipt.stage='donor-recheck';assert.deepEqual(await inventory(donor+'/node_modules'),before,'donor remains unchanged');
 assert.equal(await fileHash(donor+'/package-lock.json'),receipt.lockSha256);
 assert.equal(await fileHash(donor+'/node_modules/.package-lock.json'),receipt.installedLockSha256);
 receipt.status='passed';receipt.stage='complete';
}catch(e){receipt.status='failed';receipt.failure=e instanceof Error?e.stack:String(e);throw e;}
finally{receipt.elapsedMs=Date.now()-started;await writeFile(out+'clone-receipt.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));}
