# 🧭 SPN-146 explicit hosted-environment plan revision B

Independent read-only scope/process judgment. No action, workload, grade, workflow dispatch or publication is performed or authorized by this report.

**Yes: a separately preregistered, independently reviewed single Linux hosted component attempt is an acceptable explicit plan revision.** The earlier “no automatic hosted fallback” rule prevented implicit renewal after a failed attempt; it does not prohibit a documented new capability decision under the existing runbook and owner-authorized work. The runbook explicitly assigns resource-blocked or unsafe local validation to hosted CI. Retaining the failed local attempt and obtaining review before choosing a different environment honors that boundary.

## ✅ Why this revision is justified

The local attempt failed during Chromium startup because system memory pressure rose. No component observations, matched comparisons, CPU profile or trace were obtained. Thus this proposal does not discard unfavorable timing samples, repeat a contradictory experiment or wait for a desired result. The original finite local allowance must be closed permanently and retained as resource-aborted, including known-process cleanup and the absence of measurements.

The proposed hosted work asks the same still-unanswered guard-inclusive component-cost question on a feasible runtime, rather than repeating the separate 2,086-key full-application diagnostic. Existing Linux application runs establish that the hosted environment can install and launch the pinned browser; they do **not** prove this component bundle, trace collection, GC control or causal criterion will succeed. That remaining uncertainty is precisely why the new lane stays a bounded experiment with a first outcome, not accepted evidence in advance.

Linux is also relevant to the independently owned application acceptance environment. No result may be pooled with the nonexistent Mac observations or presented as cross-platform qualification.

## 📋 Conditions to record before execution

- Name this as an **explicit environment/capability revision**, not a new causal hypothesis or an unnoticed continuation. Link the original plan, rejected preparations/reviews, local resource abort and this disposition. State that local execution is closed, zero observations were obtained, and no automatic further fallback follows.
- Admit exactly one clean Linux hosted component attempt: the same four immutable cache pairs, both exact prior/candidate manager representations, the same two fixed orders, 32 observations/16 comparisons, 4× CPU throttle, all-observation retention and immediate first-semantic-failure stop. No warmup, replacement case, resampling or unchanged rerun.
- Preserve the preregistered positive criterion of **both ≥20% and ≥1 ms whole-flush reduction in every matched comparison**, with complete phase/clock/pause evidence. Do not reinterpret mixed or small results after seeing them. Contradictory or incomplete results retain their original classifications and stop the allowance.
- Bind exact reviewed source/tree, native/Core/input/fixture identities, generated bundle and transitive dependency closure, actual Chromium version/platform and throttle acknowledgment. A clean install replaces the unavailable local capability; it does not excuse changed native bytes, sinks, instrumentation or data.
- Define bounded clean installation/preparation, one runtime phase and one conversion/analysis phase separately. Preserve the existing measurement, collection, memory and ownership protections; any platform-specific watchdog adaptation must retain process-tree ownership and terminate only task resources. Keep partial journaling/retrieval, deadline interruption, late-stream settlement, first failure and incomplete-output handling.
- Implement a real **pre-merge execution route** bound to the new reviewed source and explicit one-time allowance. The new PR is already open, and a workflow not on main cannot simply rely on manual dispatch. Review the concrete event/selection guards so synchronization, body edits, unrelated refs or later metadata work cannot silently repeat this experiment.
- Finish feasible local checks and two independent qualifying reviews of the complete exact candidate before the validation publication, including the workflow, hosted adapter, analysis and maintained plan. Fresh source checks remain distinct from the older 1eeb application successes. Do not trigger unrelated repetitions merely to collect a new component result.

## 🎯 What a result would permit

A valid positive result would supply the missing intervention evidence for this component on Linux, including guard cost, controlled publication dispatch and observed runtime-pause boundaries. Together with unchanged current-source full-application latency/content/history/access/persistence acceptance, it could support an honest final ticket disposition while leaving exact uncaptured historical pause contributions unknown.

It would not retroactively accept the first hosted trace failure, prove complete historical maxima came from this mechanism, or make controlled sinks equivalent to full app subscribers. A failed, resource-aborted, invalid-trace or inconclusive hosted result would not authorize another environment or a relaxed criterion. Those outcomes require retention and a fresh disposition, not an automatic loop.

## Disposition

There is no concrete process reason to abandon SPN-146 solely because the local capability failed before measurements. The proposed explicit, finite hosted revision is legitimate under the runbook **subject to the concrete plan/source/ownership reviews above**. The ticket remains pending until actual evidence and required acceptance are complete. This is scope/admission advice, not approval of an unseen implementation, a grade, dispatch authority or merge approval.
