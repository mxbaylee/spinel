# 🐧 SPN-146 Linux lane — independent draft inspection A

**The explicit Linux environment revision and event route are supportable, but the draft analyzer/resource guards need the concrete fail-closed repairs below before the single validation publication.** This is a read-only review of uncommitted preparation, not an exact-head grade or execution authorization. No component, browser, converter, test, or other validation workload was executed.

Reviewed `.github/workflows/doc-native-runtime.yml`, the five new runtime modules, synthetic controls, reused frozen browser-body design, and the explicit Linux section in the implementation record. The proposed lane preserves the closed local resource-aborted allowance and failed original hosted diagnostic.

## 🛠️ Findings before publication

1. **P2 — GC representations can be accepted without usable per-interval evidence.** `analysis.ts` permits `I`/`i` GC events, but only `X` and reconstructed `B`/`E` contribute to `gcIntervals` and `gcOverlaps`. A valid later `X` control therefore allows `valid:true`/positive disposition while a GC marker in a measured interval has unrepresented duration. Retaining the raw `gcEvents` is valuable but does not make an empty overlap list a complete pause account. Either reject that unsupported attribution or expose per-interval unresolved GC evidence and prevent an unsupported positive causal disposition. Do not infer zero pause from a durationless event. Add a negative/explicit-inconclusive control containing a measured GC instant plus an otherwise valid interval control.

2. **P2 — the forced-GC witness only requires overlap.** A GC interval that starts before the post-observation control and spans it can satisfy `control.length > 0`; this does not demonstrate observation of the requested post-32 `collectGarbage` control. Require a valid bounded GC interval attributable to that control, using the measured clock uncertainty, and cover an earlier spanning interval as a negative. Preserve overlapping/nested GC records; never subtract their duration to manufacture the registered improvement.

3. **P2 — final observed resource violations can pass.** `watchdog.ts` applies RSS/available-memory bounds on interval snapshots, but its final snapshot is not subjected to the same checks (only elapsed time is checked afterward). A final observed RSS above 2 GiB or MemAvailable below 1 GiB can consequently be written as `passed` if no interval tick saw it. Apply the same finite/availability/RSS/deadline validation to the final observation before success and retain the failing reason. A small deterministic boundary helper/control is sufficient; another browser run is unnecessary.

These are concrete preparation issues and do not consume a native allowance. Retain original preparation/control results and revalidate the repaired complete commit before publication. I have not independently evaluated a later edit to these files.

## 🚦 Event and source admission

The route is materially narrower than an ordinary repeated PR workflow: only `pull_request.synchronize` targeting main, same repository, exact owning branch, and `before == 1eeb90f1d50291791d39913350c28c672c7154ee`. It checks workflow attempt 1 before installation and checks out the event's exact head; the runner compares that checkout with the reviewed-head environment. PR edits, reopening and normal subsequent updates do not renew this allowance. This is not a persistent lock against intentionally rewinding and repeating the branch transition; the process must prohibit that just as it prohibits manually changing the trigger to regain attempts.

The relevant GitHub-supported PR event/check-out behavior is documented in [GitHub's workflow event reference](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows). The [Octokit synchronize payload schema](https://raw.githubusercontent.com/octokit/webhooks/main/payload-schemas/api.github.com/pull_request/synchronize.schema.json) explicitly includes required `before`/`after` fields. The route therefore avoids the earlier default-branch-only dispatch capability problem. Concrete workflow source, event before/after, run/attempt and checked-out head still belong in the actual receipt.

The 15-minute job, eight-minute clean setup, and three separately bounded 60-second phases are prospectively specified. Ordinary selected CI remains separate and must run on the eventual reviewed source. A setup/trace/resource failure is not permission to repeat this lane.

## 🔗 Inputs, measurements and ownership

The builder validates retained artifacts against the maintained manifest, checks the four selected sequences and fixed input hash, and binds exact prior/candidate manager/Core identities. It reuses the frozen repaired browser body by hash; that preserves the one-shot journal, immediate pair parity, post-flush nonmutation checks and primary/cleanup error separation. Bundle closure/module hashes and package versions are retained. A local builder bridge proves preparation capability only; it is not a Linux runtime sample.

The runner keeps fixed 32 observations, shared 4× throttle, marks and phase nesting, post-observation GC control, strict bounded trace collection, and original cached teardown promises. It retrieves existing partial state without calling the experiment again. The Linux watchdog retains identities across reparenting and checks start identity before signalling. Its ownership control currently tests the selector; it does not establish every monitor/signal failure path. Monitoring failure must remain failure and must not be reported as settled cleanup without a terminal owned-process inventory.

The analyzer checks all fixed case identities, positive finite ranges, per-case cleanup/parity, raw paired output, phase nesting, 194 unique same-thread marks, and a 0.25-ms offset spread. Threshold comparison preserves all 16 matches and requires both 20% and 1 ms; it does not average or subtract pauses. The duration and clock rules are appropriate bounded evidence checks, subject to the GC findings above. The profile is retained and hash-bound without pretending its sample times give exact cause attribution.

The converter reuses the strict authority/framing/import/child-cleanup path and validates raw/stored/derived hashes before bounded JSON analysis. A valid but inconclusive or contradictory result is preserved and fails the diagnostic outcome. It must not cause an unchanged rerun. No inference is made here that the unseen actual trace will use the anticipated event representations or satisfy the thresholds.

## 📏 Acceptance limits

A successful outcome would be Linux-specific component evidence with controlled sinks/timers and shared ES Core for both manager formats. It would not reproduce or explain the full historical maxima, establish device-population latency, or include real app renderer/subscriber/transport costs. The complete actual trace, partial failures, GC/control representation, clock limits and watchdog receipts need independent outcome audit before any final causal disposition. The current green application source remains separate from the later diagnostic implementation head.

No final source score is assigned. The three findings above require repair before the exact committed candidate is eligible for a qualifying pre-push review.

## 🔄 Draft repair readback

After the initial inspection, read the revised source and three added controls. GC instant representations are now rejected; the positive-duration control must fit fully inside the control's clock-uncertainty interior. Findings 1 and 2 are closed by static inspection. The explicit RxJS `esm5` alias now matches the original browser bundle dependency choice; retain the earlier nonidentical bridge preparation as reported.

Finding 3 is substantially repaired by the shared finite resource-policy helper at preflight, ticks and `checking-final`, but one concrete finalization detail remains: after checking the `checking-final` snapshot, the code calls `snapshot('passed')`, which performs a new unvalidated resource read. The actual passed receipt could still contain newly crossed bounds. Write/finalize the already-checked snapshot or select disposition after validating the final read itself. This is the same final-observation finding, not a request for another browser test or expanded scope. No final grade is assigned while source remains uncommitted.
