import {readFileSync,writeFileSync} from 'node:fs';
const root='/Users/mxbaylee/projects/spinel-spn-146';
let source=readFileSync(root+'/scripts/ci/doc-native-runtime/build.ts','utf8');
source=source.replace("from 'vite'","from '/Users/mxbaylee/projects/spinel/node_modules/vite/dist/node/index.js'").replace("from '../../dependencies/patch-univer-docs.ts'",`from '${root}/scripts/dependencies/patch-univer-docs.ts'`).replace("new URL('./build.ts', import.meta.url)",`new URL('file://${root}/scripts/ci/doc-native-runtime/build.ts')`);
writeFileSync('/tmp/spn146-investigation/hosted-preparation-bridge.ts',source,{flag:'wx'});
