# 🔬 SPN-146 prospective Linux lane — independent inspection B

Read-only inspection of the uncommitted Linux lane in `/Users/mxbaylee/projects/spinel-spn-146`, 2026-11-05. This is an execution-admission inspection, not an exact-head source grade, hosted pass, causal conclusion or merge approval. No browser, converter, tests or resource workload was executed by this reviewer. Project files were not changed.

## Decision

The explicit Linux environment revision is a legitimate next capability plan: the Mac allowance is permanently closed after zero observations, the failed original full-workload diagnostic is retained, and no favorable sample is discarded or pooled across environments. The declared component question remains distinct from full application acceptance and from explaining historical maximum pauses. The lane is substantially narrower than repeating the long application diagnostic.

**Do not treat the inspected version as execution-ready until the final-journal persistence gap below is repaired and independently revalidated.** Complete and commit the candidate, preserve local checks and obtain both exact-source reviews before the single validation push. This report authorizes no rerun, fallback or expanded threshold.

## Findings requiring repair

1. **Final progress persistence can fail after the last rejection check.** `run.ts` checks `progress.persistenceFailure` before `progress.terminal(...)`. The shared progress writer deliberately catches write/rename failures. If only the terminal write fails, `observation.json` can already contain `complete: true`, the runner exits successfully, and `convert.ts` currently never checks the terminal journal. Thus a missing final cleanup/terminal receipt can be accepted despite the declared complete-evidence contract. Check the writer after terminal publication and fail the process; independently require a passed terminal journal, no original/persistence failure or dropped events, and the expected cleanup witness before analysis can pass. Add a deterministic terminal-write-only negative and a stale/missing/failed journal negative; no browser run is needed to prove these boundaries.

2. **Final analysis receipt persistence replaces a primary failure.** `convert.ts` records an earlier conversion, validation or criterion error, then awaits an unguarded `writeFile(analysis.json)` in `finally`. A second persistence error replaces the original thrown cause. Preserve the original cause and report the persistence failure separately; persistence-only failure must also exit nonzero. Retain a bounded dual-failure negative.

Both findings were sent to the parent while source changes were still uncommitted. They concern evidence authority and first-failure preservation, not a claim that the hosted environment has actually suffered either error.

## Route, bounds and identity

The workflow is reachable through `pull_request/synchronize`, requires the same repository and exact ticket branch, and binds `github.event.before` to the published `1eeb90f1d50291791d39913350c28c672c7154ee`. Its first step rejects attempts other than 1 before installation. Checkout is the event's exact reviewed head, not a moving branch or implicit merge ref. Later ordinary pushes and edits do not renew the route. This depends on preserving the declared branch history rather than deliberately resetting the remote to recreate the old transition; no such reset is admitted by the plan.

The 15-minute job and eight-minute setup cap are explicit. Each preparation, runtime and conversion/analysis phase has a 60-second parent watchdog, two-GiB owned-RSS limit and one-GiB Linux MemAvailable floor. Browser and converter cooperative deadlines reserve ten seconds for closure. Linux MemAvailable is correctly described as a distinct host-availability criterion, not a macOS pressure metric. Process identity includes PID and start time, tracks observed descendants across reparenting, rechecks identities before signals and rejects surviving owned descendants. The watchdog is sampled; its inventory does not prove absence of arbitrary unobserved system processes.

The builder binds the original capture to its retained artifact manifest, expected source/tree and unchanged lockfile; binds the four selected cache pairs to their fixed hash; derives both prior and candidate manager regions from guarded patched bytes; verifies Core bytes and package versions; retains real module closure hashes and rechecks them before use. The frozen repaired browser body hash is explicit. Both manager format labels deliberately use shared ES Core in the browser. Controlled sink dispatch, stub timers and bundle preparation outside the timed flush are stated limitations, not full application subscriber measurements. The inherited Apache header and original RxJS esm5 alias are present in the inspected builder.

## Clock, GC and decision integrity

The analyzer requires all 32 identities in fixed counterbalanced order, exact cache sequences, complete semantic/cleanup flags, adjacent raw publication equality, both phase names/order/nesting, and all 194 uniquely named marks. Marks must resolve once on one renderer thread with clock-offset spread at most 0.25 ms. Whole/phase windows retain that uncertainty and require a containing renderer script/task interval. Every one of 16 comparisons must meet both at least 20% and at least 1 ms whole-flush reduction; improvements elsewhere cannot hide a failed pair. GC time is reported, never subtracted to obtain a pass.

The initially observed duration-unknown GC and mere-overlap control weaknesses were repaired during inspection: GC instant/unknown forms now reject, and a positive-duration post-control interval must lie fully inside the uncertainty-adjusted control window. The common resource policy now applies to preflight, monitor and final observations and rejects nonfinite resource observations. I inspected the corresponding negative controls without executing them. These repairs improve admission integrity but do not establish actual Linux category/clock capability; the first real result may still be inconclusive or fail.

A remaining narrow interpretive boundary is the generic B/E reconstruction: it relies on properly ordered, well-formed synchronous trace events and does not validate named end-event compatibility. The converter normally materializes complete X events. Avoid claiming arbitrary malformed B/E input is proven sound; either constrain supported GC representation or cover supported endpoint compatibility if retained output uses it. This is not evidence of an actual hosted trace defect.

## Remaining acceptance

A passing synthetic suite or bundle preparation cannot supply browser timings, valid complete trace/framing/import, GC visibility, process cleanup or a positive runtime effect. The original local resource abort and first hosted diagnostic remain failed/inconclusive. Current published-head application passes remain independent evidence for that source only. New-source selected CI, complete first Linux component evidence, supported causal interpretation and final current-head acceptance remain pending. A positive component result would establish a contributor under the controlled Linux experiment; it would not quantify historical GC shares or explain complete historical pauses. Missing evidence, resource/deadline failure or mixed effects must stop without another automatic allowance.

## ✅ Static repair revalidation

The parent repaired both concrete findings before committing. I reread the changed source and controls:

- The runner now writes terminal progress before calculating `observation.complete`, checks the progress writer immediately afterward, and converts terminal-only persistence failure into a nonzero result and incomplete observation. Observation-persistence failure also attempts a failed terminal record.
- Conversion independently reads and hash-binds the progress journal and parent observation-watchdog receipt. `validateRuntimeJournal` requires the passed terminal, null original/persistence failure, zero dropped events, ordered final cleanup/terminal witnesses, and exactly three fulfilled cleanup resources. The parent watchdog must report passed, no failure, and valid resource bounds.
- Analysis publication uses the existing `persistCallbackManifest` helper, preserving an original conversion/criterion failure while recording a secondary publication failure. Publication-only failure also becomes the returned failure.
- New source controls exercise an actual terminal temporary-path write failure, failed/missing journal fields and cleanup witnesses, and an actual analysis rename failure with a preexisting primary cause. I inspected these controls but did not execute them. The parent's reported 24 passing targeted controls and separately retained broader-suite dependency-loading failure remain distinct evidence; the latter is not an application check pass.

**Both concrete inspection findings are closed at the static source level.** No additional execution-admission blocker was found in the repaired lane. The full committed candidate still requires independent exact-head grades and the new-source hosted result. This updated disposition supersedes the initial hold above only for those repaired source findings; it does not certify runtime capability, timing benefit or merge readiness. The original findings remain in this report for provenance. No reviewer workload or project edits were performed.
