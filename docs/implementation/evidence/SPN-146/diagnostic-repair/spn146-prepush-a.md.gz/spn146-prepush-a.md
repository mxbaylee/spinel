# 🔎 SPN-146 independent pre-push review A

**Reviewed commit:** `13dd8b687f0eafc8295a40b12825a810d53dd5b6`  
**Base:** `2f442317dd2e1c188ae4a810ac094fd1162a4a2a`  
**Score: 92/100 — does not qualify for a validation push.** No merge approval. The composition repair has meaningful semantic evidence, but the newly added hosted diagnostic has unresolved trigger and cleanup/ownership defects. Parent has acknowledged the trigger issue and intends a new commit; that prospective repair is not credited to this SHA.

## 📐 Independent rubric

- **Scope and acceptance: 35/35.** The original XL outcome, four retained first failures, explicit unknown causality, all original workload/budget/history/access requirements and pending clean-install/native acceptance remain accounted for. Conditional landing bookkeeping is preparation, not a false claim of accepted runtime evidence. The diagnostic is relevant to the retained causal requirement rather than an unrelated feature.
- **Correctness, integrity and access: 22/25.** Deduct 3 for incomplete ownership/settlement on the new trace failure paths and cleanup/error precedence issues described below. No remaining concrete semantic defect was found in the repaired paragraph guard during this review.
- **Meaningful verification: 18/20.** Deduct 2 because the new deadline test can pass with a permanently unsettled command, and the diagnostic caller lacks tests that prove teardown completes despite preceding evidence/profile/disposal failures. The 202 manager controls and 67 evidence contracts are substantial but do not establish those new boundaries.
- **CI and operations: 7/10.** Deduct 3 for a workflow-dispatch-only diagnostic newly introduced off the default branch: the declared required premerge observation has no supported trigger in this source. All ordinary current-head gates remain explicitly pending; that pending state itself is not counted as a failed check.
- **Maintainability/process/over-complexity: 10/10.** The single-Enter guard, finite diagnostics and retained upgrade hashes are scoped to this outcome. No separate arbitrary complexity deduction is warranted. Fix the collector ownership contract or reuse the established ownership pattern; this review does not demand a broad framework or a larger test matrix for its own sake.

## 🛑 Blocking findings on this SHA

### A1 — P2: declared premerge diagnostic cannot dispatch from its new branch-only workflow

`.github/workflows/doc-native-diagnostic.yml:3–4` adds only `workflow_dispatch`; the file does not exist in the reviewed base/default branch. The maintained plan requires this observation before acceptance/merge. GitHub's official [manual-workflow documentation](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow) says the workflow must be in the default branch to trigger `workflow_dispatch`. Branch selection is available for an already registered workflow; it does not establish this new file before first execution.

**Repair:** provide and preregister a supported bounded premerge trigger, constrained to the owning candidate and one declared event, with reviewed source/tested tree identities retained. Do not merge the unaccepted implementation to bootstrap its acceptance tool. Parent proposes an owning-branch `pull_request: opened` route with no synchronize/reopen retry; assess its actual new source and identity guards on re-review.

### A2 — P2: diagnostic trace timeout/failure does not own all in-flight work and late completion

`e2e/doc-responsiveness-native-trace.ts:60–106` races each operation with an expired promise. The timeout launches an unawaited detach; later cleanup independently detaches again. `stream` is assigned only after `Tracing.end` successfully resolves and the completion promise is consumed. If end rejects and a completion event arrives before or during detachment, its handle resolves a promise that is no longer consumed, so no explicit stream close is issued. The completion listener is removed before the awaited final detach finishes. Pending IO/write promises are not tracked through settlement; after timeout, racing `IO.close` against the already rejected deadline does not prove close settled. File close/final detach remain unbounded by the advertised drain timer.

This does not turn the run into a success—the helper will fail—but it undermines the promised bounded, owned partial-evidence cleanup, precisely the outcome required when the finite diagnostic fails. `scripts/ci/doc-native-trace.test.ts`'s hanging-end mock leaves `send` pending forever and merely checks that detach appeared in the calls. Passing it is not proof of resource settlement.

**Repair:** use one owned interruption/teardown promise, retain completion ownership until interruption/session closure settles, capture and close late known handles once, track pending IO/output work and expose terminal settlement in the receipt. Keep the first failure primary and retain secondary cleanup outcomes. Add end-rejection/late-completion and pending-read/output-write deadline controls whose fake work actually settles on interruption; assert no remaining handle/listener/operation ownership. The previously established callback collector ownership pattern is relevant, without requiring its converter or broader capture contract.

### A3 — P2: diagnostic caller teardown can be skipped and secondary evidence failure can replace the first cause

In `e2e/doc-responsiveness.spec.ts:795–877`, fixture/CDP teardown is reached only after several awaited evidence operations. For example, a rejection from `retainProfile` at line824 or reload-observer disposal at line834 exits this `finally` before `f.close()` and the new cleanup journal. The timed test also has no independent teardown owner that joins interrupted diagnostic finalization after its deadline. Adding a positive cleanup record near the end of the same vulnerable sequence does not make that path unconditional.

Separately, `e2e/doc-responsiveness-native-trace.ts:125` awaits receipt persistence outside failure preservation: receipt IO failure can replace the original collection failure before line126 rethrows it. In the caller, line855 assigns a detach error over an already retained metrics-persistence error. These are observable first-cause/diagnostic-loss cases, not speculative performance concerns.

**Repair:** establish one idempotent owned teardown that attempts fixture/session closure regardless of profile, observer or persistence failure; ensure it is joined by the test's teardown boundary when the test is interrupted. Preserve the original test/collection failure and append cleanup/persistence failures as secondary records; a cleanup failure on an otherwise successful run must still fail it. Add targeted controls for profile retention/reload disposal/receipt write failures and interruption while collection is pending. Do not rewrite unrelated ordinary acceptance logic merely to fix diagnostic ownership.

## ✅ Repaired semantic findings and source assessment

The primitive `paragraphStyle` issue from my provisional inspection is fixed with a non-null object check before `Reflect.ownKeys`, plus primitive-style fallback controls. The admitted metadata gap now has explicit absent/undefined/empty cases and both COVER/REPLACE modes, including retained-style and old-body variants. Artificial old-body variants correctly use native composition/applied snapshots as their oracle without falsely claiming independently authored edits.

The production transformation remains narrow: redo only, one recognized root-body Enter with a one-character style retain/old body, default paragraph style and paragraph identity, a wholly qualified final plain-insert run, append-contiguous offsets and matching outer unit/segment. Undo, plain-only groups and unsupported shapes retain the previous paths. Head/suffix recursion terminates structurally; it does not search for later islands. The new guard uses ordinary data descriptor checks; arbitrary Proxy observational equivalence is not established or required by the retained native-data evidence.

All 32 Enter positions in both cover modes, nonzero offsets, divergent caches, exact current/upstream raw publications, full applied snapshots, source-result ownership and fallback operand identity provide useful evidence for the non-null accumulator join. Exact prior ES/CJS package bytes remain available as both installer-upgrade inputs and work negatives. No runtime grouping, publication location, snapshot normalization, budget or access fence is intentionally weakened.

The descriptor walk visits the whole state graph, including metadata not read by composition; its allocation/CPU cost is outside the clone counters. This is disclosed and must be included in native diagnosis/acceptance. It is a pending performance question, not proof of a regression or justification to remove safety checks. Current deterministic reductions are not historical browser-cause evidence.

## 🧾 Independent verification performed

I read the original base ticket, complete source/test/workflow/bookkeeping diff, process/runbook/testing/personas, maintained decisions and prior retained failure dispositions. No implementation edits, package writes, installs, browser runs or converter runs were made.

One serial/watchdog evidence pass verified all **86 gzip payloads**, their exact group member sets, compressed/uncompressed sizes and SHA256 values: **248,240 stored bytes / 6,763,291 decoded bytes**. All **16 prepush candidate-source bindings** match exact commit blobs. Base ancestry, next ID147, conditional SPN146 completion/ticket removal and preservation of SPN145 were checked. The proof uses Git blobs from the reviewed SHA, so subsequent worktree repair cannot silently change it.

Proof: `/tmp/spn146-prepush-proof-a.ts`, `.json`, `.log`, and `-watchdog.json`. First pass completed **1,044 ms / 201,936 KiB**, normal pressure. It recorded `generatedMatches:false` because my independent expected rewrite initially covered only one specific docs evidence URL. I then read the retained generation helper and corrected that expectation to its generic docs-prefix rewrite. A separate proof, `/tmp/spn146-prepush-generated-a.ts/.json/.log/-watchdog.json`, verifies exact equality of the generated test to current maintained source with only the recorded path/import substitutions, **143 ms / 90,064 KiB**, normal pressure. The first mismatch remains preserved; the 86-payload integrity result was not rerun or relabeled.

The retained final manager log reports202/202, no failures/cancellations/skips, watchdog15,022ms/430,544KiB. Evidence-contract log reports67/67, watchdog500ms/389,616KiB. Scoped type/lint results and first failures are retained. I did not duplicate these executions: the new source findings are outside what their present controls prove. The read-only external Core identity receipt binds donor ES/CJS hashes to the current hash-guarded Core patch; unrelated Express mismatch still prevents treating that donor as a complete clean installation.

Both resource-aborted installs, the stopped dependency clone, first COVER/REPLACE qualification failure, stale list-count expectation and temporary type/lint setup failures remain visible with their dispositions. These are not silently replaced by later successes. Full project Typecheck/Lint/build on clean dependencies and all native acceptance remain pending.

## 🧭 Personas, routing and remaining obligations

The Operator receives a finite diagnostic and source-bound evidence, but needs executable CI and reliable terminal cleanup. Owner and Collaborator need exact native edit/history/saved/peer outcomes; the raw semantic tests address those boundaries. Editable Link guests retain access/revocation requirements and no diagnostic permission path is exposed in normal builds. Diagnostic event listeners are opt-in; the new shared harness inputs are hashed and copied into both relevant baseline setups. CI selection is conservatively broadened, not narrowed.

Conditional branch-local ticket/dependency/index bookkeeping is internally consistent with the documented landing policy; main's ticket remains authoritative until accepted squash. SPN141/140/120/089 are still blocked on actual acceptance and fresh integration, not on a source grade alone.

After repairs, obtain both independent reviews on the new complete commit before a validation push. A supported finite prior-native diagnostic disposition, fresh clean-install seven gates and every selected current-source unprofiled/semantic/history/access/cleanup owner are still required. No successful local counter or future green sample alone explains the four historical maxima. **Current 13dd8b68 is not qualifying for validation publication or merge.**
