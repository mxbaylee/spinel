import { registerHooks } from 'node:module';
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const root='file:///Users/mxbaylee/projects/spinel/package.json';
const installed=JSON.parse(readFileSync('/Users/mxbaylee/projects/spinel/node_modules/@playwright/test/package.json','utf8'));
const lock=JSON.parse(readFileSync('/Users/mxbaylee/projects/spinel-spn-146/package-lock.json','utf8'));
assert.equal(installed.version,lock.packages['node_modules/@playwright/test'].version);
registerHooks({resolve(specifier,context,next){
  if (specifier === '@playwright/test') return next('/Users/mxbaylee/projects/spinel/node_modules/@playwright/test/index.js', context);
  if (specifier === '@playwright/test/package.json') return next('/Users/mxbaylee/projects/spinel/node_modules/@playwright/test/package.json', context);
  return next(specifier,context);
}});
