import { execFileSync } from 'node:child_process';

export interface ProcessRow {
  pid: number; parent: number; group: number; rssKiB: number; started: string; command: string;
}
export function processes(): ProcessRow[] {
  return execFileSync('ps', ['-axo', 'pid=,ppid=,pgid=,rss=,lstart=,command='], { encoding: 'utf8' })
    .trim().split('\n').map(line => {
      const match = line.match(/^\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\S+\s+\S+\s+\d+\s+\S+\s+\d+)\s+(.+)$/);
      if (!match) throw new Error('Unrecognized process row');
      return { pid: +match[1], parent: +match[2], group: +match[3], rssKiB: +match[4], started: match[5], command: match[6] };
    });
}
export const sameProcess = (a: ProcessRow, b: ProcessRow) =>
  a.pid === b.pid && a.started === b.started && a.command === b.command;

export function ownedProcesses(rows: ProcessRow[], root: number, known: Map<number, ProcessRow>) {
  const owned = new Set(rows.filter(row => row.pid === root ||
    (known.has(row.pid) && sameProcess(known.get(row.pid)!, row))).map(row => row.pid));
  for (let size = -1; size !== owned.size;) {
    size = owned.size;
    for (const row of rows) if (owned.has(row.parent)) owned.add(row.pid);
  }
  const result = rows.filter(row => owned.has(row.pid));
  for (const row of result) known.set(row.pid, row);
  return result;
}

export function signalOwned(known: Map<number, ProcessRow>, signal: NodeJS.Signals, exclude: number) {
  const live = processes().filter(row => row.pid !== exclude && known.has(row.pid) &&
    sameProcess(known.get(row.pid)!, row));
  for (const row of live) {
    // Revalidate immediately before signalling; never select all newly created PIDs.
    const current = processes().find(value => sameProcess(value, row));
    if (current) try { process.kill(row.pid, signal); } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ESRCH') throw error;
    }
  }
  return live;
}
