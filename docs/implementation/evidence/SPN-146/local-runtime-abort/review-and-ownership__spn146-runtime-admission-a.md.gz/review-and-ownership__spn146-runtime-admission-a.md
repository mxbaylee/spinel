# 🔬 SPN-146 Chromium component experiment — pre-execution review A

**Disposition: the finite component question is justified, but the inspected preparation has two concrete evidence/stop-condition defects to repair before its single runtime allowance.** No experiment, converter, benchmark, or validation workload was executed by this reviewer. This is admission review, not a source grade or acceptance approval.

Reviewed the local `f5b7862c1990e4a70cb247d90d44f2ee19db8673` declaration, `/tmp/spn146-investigation/runtime/{build.ts,browser-body.ts,entry.ts,run.ts}`, the external 60-second watchdog, preparation receipt, and the reused native trace wrapper. The declared runner/bundle hashes are `221194c856a3a08720ad7b516c37ce4442db9b081ea1449c8258e4bb68e3fbae` and `e81684d9cfa903cca180706be21d6d9e09ca59adf14af013772853fa0de7ea37`; this static review did not independently rehash the full dependency closure. No observed runtime values exist yet.

## 🛠️ Required preparation repairs

1. **Partial observations are lost on failure.** `browser-body.ts` stores `records` locally and returns them only after all 32 cases and final parity assertions. `run.ts` assigns `record.observation` only after that successful `page.evaluate` result. A mid-run semantic error, cooperative body deadline, or evaluation rejection discards the earlier completed timing/output records. Furthermore, each individual record is constructed only after several post-flush assertions, so even the failing case's measured intervals are absent. This contradicts retaining every observation and partial evidence. Retain the started/measured case and completed predecessors in a bounded browser-side journal, and retrieve that existing state on failure when the page remains usable, without invoking the experiment again. An equivalent owned mechanism is acceptable. Explicitly preserve the narrower limitation for browser crash/hard process kill: those cases may leave only already-retained trace/progress/process evidence, never an invented complete observation set.

2. **Pair parity is checked after all observations rather than at the first available semantic boundary.** The final loop compares outputs only after all 32 flushes. A mismatch in the first pair permits the other 30 observations despite the declared stop-on-first-semantic-failure rule. Check each pair immediately when its second measured record is available, after retaining both records; retain its failed status before propagating the original error.

These are preparation defects, not consumed runtime observations. Keep the original prepared bytes/identities and bind any repaired files/bundle before execution. A repaired builder is not permission to repeat an actual partial runtime observation.

## ✅ Why the finite question is useful

The design uses the four actual hosted 32-entry history/collaboration pairs, verifies capture and build against maintained artifact hashes, and reconstructs exact prior/candidate native manager regions. It measures the real manager flush and its qualification/composition/publication dispatch. This directly addresses whether the already-proved native work reduction remains a meaningful runtime contribution once guard overhead is included.

The matrix is fixed at 32 observations: four input pairs, two manager build formats, both variants, and both orders. Fresh decoding/class construction occurs outside the measured flush; primitive counters and output serialization are outside timing. Marked phase wrappers apply equally to both variants. No warmup or resampling is introduced. The preregistered all-16-pairs effect threshold (at least 20% and at least 1 ms for whole flush) is a diagnostic criterion, not a replacement for product budgets. Mixed/small differences or invalid runtime evidence remain inconclusive; no averaging a miss into success.

The builder checks Core/native identities and lockfile agreement, records real module bytes and package versions, and the runner rechecks the bundled real-file closure before use. The prior path alias failure was a preparation failure, not an experiment. Full-app local execution remains unauthorized by this verified component closure.

## 🧹 Ownership and timing assessment

The runner's 50-second abort requests cached CDP/context/browser interruption, and final cleanup awaits those same cached operations; the external watchdog independently bounds process ownership/resources at 60 seconds. Earlier primary failure is retained when trace finalization or teardown also fails. The mature collector provides strict protobuf completion, loss checks, size cap, and awaited interruption; no new ad hoc stream collector is introduced. The parent watchdog can terminate a blocked synchronous browser operation even if the browser-side 30-second checks cannot run during it.

The source has no automatic native rerun/fallback. Trace completion failure must keep the run failed/inconclusive even if all flush measurements finished. A successful collection flag is not a positive effect result. The post-observation forced-GC control is separated from all 32 measured cases; absence-of-GC interpretation requires that control to be visible in a complete trace. Full trace conversion/analysis has its own single bounded phase and must preserve framing/import/hash/cleanup failures. This review does not establish that the eventual converter or attribution analysis succeeds.

## 📏 Required interpretation limits

- The fixture substitutes its clock/timer services and controlled publication sinks. Real renderer, full subscribers, transport, keyboard scheduling, and long-lived application state are excluded. Measure the native compute component honestly rather than call it a full application flush cost.
- Both manager format labels use the browser's imported ES Core dependency. They exercise two manager build regions; they are not separate CJS-Core runtime or deployment environments.
- Phase wrappers/marks, CPU profiling and tracing have overhead. Whole-flush timing includes both phase wrappers; phase timing excludes the wrapper's start/end mark calls. Retain the actual boundaries and uncertainty rather than treating phase totals as an exact decomposition of whole-flush duration.
- Fresh class construction and fixed order can involve JIT/GC state and carryover. Counterbalancing exposes order sensitivity but does not provide a device population or statistical performance guarantee. Preserve all observations and pause evidence.
- A clear positive result could support a bounded causal statement about this native compute contributor on these inputs/runtime. It cannot identify the entire cause of the old uncaptured 100-ms maxima or predict Linux/full-app timing. Current first-attempt full application gates and unchanged budget/content/history/access obligations remain separate.

**Admission remains pending the two concrete preparation repairs above.** No further exploratory workload or broader harness is requested by this review.
