# 🔬 SPN-146 Chromium component execution-admission inspection B

Read-only inspection of the preregistered plan at local source `f5b7862c1990e4a70cb247d90d44f2ee19db8673`, external build/browser/runner/watchdog files and preparation receipt. Initial reviewed bundle SHA256 `e81684d9cfa903cca180706be21d6d9e09ca59adf14af013772853fa0de7ea37`; caller-supplied runner SHA256 `221194c856a3a08720ad7b516c37ce4442db9b081ea1449c8258e4bb68e3fbae`. No browser, converter, test or validation workload was executed by this reviewer; no project/source edit was made. This is not a source grade or merge approval.

## 🛑 Required before first execution

**B-R1: enforce the declared first-semantic-failure stop.** `browser-body.ts` checks paired raw publication equality only in the loop after all 32 observations. A mismatch in the first pair would still consume the other 30 observations. Compare each completed adjacent prior/candidate pair immediately before constructing the next fixture. Preserve the failed pair and stop; do not substitute another case.

**B-R2: retain partial observations.** Completed records currently exist only in the local `run()` array, returned through `page.evaluate` after all work succeeds. A later semantic/deadline exception loses earlier measured records and the failed/inflight identity. Keep a browser-side partial journal updated outside timed work, with completed observations, current source/case/order/variant and first failure. Retrieve it on ordinary evaluation failure while the page remains usable, without invoking `run()` again. Explicitly report that a renderer crash or hard watchdog termination may prevent retrieval; preserve the parent ownership/progress record and do not repeat the allowance. Reviewer A independently raised the same retention issue.

After repairing these, retain revised source and bundle/runner identities and have both reviewers revalidate the concrete delta before execution. A preparation rebuild is not a native runtime retry, but its first failures remain evidence.

## ✅ Timing and semantic scope

The loop fixes 32 observations in advance: four cache pairs, ES/CJS manager representations, both variants and both adjacent orders. Source/class construction, decode and input snapshots precede timing. Whole-flush timing encloses actual manager qualification/composition/publication plus the common phase instrumentation. Phase timings bracket native method calls with the new guard included. Raw encoding and pair comparison happen after timing. There are no primitive counters or service-sink serialization inside measured work.

The actual publication dispatch reaches minimal sinks that retain original values and record order/queue state. This is an honest compute experiment, not full application subscriber, DOM, transport, idle-scheduler or latency acceptance. The existing fixture uses controlled timers and a stubbed native observation clock; the independent browser `performance.now` and marks own these measured synchronous intervals. Both ES and CJS manager representations are supplied the same bundled browser Core implementation, so do not label the CJS-manager result as a separate CJS Core browser deployment.

Input descriptor/prototype snapshots, empty queues, one history/change publication, phase count and fixture timer/command cleanup checks are meaningful. Existing offline raw-output/ownership controls remain complementary. Phase order and whole/phase nesting should be explicitly verified during analysis, alongside exact 32 identities and 16 pairs; a mere count of two phases is not a temporal proof.

## 📦 Provenance and resource boundaries

Preparation binds the original hosted artifact member hashes, source/tree, selected cumulative state counts, prior/candidate package hashes, extracted manager regions, exact Core files, generated fixture/body/entry and bundle. The runner rechecks bundle bytes and real-file module hashes immediately before use. The receipt reports 888 modules/15 locked packages; this inspection follows those checks in source and reads the receipt, rather than independently rehashing the entire closure. Virtual bundler modules are covered by final bundle identity, not individual source-file hashes. Root dependencies are read-only and the unrelated full-app body-parser mismatch supplies no full-app claim.

The process watchdog enforces normal pressure, combined 2 GiB RSS and a 60-second browser-phase deadline, retaining observed descendant identities and rejecting remaining owned descendants. The child has a 50-second abort/interruption request. It is not a 50-second extra allowance after the parent deadline. The shared collector owns trace shutdown; setup-acquired resources are also closed in the outer finally. No hard-kill result can be called complete cleanup or valid timing. Avoid starting new setup work after the abort signal has already fired; check it around expensive setup stages as a precaution within the existing bound, without changing the allowance.

## 📏 Interpretation checks still required

The fixed threshold—every matched comparison reduces whole-flush duration by both 20% and 1 ms—must remain unchanged. All observations stay visible, including order/JIT/GC variation. Counterbalancing does not establish a stable population distribution, and fresh per-fixture compilation means these are the declared component invocations rather than warmed full-app behavior.

The post-observation GC control is correctly outside all measured samples. It can establish category observability only if its marker-bounded GC event actually appears. Complete protobuf framing, pinned conversion/statistics, source/trace hashes and clock/mark reconciliation are prerequisites to valid causal interpretation. Report overlapping pauses rather than subtracting them to obtain a pass; absence of GC needs a visible control and complete trace. Whole and phase markers must map consistently to one renderer thread and returned timing brackets. CPU profiling and marks add common measurement overhead; do not call this unprofiled acceptance.

No conversion/analysis script was supplied for source inspection, so this review does not pre-approve its implementation or any future interpretation. Review that concrete logic before its separately bounded execution. Positive timing alone is insufficient if trace or temporal validity fails. Contradictory/mixed/small/invalid results remain as preregistered, with no renewed run, widened trace buffer or automatic hosted fallback.

## 🧭 Disposition

The experiment is well scoped to the remaining guard-inclusive native-compute question and can complement the independently completed Linux application gates. Correct B-R1 and B-R2 before consuming the single runtime allowance. No additional full-app subscribers are needed for this component claim, but historical full-interval/GC causality remains outside it. The original failed hosted diagnostic stays failed; this review grants no merge approval or unchanged native rerun.
