// Browser adapter for the existing actual-manager fixture. No primitive counters
// or serialization run inside the measured native flush/phase boundaries.
const assert = Object.assign((condition:any,message='Assertion failed')=>{if(!condition)throw new Error(message);},{
 ok(condition:any,message='Assertion failed'){if(!condition)throw new Error(message);},
 equal(a:any,b:any,message='Values differ'){if(a!==b)throw new Error(message+`: ${String(a)} !== ${String(b)}`);},
});
function instantiate(code:string,bindings:Record<string,unknown>,_options:unknown){
 return new Function(...Object.keys(bindings),`return (() => { ${code.replace(/DocStateChangeManagerService;$/, 'return DocStateChangeManagerService;')} })();`)(...Object.values(bindings));
}
function encode(value:any):any {
 if(value===undefined)return{kind:'undefined'};
 if(value===null||typeof value!=='object')return{kind:'value',value};
 assert.equal(Object.getPrototypeOf(value),Array.isArray(value)?Array.prototype:Object.prototype,'Unexpected prototype');
 return{kind:Array.isArray(value)?'array':'object',entries:Reflect.ownKeys(value).map(key=>{
  assert.equal(typeof key,'string');const d=Object.getOwnPropertyDescriptor(value,key)!;assert.ok(Object.hasOwn(d,'value'));
  return[key,{value:encode(d.value),writable:d.writable,enumerable:d.enumerable,configurable:d.configurable}];
 })};
}
const mark=(name:string)=>({name,time:performance.mark(name).startTime});
export function run(){
 const started=performance.now(),records:any[]=[];
 // Parse/class construction is per fixture outside the native timed interval.
 for(const format of ['es','cjs'] as const)for(const pair of pairs)for(const order of [['prior','candidate'],['candidate','prior']])for(const variant of order){
  assert.ok(performance.now()-started<30_000,'Observation body exceeds30seconds');
  const id=records.length,label=`spn146-runtime-${id}`;
  const history=decodeCapture(pair.history),collaboration=decodeCapture(pair.collaboration);
  const states={history,collaboration},retained=[...history,...collaboration],before=JSON.stringify(encode(retained));
  assert.ok(retained.every(state=>state.unitId===unitId));
  assert.equal(history.length,32);assert.equal(collaboration.length,32);
  const fixture=managerFixture(native[format][variant]);
  const phases:any[]=[];
  for(const [method,phase] of [['_pushHistory','history'],['_emitChangeState','collaboration']]){
   const original=fixture.manager[method];
   fixture.manager[method]=function(...args:any[]){
    const first=mark(`${label}-${phase}-start`),began=performance.now();
    try{return Reflect.apply(original,this,args);}
    finally{const ended=performance.now(),last=mark(`${label}-${phase}-end`);phases.push({phase,first,began,ended,last,durationMs:ended-began});}
   };
  }
  let record:any;
  try {
   fixture.manager.setStateCache(unitId,states);
   const first=mark(`${label}-start`),began=performance.now();
   fixture.manager.flushPendingChanges(unitId);
   const ended=performance.now(),last=mark(`${label}-end`);
   assert.ok(performance.now()-started<30_000,'Observation body exceeds30seconds');
   assert.equal(JSON.stringify(encode(retained)),before,'Retained inputs changed');
   const cache=fixture.manager.getStateCache(unitId);assert.equal(cache.history.length,0);assert.equal(cache.collaboration.length,0);
   assert.equal(fixture.history.length,1);assert.equal(fixture.changes.length,1);assert.equal(phases.length,2);
   record={id,format,completed:pair.completed,sequences:pair.sequences,order:order.join('-'),variant,first,began,ended,last,durationMs:ended-began,phases,output:encode({history:fixture.history,changes:fixture.changes,publication:fixture.publication})};
  }finally{fixture.close();}
  record.cleanup=true;records.push(record);
 }
 assert.equal(records.length,32);
 for(let index=0;index<records.length;index+=2)assert.equal(JSON.stringify(records[index].output),JSON.stringify(records[index+1].output),'Paired publication values/order differ');
 return{records,elapsedMs:performance.now()-started,timeOrigin:performance.timeOrigin,userAgent:navigator.userAgent};
}
