# 🧯 SPN-146 component runtime attempt — independent disposition A

**The single declared runtime phase is resource-aborted and inconclusive. The guard-inclusive runtime evidence remains explicitly resource-blocked/pending; existing passing application checks do not fill that causal evidence gap.** This is not a new source grade, an implementation failure diagnosis, or merge approval.

## 🔎 Observed outcome

Read the retained runtime log, watchdog inventory, browser progress and post-abort inspection. The watchdog detected pressure `2` at **4,366 ms**, observed RSS **543,952 KiB**, and invoked its resource-abort path. Its final retained inventory is at **4,419 ms**, pressure `2`, RSS/peak **671,888 KiB**. These are distinct snapshots, not conflicting peak claims. The trigger is elevated memory pressure; the observed RSS is below the independent 2-GiB ceiling. There is no evidence that a measured native flush exceeded a time or memory budget.

Progress retains only fixture start and `browser-start`. The inventory shows the Chromium process and startup helpers; no component observation was returned or journal retrieved. The post-abort retained-file list contains bundle/preparation/progress artifacts, with no observation, CPU profile or trace file. This supports **startup aborted before any retained component measurement or trace**, not a completed zero-cost experiment. No converter has an input to process.

Post-abort inspection reports no survivors matching the exact recorded process identities. Its scope is observed owned descendants and retained identities, not system-wide absence. The hard-kill path did not produce the runner's normal terminal/cleanup receipt; progress `firstFailure:null` and `terminal:null` are incomplete progress after termination, not success. Preserve the watchdog and external inspection as the actual termination/ownership evidence.

## ✅ Separate successful evidence

The terminal ordinary CI record independently shows run **41992099254**, attempt **1**, source **1eeb90f1d50291791d39913350c28c672c7154ee**, completed/success; the retained jobs file contains **33 successes**. Parent reports all seven gates, native owners and Storybook accepted and current mobile first attempts passed, with capacity maxima **44.6 / 31.9 / 36.8 ms**, p95 **23.7 / 20.4 / 20.7 ms**, and the full 66-group history owner. This limited disposition does not duplicate those raw owner audits or independently promote their detailed measurements from parent report to a new audit.

Those observations demonstrate the current-source application contract on their actual executions. They remain useful acceptance evidence and are not invalidated by a separate local resource abort. They also cannot be treated as measurements of the unexecuted prior-versus-candidate component intervention.

The retained 16-flush same-input experiment still proves raw semantic preservation, actual-input guard admission and removal of counted growing-tail work. The first hosted diagnostic remains failed at strict trace completion and does not supply usable complete temporal/pause attribution. None of these existing records measures the net guard-inclusive runtime effect required by the current declared component question. A separate successful profile or green maximum must not silently substitute a differently controlled experiment or explain historical missing traces.

## 🧭 Remaining disposition

Under the existing plan, record: **“Supported native work reduction and current-source application checks passed; the single component runtime attempt aborted on host pressure during startup; guard-inclusive runtime contribution remains unmeasured and the causal investigation remains pending.”** No old failure is waived, no historical pause fraction is invented, and no known synchronous-work result is discarded.

The abort is neither positive nor contradictory evidence about the candidate's runtime benefit. Unknown historical pause fractions are still not an absolute demand to recreate old executions. The narrower remaining requirement is actual supported runtime evidence for the identified compute contributor, including qualification overhead and honest pause/clock limits. Nothing newly present in this abort resolves it.

The declared browser phase was attempted once and stopped on its specified resource condition. Zero observed flushes do **not** automatically renew the phase or authorize an unchanged retry, hosted fallback, conversion, relaxed watchdog, or larger budget. If work resumes on this question, retain this first outcome and establish a prospectively justified finite capability/method decision with independent admission before any additional execution. This report does not select or authorize such a run. The original XL outcome must remain explicitly pending rather than close or unblock dependents on the basis of ordinary CI alone.

No source changes, browser/converter execution, profile parsing or validation workloads were performed for this disposition. Only small retained-record reads and terminal CI status summarization were used.
