# 🔬 SPN-146 runtime probe repair admission B

Static, nonimplementing revalidation of the external probe against preregistered local source `f5b7862c1990e4a70cb247d90d44f2ee19db8673`. No workload executed, no source edited and no new execution allowance added.

Reviewed repaired `/tmp/spn146-investigation/runtime/browser-body.ts` and `run.ts`. Supplied current identities: body `8950279e7723e36947f03958c140d8a5f9ca31b1f64f74a09f356e1826105874`; runner `87ebe61049a8139af26b99d1e7a7fed3538255999fba89fe47610e1d4f4f3ac1`; bundle `53316317b2487e1ba1ab7c2ffc750cc271a7ddf506be89403fee0b15db6a9566`; preparation `b6ae16a3e2732b94ff5318969b7f50133086ce31eabd6c40282ee38c62acbc9e`. I inspected the concrete source but did not duplicate the implementer's bundle/closure hash workload. Prior preparation inputs are retained separately.

## ✅ B-R1 resolved

Each record is pushed before preparation and carries source-case identity, order, variant and stage. Once the second member of an adjacent pair finishes and its fixture closes, raw output equality is checked immediately. A mismatch enters the outer catch, records the first failure and exits the loop before another fixture starts. The failed second record remains failed; the first has no successful pair-parity witness. Analysis must continue to require complete successful pairs rather than treating the first member's individual `passed` field as pair acceptance.

## ✅ B-R2 resolved for recoverable evaluation failures

The module retains a one-shot journal, exposes a read-only `inspect()` accessor and refuses a second `run()`. Whole-flush times are recorded in `finally` before semantic assertions; phase intervals, earlier completed records, active/inflight identity, stage and primary/cleanup failures survive an ordinary throw. Fixture closure cannot replace an earlier failure. The runner catches failure and retrieves the existing journal only while the page remains available and the abort signal is unset. It never invokes `run()` again, and retrieval remains under the active deadline/interruption mechanism.

Renderer crash or hard watchdog termination can still prevent journal retrieval; that limitation is explicitly reported, not treated as completed measurement or grounds to repeat. The parent ownership/progress record remains the available partial evidence in those cases. Added setup abort checks reduce the chance of beginning new setup work after the soft deadline.

## 📏 Unchanged boundaries

The fixed 32 observations/16 comparisons, counterbalanced orders, all-sample retention, 4× actual Chromium component environment, source/bundle closure checks, 50-second child interruption and 60-second parent resource bound remain unchanged. Pair comparison and journal serialization are outside measured intervals. Whole-flush timing still includes guard/native phase work and common phase instrumentation; controlled service sinks, stubbed manager clock and shared browser Core limitations remain as documented in the initial review.

The separately bounded conversion/analysis must still validate complete protobuf transport/framing/import statistics, exact markers/phase nesting/renderer clock, visible post-observation GC control and all observations before evaluating the preregistered ≥20% and ≥1 ms criterion. No conversion/analysis implementation is approved by this static runner review. Invalid, contradictory, mixed or small effects do not authorize renewed execution or altered thresholds.

## 🧭 Disposition

B-R1 and B-R2 are resolved in the inspected repair. I find no remaining static blocker to consuming the **single already-preregistered runtime allowance**, after the other independent review and immediate normal-pressure/identity checks. This is execution-admission advice only: no runtime result, full-app latency claim, native rerun allowance, fallback authorization or merge approval is inferred. The original failed hosted diagnostic remains failed and causally inconclusive.
