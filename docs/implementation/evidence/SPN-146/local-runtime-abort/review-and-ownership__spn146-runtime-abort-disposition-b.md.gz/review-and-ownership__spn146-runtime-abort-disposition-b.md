# 🛑 SPN-146 component runtime resource-abort disposition B

Read-only review of the attempted Chromium component phase under the preregistered plan at local source `f5b7862c1990e4a70cb247d90d44f2ee19db8673`. No workload, rerun, fallback, conversion or source edit was performed by this reviewer. This is an outcome/acceptance disposition, not a grade.

## 📋 Recorded outcome

The runtime log records `WATCHDOG ABORT` at **4,366 ms**, memory pressure **2**, observed task RSS **543,952 KiB**. The final ownership inventory records `resource-aborted` at **4,419 ms**, pressure 2 and RSS/peak **671,888 KiB**. The abort was triggered by elevated system pressure, not the 2 GiB per-task ceiling or the 60-second deadline. Remaining below 2 GiB does not make the attempt safe or passing.

The retained progress journal contains only `fixture/started` and `browser-start` (212.866 ms), with no `fixed32-observations` phase, no terminal status and no recorded progress-persistence failure. The observed process inventory contains the watchdog, runner and Chromium startup descendants, without a recorded renderer measurement process. The directory inventory has preparation/bundle/progress only: **no observation JSON, CPU profile or runtime trace**. These records support a startup-stage resource abort before measured flushes, with **zero accepted component observations**. The empty progress first-failure field is not a pass: the outer watchdog owns this termination and retained its cause.

The separate post-abort identity inspection at `2026-11-05T09:15:37.614Z` reports no survivors matching the recorded task identities and sent no additional signals. Its scope is exact known identities/observed descendants, not system-wide process absence. This is verified forced-termination cleanup evidence, not a graceful runner-finally/trace-close receipt. No final result was fabricated after the kill.

## ✅ Application CI remains valid, separately scoped

I independently read the final run/job metadata: ordinary CI **41992099254**, source `1eeb90f1d50291791d39913350c28c672c7154ee`, attempt 1, completed successfully with **33 successful jobs**. The parent reports all seven gates and current native/Storybook owners passed; reported candidate mobile capacity maxima are 44.6/31.9/36.8 ms, p95 23.7/20.4/20.7 ms, with full 66-group history in plain-1. I did not perform a new complete mobile artifact/member/assertion audit in this resource-abort review, so those detailed acceptance figures retain their existing owner-audit provenance.

Those first-attempt application results must be preserved as real successes. They are not invalidated by the independent local capability abort. They apply to published `1eeb90f1` and its equal tested tree, not automatically to subsequent local telemetry/plan commits. They also do not turn the earlier prior-native trace-contract failure into a successful diagnostic.

## 🔎 Can existing evidence close the remaining question?

**Not on the evidence currently established.** Existing offline manager comparisons and the first 16-flush replay prove exact raw-output/ordering/ownership parity and removal of repeated-tail primitive work on actual hosted inputs. They do not include the new descriptor/qualification cost in a browser-runtime counterfactual. The published application acceptance proves its workload meets unchanged limits in its declared observations, but does not isolate that component's contribution.

The prior-native hosted observation lacks a complete trace, contains no comparable slow event, and has a CPU-profile clock bracket/negative-delta limitation. Comparing it directly with current ordinary samples would also mix instrumentation and execution conditions. The historical uncapped baseline is not the exact bounded prior implementation on matching 32-state caches. None of these is an honest substitute for the missing guard-inclusive intervention result. No collection, timing, pause or GC conclusion can be extracted from the aborted component phase because it produced no measurements.

The exact remaining item is therefore **resource-blocked, pending guard-inclusive native-compute evidence and a supported final causal disposition**. Historical exact-pause reconstruction is still not required; a useful finite intervention could establish the relevant component contribution without reproducing a >100 ms event. But the planned intervention did not run to measurement, and its absence cannot be repaired with wording or a later green gate alone.

## 🧭 Disposition under the existing plan

Preserve this first capability attempt, normal-then-elevated pressure outcome, exact preparation/runner/bundle identities, process inventory and post-abort inspection alongside the genuine CI successes and earlier failed diagnostic. No conversion phase is applicable because no trace exists. The plan gives **no automatic local retry, automatic hosted fallback, threshold relaxation or buffer change**. Zero measured observations does not by itself renew the capability allowance.

Complete independent evidence consolidation and exact-source bookkeeping without claiming SPN-146 accepted. Any different execution capability or further finite investigation requires its own concrete prospective scope, resource/ownership bounds and independent admission review; this report does not authorize one. The ticket's causal obligation and dependent integrations remain pending, while already completed application acceptance retains its actual source/attempt attribution. No merge approval is given.
