// Browser adapter for the existing actual-manager fixture. No primitive counters
// or serialization run inside the measured native flush/phase boundaries.
const assert = Object.assign((condition:any,message='Assertion failed')=>{if(!condition)throw new Error(message);},{
 ok(condition:any,message='Assertion failed'){if(!condition)throw new Error(message);},
 equal(a:any,b:any,message='Values differ'){if(a!==b)throw new Error(message+`: ${String(a)} !== ${String(b)}`);},
});
function instantiate(code:string,bindings:Record<string,unknown>,_options:unknown){
 return new Function(...Object.keys(bindings),`return (() => { ${code.replace(/DocStateChangeManagerService;$/, 'return DocStateChangeManagerService;')} })();`)(...Object.values(bindings));
}
function encode(value:any):any {
 if(value===undefined)return{kind:'undefined'};
 if(value===null||typeof value!=='object')return{kind:'value',value};
 assert.equal(Object.getPrototypeOf(value),Array.isArray(value)?Array.prototype:Object.prototype,'Unexpected prototype');
 return{kind:Array.isArray(value)?'array':'object',entries:Reflect.ownKeys(value).map(key=>{
  assert.equal(typeof key,'string');const d=Object.getOwnPropertyDescriptor(value,key)!;assert.ok(Object.hasOwn(d,'value'));
  return[key,{value:encode(d.value),writable:d.writable,enumerable:d.enumerable,configurable:d.configurable}];
 })};
}
const mark=(name:string)=>({name,time:performance.mark(name).startTime});
let journal:any;
export function inspect(){return journal??null;}
export function run(){
 assert.equal(journal,undefined,'Runtime allowance already started');
 const started=performance.now();
 journal={records:[],started,finished:false,elapsedMs:0,timeOrigin:performance.timeOrigin,userAgent:navigator.userAgent};
 const records=journal.records;
 try{
  // Parse/class construction is per fixture outside the native timed interval.
  for(const format of ['es','cjs'] as const)for(const pair of pairs)for(const order of [['prior','candidate'],['candidate','prior']])for(const variant of order){
   const id=records.length,label=`spn146-runtime-${id}`;
   const record:any={id,format,completed:pair.completed,sequences:pair.sequences,order:order.join('-'),variant,stage:'preparation',phases:[],passed:false};
   records.push(record);journal.active=id;
   assert.ok(performance.now()-started<30_000,'Observation body exceeds30seconds');
   const history=decodeCapture(pair.history),collaboration=decodeCapture(pair.collaboration);
   const states={history,collaboration},retained=[...history,...collaboration],before=JSON.stringify(encode(retained));
   assert.ok(retained.every(state=>state.unitId===unitId));
   assert.equal(history.length,32);assert.equal(collaboration.length,32);
   const fixture=managerFixture(native[format][variant]);
   let primary:unknown;
   try{
    for(const [method,phase] of [['_pushHistory','history'],['_emitChangeState','collaboration']]){
     const original=fixture.manager[method];
     fixture.manager[method]=function(...args:any[]){
      const first=mark(`${label}-${phase}-start`),began=performance.now();
      try{return Reflect.apply(original,this,args);}
      finally{const ended=performance.now(),last=mark(`${label}-${phase}-end`);record.phases.push({phase,first,began,ended,last,durationMs:ended-began});}
     };
    }
    fixture.manager.setStateCache(unitId,states);record.stage='flush';
    const first=mark(`${label}-start`),began=performance.now();
    try{fixture.manager.flushPendingChanges(unitId);}
    finally{
     const ended=performance.now(),last=mark(`${label}-end`);
     Object.assign(record,{first,began,ended,last,durationMs:ended-began,stage:'semantics'});
    }
    assert.ok(performance.now()-started<30_000,'Observation body exceeds30seconds');
    assert.equal(JSON.stringify(encode(retained)),before,'Retained inputs changed');
    const cache=fixture.manager.getStateCache(unitId);assert.equal(cache.history.length,0);assert.equal(cache.collaboration.length,0);
    assert.equal(fixture.history.length,1);assert.equal(fixture.changes.length,1);assert.equal(record.phases.length,2);
    record.output=encode({history:fixture.history,changes:fixture.changes,publication:fixture.publication});
   }catch(error){primary=error;record.failure=String(error);}
   finally{
    try{fixture.close();record.cleanup=true;}catch(error){record.cleanup=false;record.cleanupFailure=String(error);primary??=error;}
   }
   if(primary)throw primary;
   record.stage='pair-parity';
   if(id%2===1){
    assert.equal(JSON.stringify(records[id-1].output),JSON.stringify(record.output),'Paired publication values/order differ');
    records[id-1].pairParity=true;record.pairParity=true;
   }
   record.passed=true;record.stage='complete';
  }
  assert.equal(records.length,32);journal.finished=true;journal.active=null;
  return journal;
 }catch(error){
  journal.failure=String(error);
  if(journal.active!==null){const record=records[journal.active];if(record){record.failure??=String(error);record.passed=false;}}
  throw error;
 }finally{journal.elapsedMs=performance.now()-started;}
}
