import { spawn, execFileSync } from 'node:child_process';
import { writeFileSync, renameSync } from 'node:fs';
import { ownedProcesses, processes, signalOwned } from '/tmp/spn135-local-processes.ts';
import type { ProcessRow } from '/tmp/spn135-local-processes.ts';

const [destination, command, ...args] = process.argv.slice(2);
const started = Date.now();
const known = new Map<number, ProcessRow>();
const initial = processes().find(row => row.pid === process.pid)!;
if (initial.group !== process.pid) throw new Error('Run this watchdog through scripts/serial.ts');
if (execFileSync('sysctl', ['-n', 'kern.memorystatus_vm_pressure_level'], { encoding: 'utf8' }).trim() !== '1')
  throw new Error('Memory pressure must be normal before launch');
let peakKiB = 0;
function snapshot(outcome: string) {
  const live = ownedProcesses(processes(), process.pid, known);
  const rssKiB = live.reduce((sum, row) => sum + row.rssKiB, 0);
  peakKiB = Math.max(peakKiB, rssKiB);
  const pressure = execFileSync('sysctl', ['-n', 'kern.memorystatus_vm_pressure_level'], { encoding: 'utf8' }).trim();
  const record = { root: process.pid, started, elapsedMs: Date.now() - started, outcome, pressure,
    rssKiB, peakKiB, live, known: [...known.values()], scope: 'Observed task descendants, retaining start/command identities across reparenting; not system-wide absence' };
  // A failed update must leave the last complete ownership inventory readable.
  writeFileSync(destination + '.tmp', JSON.stringify(record, null, 2) + '\n');
  renameSync(destination + '.tmp', destination);
  return record;
}
snapshot('ready');
const child = spawn(command, args, { stdio: 'inherit' });
function abort(reason: string) {
  try { snapshot(reason); } catch (error) { console.error('Snapshot retention failed', error); }
  try { signalOwned(known, 'SIGKILL', process.pid); }
  finally { process.kill(0, 'SIGKILL'); }
}
const monitor = setInterval(() => {
  try {
    const state = snapshot('running');
    if (state.pressure !== '1' || state.rssKiB > 2 * 1024 ** 2 || state.elapsedMs > 60_000) {
      console.error('WATCHDOG ABORT: ' + JSON.stringify({ pressure: state.pressure, rssKiB: state.rssKiB, elapsedMs: state.elapsedMs }));
      abort('resource-aborted');
    }
  } catch (error) {
    console.error('WATCHDOG MONITOR FAILED', error);
    abort('monitor-failed');
  }
}, 250);
child.once('error', error => {
  clearInterval(monitor);
  console.error(error);
  try { snapshot('spawn-failed'); process.exitCode = 1; }
  catch (failure) { console.error('Final snapshot failed', failure); abort('monitor-failed'); }
});
child.once('close', (code, signal) => {
  clearInterval(monitor);
  try {
    const state = snapshot(code === 0 ? 'command-passed' : 'command-failed');
    if (state.live.some(row => row.pid !== process.pid && !(row.parent === process.pid && /^(?:\/bin\/)?ps -axo /.test(row.command)))) { abort('unsettled-owned-descendants'); return; }
    console.error('WATCHDOG: ' + JSON.stringify({ code, signal, elapsedMs: state.elapsedMs, peakKiB }));
    process.exitCode = code ?? 1;
  } catch (failure) { console.error('Final snapshot failed', failure); abort('monitor-failed'); }
});
