# 🔬 SPN-146 retained-cache plan and telemetry admission A

**Disposition:** the declared16-flush offline replay is useful and admissible as a distinct integration question. The narrow completion-telemetry repair addresses the known evidence-loss defect without weakening the trace contract. This is plan/source inspection, not an exact-head grade, validation-push approval, native rerun allowance or causal acceptance.

Reviewed local-only head `13d4a9b56d0e82bb1592f148fedc10e052fd90ba` in `/Users/mxbaylee/projects/spinel-spn-146`, its complete delta from `1eeb90f1`, maintained “First hosted diagnostic and finite retained-cache follow-up” checkpoint, telemetry controls, and first-hosted-diagnostic manifest. No source edits, diagnostic replay, native execution, package changes, tests or bulk hash verification. The prepared probe itself was not supplied for execution review; this report admits the plan with the boundaries below, not unseen helper bytes.

## 🧪 Why this question is new

The earlier work established equivalence and reduced native primitive work on older SPN-142 captures and constructed Enter/metadata cases. The newly retained failed diagnostic supplies source-bound cache objects from the actual current browser/instrumented prior-native run. It can now answer whether those concrete shapes satisfy the production qualifier and preserve exact raw manager publications. That is a real integration question rather than a repeated attempt to improve a timing measurement.

Four declared completed-state windows544/672/1440/1984 × ES/CJS × accepted prior/candidate are16 actual-manager flushes. The existing manager fixture and read-only exact Core are the appropriate lowest layer. No reconstructed document snapshot or CPU/GC conclusion is needed to answer the raw-composition question. The60-second,2GiB,one-process,normal-pressure allowance and first semantic/resource failure stop are finite and appropriate.

These are cache windows from the **new** run, selected at the same workload positions as historical failures; they are not recovered historical failing caches. The new run never produced a comparable≥80ms pair, and its native semantic checks after trace completion were not reached. Matching its raw cached data does not retroactively prove native content/history acceptance or explain any>100ms event.

## 🧱 Required execution boundaries

The preregistration is supportable provided the concrete helper preserves these conditions:

- Bind the exact11-member artifact/retained encoded cache hash, reviewed diagnostic source/build identities and exact prior/candidate ES/CJS/Core/fixture/probe hashes. The manifest includes the full original ZIP and member identities; I inspected that declaration but did not rehash it in this read-only admission pass.
- Derive each selected history/collaboration pair from phase identity, cumulative completed-state counts and capture order. Assert the expected32-entry counts and paired windows. Do not infer all positions solely from `sequence/2` or silently reuse source arithmetic in place of identifying actual recorded caches. Preserve unit/segment/metadata identities through the fixture.
- Decode the lossless representation without erasing own-undefined fields, array shape or metadata. Retain before/after raw-shape and nonmutation/ownership witnesses. The recorded encoder preserves native data values/keys, not arbitrary original JavaScript descriptor attributes; describe descriptor checks as checks on the decoded input actually replayed.
- Compare complete raw history/change/publication output and original publication ordering, queue clearing, returned ownership and fixture timer/listener cleanup between the exact prior and candidate. Do not normalize a mismatch or claim the unavailable initial snapshot has been reconstructed.
- Record **qualification/admission**, semantic parity and work counts as distinct outcomes. A qualifier rejection or no work reduction can be a valid, useful result, even if raw parity passes. Do not make the run “successful” only by widening the guard, choosing replacement caches or repeating it. If the question is whether the join executes, use an explicit nonmutating branch/call witness or explain why the exact prior/candidate difference makes the observed work delta sufficient evidence.
- Keep primitive counters separate from total allocations, guard overhead and native/browser wall time. If a semantic/ownership/cleanup/source mismatch occurs, retain the active case and completed count and stop the allowance; do not repair the helper and quietly restart the same matrix.

No additional broad matrix or actual browser observation is required before asking this bounded question. Its result may establish that the candidate fits these real shapes, or prune the proposed mechanism. Neither outcome alone closes the XL causal requirement.

## 🧾 Telemetry repair inspection

The collector still requires a stream and exact `proto`/`none`/`dataLossOccurred:false` before reading. Its new error property records field presence, JavaScript type and value, so omitted versus own-undefined versus false are not collapsed merely because JSON stores the value slot as null. Stream presence is recorded without exposing the handle. The native wrapper copies that error metadata into the failed receipt; it does not fabricate the missing fields from the first hosted attempt.

`streamClose` is a shared record attached before cleanup and serialized after the owned close settles. It distinguishes attempted, settled and secondary error; settled is correctly **not** synonymous with successful close. A close rejection goes through the existing first-error-preserving path, leaving the completion validation failure primary. The injected wrong-format/compression/loss/omitted-or-undefined and secondary-close tests check exact receipt fields, zero reads, one close, no retained owned output and no completion listener. No category, buffer, timeout, format acceptance or ownership contract is loosened.

A useful small remaining coverage addition before a later exact-head review is an explicit no-stream completion telemetry assertion: verify streamPresent:false, close attempted/settled:false and original missing-stream error, rather than extrapolating from controls with a valid handle. This is not a blocker to the independent offline cache replay. The error-attached telemetry currently covers completion-validation failures; end/read/output failures do not automatically gain a completion snapshot. Keep that narrower scope explicit instead of claiming a universal failure journal.

## 🧭 Disposition and limits

The first hosted attempt remains failed and causally inconclusive, its single observation allowance consumed. The full11-member ZIP plus20 payloads and source identities are retained in the candidate's evidence manifest; a later published repair must preserve that failure and obtain new exact-head reviews. Existing remote CI on `1eeb90f1` cannot validate the local telemetry change.

Operator benefits from a finite source-bound investigation; Owner and Collaborator retain exact editing/history/saved-peer requirements; editable Link guests retain their access fences. No persona gains a weaker responsiveness or cleanup contract. **Proceed only with the preregistered16-flush retained-data question under its watchdog once the helper is ready and resource ownership is coordinated. Do not treat this admission as permission for another native observation or as production/merge acceptance.**
