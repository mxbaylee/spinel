// External deadline still fires when the replay's single thread is synchronous.
import { execFileSync } from 'node:child_process';
execFileSync(process.execPath,['/tmp/spn146-investigation/hosted-replay.ts'],{
 timeout:60_000,killSignal:'SIGKILL',stdio:'inherit',
});
