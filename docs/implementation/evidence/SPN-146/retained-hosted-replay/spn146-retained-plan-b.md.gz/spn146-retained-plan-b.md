# 🔎 SPN-146 local telemetry and retained-cache plan review B

Read-only inspection of local commit **13d4a9b56d0e82bb1592f148fedc10e052fd90ba**, compared with published/first-diagnostic source `1eeb90f1d50291791d39913350c28c672c7154ee`. No publication or merge grade; no workload executed and no project edits. This review does not transfer remote CI results to the local source.

## ✅ Telemetry repair

The repair addresses an actual missing-evidence defect: a rejected completion event now carries presence, JavaScript type and value for each of the three validated fields, plus stream presence and the eventual close attempt/settlement/error. Missing and explicitly undefined fields remain distinguishable despite using null for their serialized value. The mutable close record is attached before failure handling and serialized by the diagnostic after shared collection has settled, so a secondary close failure is observable without replacing the primary completion-contract failure. Handles themselves are not published.

The validation predicates and limits remain strict and unchanged. Tests cover wrong format, wrong compression, true loss, absent loss, explicitly undefined format and each with secondary close failure; they require no read, exactly one close and no retained invalid output. Prior late-handle, deadline and persistence controls remain. This source inspection supports the narrow repair; I did not independently rerun the reported 44 controls, types or lint, or re-hash the retained 20-payload archive.

The repair cannot recover the omitted fields from run 41992099001. In particular it does not establish overflow, a benign omitted flag, or a reason to loosen validation. It is an observability change, not a reason by itself to repeat native typing. Shared collector modification remains subject to normal source routing and exact-head review before any publication.

## 🔬 The retained-cache question is distinct and useful

The proposed 16 flushes are justified as a finite **actual-input integration check**: four newly captured hosted history/collaboration cache pairs × ES/CJS × exact prior/candidate source. Earlier older-capture and synthetic-position matrices establish broad semantic evidence but do not establish that these newly observed hosted action representations qualify for the production optimization. The failure to obtain a comparable slow interval does not invalidate this smaller question; conversely, answering it does not solve that causal limitation.

The appropriate question is: do the actual hosted caches at completed states 544, 672, 1440 and 1984 enter the narrow production path, retain raw native publications and ordering, and remove its measured repeated-tail work? A negative qualification result is valuable and must be retained as a hypothesis falsification. It must not lead to broadening the guard automatically or silently selecting replacement cases.

## 📏 Required execution boundaries

The declared one process, 16 serial flushes, 60 seconds, 2 GiB, normal-pressure serial/watchdog and first-mismatch stop are proportionate. Before running, the probe should pin the hosted artifact/capture digest, source/Core/ES/CJS build hashes and exact fixture/helper bytes. Bind each selected case to original phase sequence, phase name, cumulative completed-state mapping, unit identity and retained history/collaboration records; do not assume array position or fixed-workload arithmetic alone proves the selected cache's identity. These are new observed caches at matching logical positions, not recovered historical failing caches.

Preserve the lossless decoder's own-undefined/array representations and inspect/compare complete inputs before and after each execution. Give each prior/candidate run independent owned input copies while retaining the same raw values. Compare exact history/change/publication payloads and order, queue/listener/timer cleanup and primitive counts, not just normalized JSON or applied text. Count or otherwise demonstrate actual qualifier admission for each case; a generic passing output comparison alone does not prove the optimized path was used. Keep history and collaboration independently captured rather than reconstructing one from the other.

No exact initial document snapshot was captured here. Therefore do not synthesize one and label it full content/history equivalence. Raw operation/publication parity against the exact accepted prior implementation is the supported oracle for this experiment; complete applied-state, undo/redo, persistence/access and latency acceptance remain separately required. Wall time includes local fixture/instrumentation and cannot be compared to browser budget or treated as GC evidence.

Stop on any identity, decoder, semantic, ordering, mutation/ownership, cleanup or resource mismatch and retain the first result. If all 16 pass, the conclusion is limited to admission and primitive-work behavior for these four hosted cache pairs. Do not renew this allowance, replay the browser, raise a trace buffer or add hidden samples.

## 🧭 Disposition

The local telemetry repair is appropriately narrow, and the preregistered retained-cache question is useful rather than a duplicate native trial. I see no static blocker to this finite offline experiment under the above existing bounds. This is plan/admission advice, not a production grade, native rerun allowance or merge approval. Historical causality remains inconclusive, the failed diagnostic remains failed, ordinary CI is independently pending, and SPN-146's full XL outcome remains open. All four personas retain their original integrity/access/responsiveness obligations; Operator gains a finite, inspectable integration answer without repeating the failed expensive observation.
