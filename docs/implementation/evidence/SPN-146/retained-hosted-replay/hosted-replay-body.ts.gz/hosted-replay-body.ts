// SPN-146: one finite replay of four newly captured real browser cache pairs.
let activeStates:{history:State[];collaboration:State[]}, activeAdmissions:any;
const root='/Users/mxbaylee/projects/spinel-spn-146';
const hash=(b:string|Buffer)=>createHash('sha256').update(b).digest('hex');
const base='/tmp/spn146-hosted/diagnostic/test-results/doc-responsiveness/doc-responsiveness-mobile-sustained-native-typing-profile-doc-responsiveness';
const source=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const began=performance.now(), results:any[]=[];
let flushes=0,failure:string|undefined,active:any;
const timer=setTimeout(()=>{console.error('Retained replay exceeded60seconds');process.exit(2);},60_000);
const encode=(value:any):any=>value===undefined?{kind:'undefined'}:value===null||typeof value!=='object'?{kind:'value',value}:{kind:Array.isArray(value)?'array':'object',entries:Reflect.ownKeys(value).map(k=>[k,encode(value[k])])};
try {
 assert.equal(source,'13d4a9b56d0e82bb1592f148fedc10e052fd90ba');
 const bytes=await readFile(base+'/spn146-native-caches.json');
 const manifest=JSON.parse(await readFile(root+'/docs/implementation/evidence/SPN-146/first-hosted-diagnostic/manifest.json','utf8'));
 const member=manifest.artifactMembers.find((x:any)=>x.path.endsWith('/spn146-native-caches.json'));
 assert.equal(bytes.length,member.bytes);assert.equal(hash(bytes),member.sha256);
 const capture=JSON.parse(bytes.toString());assert.equal(capture.unitId,unitId);assert.equal(capture.dropped,0);assert.deepEqual(capture.errors,[]);assert.equal(capture.restored,true);
 const buildBytes=await readFile('/tmp/spn146-hosted/diagnostic/spn146-diagnostic-build.json');
 const buildMember=manifest.artifactMembers.find((x:any)=>x.path==='spn146-diagnostic-build.json');
 assert.equal(buildBytes.length,buildMember.bytes);assert.equal(hash(buildBytes),buildMember.sha256);
 const build=JSON.parse(buildBytes.toString());
 assert.equal(build.source,'1eeb90f1d50291791d39913350c28c672c7154ee');assert.equal(build.reviewedHead,build.source);
 assert.equal(build.tree,'63aff27fd8ce112942db85b9b32eadcfcfaa3762');assert.equal(build.nativeReference,'2f442317dd2e1c188ae4a810ac094fd1162a4a2a');
 for(const format of ['es','cjs'] as const) assert.equal(hash(await readFile(`/Users/mxbaylee/projects/spinel/node_modules/@univerjs/core/lib/${format}/index.js`)),build.sources[`node_modules/@univerjs/core/lib/${format}/index.js`]);
 assert.equal(hash(await readFile(root+'/scripts/dependencies/patch-univer-docs.ts')),build.sources['scripts/dependencies/patch-univer-docs.ts']);
 let completed=0;const selected:any[]=[];const targets=[544,672,1440,1984];
 assert.equal(capture.captures.length,132);
 for(let i=0;i<capture.captures.length;i+=2){const history=capture.captures[i],collaboration=capture.captures[i+1];
  assert.equal(history.phase,'history');assert.equal(collaboration.phase,'collaboration');assert.equal(history.sequence,i);assert.equal(collaboration.sequence,i+1);assert.equal(history.count,collaboration.count);
  completed+=history.count;
  if(targets.includes(completed)){assert.equal(history.count,32);selected.push({completed,history,collaboration});}
 }
 assert.equal(completed,2086);assert.deepEqual(selected.map(x=>x.completed),targets);
 for(const format of ['es','cjs'] as const){
  const prepared=prepareDocsPatch(await readBuild(format),format);
  const reference=build.builds.find((x:any)=>x.format===format);
  assert.equal(hash(prepared.constantGuardPatched),reference.priorSha256);assert.equal(hash(prepared.patched),reference.installedSha256);
  for(const selectedPair of selected){
   const measured:any[]=[];
   for(const [variant,nativeSource] of [['prior',prepared.constantGuardPatched],['candidate',prepared.patched]] as const){
    active={format,completed:selectedPair.completed,variant};assert.ok(performance.now()-began<60_000);
    // Decode fresh independent copies, preserving own undefined and captured IDs.
    activeStates={history:decodeCapture(selectedPair.history.cache),collaboration:decodeCapture(selectedPair.collaboration.cache)};
    assert.equal(activeStates.history.length,32);assert.equal(activeStates.collaboration.length,32);
    assert.ok([...activeStates.history,...activeStates.collaboration].every(x=>x.unitId===unitId));
    const value=measuredFlush(nativeSource,activeStates.history,activeStates.collaboration,true);flushes++;assert.ok(performance.now()-began<60_000);
    assert.equal(value.output.history.length,1);assert.equal(value.output.changes.length,1);
    measured.push({...value,admission:activeAdmissions,sourceSha256:hash(nativeSource)});
   }
   assert.deepEqual(measured[1].output,measured[0].output,`${format}/${selectedPair.completed}: complete raw publication/order parity`);
   results.push({format,completed:selectedPair.completed,captureSequences:[selectedPair.history.sequence,selectedPair.collaboration.sequence],inputSha256:hash(JSON.stringify([selectedPair.history.cache,selectedPair.collaboration.cache])),variants:measured.map((x,i)=>({variant:i?'candidate':'prior',sourceSha256:x.sourceSha256,admission:x.admission,counts:x.counts,outputSha256:hash(JSON.stringify(encode(x.output))),output:encode(x.output)}))});
  }
 }
 assert.ok(performance.now()-began<60_000);assert.equal(flushes,16);assert.equal(results.length,8);
}catch(error){failure=error instanceof Error?error.stack:String(error);throw error;}
finally{
 clearTimeout(timer);
 const result={diagnosticOnly:true,source,status:failure?'failed':'passed',failure,active,flushes,elapsedMs:performance.now()-began,probeSha256:hash(await readFile('/tmp/spn146-investigation/hosted-replay.ts')),fixtureSha256:hash(await readFile(root+'/scripts/dependencies/patch-univer-docs.test.ts')),results};
 await writeFile('/tmp/spn146-hosted/retained-replay-results.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,results:results.map(({variants,...r})=>({...r,variants:variants.map(({output,...v}:any)=>v)}))}));
}
