import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
const commit='8872c05cddb92d5c21c3ff7cb196d3d8660aa4ff',dir='docs/implementation/evidence/SPN-146/single-clone/';
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const git=(p:string)=>execFileSync('git',['show',commit+':'+p],{maxBuffer:4*1024*1024});
const m=JSON.parse(git(dir+'manifest.json').toString());
const proof:any={complete:false,commit,sources:[],payloads:[],receipts:{}};
try{assert.equal(m.predecessor,'97d0b3203fbddc673d5a9bc729410949eb875523');
for(const s of m.sourceBindings){const b=git(s.path);assert.equal(b.length,s.bytes);assert.equal(sha(b),s.sha256);proof.sources.push(s);}
for(const p of m.payloads){const z=git(dir+p.path),b=gunzipSync(z,{maxOutputLength:4*1024*1024});assert.equal(z.length,p.storedBytes);assert.equal(b.length,p.rawBytes);assert.equal(sha(z),p.storedSha256);assert.equal(sha(b),p.rawSha256);proof.payloads.push(p);if(/result.json.gz$|(?:integration|types|lint|app-build|runtime-tests)-watchdog.json.gz$/.test(p.path))proof.receipts[p.path]=JSON.parse(b.toString());}
proof.tree=execFileSync('git',['rev-parse',commit+'^{tree}'],{encoding:'utf8'}).trim();assert.equal(proof.tree,'793cd7db7c579d7dfc98f19b833e764235b2b29c');proof.complete=true;
}catch(e){proof.error=String(e);throw e;}finally{writeFileSync('/tmp/spn146-investigation/single-clone-proof-a.json',JSON.stringify(proof,null,2)+'\n');}
console.log(JSON.stringify({complete:proof.complete,sources:proof.sources.length,payloads:proof.payloads.length,rawBytes:proof.payloads.reduce((s:number,p:any)=>s+p.rawBytes,0)}));
