# 🔎 SPN-146 single-clone candidate — independent review A

Exact reviewed commit **`8872c05cddb92d5c21c3ff7cb196d3d8660aa4ff`**, tree **`793cd7db7c579d7dfc98f19b833e764235b2b29c`**, base **`2f442317dd2e1c188ae4a810ac094fd1162a4a2a`**. Independent grade **94/100 — withhold validation publication until the P2 below is repaired and the new complete head re-reviewed**. No runtime/browser/qualification was executed by this reviewer.

I inspected the original main ticket, maintained full scope and conditional bookkeeping, the complete new 97d-to-8872 source/test/workflow delta, retained proof identities, the actual public Core iterator/slicer/push implementations and the runtime builder's fixture extraction. Prior unchanged full-PR reviews supply continuity, not a carried-forward numerical approval. The original failed maximums and all consumed experiments remain failed/closed.

## ⚠️ P2: no-counter runtime still wraps only the candidate slicer

`scripts/dependencies/patch-univer-docs.test.ts:137–144` always overrides the context's public `getBodySliceForSplitTextXAction` export with a diagnostic forwarding function. The function still creates/rest-spreads its arguments and checks `costs.bodySlice` even when that callback is absent. `scripts/ci/doc-native-runtime/build.ts` copies this fixture into the fixed timed bundle unchanged. The new candidate calls that wrapper for each admitted leaf; the old constant-guard baseline's internal ActionIterator calls the Core function directly.

This is avoidable asymmetric test-only work in the prospective native comparison. It does not demonstrate production corruption or establish the size/direction of a JIT effect, but the registered comparison should not depend on an unnecessary forwarding layer for only the changed path. A lower iterator count cannot substitute for a clean timing boundary.

**Required narrow repair:** preserve the exact original Core export when no body-slice counter is supplied; install the forwarding counter wrapper only for measured semantic/work controls. Add or inspect a control that proves no-counter binding identity and still counts direct slicing when requested. Rebuild/rebind the bundle once as preparation, without running a browser, and obtain fresh exact-head reviews. The implementing parent acknowledged this finding; no repair is credited in this 8872 review.

## ✅ Production and evidence assessment

The actual algorithm proposal is narrow and coherent. For fully qualified plain one-character insert leaves, `normalizeDocInsertLeaf` keeps the same leaf spread, length1 and public full-body slice with `(body,0,1,false)`, while omitting only ActionIterator's immediately redundant deep clone. Public `TextX.push` clones before accessing/mutating its retained actions and preserves native merge behavior. The guard excludes accessors/nonplain graphs; unsupported, undo, tiny-head null fold, Enter boundary and final JSONX composition remain unchanged. No private Core array or Pro API is used.

The required full-module ES named import and CJS namespace binding are present. Actual complete-module controls exercise admitted prefixes3/4/23, including real CJS Core in a bounded isolated child; missing-slicer negatives prove the region fixture cannot mask a missing import. The historical missing-iterator regression remains exercised against the exact 97d control. Installer recovery recognizes and hash-checks the prior complete linear-prefix build, rejects unknown/partially modified files and preserves earlier exact upgrade/control hashes. Both package builds are validated before writes.

Direct public slices are counted by the new semantic instrumentation, alongside internal iterator slicing. Thus the reported equal slicing/composition counts do not falsely turn removed iterator calls into eliminated normalization. Shared nested-style/alias fingerprints, output mutation isolation, repeated independent calls, prior normalizations, unsupported read order and existing full raw/applied/sequential oracles are meaningful controls. Prototype graph fingerprints are structural evidence within these fixtures, not a universal proof about every JavaScript object. The retained broader matrix uses ES Core for both manager-region formats; actual CJS complete-module execution is a separate control and is not conflated with that matrix.

The original main ticket requires actual unprofiled 2,086-key,16-paragraph,4× mobile capacity/idle budgets and full local/saved/peer/history/access/cleanup behavior, plus a supported causal disposition. Nothing here relaxes those requirements. The new one-transition workflow remains same-repository/exact branch, synchronize only, exact predecessor97d and attempt1, checked-out reviewed head, fixed32 observations/16 comparisons. The baseline remains the original constant-guard version, not an easier 97d comparator. Every comparison must meet both≥20% and≥1ms; unchanged resource/trace/GC/cleanup constraints apply. The application-window allowance stays closed. Prior97d 13/16 is not a pass and is not retroactively reclassified.

## 🧪 Independent integrity and feasible checks

`single-clone-proof-a.ts` independently verified **51 payloads / 2,693,668 decoded bytes**, including stored/decoded size/SHA checks, and **5 exact source bindings** from 8872 Git blobs. First execution passed **809 ms / 186,032 KiB**, normal pressure, under the serial60s/2GiB watchdog. Proof/log/watchdog are external alongside this report. No passing workload was duplicated.

Retained integration records report **208 Docs tests** passing42,576ms/636,528KiB, **29 runtime controls**312ms/90,272KiB, full types4,683ms/1,586,720KiB, lint/format/dependencies16,840ms/799,520KiB and app build1,669ms/1,064,288KiB. The 888-module/15-package bundle preparation was on a dirty97d checkout; its actual source-file hashes are preserved, but it is neither exact8872 hosted preparation nor timing acceptance. No browser/converter ran for it.

## 🧮 Rubric and complexity

- **35/35 scope/acceptance:** one complete original XL outcome retained; no waived physical/latency/access requirement or hidden follow-up.
- **25/25 correctness/integrity/access:** no production semantic, binding or ownership blocker found in this delta; exact source/evidence provenance retained.
- **14/20 meaningful verification:** six-point deduction for the concrete avoidable asymmetry in the next timing fixture. Semantic evidence is useful, but the finite runtime question needs the repaired binding before publication.
- **10/10 CI/operations:** source/shared dependency routing remains selected and fail-closed; finite workflow routing and ordinary CI retention are explicit.
- **10/10 maintainability/process/over-complexity:** the production helper is smaller than bypassing native ownership or inventing caching. Historical transformations increase patch-maintenance cost but retain required exact install upgrades and executable negatives. No additional framework is warranted.

Raw full diff: **689 files,15,866 additions/547 deletions**, not the exclusion-adjusted PR count. Increment: **59 files,774 additions/23 deletions**, mostly durable evidence. This exceeds the soft review boundary; the scope checkpoint must remain visible. The source repair and its proof are inseparable from native flush acceptance, so splitting them into a purported completed parent would hide the still-unmet outcome. Conditional ticket deletion/ledger/index are landing preparation only. Old controls may eventually be retired only through their explicitly separate upstream/retirement owner, not silently here.

Owner and Collaborator retain exact content/formatting/history and responsive typing requirements. Operator receives bounded source-bound proof and preserved failures rather than repeated tests until green. Link guest keeps the same edit/access fences. The remaining failure is a test-boundary issue, not a persona tradeoff that permits a weaker threshold.

## 🚦 Disposition

Repair the counter-free binding, retain this rejected exact-head report, revalidate the new complete commit and then assess publication. A qualifying source grade will still not establish current-head hosted/application acceptance, browser speedup or the causal disposition of the historical129.1/114.4/131.2ms events. No further native execution or merge approval is given here.
