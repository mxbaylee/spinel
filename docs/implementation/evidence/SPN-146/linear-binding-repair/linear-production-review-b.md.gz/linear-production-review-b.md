# 🔎 SPN-146 production candidate — independent review B

**Reviewed commit: `418f8b6f85711731fd322ab81040ed00f35cadcb`, base `2f442317dd2e1c188ae4a810ac094fd1162a4a2a`. Score: 90/100. Rejected for validation publication: one P1 production integration blocker.** No runtime push or merge is approved. This report remains tied to this commit even while the implementer prepares its repair.

## 🚨 P1 — missing ES module binding for ActionIterator

`scripts/dependencies/patch-univer-docs.ts:324` chooses an empty namespace for ES, and lines 335/347 emit bare `new ActionIterator(...)` in the new qualified tail/prefix paths. The complete patched ES build identified by SHA `e47c9319b3c85c737add0e7807edbc27aeafcc81b81dd6ad870058e4fe3da093` does **not** import or otherwise declare `ActionIterator`. Its full first-line Core import contains TextX and TextXActionType but omits ActionIterator; the only ActionIterator occurrences in that emitted module are the two newly generated uses (observed at installed lines 3622/3632).

Consequently an actual ES application reaching an admitted Enter flush will evaluate an unbound identifier and throw `ReferenceError`, interrupting native history/collaboration publication. This is a production execution defect, not merely missing hosted evidence. The CJS namespace path does not establish the missing ES binding.

The passing semantic tests do not detect it: `scripts/dependencies/patch-univer-docs.test.ts:128–148` extracts the manager region and injects the entire Core namespace into its evaluation context. The new direct helper also supplies all Core exports. `scripts/ci/doc-native-runtime/build.ts:113–146` similarly extracts manager regions and supplies Core in the component bundle. These fixtures legitimately test isolated native semantics but cannot prove the lexical bindings of the complete production module. A bundle/build pass can leave an unresolved global in JavaScript and is insufficient here.

**Required repair:** add the exact guarded ES import binding; preserve original and previously published upgrade identities rather than silently rewriting their historical bytes. Add a meaningful complete-module lexical/integration control that fails on this exact missing-import candidate and exercises or verifies the production binding without an injected global. Refresh new full-module hashes and runtime source bindings, rerun affected feasible checks, commit the complete repair and obtain both new exact-head reviews before publication. The implementer acknowledged this finding; no runtime push had occurred. The unchanged manager-region semantic results remain valid within their stated scope, but are not complete-module acceptance.

## 📏 Independent rubric

- **Scope and acceptance: 35/35.** The complete original XL outcome is retained, including the causal-cost-versus-pause requirement, unprofiled budgets and full semantic/access owners. The new mechanism and finite candidate qualification are explicitly separated from prior failed allowances. Landing bookkeeping is prepared, not claimed as a completed merge.
- **Correctness, integrity and access: 18/25.** Deduct 7 for the P1 missing production binding above. The actual guarded construction, raw metadata preservation, fallback/undo authority and package upgrade boundary otherwise remain narrowly scoped and well supported.
- **Meaningful verification: 17/20.** Deduct 3 for the integration blind spot: all current targeted semantic and component contexts inject the new symbol and therefore cannot detect its absence from the deployed ES module. The retained native negatives/ownership cases and first-failure controls are otherwise substantive. This deduction is not for declining to repeat passing tests or for the resource-aborted typecheck.
- **CI and operations: 10/10.** The one-transition, first-attempt qualification route, exact checkout, source/closure binding, unchanged criterion and fail-closed collection/cleanup are appropriate. Current hosted acceptance remains pending, with no numerical credit claimed for its outcome.
- **Maintainability, documentation and over-complexity: 10/10.** The actual algorithm change is small and source-specific. No generic composer, persistent cache or new package is added. The extensive retained investigation and closed diagnostic paths increase review surface but preserve an inseparable causal/acceptance history; they do not justify dropping required evidence or inventing another feature split. The existing SPN-122 retirement boundary remains distinct.

## 🧩 Full scope and algorithm review

Read the original base ticket, current process/testing/runbook/personas, full changed-file scope and current main-to-candidate changes, with focused comparison from `8b682819…`. Reused earlier independent inspection of unchanged diagnostic/trace/window lifecycle code and inspected the current runtime build/run/conversion/analysis route. No application, browser, install, test or converter was rerun by B.

The production helper construction matches the passed tail/prefix manager-region proposals: full single-Enter/append-contiguous guard remains authoritative; each admitted leaf uses public native normalization and TextX push; the first absolute retain is preserved; prefix below four retains its null fold; prefix/Enter and final head/tail joins keep order. Undo, nonqualifying shapes and fallback operand/read order retain their prior behavior. It neither serializes away own-undefined metadata nor introduces an aliasing cache.

The installer reconstructs exact original bytes, checks whole-package identity and both formats before writes, retains `qualifiedRangesPatched` as an exact upgrade/control and rejects the unpublished tail-only intermediate as installed input. Altered prior bytes remain rejected. The missing ES binding must be integrated into this existing guarded mechanism, not bypass it.

Maintained tests compare original/current/tail-only/combined semantics, every Enter position and cover mode, offsets, normalization/style variants, raw descriptor/alias topology, mutation isolation, independent calls, metadata/oldBody interactions and unsupported fallbacks. The earlier independently reviewed real-cache and broader matrices remain historical scratch evidence with exact source identities. CJS syntax variants execute ES Core in these fixtures; no separate CJS Core runtime claim is made.

## 🧾 Evidence actually reviewed

Read current local logs and receipts: **204 Docs controls**, **38 runtime/window controls**, full lint/format/dependency checks, application build, backlog and source/hash records. Docs controls passed in 42,233 ms/587,056 KiB; runtime controls passed in 392 ms/256,576 KiB; full lint passed in 18,460 ms/761,376 KiB. Local dependencies are an isolated, version-checked clone, not evidence of a clean install. Existing build warnings are retained.

Full typecheck was resource-aborted at **5,685 ms**, pressure 2, observed process-tree 1,440,736 KiB, with no compiler diagnostic. It is incomplete, not passed. Hosted clean install and typing remain necessary. Backlog passed with pre-existing length/grooming warnings.

The new linear-copy manifest binds six current source files and retained experiment/results/raw proofs/reviews/local checks. Reviewer A independently reported its first-pass verification of all **76 payloads/4,385,582 decoded bytes plus six exact Git-blob bindings** (1,089 ms/184,064 KiB). B did not duplicate that scan. B's earlier independent artifact audit of the first tail proof remains recorded separately; later prefix/broader assessments explicitly distinguish static receipt inspection from binary rehashing. Original setup/semantic investigation failures and both prior inconclusive component outcomes remain preserved.

## 🔬 Qualification and remaining acceptance

The workflow admits only same-repository ticket-branch synchronization whose predecessor is `8b6828196266f1fac6c46e2cc16b16321db72cf7`, checks run attempt 1 before work and checks out the reviewed head. There is no manual/automatic renewed allowance. The builder keeps the **original constant-guard comparator**, exact four real input pairs and frozen component body; previous qualified candidate hashes are separate provenance. The analyzer still requires all **16 comparisons from 32 fixed observations** to meet **at least 20% and at least 1 ms whole-flush reduction**, with unchanged Linux/throttle, complete trace/converter, clock/GC context and resource/cleanup requirements. Ordinary required CI is not cancelled to create another qualification attempt.

The changed normalization/copy mechanism is a sound basis for preparing one new candidate qualification after the P1 repair and fresh reviews. No old runtime failure is erased. A future component pass would not explain the exact historical 129.1/114.4/131.2 ms pauses or replace unprofiled first-attempt p95/max, idle, saved/peer content, selection/history, continuation/IME/reconnect, revocation/access or owned-cleanup acceptance. All seven current-head gates and selected application/native owners remain pending on the eventual repaired head.

## 👥 Personas and bookkeeping

Owner/Collaborator require preserved content, metadata, history and publication; the missing binding directly endangers their editing path and therefore blocks publication. Operator gets bounded, first-failure-preserving investigations and truthful source/resource evidence. Link guest authority is unchanged and remains owned by selected application access checks. No new UI state requires a separate design/visual approval in this algorithm change.

The candidate deletes SPN-146, removes SPN-089's dependency, appends only SPN-146 to the completion ledger and updates the generated index as conditional landing preparation. The maintained record still says the complete outcome is unresolved. No unrelated ticket completion, ID allocation, authority or budget change is introduced. The full history/evidence makes this an XL review; the executable/documentation delta excluding retained evidence is approximately 7,632 changed lines, and retained manifests add to the checker-accounted total. The soft-limit reassessment must remain explicit in publication; this is not a rationale to split away the test weakness or original acceptance contract.

**Final disposition: 90/100, P1 unresolved on `418f8b6f…`; do not push this candidate for validation. Repair the full-module binding and its regression control, then revalidate the new complete commit.**
