Sustained mobile Doc typing can exceed the unchanged 100 ms native flush maximum when a 32-state cache contains an Enter followed by plain append edits. This change keeps the structural head unchanged and balances only the fully qualified plain tail, preserving raw history/collaboration publications, metadata, ownership and fallbacks.

## 🚧 Run checkpoint — current validation candidate

- Candidate: `483bf8ae4609fa8027485293e6050fe8dca88e1c` on `codex/spn-146-mobile-flush`, based on main `2f442317dd2e1c188ae4a810ac094fd1162a4a2a`.
- Worktree: `/Users/mxbaylee/projects/spinel-spn-146`; complete candidate committed, no uncommitted work. The source is being published for fresh selected CI and one explicitly reviewed Linux component experiment. Keep this PR draft until actual acceptance is complete.
- **Current-head CI and diagnostic result remain pending.** The prior published source's green gates are recorded below and are not reused as passes for this head.
- SPN-141 → SPN-140 → SPN-120 and SPN-089 remain blocked on an accepted SPN-146 outcome. SPN-143/PR #263 and SPN-144/PR #265 already merged. No foreign branch was taken over; any future takeover first verifies the owner's two-hour age rule and current ownership.
- Complete scope remains XL. Agent review only; no visual product change or visual-approval claim.

## 🔎 Behavior and regression contract

The qualification path admits only descriptor-safe native shapes, one recognized Enter and its matching style retain, followed by at least four contiguous plain append states on the same unit/segment. It preserves the original head through Enter and composes the balanced tail once. Unsupported structures/metadata, multiple boundaries and nonqualifying sequences use the existing reducer unchanged. Undo behavior and all product budgets remain unchanged.

The actual-manager suite covers ES/CJS builds, all32Enter positions, retain modes, nonzero offsets, unequal queues, metadata/fallback negatives, raw publications, retained-input nonmutation, accumulator ownership and full applied snapshots. The existing native fixture still owns all2,086keys, continuation/IME/history/access/reconnect contracts; Chromium desktop/emulated mobile acceptance is not a physical-phone claim.

[Maintained implementation, decisions and exact source identities](https://github.com/mxbaylee/spinel/blob/483bf8ae4609fa8027485293e6050fe8dca88e1c/docs/implementation/SPN-146.md).

## 🧪 Test plan and evidence

Local evidence:
- Earlier unchanged algorithm candidate: 202 actual-manager tests; exact earlier implementation retained as the work/semantic negative. The newer trace rejection telemetry has 44 controls. Their original source identities remain in maintained manifests.
- Current component analysis/ownership: 24 focused controls passed, including missing selected evidence, one below-threshold comparison, unknown/incorrect GC evidence, PID reuse, final resource bounds and actual filesystem journal/manifest failures. Scoped TypeScript, lint and PR backlog validation passed under normal memory pressure.
- Portable preparation passed with 888 modules / 15 locked packages, exact input/native/Core hashes and the same frozen browser body. No actual native timing or real trace conversion ran locally after the resource abort.
- One broader callback-progress test command could not load this worktree's partial Playwright installation. 40 other controls in that command passed; the overall command failed and is retained. Focused actual shared-helper persistence controls passed separately. Clean hosted CI owns the full dependency installation and broader suites.
- [Linux preflight manifest and exact candidate source hashes](https://github.com/mxbaylee/spinel/blob/483bf8ae4609fa8027485293e6050fe8dca88e1c/docs/implementation/evidence/SPN-146/linux-runtime-preflight/manifest.json).

The Linux diagnostic has a single reachable first-attempt event: this branch's first synchronize away from `7e041c0c7c84bc28c56aeff1bda35b2a93654114` after the explicit preparation repair below. Later pushes/edits cannot renew it; workflow reruns fail before installation. Setup is bounded to 8 minutes, whole job 15 minutes; preparation, browser/collection/teardown and conversion/analysis each have 60 seconds and 2 GiB owned RSS. Linux requires 1 GiB MemAvailable. Owned process identities survive reparenting and exclude unrelated apps.

Exactly 32 serial observations compare the same four real hosted cache pairs in both manager formats, both variants and both orders under4× CPU. The positive criterion is **every one of 16 matched whole-flush comparison reducing both ≥20% and ≥1 ms**, with raw parity, nonmutation, cleanup and complete trace/GC/clock evidence. All 194 marks must map to one renderer/thread within 0.25 ms offset uncertainty. Pauses are reported, never subtracted; the post-observation GC control is separate. Conversion uses pinned Perfetto v59.1 with complete protobuf framing, import statistics and owned cleanup. Missing/failed evidence, mixed/small effects or resource abort is inconclusive; consistent increase contradicts benefit. No automatic retry, larger limit, dropped interval or replacement sample.

## ⚠️ Retained failures and interpretation limits

Original unprofiled first-attempt failures remain valid: 129.1 ms at state 672 on SPN-089's earlier source,114.4ms at state 1440 on its corrected source, plus SPN-141's116.5ms at state 1984 and122.3ms at state 544. No profile was captured inside those exact failed maxima. This PR does not claim their entire elapsed time was explained.

The first dedicated prior-native hosted diagnostic ([run 41992099001](https://github.com/mxbaylee/spinel/actions/runs/41992099001), job 127126484269, source `1eeb90f1d50291791d39913350c28c672c7154ee`) captured all 2,086 inputs and 132 cache phases but failed strict protobuf transport completion before reading a raw trace. The missing completion flags were not retained, so overflow/format/loss cause remains unknown. Its maximum instrumented capacity pair was 75.6 ms and CPU clock evidence was insufficient for exact pause attribution. It did not reach content/history final acceptance. Narrow telemetry repair now retains rejection fields and owned stream-close outcomes without relaxing the gate.

The retained 16-flush offline replay on those real cache pairs proved exact native publication values/order and reduced composition allocations/iterations, with cleanup and input nonmutation. It did not establish guard-inclusive browser time. [Replay manifest](https://github.com/mxbaylee/spinel/blob/483bf8ae4609fa8027485293e6050fe8dca88e1c/docs/implementation/evidence/SPN-146/retained-hosted-replay/manifest.json).

The separately preregistered local Chromium phase then aborted during browser startup: macOS pressure 2 at 4366 ms; final inventory 4419 ms / 671888 KiB. Zero native observations, no CPU profile/trace/GC control and no graceful finalizer. Exact recorded process identities had no survivors afterward. That local allowance is permanently closed. [Complete preparation/abort/review record](https://github.com/mxbaylee/spinel/blob/483bf8ae4609fa8027485293e6050fe8dca88e1c/docs/implementation/evidence/SPN-146/local-runtime-abort/manifest.json).

Two independent reviews supported a **new explicit Linux capability-plan revision**, following the runbook's hosted ownership of resource-blocked acceptance. This does not turn either failed diagnostic into a pass. Linux inference stays specific to the component/runtime; it is not pooled with Mac timing or substituted for full application acceptance.

## 🛠️ Workflow preparation failure and narrow repair

The first Linux publication, `7e041c0c7c84bc28c56aeff1bda35b2a93654114`, received A98/B97 pre-push grades but GitHub rejected [workflow run42004830910](https://github.com/mxbaylee/spinel/actions/runs/42004830910) before any job (`total_count: 0`). No setup, native case, trace or conversion ran. Both initial reviews missed an unsupported `runner.temp` reference in job-level `env`; those reviews and the failure remain preserved.

Official actionlint v1.7.12, verified against the release asset SHA/size, reproduces the original context failure and accepts the repair. The converter path now initializes from `RUNNER_TEMP` in the setup step and persists via `GITHUB_ENV`. The one source transition is explicitly reanchored to the actually published7e041c0c head. All fixed cases, thresholds, evidence and resource bounds remain unchanged; this is preparation repair before the first Linux job, not a retry of observed native data.

Superseded CI42004840062, Storybook42004839728, native42004839916 and earlier metadata CI42004793620 are confirmed terminally cancelled. Their aggregate/applicability failures explicitly reflect cancelled or missing selected work. No cancelled, skipped or partial result is acceptance. Fresh selected checks are required for `483bf8ae4609fa8027485293e6050fe8dca88e1c`.

[Failure, original reviews, cancellation receipts/logs, and static repair proof](https://github.com/mxbaylee/spinel/blob/483bf8ae4609fa8027485293e6050fe8dca88e1c/docs/implementation/evidence/SPN-146/linux-workflow-parse-repair/manifest.json).

## ✅ Prior published source acceptance — historical, not current-head credit

On source `1eeb90f1d50291791d39913350c28c672c7154ee`, tested merge `50f22d7a6a2c66f7bbd94edf031112d697962d95` had identical tree `63aff27fd8ce112942db85b9b32eadcfcfaa3762`:
- [CI41992099254](https://github.com/mxbaylee/spinel/actions/runs/41992099254), attempt 1: all 33 jobs and all seven required gates succeeded.
- [Storybook41992098916](https://github.com/mxbaylee/spinel/actions/runs/41992098916), attempt 1:8 successes, 2 Pages skips; all selected viewport checks and aggregate passed.
- [Native41992098850](https://github.com/mxbaylee/spinel/actions/runs/41992098850), attempt 1: Firefox/Chrome/Safari passed 37/37/39 acceptance stages. SPN-141's additional stages are not in this source.
- Mobile plain 1/2/3 first attempts: capacity p95 23.7/20.4/20.7 ms, maxima 44.6/31.9/36.8 ms; idle maxima 4.9/0.9/2.1 ms. Exact saved/live text, selections and Online passed. Plain 1 actually traversed all 66 Undo/Redo groups; the other plain/profile cases traversed one each.
- Desktop capacity maxima 4.4/4.2/4.4 ms. Both responsiveness comparisons and both callback-lifetime comparisons accepted with no failures.

[Durable first-candidate results, source/tested/artifact identities and native/responsiveness archives](https://github.com/mxbaylee/spinel/blob/483bf8ae4609fa8027485293e6050fe8dca88e1c/docs/implementation/evidence/SPN-146/first-candidate-ci/manifest.json). Large callback raw traces/source maps remain supplementary 30-day Actions artifacts plus locally retained copies; summaries are not called full raw traces. Final-source acceptance must be retained before merge.

## 👀 Exact-head independent pre-push reviews

Both independent nonimplementing reviews revalidated exact repair `483bf8ae4609fa8027485293e6050fe8dca88e1c`: A **98/100** (35/25/18/10/10), B **97/100** (35/25/18/9/10). No unresolved source blockers. Fresh selected application CI and the first actual Linux component experiment remain pending; these grades permit validation publication, not merge.

<details>
<summary>Independent reviewer A — exact repair assessment</summary>

# 🔎 SPN-146 workflow repair — exact-head review A

**Exact reviewed commit: `483bf8ae4609fa8027485293e6050fe8dca88e1c`. Base: `2f442317dd2e1c188ae4a810ac094fd1162a4a2a`. Independent score: 98/100. No unresolved source blocker identified. Qualifies for the explicitly revised validation publication after both exact-head reviews; not merge approval.**

This assessment covers the complete SPN-146 scope, including the original ticket's causal requirement and all application integrity/performance obligations. I revalidated the complete candidate by inspecting its exact delta against the previously reviewed full change, confirming all TypeScript, native implementation, tests, analyzer and watchdog source is unchanged, and independently inspecting the new workflow and failure-disposition evidence. Worktree is clean. No tests, browser, converter or runtime observations were executed for this review.

## 📊 Independent rubric

- **35/35 scope:** The XL native-work repair and remaining causal/runtime acceptance remain explicit. The parse repair does not waive the original historical failure or redefine the 32-case experiment. Prepared landing bookkeeping remains conditional on actual acceptance and merge.
- **25/25 correctness/integrity/access:** The strict single-Enter composition guard, raw semantics, fallback/ownership controls and access boundaries are unchanged from the reviewed complete implementation. The converter path is now valid in both the setup shell and subsequent steps. The change introduces no runtime or data behavior.
- **18/20 meaningful verification:** Actionlint now detects the actual original expression defect and accepts the repaired workflow, supplementing rather than misrepresenting the prior TypeScript/lint controls. Two points remain deducted for unperformed actual Linux process/trace/GC integration and clean final-source application verification. Historical green runs and synthetic tests are not substituted for those obligations.
- **10/10 CI/operations:** The reachable event is explicitly the one same-repository owning-branch synchronization away from published `7e041c0c`; rerun attempts are rejected before installation. The same budgets, watchdogs, strict trace requirements and partial-evidence retention remain. Cancellations and their fail-closed aggregate consequences are retained accurately.
- **10/10 maintainability/process/over-complexity:** The repair adds two shell lines and changes the transition anchor; it adds no abstraction, dependency, general retry machinery or speculative scope. The existing diagnostic support remains justified by the full XL outcome. Documentation candidly preserves the source-review miss and first failure. No actionable unnecessary complexity was found.

## 🛠️ Concrete repair verified

`DOC_TRACE_PROCESSOR_PATH` is removed from job-level `env`, where `runner` is unavailable. The setup step now exports `"$RUNNER_TEMP/spn146-trace-processor"` for its own installer and writes the same value through `$GITHUB_ENV` for later steps. This fixes both expression placement and same-step versus later-step environment availability.

The workflow hash independently computed from this head is **`19fcb1724520ac143747c0537c05abae3632ea9a9eeb02a983d4c73c0989a4da`**, matching the repair manifest. Retained actionlint results show original status 1 with the specific unavailable `runner` context error, repaired status 0, and no output errors. The validation watchdog reports **605 ms / 171,088 KiB**, normal pressure. Shellcheck/pyflakes integrations were disabled; neither the source nor this review claims they ran.

The official context restriction was missed by my previous 98/100 review. That review remains a historical assessment with a subsequently discovered blocker, not proof the rejected workflow was valid. This exact repair is assessed with the new negative evidence; it does not erase the miss.

## 📁 Failure and cancellation reconciliation

Independently read the retained jobs response for parse run **42004830910**: `total_count:0`, `jobs:[]`. The run failed on exact `7e041c0c` before setup or component observations. It is a failed workflow preparation, not a cancelled or successful runtime diagnostic.

All four superseded run records are terminal cancelled and every listed job is completed:

- Metadata CI **42004793620**, source `1eeb90f1`: 16 jobs, including three failed applicability/aggregate jobs.
- Application CI **42004840062**, source `7e041c0c`: 33 jobs; two failed aggregates require selected unit/lib work that was cancelled.
- Storybook **42004839728**, source `7e041c0c`: eight jobs; failed aggregate receives cancelled build/desktop/tablet/mobile results.
- Native **42004839916**, source `7e041c0c`: three cancelled jobs.

The six retained failure logs substantiate cancelled classification or cancelled selected work; I did not relabel them as passing gates or claim an application assertion failed. The new 33-payload manifest preserves those receipts, original reviews/proof and workflow validation. I read critical payloads and checked the current workflow hash; I did not repeat a complete 33-payload hash scan. The previous independent 159-payload/source proof remains applicable to its unchanged evidence groups, with its exact scope and original source identity retained.

## 👥 Personas and acceptance limits

Owner and Collaborator retain exact native output, history, publication ordering and peer content requirements. Link guest access/revocation owners remain independent. Operator benefits from a valid, finite lane with durable failure and cleanup evidence; no automatic retry is added. The prior scope/complexity assessment of the unchanged production guard and diagnostic source remains substantiated by the full review, not by a desired score.

The Linux allowance is explicitly repaired before its first job; reanchoring it does not permit a later measured failure to renew the experiment. Same inputs/native/Core bytes, both fixed orders, all 16 comparisons meeting **both ≥20% and ≥1 ms**, complete trace/GC/clock/source evidence, raw semantic parity, journals and resource/cleanup limits remain mandatory. Any failed or inconclusive runtime result remains failed/pending without automatic rerun or threshold change.

Fresh selected CI and all seven gates must pass this actual final source. The eventual component result needs independent raw audit and an honest causal disposition; it cannot reconstruct historical missing traces or replace full unprofiled application acceptance. No old pass or cancellation grants current-head acceptance. **Source review qualifies this narrow repair for publication; hosted outcome, final evidence and merge readiness remain pending.**

</details>

<details>
<summary>Independent reviewer B — exact repair assessment</summary>

# 🔬 SPN-146 exact-head parse-repair review B

**Candidate:** `483bf8ae4609fa8027485293e6050fe8dca88e1c`  
**Tree:** `02fe8769b8b3b6568fd9356cfd7adf6d661654d1`  
**Base/original ticket:** `2f442317dd2e1c188ae4a810ac094fd1162a4a2a`  
**Reviewer:** independent nonimplementing agent B, 2026-11-05.

**97/100. No unresolved source blocker.** This complete candidate is ready for the explicitly revised single validation push if the other independent exact-head review also qualifies. It is not ready to merge: the first Linux component execution, supported causal disposition and fresh selected current-head CI remain pending.

## Verified change and failure disposition

The working tree is clean. Relative to the rejected `7e041c0c` source, the only functional delta is the workflow environment initialization and exact predecessor anchor. All TypeScript implementation, tests, runtime/analyzer/watchdog, application/native source, dependencies and normal CI wiring are byte-identical. I reuse the earlier full-base-diff source inspection and applicable checks only on that verified basis; the older numerical approval is not itself evidence of this head's correctness.

Run `42004830910` has an empty jobs array and `total_count: 0`; the retained run view identifies a workflow-file failure. No runner setup or component observation occurred. The precise unsupported `runner` context is independently reproduced by the retained actionlint negative. GitHub's current context table excludes `runner` from `jobs.<job_id>.env` and allows it at step execution. I checked the primary [GitHub context-availability reference](https://docs.github.com/en/actions/reference/workflows-and-actions/contexts#context-availability). This workflow parse defect was missed in my prior pre-push review. That review and the failed run remain retained; neither is rewritten into a successful validation.

The repair removes the illegal job-level expression. The setup shell exports `DOC_TRACE_PROCESSOR_PATH` from the runner's `RUNNER_TEMP` for commands in that same step and appends it to `GITHUB_ENV` for later conversion. This preserves the pinned converter's purpose and path ownership without introducing another download or in-observation setup step. The workflow SHA matches the new manifest (`19fcb1724520ac143747c0537c05abae3632ea9a9eeb02a983d4c73c0989a4da`).

The retained official actionlint 1.7.12 validation rejects the original source with the specific unavailable-context diagnostic and accepts the repaired workflow. Its receipt records 605 ms, 171,088 KiB and normal pressure. Shellcheck/pyflakes integrations were disabled, so this is a workflow syntax/context check, not a shell or runtime acceptance claim. I inspected the validation source/output and did not rerun it.

Reanchoring `github.event.before` to the actually published `7e041c0c7c84bc28c56aeff1bda35b2a93654114` is a documented preparation repair before any Linux job. It is not permission to repeat measured observations. The same repository/branch restriction, reviewed-head checkout, attempt-1 guard, 32 fixed observations, 16 per-pair thresholds, trace/clock/GC requirements and resource/deadline bounds remain unchanged. Later ordinary pushes and PR edits cannot renew the route. Any eventual executed result must be retained and interpreted under the existing stop conditions.

I also read the four superseded/metadata run and job receipts: `42004793620`, `42004840062`, `42004839728` and `42004839916` are all completed/cancelled, and every listed job is terminal. The six retained failed job logs show cancelled classification, cancelled selected unit/lib work, or cancelled Storybook build/viewports. These failures correctly prevent acceptance; they are not a compiler or application regression diagnosis and are not green gates. The prior ordinary/native source has no partial acceptance credit carried into this candidate.

## Independent rubric

- **35/35 — scope and acceptance.** The full XL ticket still owns a causal repair or supported measurement disposition, unchanged mobile maximum/p95 limits, exact native workload, content/history/access and cleanup. The narrow Enter-tail algorithm and semantic controls remain unchanged. The failed original diagnostic, resource-aborted Mac experiment and zero-job workflow failure are explicitly retained. No historical pause is called noise, no count reduction is equated with elapsed time, and no later green application run is substituted for cause evidence.
- **25/25 — correctness, data integrity and access.** The prior complete inspection of the strictly qualified redo-only structural boundary, plain-data guards, metadata/scope constraints, raw/current/upstream parity, applied snapshots, ownership and fallback call ordering remains applicable byte-for-byte. The environment repair supplies the same pinned converter path at the supported execution scope. Primary-failure preservation, terminal journal gating and independently checked watchdog receipts remain intact. No content, persistence or authorization behavior changes in this delta.
- **18/20 — meaningful regression protection and evidence.** Retained 202 manager controls, 44 trace controls and 24 component controls remain source-applicable; the original-fails/repaired-passes workflow negative directly detects the actual new failure. Deduct two points for still-missing guard-inclusive browser cost evidence and complete fresh source acceptance. The one declared hosted observation and selected current-head checks are the required next evidence, with no automatic rerun if they fail.
- **9/10 — CI and operations.** The actual parse blocker is repaired and the finite route is reachable before merge. Cancelled selected work remains failed closed. Broad file selection, paired harness identity and all normal gates are unchanged. Deduct one point because actual Linux process monitoring, complete collection/conversion and owned cleanup have not yet executed successfully. Syntax validation cannot fill that integration gap.
- **10/10 — maintainability, documentation, backlog and over-complexity.** The repair is minimal: supported shell initialization plus one durable environment export, with an explicit successor anchor and retained diagnosis. No new abstraction, dependency, generalized retry mechanism or expanded experiment is introduced. Prior full-scope maintainability judgment remains supported by unchanged files. Canonical decisions and conditional ticket deletion/dependency/completion/index bookkeeping are unchanged and remain contingent on accepted landing.

**Total: 97/100.** Deductions name missing evidence; none is waived by the pre-push grade. The now-fixed parse defect is not double-counted as an unresolved defect on this source.

## Persona and complexity assessment

Owner and Collaborator still require exact local/saved/peer content, native history and selection. Link guests retain existing mutation denial and revocation owners. Operator benefits from explicit failed-run/cancellation receipts, bounded one-time execution and no production service/dependency growth. The repair adds no visual state or UI scope; applicable existing rendering/interaction owners remain selected. The complete diagnostic is justified by the native boundary and uses shared transport/converter infrastructure rather than a second protocol implementation.

## Review limits and remaining gates

This was read-only review of the exact commit, full delta and retained evidence. No source edits, application tests, browser experiment, trace conversion or retry was performed. I did not repeat the full unchanged evidence-payload scan. The complete preceding review is preserved at `/tmp/spn146-linux-prepush-review-b.md` and in the new maintained evidence package, including the original missed workflow-context finding.

Before merge, require both qualifying exact-source reviews; the revised first Linux execution and its complete semantic/timing/clock/GC/trace/process evidence; an honest original-ticket causal disposition; fresh all-seven selected CI gates and required native/callback/responsiveness/Storybook acceptance; durable final source/tested/run/attempt/failure identities; and fresh base/head/review merge guards. Neither `1eeb90f1` green checks, `7e041c0c` cancelled checks nor the actionlint repair is current-head acceptance. No unchanged runtime rerun, threshold relaxation, larger buffer/budget or automatic environment renewal is authorized. Downstream SPN-141/140/120/089 remain dependent on accepted integration and their own fresh complete outcomes.

</details>



## 🚀 Remaining landing requirements

Both qualifying current-head grades, all seven current-head gates and selected native/Storybook/application checks, supported diagnostic disposition, no unresolved blockers and an up-to-date base. Pre-push grading does not certify pending hosted acceptance. After guarded squash merge, preserve unique evidence and remove obsolete ticket-created refs only after rechecking their heads and active PR ownership.
