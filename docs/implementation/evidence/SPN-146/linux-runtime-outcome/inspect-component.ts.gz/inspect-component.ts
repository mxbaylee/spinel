import {execFileSync} from 'node:child_process';
execFileSync('python3',['-c',`
from pathlib import Path
import json,zipfile,hashlib,gzip,collections
r=Path('/tmp/spn146-linux-hosted');p=r/'component-13405220484.zip'
assert p.stat().st_size==2365966
assert hashlib.sha256(p.read_bytes()).hexdigest()=='7242949d61d77c447c2eb2887af4d0c155fa2579b43d30874c3521e93faaee83'
d=r/'component';d.mkdir()
with zipfile.ZipFile(p) as z:
 assert sum(i.file_size for i in z.infolist())<128*1024**2
 for i in z.infolist():
  assert not Path(i.filename).is_absolute() and '..' not in Path(i.filename).parts
  z.extract(i,d)
obs=json.loads((d/'observation.json').read_text());trace=json.loads(gzip.decompress((d/'runtime.trace.json.gz').read_bytes()));analysis=json.loads((d/'analysis.json').read_text());conv=json.loads((d/'conversion.json').read_text())
events=trace['traceEvents'];gc=[dict(e,index=i) for i,e in enumerate(events) if 'gc' in e.get('name','').lower() or 'garbage' in e.get('name','').lower()]
summary={'observationComplete':obs['complete'],'count':len(obs['observation']['records']),'analysis':analysis,'conversionPassed':conv['passed'],'gcRepresentations':dict(collections.Counter((e.get('ph','')+' '+e.get('name','')) for e in gc)),'unsupportedExamples':[e for e in gc if e.get('ph') not in ['X','B','E']][:30]}
(r/'component-inspection.json').write_text(json.dumps(summary,indent=2)+'\\n')
print(json.dumps(summary,indent=2))
`],{stdio:'inherit'});
