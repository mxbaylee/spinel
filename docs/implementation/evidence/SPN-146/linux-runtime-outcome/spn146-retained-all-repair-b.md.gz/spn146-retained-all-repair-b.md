# ✅ SPN-146 retained-data repair admission B

**Revised plan SHA-256:** `6ab25d1b9c93c156181e26faee2b8e8fb654e90e4eda0e54f3d1a087045ccefa`  
**Repaired script SHA-256:** `89ca9c9dd728cdb13ce1ed355e400d4dd24f5ede0dc930f43413d1be7d2aea56`  
**Files:** `/tmp/spn146-linux-hosted/retained-plan.md` and `inspect-retained-all.ts`.

**Admitted for the one declared retained-data analysis under the existing serial 60-second, normal-pressure, two-GiB parent watchdog.** The prior identity-chain finding is closed. No further concrete static admission blocker was found. This is not an execution result, production-hypothesis approval, new browser/converter allowance or merge approval.

I reread the complete repaired script and revised plan and independently checked their current hashes. The conversion receipt is now fixed at 2,175 bytes and SHA-256 `7be7a92c566c40b74cbc1a5c90326d7958d4e61e3154d997fad6a0cf13fc9c4c`; the retained local receipt matches those values. The plan records its byte equality to the original artifact member. The script explicitly verifies receipt input and framing bytes/hash against the verified original protobuf, pins both stored and decoded derived JSON identities, and checks the actual derived bytes against them. This closes the previously unbound raw-to-derived association without another converter execution. I did not repeat the parent's original ZIP/member comparison.

The repair additionally checks the exact four cache sequence pairs, each completed record stage, finite GC-control times, expected control names and ordering after the final observation, and uniqueness of all 194 names. It preserves the existing fixed 32-case identities, 96 whole/history/collaboration windows, paired raw publication equality, finite/nested duration checks and single-renderer 0.25 ms clock bound.

The computation's limits remain appropriate: finite main-thread X-event overlap uses uncertainty-expanded windows and interval union to avoid nested double-counting. Instant/flow/other non-X records remain separately visible with no inferred duration or absence claim. The forced GC control remains outside measured cases. CPU output is aggregate observed sample-node/call-frame information only, with all negative deltas and startup-bracket uncertainty preserved; no sorting/reordering of samples, exact per-window CPU time or verified eval-source attribution is claimed. The original 16 pair values and unchanged criterion are retained, and the original failed/inconclusive disposition is fixed rather than recalculated into acceptance.

Exclusive report creation, primary-error preservation and a separate stderr persistence failure remain intact. The parent watchdog must enclose the complete script, including synchronous observation parsing, equality checks, decompression, serialization and publication. An internal elapsed check is not a substitute for that bound. A resource/schema/identity/clock/publication failure stops the allowance; there is no automatic replacement analysis. Original retained inputs remain immutable even if a hard kill prevents partial report publication.

Only static source/plan and small receipt/hash reads were performed in this revalidation. I did not execute the analysis, parse the 60 MiB observation or full trace, run tests, launch a browser/converter, or edit project/input files. The initial finding remains preserved in `/tmp/spn146-retained-all-admission-b.md`.

The eventual report must retain all cases and unknowns, its exact source/input/output identities and watchdog/log. It can support a next discriminating question, but cannot turn the original eight passing pairs, three smaller improvements and five slower pairs into a positive experiment or establish historical pause causality. SPN-146 acceptance remains pending.
