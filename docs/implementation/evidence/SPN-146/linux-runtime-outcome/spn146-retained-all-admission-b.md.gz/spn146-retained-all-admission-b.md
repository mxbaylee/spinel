# 🔎 SPN-146 retained-data inspection — admission review B

**Plan:** `/tmp/spn146-linux-hosted/retained-plan.md`, SHA-256 `968c40b8fdd094f683a06c7cab5a73fc0a9ef8b6303574795bdd9698b1918990`  
**Initially reviewed script:** `/tmp/spn146-linux-hosted/inspect-retained-all.ts`, SHA-256 `c132ec9c1d7bd3e2a9e02f733b43abc578505e3f45db70d7eea46615ab6f91e5`  
**Original experiment:** source `483bf8ae4609fa8027485293e6050fe8dca88e1c`, run `42006109881`, job `127173148420`, artifact `13405220484`.

Independent static inspection only. No script execution, workload parsing, browser, converter, source edit or new timing observation was performed.

## Admission decision

The retained-only question and fixed bounds are appropriate and useful. **Hold execution of the initially reviewed script until the raw-to-derived identity gap below is repaired.** This is a source repair before the single analysis allowance is consumed, not permission to replace a failed executed analysis. The original Linux experiment remains failed and its fixed effect criterion inconclusive regardless of this diagnostic's outcome.

## Concrete finding

The script hash-pins observation.json and validates raw stored/decoded trace and profile against that observation. However, conversion.json is not itself hash-pinned, and neither conversion.input nor conversion.framing is compared with the verified raw protobuf identity. The derived stored/decoded hashes are checked only against this unbound receipt. Consequently, a wrong retained conversion receipt plus its matching derived file could be analyzed without demonstrating that it belongs to the exact original raw input. This falls short of the plan's explicit original artifact/input identity chain.

Bind the exact retained conversion receipt to a pinned artifact-member or independently recorded hash, assert its input and framing hash/byte values equal the verified raw protobuf, and pin the declared derived stored/decoded identities. These are static/file-identity repairs, not a need for another converter or browser run. The parent was notified before any admitted execution.

## Inspection of the proposed computation

The script reads only retained inputs and writes one new diagnostic report with exclusive creation. It fixes the original failed/inconclusive disposition rather than calling the old validator with loosened options. The 32-case format/cache/order/variant enumeration, paired raw publication equality, phase names and nesting, numeric mark boundaries and duration consistency are checked. All 194 returned marks must resolve once on a single renderer thread with the original 0.25 ms offset-spread bound. All original 16 pair values and criterion evaluations are retained; there is no averaging or omission.

For each of the 96 whole/history/collaboration windows, the script expands the trace interval by the retained clock uncertainty. It records all matching finite X-duration GC-related events and their clipped interval union, avoiding double-counting nested durations. Those values are descriptive uncertainty-expanded overlap, not exact stop-the-world pause time, and must not be subtracted from the original measured flushes. Main-thread filtering is explicit; it does not measure all background GC work.

Non-X records are retained in a separate complete inventory; matching point indexes are attached to each window without manufacturing durations. The forced GC control is collected separately from the measured observations. Unsupported forms remain visible and there is no absence-of-GC or complete-pause attribution claim. This is a useful diagnostic treatment of retained representations, not retroactive acceptance of the old analysis failure.

CPU output deliberately ranks counts by observed sample-node ID and preserves the original call frame, script ID and locations. It retains negative deltas and the profiler startup bracket. It does not reconstruct per-window timestamps, reorder samples or interpret a name as verified dynamic source identity. Counts cover the complete captured profile, including setup, measured work, serialization and GC control; they are not qualifier milliseconds or a production causal allocation. Missing eval-source mapping remains a material limitation. Aggregate counts may guide a next discriminating question, not prove that a proposed guard simplification would improve runtime.

The report preserves an original failure if report writing fails and records the secondary persistence error to stderr. Exclusive report creation prevents overwriting a prior result. Original input artifacts remain available even if a hard resource kill prevents partial output. The script's internal elapsed check is supplementary: synchronous JSON parsing, equality checks, decompression and output serialization require the declared parent watchdog for the actual 60-second/two-GiB/normal-pressure bound. The 60 MiB observation must not be described as a tiny metadata-only read; no expansion of the allowance follows if its parse/compare cost fails that bound.

## Conditions after repair

Revalidate the repaired script identity before the single serial/watchdog execution. Retain exact plan/script/input/output hashes, watchdog/log, every pair and all unknown/unattributed forms. Stop on first identity/schema/clock/resource/persistence failure with no automatic replacement analysis. A completed diagnostic may identify a relevant operation or unresolved source/clock limit; it cannot by itself admit a new production hypothesis, authorize another native experiment or close SPN-146. Original analysis failure, eight criterion passes/three smaller improvements/five slower comparisons and all pending application/current-head acceptance remain intact.
