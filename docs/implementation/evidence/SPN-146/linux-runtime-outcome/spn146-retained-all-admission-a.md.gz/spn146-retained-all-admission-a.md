# 🔎 SPN-146 retained-only analysis — admission A

**The question, scope and non-reclassification rules are appropriate. Execution admission is pending a small input-binding repair and the declared identity checks identified below.** No trace/profile/observation parsing or native/browser/converter execution was performed by this reviewer.

Independently verified the supplied small-file SHA-256 identities: plan `968c40b8fdd094f683a06c7cab5a73fc0a9ef8b6303574795bdd9698b1918990`; script `c132ec9c1d7bd3e2a9e02f733b43abc578505e3f45db70d7eea46615ab6f91e5`. This is static review of those exact prepared bytes, not a runtime result or source grade.

## 🛠️ Before execution

1. **Bind the original conversion receipt independently.** The script hard-pins the observation and verifies raw stored/decoded protobuf against its receipt, but accepts `conversion.json` without checking that receipt's bytes against the retained artifact/member identity. The derived trace hashes then come solely from that unbound JSON. Pin or verify the original conversion receipt bytes using the retained member proof, and assert its input/framing bytes and SHA-256 equal the already verified raw protobuf. The derived output may then be checked against that bound receipt. This requires no converter execution and avoids claiming an exact raw-to-derived provenance chain that the current script does not independently enforce.
2. **Complete the declared fixed identity/control checks.** Add each case's expected sequence pair (`544:[32,33]`, `672:[40,41]`, `1440:[88,89]`, `1984:[122,123]`). Check GC-control marker names, finite times, start/end order and placement after the last measured interval, and require 194 distinct mark names. These are inexpensive checks matching the declared plan; the currently pinned observation limits substitution risk, but the analysis should not claim it checked predicates omitted from its code.

Preserve these original preparation bytes and bind the repaired script before the one execution. No repeated experiment or allowance renewal is implied.

## ✅ Supported analysis design

All 32 cases and 96 intervals are retained with original raw durations, both formats/orders, paired publication equality, phase ordering/nesting and the original effect comparisons. The code does not discard misses, average them away, subtract GC or turn this failed/inconclusive original result into a positive outcome. Original precision is preserved rather than relying on the rounded first inspection.

The trace windows are expanded by the measured min/max marker offsets. Known main-thread GC `X` intervals are clipped to each expanded window and unioned, preventing nested double-counting. The union is explicitly descriptive within the expanded uncertainty interval; it is not exact elapsed GC time and could exceed the unexpanded measured duration. Instant/linkage/other forms remain in the nonduration inventory and per-window point references. That is appropriate for this diagnostic report, provided neither a zero known-X union nor missing point is described as absence of pauses. Background or unmatched flow effects remain unknown.

The forced-GC control remains separate from all measured cases and requires a positive known interval inside the uncertainty interior. This retained-only reader deliberately does not repair/reclassify the original acceptance analyzer; its distinct scope and original failure remain visible.

CPU work is restricted to hash-bound node/sample consistency, negative-delta diagnostics, original clock bracket and aggregate observed node/call-frame counts. It does not reorder sample time, construct a per-window timeline, convert counts into milliseconds, prove eval-source identity from names, or attribute a mixed timing outcome to a particular function. Ranking node counts is an inventory ordering, not temporal sample reordering. Setup, preparation, serialization and control contributions remain in the aggregate and prevent treating these counts as measured qualifier cost.

## 🧹 Bounds, persistence and interpretation

The plan requires one serialized normal-pressure, 2-GiB, 60-second parent-watchdog execution. The script's final elapsed assertion is insufficient by itself against synchronous parsing, so the independently effective parent watchdog must wrap this exact repaired script as declared. The stored observation is about 62.7 MB; the fixed decoded protobuf/trace caps are 64/128 MiB. No input executes browser/native/converter commands.

A primary analysis failure is preserved if result creation fails; the result uses exclusive creation and failure is also logged. Hard process termination may prevent a final JSON and must remain represented by the watchdog/last retained files, not a fabricated complete report. Existing input files and original outcome receipts must remain unchanged.

This analysis can support a discriminating next hypothesis or show that retained data is insufficient. Aggregate anonymous function samples alone cannot justify a production change, explain JIT behavior or recover historical causes. Any subsequent implementation/runtime plan remains a separate explicit decision and review. **No heavy work is admitted until the concrete input/identity repairs above are read back.**
