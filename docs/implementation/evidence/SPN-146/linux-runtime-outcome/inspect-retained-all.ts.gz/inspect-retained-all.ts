import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
const root='/tmp/spn146-linux-hosted',dir=root+'/component';
const hash=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const report:any={diagnosticOnly:true,disposition:'Original analysis failed; original fixed effect criterion remains inconclusive.',complete:false,started:performance.now()};
let failure:unknown;
try{
 const rawObservation=await readFile(dir+'/observation.json'),o=JSON.parse(rawObservation.toString());
 assert.equal(hash(rawObservation),'16864ca6e286f9a0d04323ea7f511f3461a89fb71308a0ce8e64315d1d7f79f8');assert.equal(o.source,'483bf8ae4609fa8027485293e6050fe8dca88e1c');assert.equal(o.complete,true);assert.equal(o.trace.complete,true);
 const rawTrace=await readFile(dir+'/runtime.pftrace.gz');assert.equal(hash(rawTrace),o.trace.transport.sha256);assert.equal(rawTrace.length,o.trace.transport.bytes);
 const rawProto=gunzipSync(rawTrace,{maxOutputLength:64*1024**2});assert.equal(hash(rawProto),o.trace.transport.transport.sha256);assert.equal(rawProto.length,o.trace.transport.transport.bytes);
 const conversionBytes=await readFile(dir+'/conversion.json');assert.equal(conversionBytes.length,2175);assert.equal(hash(conversionBytes),'7be7a92c566c40b74cbc1a5c90326d7958d4e61e3154d997fad6a0cf13fc9c4c');const conversion=JSON.parse(conversionBytes.toString());assert.deepEqual(conversion.input,{bytes:rawProto.length,sha256:hash(rawProto)});assert.equal(conversion.framing.bytes,rawProto.length);assert.equal(conversion.framing.sha256,hash(rawProto));assert.deepEqual([conversion.output.bytes,conversion.output.sha256,conversion.output.decoded.bytes,conversion.output.decoded.sha256],[228871,'e14d443c234ce22b4315e59bc650495348da02d34007e22eca99351ed65b59b8',1607918,'695842e63a4ebfa242429955a29b6a8b7588740d1fa708f7ecdcd12366c57d0e']);assert.equal(conversion.passed,true);assert.equal(conversion.temporaryRemoved,true);
 const compressed=await readFile(dir+'/runtime.trace.json.gz');assert.equal(hash(compressed),conversion.output.sha256);assert.equal(compressed.length,conversion.output.bytes);
 const decoded=gunzipSync(compressed,{maxOutputLength:128*1024**2});assert.equal(hash(decoded),conversion.output.decoded.sha256);assert.equal(decoded.length,conversion.output.decoded.bytes);
 report.identities={observation:hash(rawObservation),rawProto:hash(rawProto),derivedTrace:hash(decoded)};
 const events=JSON.parse(decoded.toString()).traceEvents.map((e:any,index:number)=>({...e,index}));assert.ok(Array.isArray(events));
 const records=o.observation.records;assert.equal(records.length,32);assert.equal(o.observation.finished,true);
 const marks:any[]=[],windows:any[]=[];let index=0;
 for(const format of ['es','cjs'])for(const completed of [544,672,1440,1984])for(const order of ['prior-candidate','candidate-prior'])for(const variant of order.split('-')){
  const r=records[index];assert.deepEqual([r.id,r.format,r.completed,r.order,r.variant],[index,format,completed,order,variant]);assert.deepEqual(r.sequences,({544:[32,33],672:[40,41],1440:[88,89],1984:[122,123]} as Record<number,number[]>)[completed]);assert.equal(r.stage,'complete');assert.equal(r.passed,true);assert.equal(r.cleanup,true);assert.equal(r.pairParity,true);assert.deepEqual(r.phases.map((p:any)=>p.phase),['history','collaboration']);
  const[h,c]=r.phases;assert.ok(r.began<=h.first.time&&h.last.time<=c.first.time&&c.last.time<=r.ended);
  for(const range of [{...r,phase:'whole'},...r.phases]){
   assert.ok([range.first.time,range.began,range.ended,range.last.time,range.durationMs].every(Number.isFinite));assert.ok(range.first.time<=range.began&&range.began<=range.ended&&range.ended<=range.last.time);assert.ok(Math.abs(range.durationMs-(range.ended-range.began))<1e-7);
   const label=`spn146-runtime-${index}${range.phase==='whole'?'':'-'+range.phase}`;assert.equal(range.first.name,label+'-start');assert.equal(range.last.name,label+'-end');
   marks.push(range.first,range.last);windows.push({id:index,format,completed,variant,order,phase:range.phase,began:range.began,ended:range.ended,durationMs:range.durationMs});
  }
  if(index%2===1)assert.deepEqual(records[index-1].output,r.output);index++;
 }
 assert.equal(o.gcControl.gcStart.name,'spn146-runtime-gc-control-start');assert.equal(o.gcControl.gcEnd.name,'spn146-runtime-gc-control-end');assert.ok(Number.isFinite(o.gcControl.gcStart.time)&&Number.isFinite(o.gcControl.gcEnd.time));assert.ok(records[31].last.time<=o.gcControl.gcStart.time&&o.gcControl.gcStart.time<o.gcControl.gcEnd.time);marks.push(o.gcControl.gcStart,o.gcControl.gcEnd);assert.equal(marks.length,194);assert.equal(new Set(marks.map(m=>m.name)).size,194);
 let renderer:any;const offsets:number[]=[];
 report.markers=marks.map(mark=>{const matches=events.filter((e:any)=>e.name===mark.name);assert.equal(matches.length,1);const e=matches[0];assert.ok(Number.isFinite(e.ts)&&Number.isSafeInteger(e.pid)&&Number.isSafeInteger(e.tid));assert.ok(e.cat.split(',').includes('blink.user_timing'));renderer??={pid:e.pid,tid:e.tid};assert.deepEqual({pid:e.pid,tid:e.tid},renderer);offsets.push(e.ts/1000-mark.time);return{...mark,eventIndex:e.index,traceTimeUs:e.ts};});
 const low=Math.min(...offsets),high=Math.max(...offsets);assert.ok(high-low<=.25);report.clock={renderer,offsetMinMs:low,offsetMaxMs:high,uncertaintyMs:high-low};
 const thread=events.filter((e:any)=>e.pid===renderer.pid&&e.tid===renderer.tid);
 const gc=thread.filter((e:any)=>e.cat?.split(',').includes('disabled-by-default-v8.gc')||/MajorGC|MinorGC|GarbageCollection/.test(e.name??''));
 const spans=gc.filter((e:any)=>e.ph==='X');assert.ok(spans.every((e:any)=>Number.isFinite(e.ts)&&Number.isFinite(e.dur)&&e.dur>=0));
 report.gcEventForms=Object.fromEntries([...new Set(gc.map((e:any)=>e.ph+' '+e.name))].map(key=>[String(key),gc.filter((e:any)=>e.ph+' '+e.name===key).length]));
 report.gcNondurationEvents=gc.filter((e:any)=>e.ph!=='X');
 const overlaps=(e:any,start:number,end:number)=>e.ts/1000<=end&&(e.ts+e.dur)/1000>=start;
 function union(input:number[][]){const sorted=input.toSorted((a,b)=>a[0]-b[0]);let start=-Infinity,end=-Infinity,total=0;for(const[a,b]of sorted){if(a>end){if(Number.isFinite(start))total+=end-start;start=a;end=b;}else end=Math.max(end,b);}if(Number.isFinite(start))total+=end-start;return total;}
 report.windows=windows.map(w=>{const start=w.began+low,end=w.ended+high,known=spans.filter((e:any)=>overlaps(e,start,end));return{...w,expandedTraceMs:{start,end},observedGcDurationUnionMs:union(known.map((e:any)=>[Math.max(start,e.ts/1000),Math.min(end,(e.ts+e.dur)/1000)])),observedGcSpans:known.map((e:any)=>({index:e.index,name:e.name,ts:e.ts,dur:e.dur})),gcNondurationPoints:report.gcNondurationEvents.filter((e:any)=>Number.isFinite(e.ts)&&e.ts/1000>=start&&e.ts/1000<=end).map((e:any)=>e.index)};});
 report.gcControl=spans.filter((e:any)=>e.dur>0&&e.ts/1000>=o.gcControl.gcStart.time+high&&(e.ts+e.dur)/1000<=o.gcControl.gcEnd.time+low).map((e:any)=>({index:e.index,name:e.name,ts:e.ts,dur:e.dur}));
 assert.ok(report.gcControl.length>0);
 report.comparisons=[];for(let i=0;i<32;i+=2){const pair=records.slice(i,i+2),p=pair.find((r:any)=>r.variant==='prior'),c=pair.find((r:any)=>r.variant==='candidate'),delta=p.durationMs-c.durationMs;report.comparisons.push({ids:[i,i+1],priorMs:p.durationMs,candidateMs:c.durationMs,reductionMs:delta,reductionFraction:delta/p.durationMs,meetsOriginalCriterion:delta>=1&&delta/p.durationMs>=.2});}
 const profileBytes=await readFile(dir+'/runtime.cpuprofile');assert.equal(hash(profileBytes),o.profileSha256);const profile=JSON.parse(profileBytes.toString());assert.equal(profile.samples.length,profile.timeDeltas.length);assert.ok(profile.timeDeltas.every(Number.isFinite));
 const nodes=new Map<number,any>(profile.nodes.map((n:any)=>[n.id,n]));assert.equal(nodes.size,profile.nodes.length);assert.ok(profile.samples.every((id:number)=>nodes.has(id)));
 const counts=new Map<number,number>();for(const id of profile.samples)counts.set(id,(counts.get(id)??0)+1);
 const ranked=[...counts].map(([id,samples])=>({id,samples,callFrame:nodes.get(id).callFrame})).toSorted((a,b)=>b.samples-a.samples);
 report.profile={sha256:hash(profileBytes),samples:profile.samples.length,nodes:profile.nodes.length,negativeDeltas:profile.timeDeltas.flatMap((d:number,i:number)=>d<0?[{index:i,value:d}]:[]),startTime:profile.startTime,endTime:profile.endTime,startBracket:o.profilerBracket,startBracketMs:o.profilerBracket.after-o.profilerBracket.before,rankedSymbols:ranked,limits:'Sample counts only, across setup/measurement/serialization/control. No sample reordering, exact per-window duration, verified eval-source mapping or source-causal allocation.'};
 report.limits='GC X overlap is descriptive union in an uncertainty-expanded interval. Instant statistics/flow links have no inferred duration; no absence-of-GC or complete pause attribution. No pauses subtracted and no original result reclassified.';
 assert.ok(performance.now()-report.started<60_000);report.complete=true;
}catch(error){failure=error;report.failure=String(error);}
finally{report.elapsedMs=performance.now()-report.started;try{await writeFile(root+'/retained-all-result.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});}catch(error){report.persistenceFailure=String(error);failure??=error;console.error(JSON.stringify({failure:String(failure),persistenceFailure:report.persistenceFailure}));}}
if(failure)throw failure;
console.log(JSON.stringify({complete:true,windows:report.windows.length,marks:report.markers.length,criterionMet:report.comparisons.filter((p:any)=>p.meetsOriginalCriterion).length,profileNegativeDeltas:report.profile.negativeDeltas.length,elapsedMs:report.elapsedMs}));
