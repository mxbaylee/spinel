# 🔎 SPN-146 retained result and next code question — review A

**The retained inspection is useful and complete within its declared limits. It supports investigating demonstrably duplicated qualification work; it does not establish that this work caused the five slower comparisons or justify weakening the safety guard. The original experiment remains inconclusive.** No source edits, browser/native/converter execution or heavy event/profile reparse were performed by this reviewer.

## 📋 Observed result

Read `/tmp/spn146-linux-hosted/retained-all-result.json`, its log, and the current guard/composition source. The retained execution completed in **233.529 ms**, with parent watchdog **476 ms / 340,592 KiB**, normal pressure. It reports all **96 windows**, **194 marks**, a single renderer/thread and clock-offset spread **0.189 ms**, and still **8/16** comparisons satisfying the original criterion. The original analyzer failure is not overwritten.

Known GC-X overlap is real descriptive evidence, not a complete pause explanation. For example, ES1440's first prior case contains about 23.299 ms of known-X union within its expanded 45.8-ms interval, while its paired candidate has no recognized X overlap. Conversely, CJS672 and CJS1440 are slower in both orders despite no recognized main-thread GC-X overlap in those eight windows. The latter contradicts a claim that *every* miss is explained by the recognized GC spans, but does not establish absence of other pauses, JIT effects, scheduling or instrumentation effects. Nothing is subtracted from original elapsed times.

The CPU report contains 8,258 samples, 1,873 nodes, 80 negative deltas and a 700.1-ms startup bracket. `isPlainDocDeleteData` has observed self-sample counts associated with script IDs/locations resembling the candidate/prior implementations. URLs are empty and exact dynamic-source identity is not established. These are aggregate sample clues across preparation/measurement/serialization/control, not measured qualifier duration, per-window evidence or proof of why a case slowed down. No exact-source conclusion should be attached to script 24/26 versus 23/25 without additional retained binding evidence.

## 🔬 What source inspection actually proves

On an admitted single-Enter path:

- The outer composition call already scans its leading insert prefix.
- `canComposeDocParagraphTail` performs the descriptor/plain-data walk, checks the Enter and surrounding metadata, qualifies the full final plain-insert run, and verifies offsets/unit/segment consistency.
- It then calls `composeDocStateActions` recursively on the head and tail. Those calls repeat delete/prefix qualification before composing data already proved admissible by the enclosing successful predicate.

That is a concrete redundant-work question independent of uncertain CPU attribution. However, **the whole-graph `isPlainDocDeleteData(states)` walk is not recursively repeated on the admitted head and tail**: the head has only its final unsupported Enter left, so the `remaining > 4` condition is false; the tail is entirely plain. The recursive children still perform their ordinary delete/insert qualification. Do not conflate the repeated shape scans with multiple complete enclosing graph walks.

The one enclosing graph walk has a stronger role than an incidental redundant check: it rejects accessors, foreign prototypes, symbols and unsupported nested values before new field reads. Dropping it or narrowing it to a few convenient fields would change the admissibility/observable-read contract and needs a separate proof. The current evidence does not justify doing so.

## 🛠️ A defensible next finite question

A narrowly scoped offline semantic/work experiment is supportable in principle: **after the unchanged complete predicate succeeds, can composition consume the already established prefix/tail facts without recursively requalifying them, while retaining exactly the current primitive composition tree, operand order, raw result and ownership?** This targets demonstrable duplication rather than declaring sampled names a measured root cause.

Before a production repair, record a finite counterfactual using the existing actual-manager fixture, exact current native/Core bytes and retained cases. A private qualified composition path must only be reachable after the full current guard succeeds; it must not become a public bypass flag, global shape cache, or stale memoization scheme.

Required semantic boundaries include:

- Prefix 0/1/2/3 and the existing tiny-partial-tree rule. In particular, a head containing an Enter cannot simply return a raw action where the current null-accumulator native fold clones/composes it. Preserve `compose(null, action)` behavior, raw fields and ownership.
- Exactly four tail states versus the currently unsupported shorter tail; every Enter position, COVER/REPLACE mode, absent/undefined/empty metadata and same-unit/segment qualification. Full plain groups, delete paths, multiple structural tokens and unsupported later islands keep their original route.
- Exact JSONX/TextX primitive call order and operand identities/values on admitted cases, not only final applied text. Qualification removal should leave the current composition tree/work intact; the reduction should be specifically counted qualification/descriptor visits, independently measured with an exact old-source negative.
- Raw publications, non-null accumulator equivalence, source descriptor/prototype/ownership preservation and result nonaliasing; all existing malformed/accessor fallback call/read-order negatives remain relevant. No assumption that text equality proves raw metadata or mutation equivalence.
- The four actual hosted cache pairs in both formats alongside the existing meaningful boundary fixtures. Do not choose only the favorable Linux windows. Specify the fixed cases, stop conditions, bounds and which work counters exclude instrumentation overhead before execution.

A successful deterministic experiment would justify a small correctness-preserving implementation candidate and demonstrate reduced redundant guard work. It would **not** prove net native time improved, explain historical maxima, or retroactively satisfy the failed all-16 criterion. Any later source/runtime plan requires its own explicit review, unchanged product limits and fresh acceptance; this report does not authorize another runtime experiment.

## 🧭 Present disposition

Keep the result as: **actual component benefit is mixed; some intervals overlap known GC, aggregate symbols suggest a guard-work question, and source proves repeated qualification after an already successful predicate.** Investigating that exact duplication is justified. Claims that the whole-graph guard is unnecessary, the guard caused the slow cases, or JIT/GC fully explains the result are not supported.

The original XL outcome and final causal/acceptance disposition remain open. No production edit, grade or merge approval is supplied here; concrete finite experiment/source changes need their own inspection before execution or publication.
