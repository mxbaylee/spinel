import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
const root='/Users/mxbaylee/projects/spinel-spn-146',from='/tmp/spn146-linux-hosted',target=root+'/docs/implementation/evidence/SPN-146/linux-runtime-outcome';
const hash=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const zip=readFileSync(from+'/component-13405220484.zip');assert.equal(zip.length,2365966);assert.equal(hash(zip),'7242949d61d77c447c2eb2887af4d0c155fa2579b43d30874c3521e93faaee83');
const files=['component-13405220484.zip','component-artifacts.json','component-run.json','component-jobs.json','component-job.log','initial-identity.json','published-pr.json','spn146-linux-repair-pr-body.md','spn146-linux-repair-review-a.md','spn146-linux-repair-review-b.md','inspect-component.ts','component-inspection.json','component-inspection.log','component-inspection-watchdog.json','retained-observation-inspection.json','retained-plan.md','inspect-retained-all.ts','retained-all-result.json','retained-all.log','retained-all-watchdog.json'].map(n=>[n,from+'/'+n]);
for(const name of ['spn146-linux-outcome-a.md','spn146-linux-outcome-b.md','spn146-retained-all-admission-a.md','spn146-retained-all-admission-b.md','spn146-retained-all-repair-a.md','spn146-retained-all-repair-b.md','spn146-retained-result-a.md','spn146-retained-result-b.md','spn146-runtime-watchdog.ts','spn135-local-processes.ts'])files.push([name,'/tmp/'+name]);
files.push(['retain-linux-outcome.ts',import.meta.filename]);
mkdirSync(target);
const artifactMembers:any[]=[];
function members(dir:string,prefix=''){for(const e of readdirSync(dir,{withFileTypes:true})){const path=prefix+e.name;if(e.isDirectory())members(dir+'/'+e.name,path+'/');else {const b=readFileSync(dir+'/'+e.name);artifactMembers.push({path,bytes:b.length,sha256:hash(b)});}}}
members(from+'/component');
const payloads=files.map(([name,path])=>{const b=readFileSync(path),stored=gzipSync(b);writeFileSync(target+'/'+name+'.gz',stored,{flag:'wx'});return {name:name+'.gz',rawBytes:b.length,storedBytes:stored.length,rawSha256:hash(b),storedSha256:hash(stored)};});
writeFileSync(target+'/manifest.json',JSON.stringify({source:'483bf8ae4609fa8027485293e6050fe8dca88e1c',base:'2f442317dd2e1c188ae4a810ac094fd1162a4a2a',run:42006109881,job:127173148420,attempt:1,artifact:13405220484,artifactMembers,payloads,disposition:'All32 observations/strict full protobuf conversion complete; original analyzer FAILED Unsupported GC representation. Fixed effect criterion INCONCLUSIVE:8meet,3smallpositive,5slower. One retained-only inspection complete; no result reclassification, browser/converter retry or production acceptance. Application CI is separate and not concluded by this archive.'},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({payloads:payloads.length,artifactMembers:artifactMembers.length,storedBytes:payloads.reduce((n,p)=>n+p.storedBytes,0)}));
