# 🔎 One retained-data diagnostic inspection

Source483bf8ae; run42006109881/job127173148420/artifact13405220484. The actual
32-case experiment and conversion remain complete; original analysis FAILED and
timing-only outcome INCONCLUSIVE (8/16meet,3smallpositive,5slower). No result will
be reclassified by this inspection, and no criterion, sample, buffer or allowance
changes. No browser, native flush, converter or new measurement is permitted.

One serial60second/normal-pressure/2GiB process reads only retained bytes. Bind
observation/profile/raw+derivedtrace to original receipts and artifact member
identities. Inspect all32cases/96whole-phasewindows/194marks, exactfixedidentities,
phaseordering/nesting and0.25msmarkoffsetuncertainty. Report all16comparisons with
original raw times. For each window retain main-thread GC X-duration intersections
and their union (no nested double-counting); I/i statistics and s/f flow links
remain separately labelled duration-unknown/context observations, never zero-cost
pauses. No absence-of-GC or complete pause attribution claim is allowed. The raw
trace is unchanged; all unsupported forms remain listed. Retain the forcedGC
control's observed duration spans separately from all measured cases.

CPU profile has80negative deltas and a700.1ms start bracket. Do not sort/reorder
samples or assign exact per-window durations. Report sample/node/negative-delta
quality and aggregate observed call-frame symbols/script IDs/locations. Empty URLs
or missing exact eval-source mapping remain explicit; name-only counts are clues,
not measured qualification time. A complete raw trace may support known observed
GC overlap, but may not explain all interval cost or validate a new optimization.

Stop on first input-identity/schema/clock/resource error, preserve partial report
and original failure. No automatic replacement analysis. Independent review of
this concrete script precedes its single bounded execution. The purpose is to
identify a discriminating next code/hypothesis question, not obtain a passing
result from the old experiment.

Receipt binding repair: conversion.json is 2175 bytes, SHA256
7be7a92c566c40b74cbc1a5c90326d7958d4e61e3154d997fad6a0cf13fc9c4c,
verified byte-for-byte against conversion.json in original artifact13405220484 ZIP
7242949d61d77c447c2eb2887af4d0c155fa2579b43d30874c3521e93faaee83.
Its input/framing must match the verified raw protobuf; both derived stored and
decoded hashes/lengths are pinned independently in the script. Sequence pairs,
complete stages, GC-control names/order/finite times, and194unique names are checked.
