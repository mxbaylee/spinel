# 🔬 SPN-146 first Linux component outcome — review A

**The registered experiment is inconclusive, independently of the analyzer's unsupported-GC failure. A single bounded analysis of the already retained observations/trace/profile is a useful next investigation; it cannot turn this experiment into a positive result or authorize a browser/converter rerun.**

Read-only inspection of `/tmp/spn146-linux-hosted/retained-observation-inspection.json` and the retained `analysis.json`, `conversion.json` and `progress.json`. I did not parse the 62,733,039-byte observation payload, inflate/reparse the event trace, verify the complete artifact ZIP or run a workload in this review. Parent-supplied execution identity is source `483bf8ae4609fa8027485293e6050fe8dca88e1c`, Linux run **42006109881**, job **127173148420**, artifact **13405220484**, ZIP SHA-256 **7242949d61d77c447c2eb2887af4d0c155fa2579b43d30874c3521e93faaee83**. The distinction between reviewed raw receipts and the parent's extracted/hashed artifact proof remains explicit.

## 📋 Actual disposition

The retained terminal progress is passed with zero first/persistence failures and dropped events, ordered cleanup and terminal entries. It records all-observation collection followed by the post-observation GC control and raw trace collection. The conversion receipt reports pinned v59.1 Linux authority, complete 1,122,350-byte protobuf framing with 12,319 packets, successful conversion/query children, no reported error/data-loss statistics, closed children, no output-close failure, and removed temporary state. Those receipts support successful collection/conversion, not successful effect analysis.

Original `analysis.json` remains **complete:false, passed:false**, with `Unsupported GC representation`, after 454.553 ms. The retained inspection identifies GC-name matches including `I V8.GC_Heap_Stats` and `s`/`f` records, alongside duration intervals. The strict validator rejected representations it did not know how to attribute; this does not by itself mean raw trace loss, converter failure, or an application regression. It also does not permit treating those records as zero-time pauses or silently omitting them.

The 16 timing-only comparisons independently make a positive result impossible under the existing plan: **8 satisfy both thresholds; 3 improve by less than 20%; 5 are slower.** The small improvements are ES544 reverse order (2.0 ms, 7.5%), ES1440 reverse order (1.3 ms, 7.6%), and CJS544 reverse order (1.8 ms, 9.8%). Slower candidates are ES1984 reverse order (-2.0 ms), CJS672 in both orders (-0.9/-3.3 ms), and CJS1440 in both orders (-2.5/-4.3 ms). These are the retained inspection's rounded measurements; final characterization must preserve original precision.

This is mixed benefit, not the separately declared “all comparisons slower” contradiction category and not the required all-16 positive category. A corrected format reader cannot change these timings, discard the misses, pool formats/orders, subtract GC, warm up, choose a favorable subset, or relax the criterion. The original analyzer failure and timing outcome must both remain visible.

## 🔎 Admission of the next retained-data question

The proposed question is distinct and useful: **where in the complete existing 32 observations is time spent, and does the retained temporal/sample evidence support a specific qualification, composition, JIT or pause hypothesis that could justify a new production change?** The current result specifically refutes any assumption that fewer counted allocations automatically yield uniform guard-inclusive runtime improvement.

Preregister one bounded retained-data analysis before executing it, using exactly the already captured bytes. No browser, converter, new sample, workload reconstruction or automatic retry is needed. The plan should bind the input hashes, script identity, fixed output inventory and finite time/memory/stop conditions. Keep its product an investigative report rather than a replacement acceptance result.

A useful fixed output set is:

1. All 32 cases and all 96 whole/history/collaboration intervals, both orders/formats, original durations and original comparison outcomes. Reconcile all 194 mark identities, renderer/thread identities and clock offsets first; stop attribution if alignment is invalid.
2. A complete catalog of relevant GC representations, including bounded duration intervals, instantaneous records, linkage records, thread/process changes and unmatched/ambiguous records. Associate only directly supported duration intervals with the measured thread/time windows. Preserve unknowns separately; do not turn linkage elapsed time into a GC pause or infer absence from an unsupported record. Use pinned official format/export authority before assigning new semantics to event types.
3. Per-interval conservative GC overlap and any directly observed JIT/deoptimization records, including nesting/double-counting limitations. Keep original elapsed times intact. A phase that overlaps GC is not proved to be entirely GC cost, and missing recognized overlap does not exclude scheduler/runtime effects.
4. CPU-profile diagnostics before attribution: sample/node consistency, start/end and deltas, negative/reordered data, clock bracket/quantization uncertainty, dynamic-script/source identity and unresolved frames. Report inclusive versus exclusive counts separately; ambiguous boundary samples remain ambiguous. Sparse sampled frames cannot establish exact guard/composition milliseconds or prove a function did no work when no sample hit it.
5. A per-case hypothesis disposition with supporting and contradictory observations. A guard-cost hypothesis needs reproducible source-attributed evidence of the newly introduced qualifier on the relevant cases; a JIT hypothesis needs actual compile/deoptimization evidence or must remain an order-related conjecture. No production optimization is justified solely by the labels of slower cases.

The existing trace may or may not distinguish these alternatives. A useful analysis can conclude that current evidence is insufficient; its budget does not renew itself in that case. Do not extrapolate Linux component measurements to the entire historical uncaptured maxima, full application subscriber/rendering/transport cost, or physical devices.

## ⏳ Scope and readiness

The earlier deterministic native-work and semantic proofs remain valid within their own scope. Current source's ordinary application checks retain their own status and cannot replace the missing causal disposition. This experiment supplies real counterfactual observations, but not the registered uniform positive result. SPN-146 therefore remains unresolved; no merge approval or new grade is issued here.

A concrete new production hypothesis may become justified by the bounded retained analysis, with original cases and misses preserved. Any implementation or later runtime plan would require its own explicit scope/evidence decision and exact-head review; this report admits only the narrowly described retained-data investigation in principle, pending inspection of its concrete script/bounds. No execution allowance is silently renewed.
