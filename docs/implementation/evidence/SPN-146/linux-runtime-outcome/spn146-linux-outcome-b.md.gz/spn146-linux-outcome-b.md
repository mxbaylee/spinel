# 🔬 SPN-146 first Linux component outcome — independent disposition B

**Source:** `483bf8ae4609fa8027485293e6050fe8dca88e1c`  
**Base:** `2f442317dd2e1c188ae4a810ac094fd1162a4a2a`  
**Run / job / attempt:** `42006109881` / `127173148420` / 1  
**Retained artifact:** `13405220484`, ZIP `2365966` bytes; declared verified SHA-256 `7242949d61d77c447c2eb2887af4d0c155fa2579b43d30874c3521e93faaee83`. Evidence root `/tmp/spn146-linux-hosted/component/`.

## Disposition

**The executed Linux lane failed, and the registered runtime-benefit hypothesis is inconclusive independently of the analysis-format failure. SPN-146 remains unaccepted.** No unchanged rerun, extra samples, threshold adjustment, pause subtraction or production change is justified by this result alone.

The observation completed all 32 cases and retained complete transport/conversion evidence, but `analysis.json` is incomplete/passed:false with `Unsupported GC representation`. The run and job are completed/failure. The separate successful observation journal is not the final experiment outcome.

The retained all-pair timing summary shows exactly eight of sixteen comparisons meeting both thresholds, three improvements below 20%, and five candidate slowdowns. These are mixed effects under the fixed criterion, not consistent contradiction in every pair and not a positive result. Examples that cannot be averaged away include ES/1984 candidate-first (18.2 → 20.2 ms), both CJS/672 orders (21.6 → 22.5 and 18.4 → 21.7 ms), and both CJS/1440 orders (17.8 → 20.3 and 15.4 → 19.7 ms). ES/544 and ES/1440 also show large first-order improvements but only 7.5%/7.6% in the opposite order. These order/format differences identify useful questions; they do not themselves establish JIT, GC, guard overhead or statistical noise as their explanation. The summary values are rounded; a retained follow-up must preserve original exact values and all pair identities.

## Facts and limits independently read

I inspected run/job identities, the failed analysis and watchdog receipt, original transport/conversion receipts, terminal progress, the compact all-pair timing/representation inventory, and small CPU-profile metadata. I did not rerun a browser or converter, parse the full trace event stream, load the 60 MiB raw publication observation into memory, or repeat the parent's artifact-integrity verification. Artifact hash verification is therefore reported as retained parent evidence rather than a new independent all-byte audit.

- Observation progress ends passed, with no first/persistence failure or dropped events, and ordered stream close, fixture cleanup and terminal events. Its watchdog passes at 12,098.899 ms and 1,849,660 KiB peak. Preparation passes at 1,218.917 ms and 669,944 KiB. These are successful collection/resource observations, not proof of a positive cost effect.
- The collector reports complete uncompressed protobuf, dataLossOccurred:false, with raw 1,122,350 bytes/hash `509f294ccaf4be446cc3d9d66e5686520572f804078fc524bd789d95341d7da9`; gzip transport is separately identified. The converter receipt records pinned Perfetto v59.1 Linux authority, 12,319 framed packets, successful conversion/statistics children, temporary cleanup, and no nonzero error/data_loss rows. Derived decoded JSON is 1,607,918 bytes/hash `695842e63a4ebfa242429955a29b6a8b7588740d1fa708f7ecdcd12366c57d0e`.
- The analysis process exits failed after 454.553 ms; its parent reports failed at 572.494 ms with no resource-limit violation recorded. This is a validator rejection, not a new resource abort.
- The selected GC-name inventory includes instant `V8.GC_Heap_Stats` and `s`/`f` flow-link records alongside explicit X-duration events. The original strict validator rejects those representations. Their presence does not imply trace corruption, missing packets or overflow. Nor do names/flow-link elapsed distances by themselves establish stop-the-world pause duration.
- The CPU profile contains 1,873 nodes, 8,258 samples and 8,258 deltas, including **80 negative deltas**. Start/end metadata are retained, but no phase attribution or sample-order correction has been established. Naïve cumulative timestamps, absolute-valued deltas, sorting or deleting negative samples would not be justified.

## Narrow next retained-data question

A single preregistered, bounded analysis of the already retained observation/derived JSON/profile is useful: **where do the actual observed whole/history/collaboration intervals overlap known main-thread GC durations or sampled qualifier/composition work, and what remains unresolved?** It must be explicitly diagnostic and must not rerun or reinterpret the old acceptance validator into a pass.

Use the original artifact/source/input hashes and existing converter output; verify input identities without another conversion. One coordinated serial/watchdog process with a fixed 60-second/two-GiB ceiling is an appropriate prospective bound. Retain its analysis source/hash, complete raw outputs, first failure and limit receipt. No production edit or additional browser/converter execution is admitted by this proposal.

Required outputs and boundaries:

1. Preserve all 32 observations, 16 exact original comparisons and 96 whole/history/collaboration intervals in fixed order. Keep fixture/format/cache/order identities and original duration values. Validate marks, renderer/thread identity and the already declared clock uncertainty before assigning overlap. Keep the original failed analysis separately immutable.
2. For finite-duration main-thread X events, show exact source-event indexes, names/categories, interval bounds, overlap with each measured phase, and uncertainty at its endpoints. Avoid double-counting nested MajorGC/MinorGC/V8 subevents: retain both raw intervals and their interval union when describing occupied time. Distinguish background-thread work from synchronous main-thread intervals. GC-related subevents are not automatically all stop-the-world pauses.
3. Inventory instant and flow records separately and preserve their original fields. Unknown duration remains unknown; a flow edge is a causal/context link, not the duration of a pause. Missing or unsupported forms must not become zero GC or proof of absence. Any new classification needs explicit source authority and bounded negative controls. If B/E reconstruction is used, require sound endpoint/thread/order matching; do not silently manufacture intervals.
4. Validate the CPU-profile clock, negative-delta behavior, startup bracket and consistency before assigning samples to any phase. If a sound monotonic mapping and uncertainty bound cannot be obtained from retained evidence, restrict output to source-bound aggregate sampled stacks plus explicit unattributed/ambiguous samples. Do not normalize away the 80 negative deltas. Report counts and intervals as observations, not exact CPU time or complete execution coverage.
5. Bind any qualifier/composition labels to the retained actual manager/bundle and generated/evaluated script identities, using call paths and line/source information where available. Names alone can collide across prior/candidate builds. Keep inclusive versus self sample counts distinct; do not sum parent and child stacks as independent work. If dynamic script mapping is unavailable, retain that uncertainty rather than claiming exact cost ownership.
6. Inspect retained compilation/optimization/deoptimization evidence only if the configured trace actually contains it. First-order differences are not evidence that JIT is responsible. All-case trace overlap and sample attribution can suggest a contributor; they cannot prove historical pause shares or a counterfactual improvement in the full application subscribers omitted by this component fixture.

Stop once these fixed retained-data questions are answered or the existing clocks/representations/source identities cannot support them. No new samples, altered timing thresholds, GC-time subtraction or subsequent automatic experiment follows. The original eight/three/five mixed criterion disposition remains unchanged regardless of how informative the new report becomes.

## Production-hypothesis admission

The current evidence proves a real semantic-equivalent reduction in counted repeated-copy work on relevant captured inputs, but it does **not** yet show that this reliably reduces guard-inclusive native elapsed cost across the registered matrix. A possible qualifier cost, compilation/order effect or runtime pause is a hypothesis, not a finding established by the present summary.

A new production hypothesis becomes reasonable only if the retained analysis isolates a concrete changeable operation or redundant guard traversal in the actual source, shows its relevance across all affected observations without selecting favorable samples, and explains what a lower-layer negative/counterfactual would discriminate while preserving the strict supported input boundary. For example, source-bound repeated qualifier samples could justify investigating duplicate validation work; they would not justify weakening plain-data/accessor/scope checks. If the data cannot distinguish those contributors, record the remaining causal obligation as inconclusive rather than choosing an optimization on timing patterns alone.

Fresh ordinary application CI remains a separate acceptance owner. Its eventual pass cannot retroactively waive this failed experiment or establish the old historical maxima's cause. No merge approval or new execution allowance is supplied by this report.
