// Modified for SPN-146: semantic falsification, not a production transformation.
const root='/Users/mxbaylee/projects/spinel-spn-146';
const hash=(b:string|Buffer)=>createHash('sha256').update(b).digest('hex');
const began=performance.now();const results:any[]=[];let failure:string|undefined;
const deadline=setTimeout(()=>{console.error('60 second deadline');process.exit(2);},60_000);
try{
 const bytes=gunzipSync(await readFile(root+'/docs/implementation/evidence/SPN-142/native-caches.json.gz'));
 assert.equal(hash(bytes),'714376723b3ef6a048796f7a1903a58181098960960cecb111e22e0594a2e7c8');
 const capture=decodeCapture(JSON.parse(bytes.toString()).captures[4]);
 for(const format of ['es','cjs'] as const){
  const {patched}=prepareDocsPatch(await readBuild(format),format);
  const json=format==='es'?'JSONX':'_univerjs_core.JSONX';
  const anchor='function composeDocStateActions(states, key) {';assert.equal(patched.split(anchor).length,2);
  const candidate=patched.replace(anchor,`
function composeDocStateActions(states,key) {
 if(key==='redoState') {
  const start=docInsertPrefixLength(states,key)+1;
  const tail=states.slice(start);
  if(tail.length>=4&&docInsertPrefixLength(tail,key)===tail.length)
   return ${json}.compose(composeOriginalDocStateActions(states.slice(0,start),key),composeOriginalDocStateActions(tail,key));
 }
 return composeOriginalDocStateActions(states,key);
}
function composeOriginalDocStateActions(states,key) {`);
  const control=measuredFlush(patched,capture.history,capture.collaboration,true);
  results.push({format,variant:'current',counts:control.counts,sha256:hash(patched)});
  const experimental=measuredFlush(candidate,capture.history,capture.collaboration,true);
  results.push({format,variant:'experimental',counts:experimental.counts,sha256:hash(candidate)});
  assert.deepEqual(experimental.output,control.output,`${format}: complete raw publication parity`);
  assert.ok(experimental.counts.allocations<control.counts.allocations,'reduced counted work');
  assert.ok(performance.now()-began<60_000);
 }
 assert.equal(results.length,4);
}catch(e){failure=e instanceof Error?e.stack:String(e);throw e;}
finally{
 clearTimeout(deadline);
 const result={diagnosticOnly:true,status:failure?'failed':'passed',failure,elapsedMs:performance.now()-began,results,coreSha256:hash(await readFile(new URL(import.meta.resolve('@univerjs/core')))),probeSha256:hash(await readFile('/tmp/spn146-investigation/tail.ts'))};
 await writeFile('/tmp/spn146-investigation/tail-results.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
}
