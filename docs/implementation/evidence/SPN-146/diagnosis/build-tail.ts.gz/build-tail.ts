import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const root='/Users/mxbaylee/projects/spinel-spn-146';
const test=readFileSync(root+'/scripts/dependencies/patch-univer-docs.test.ts','utf8');
let source=test.slice(0,test.indexOf("test('sequential style oracle"));assert.ok(source.length>10000);
source=source.replace("from './patch-univer-docs.ts'",`from '${root}/scripts/dependencies/patch-univer-docs.ts'`)
.replace("from '../../src/ui/nativeDocFlush.ts'",`from '${root}/src/ui/nativeDocFlush.ts'`)
.replace('`../../node_modules/@univerjs/docs/lib/${format}/index.js`','`file:///Users/mxbaylee/projects/spinel/node_modules/@univerjs/docs/lib/${format}/index.js`');
source+='\n'+readFileSync('/tmp/spn146-investigation/tail-body.ts','utf8');
writeFileSync('/tmp/spn146-investigation/tail.ts',source);
