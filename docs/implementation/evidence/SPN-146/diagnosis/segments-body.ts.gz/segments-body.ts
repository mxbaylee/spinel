// Modified for SPN-146: four flushes with per-composition work attribution.
const root='/Users/mxbaylee/projects/spinel-spn-146';
const hash=(x:string|Buffer)=>createHash('sha256').update(x).digest('hex');
const encode=(v:any):any=>v===undefined?{kind:'undefined'}:v===null||typeof v!=='object'?{kind:'value',value:v}:{kind:Array.isArray(v)?'array':'object',entries:Reflect.ownKeys(v).map(k=>{assert.equal(typeof k,'string');const d=Object.getOwnPropertyDescriptor(v,k)!;assert.ok('value' in d);return[k,encode(d.value)];})};
let activeCounts:Record<string,number>={}; let activePhase='none'; let phaseCounts:any[]=[];
const delta=(before:Record<string,number>)=>Object.fromEntries(Object.entries(activeCounts).map(([k,v])=>[k,v-before[k]]));
const began=performance.now(); const results:any[]=[]; const builds:any[]=[];
let failure:string|undefined; let pending:any;
const originalCompose=core.JSONX.compose;
const deadline=setTimeout(()=>{console.error('60 second deadline');process.exit(2);},60_000);
try {
 const bytes=gunzipSync(await readFile(root+'/docs/implementation/evidence/SPN-142/native-caches.json.gz'));
 assert.equal(hash(bytes),'714376723b3ef6a048796f7a1903a58181098960960cecb111e22e0594a2e7c8');
 const captures=JSON.parse(bytes.toString()).captures.map(decodeCapture);
 const first=JSON.parse(await readFile('/tmp/spn146-investigation/results.json','utf8'));
 for(const format of ['es','cjs'] as const){
  const installed=await readBuild(format); const prepared=prepareDocsPatch(installed,format);
  builds.push({format,installed:hash(installed),current:hash(prepared.patched)});
  for(const index of [0,4]){
   assert.ok(performance.now()-began<60_000);
   const capture=captures[index]; const calls:any[]=[]; phaseCounts=[];
   const identities=new WeakMap<object,any>();
   for(const phase of ['history','collaboration']) for(const [i,state] of capture[phase].entries())
    for(const side of ['redoState','undoState']) identities.set(state[side].actions,{side,indices:[i]});
   core.JSONX.compose=function(this:typeof core.JSONX,...args:Parameters<typeof originalCompose>){
    const left=args[0]&&identities.get(args[0]); const right=args[1]&&identities.get(args[1]);
    const input=args.map(encode); const before={...activeCounts};
    let result:any; let error:string|undefined;
    try { result=Reflect.apply(originalCompose,this,args); return result; }
    catch(e){error=String(e);throw e;}
    finally {
     const counts=delta(before);
     if(result&&typeof result==='object'&&(left||right)) identities.set(result,{side:right?.side??left?.side,indices:[...(left?.indices??[]),...(right?.indices??[])]});
     calls.push({phase:activePhase,left,right,counts,input,output:encode(result),error});
    }
   };
   pending={format,index,calls,phaseCounts};
   const measured=measuredFlush(prepared.patched,capture.history,capture.collaboration,true);
   core.JSONX.compose=originalCompose;
   const previous=first.results.find((r:any)=>r.format===format&&r.index===index&&r.variant==='patched');
   assert.deepEqual(measured.counts,previous.counts,'unchanged primitive totals');
   assert.equal(hash(JSON.stringify(measured.output)),previous.outputSha256,'retained output fingerprint');
   assert.deepEqual(phaseCounts.map(v=>v.phase),['history','collaboration']);
   results.push({...pending,counts:measured.counts,output:encode(measured.output)}); pending=undefined;
   assert.ok(performance.now()-began<60_000);
  }
 }
 assert.equal(results.length,4);
}catch(e){failure=String(e);throw e;}
finally{
 core.JSONX.compose=originalCompose;clearTimeout(deadline);
 const report={diagnosticOnly:true,status:failure?'failed':'passed',failure,elapsedMs:performance.now()-began,source:'2378020ab79915961de05d5d346be32ec524b23e',core:{url:import.meta.resolve('@univerjs/core'),sha256:hash(await readFile(new URL(import.meta.resolve('@univerjs/core'))))},fixtureSha256:hash(await readFile(root+'/scripts/dependencies/patch-univer-docs.test.ts')),patchSha256:hash(await readFile(root+'/scripts/dependencies/patch-univer-docs.ts')),probeSha256:hash(await readFile('/tmp/spn146-investigation/segments.ts')),builds,results,pending,limits:'Offline native manager with controlled endpoints; lossless shapes/counters perturb wall time; no historical failed-cache reconstruction or browser latency attribution.'};
 await writeFile('/tmp/spn146-investigation/segments-results.json',JSON.stringify(report)+'\n');
 console.log(JSON.stringify({status:report.status,flushes:results.length,elapsedMs:report.elapsedMs,core:report.core,rows:results.map(r=>({format:r.format,index:r.index,phases:r.phaseCounts,calls:r.calls.map((c:any)=>({phase:c.phase,left:c.left,right:c.right,counts:c.counts}))}))}));
}
