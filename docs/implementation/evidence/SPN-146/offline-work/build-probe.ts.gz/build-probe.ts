import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const root='/Users/mxbaylee/projects/spinel-spn-146';
const test=readFileSync(root+'/scripts/dependencies/patch-univer-docs.test.ts','utf8');
let source=test.slice(0,test.indexOf("test('sequential style oracle"));
assert.ok(source.length>10000);
source=source.replace("from './patch-univer-docs.ts'",`from '${root}/scripts/dependencies/patch-univer-docs.ts'`)
 .replace("from '../../src/ui/nativeDocFlush.ts'",`from '${root}/src/ui/nativeDocFlush.ts'`)
 .replace('`../../node_modules/@univerjs/docs/lib/${format}/index.js`','`file://'+root+'/node_modules/@univerjs/docs/lib/${format}/index.js`');
const anchor='  const fixture = managerFixture(source);';
assert.equal(source.split(anchor).length,2);
source=source.replace(anchor,anchor+`
  for (const [method,phase] of [['_pushHistory','history'],['_emitChangeState','collaboration']]) {
    const manager=fixture.manager as any;
    const original=manager[method]; assert.equal(typeof original,'function');
    manager[method]=function(...args:any[]) {
      const before={...activeCounts}; const startedAt=performance.now();
      try { return Reflect.apply(original,this,args); }
      finally { phases.push({phase,durationMs:performance.now()-startedAt,counts:Object.fromEntries(Object.entries(activeCounts).map(([key,value])=>[key,value-before[key]]))}); }
    };
  }
`);
source=source.replace("  const compose = core.TextX.compose;","  activeCounts=counts; phases=[];\n  const compose = core.TextX.compose;");
source=source.replace('return { output: flush(source, states, collaboration, raw), counts };','return { output: flush(source, states, collaboration, raw), counts, phases };');
source+='\n'+readFileSync('/tmp/spn146-investigation/probe-body.ts','utf8');
writeFileSync('/tmp/spn146-investigation/probe.ts',source);
