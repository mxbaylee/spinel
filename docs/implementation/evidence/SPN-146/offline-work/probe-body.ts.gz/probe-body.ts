// Modified for SPN-146: finite phase-specific work decomposition only.
let activeCounts:Record<string,number>={};
let phases:Array<{phase:string;durationMs:number;counts:Record<string,number>}>=[];
const root='/Users/mxbaylee/projects/spinel-spn-146';
const hash=(x:string|Buffer)=>createHash('sha256').update(x).digest('hex');
const began=performance.now();
const deadline=setTimeout(()=>{console.error('SPN-146 diagnostic exceeded 60 seconds');process.exit(2)},60_000);
const results:any[]=[];const builds:any[]=[];
let failure:string|undefined;
try {
 const raw=gunzipSync(await readFile(root+'/docs/implementation/evidence/SPN-142/native-caches.json.gz'));
 assert.equal(hash(raw),'714376723b3ef6a048796f7a1903a58181098960960cecb111e22e0594a2e7c8');
 const captures=JSON.parse(raw.toString()).captures.map(decodeCapture);assert.equal(captures.length,8);
 for(const format of ['es','cjs'] as const){
  const installed=await readBuild(format),prepared=prepareDocsPatch(installed,format);
  builds.push({format,installed:hash(installed),original:hash(prepared.original),current:hash(prepared.patched)});
  for(const [index,capture] of captures.entries()){
   assert.equal(capture.history.length,32);assert.equal(capture.collaboration.length,32);
   const pair:any[]=[];
   for(const variant of ['original','patched'] as const){
    assert.ok(performance.now()-began<60_000,'deadline before flush');
    const measured=measuredFlush(prepared[variant],capture.history,capture.collaboration,true);
    assert.deepEqual(measured.phases.map(v=>v.phase),['history','collaboration']);
    for(const value of measured.phases) assert.ok(Number.isFinite(value.durationMs)&&value.durationMs>=0);
    results.push({format,index,variant,outputSha256:hash(JSON.stringify(measured.output)),counts:measured.counts,phases:measured.phases});
    pair.push(measured);
    assert.ok(performance.now()-began<60_000,'deadline after flush');
   }
   assert.deepEqual(pair[1].output,pair[0].output,`${format}/${index}: complete raw publication parity`);
  }
 }
 assert.equal(results.length,32);
} catch(error){failure=String(error);throw error;}
finally {
 clearTimeout(deadline);
 const report={diagnosticOnly:true,source:'2f442317dd2e1c188ae4a810ac094fd1162a4a2a',preregistration:'ebbfd08f',status:failure?'failed':'passed',failure,elapsedMs:performance.now()-began,flushes:results.length,fixtureHash:hash(await readFile(root+'/scripts/dependencies/patch-univer-docs.test.ts')),patchHash:hash(await readFile(root+'/scripts/dependencies/patch-univer-docs.ts')),probeHash:hash(await readFile('/tmp/spn146-investigation/probe.ts')),builds,limits:'Single offline Node replay, no 4x browser throttle or real subscriber/renderer. Primitive counters and controlled endpoints perturb timing. No failed historical cache is reconstructed; no latency acceptance, runtime-pause attribution or production repair claim.',results};
 await writeFile('/tmp/spn146-investigation/results.json',JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({status:report.status,flushes:report.flushes,elapsedMs:report.elapsedMs,rows:results.map(r=>({format:r.format,index:r.index,variant:r.variant,counts:r.counts,phases:r.phases}))}));
}
