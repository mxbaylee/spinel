import {serialize} from 'node:v8';
import {realpath} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const matrixHash=(value:string|Buffer)=>createHash('sha256').update(value).digest('hex');
const selectedNames=[
 'every paragraph position preserves exact native output and reduces eligible prefix work',
 'REPLACE paragraph tails preserve the non-null accumulator and own their result',
 'unsupported paragraph bridges retain exact fallback calls and accessor reads',
 'admitted paragraph joins preserve absent, undefined and empty metadata',
 'following-retain and old-body variants preserve exact paragraph joins',
 'eligible keyboard shapes preserve odd tails, offsets and independent cache folds',
 'native idle, segment, remote and pre-Undo flush boundaries retain their ordering',
];
const selected:{name:string,work:()=>Promise<void>|void}[]=[];
function test(name:string,work:any){if(selectedNames.some(x=>name===`es: ${x}`||name===`cjs: ${x}`))selected.push({name,work});}
const matrixReport:any={diagnosticOnly:true,complete:false,tests:[],attemptedFlushes:0,completedFlushes:0,cleanupFailures:[],fixtureVariant:'Existing assertions; raw reference sinks; ES Core with ES/CJS manager regions',prepared:[]};
let recent:any[]=[];
function flush(source:string,history:State[],collaboration=history,raw=false){
 matrixReport.attemptedFlushes++;
 const input={history,collaboration};
 const capture:any={input,sourceSha256:matrixHash(source)};recent.push(capture);if(recent.length>3)recent.shift();
 try{const result=baseFlush(source,history,collaboration,raw);capture.output=result;matrixReport.completedFlushes++;return result;}
 catch(error){capture.failure=String(error);throw error;}
}
function linearTail(source:string,format:Format){
 const json=format==='es'?'JSONX':'_univerjs_core.JSONX',prefix=format==='es'?'':'_univerjs_core.';
 const before=`\t\treturn ${json}.compose(head, composeRange(prefix + 1, states.length));`;
 const after=`\t\tconst tail = new ${prefix}TextX();
\t\tconst firstEdits = states[prefix + 1][key].actions[1].e;
\t\tif (firstEdits.length === 2) tail.push(firstEdits[0]);
\t\tfor (let index = prefix + 1; index < states.length; index++) {
\t\t\tconst edits = states[index][key].actions[1].e;
\t\t\tconst leaf = edits[edits.length - 1];
\t\t\ttail.push(new ${prefix}ActionIterator([leaf]).next(1));
\t\t}
\t\treturn ${json}.compose(head, ["body", { et: "text-x", e: tail.serialize() }]);`;
 assert.equal(source.split(before).length,2);return source.replace(before,after);
}
function prepareDocsPatch(source:string,format:Format){
 const result=basePrepareDocsPatch(source,format),candidate=linearTail(result.patched,format);
 const identity={format,current:matrixHash(result.patched),prototype:matrixHash(candidate)};
 assert.equal(identity.current,format==='es'?'110890e889ac362b22a4c38bafd1ebb4e7cf82e8107d4524bdb86ff7fe6bd7c3':'58edceea5e1fb66ff1a83ec0a92707cf6f8d741aab87eb922d9c7e021f99207d');
 if(!matrixReport.prepared.some((v:any)=>v.format===format))matrixReport.prepared.push(identity);
 return {...result,currentPatched:result.patched,patched:candidate};
}

function runInNewContext(source:string,context:Record<string,unknown>,_options?:unknown){
 const ending=source.match(/(?:\nDocStateChangeManagerService|;composeDocStateActions);$/);
 assert.ok(ending,'Only known public manager/helper region may execute');
 const symbol=ending[0].slice(1,-1);
 return Function(...Object.keys(context),source.slice(0,-ending[0].length)+'\nreturn '+symbol+';')(...Object.values(context));
}
