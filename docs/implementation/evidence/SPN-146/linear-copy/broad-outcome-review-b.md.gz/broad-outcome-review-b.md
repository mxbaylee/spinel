# ✅ SPN-146 broader tail-only matrix — retained outcome B

The first admitted matrix completed successfully on the exact reviewed script. This is meaningful broader semantic evidence for the tail-only construction. It supports preparing a narrow production proposal or separately preparing an isolated prefix hypothesis; it is not production acceptance or permission to execute that next hypothesis.

I read the retained result, log and watchdog and checked their hashes plus the generated executable. No matrix, manager, browser or other workload was replayed; the shared slot remained available to the parent's SPN-090 work.

## 📌 Exact outcome

- Executable: `69e642d1a0326a796ad145c54043bd5de1ef3b93f2e1739608ab0bec5a2ed129`, matching the final B admission.
- Result SHA-256: `d99f9ec804bad832bdb86905db3e78b06e238b0efdca13b85fe53b15f89335ff`.
- Watchdog: `5ab038e5c4d80c151a111c6e275084aa333f7dc69c0ddf7577966e3ec92e8029`.
- Log: `d57d335479eb5b48ee56b3d1a1c7aeb5151587d6b3e7d1d570e3c0ab19304b70`.

All **16 selected groups** report passed, with contiguous before/after accounting and **1,862 attempted/completed wrapped flushes**. No cleanup, primary or persistence failure is recorded. Body elapsed is **16,049.694 ms**; the outer guard passed with exit 0 in **16,657 ms, peak 400,512 KiB, pressure 1**. These are execution accounting, not comparative latency results. Direct helper/fixture work in the unsupported-shape and idle-boundary groups is not included in the wrapped-flush count; their zero deltas correctly do not mean those groups were skipped.

Prepared current/prototype identities match the reviewed first probe: current ES `110890e8…`, CJS `58edceea…`; tail-only ES `3b6b5e87245fde1a2c9c94d10c8df1c4340485c79c49265f5cd5c07874036236`, CJS `3d3204088c7780f73c2bed5a28e77d56be4fe32c056ae38fbb6ead5790b91b2d`. The executed source guards bind the fixture, patch, actual imported ES Core and original source HEAD. Both manager formats use ES Core; this is not a separate CJS Core runtime run.

## 🧪 What is now supported

The reviewed assertions exercised all 32 Enter positions, COVER/REPLACE and independent cache folds; absent/own-undefined/empty metadata and style variants; exact unsupported bridge operand/read behavior; following-retain and artificial old-body representations; ownership and subsequent independent composition; and native idle/segment/remote/pre-Undo behavior. The new finite cases cover short length/admission edges, offsets, differing history start, normalization 0/1/3 times and identical/alternating styles.

This extends the earlier exact real-cache comparisons substantially. It preserves the raw semantic oracle rather than normalizing away differences. Applied/sequential checks use valid constructed snapshots; artificial old-body cases explicitly use native composition as oracle. No complete initial snapshot was invented for the retained browser caches. The successful matrix receipt does not contain per-case raw publication binaries; those checks are supported by exact executed assertions and first-attempt completion, while the earlier 16-flush proof files supply independently auditable real-cache raw values/alias topology.

## 🔎 Prefix preparation: justified, but distinct

A concrete prefix-only proposal with the tail held fixed is a reasonable next source question. The existing source still balances `composeRange(0, prefix)` inside the full Enter branch for `prefix >= 4`; the matrix pass does not establish that a linear prefix is equivalent. The 1440 residual count does not attribute every remaining operation to that head or prove a browser bottleneck.

The proposed four real cache pairs × two formats × tail-only/combined variants would mean **16 flushes/eight matched comparisons**, not 16 independent pairs. Before execution, determine and record which history/collaboration phases actually admit `prefix >= 4`. Eligible phases need a preregistered meaningful work reduction and exact semantic parity; ineligible/tiny-head phases must remain unchanged. Do not require or retrospectively invent a reduction for a branch that is not entered, and do not discard those negative controls. Confirm at least one eligible case in each manager format. This is a new lower-layer criterion, not a relaxation of the closed runtime criterion.

Preserve the full single-Enter qualifier, absolute first retain, insert-only native normalization and `prefix < 4` null fold. Keep the order of prefix/Enter composition and final head/tail composition. The comparator must isolate **tail-only → tail-plus-prefix** rather than credit the combined result with the already-proven tail saving. Retain original/current controls as semantic and upgrade evidence, not as substitutes for this isolation.

Reusing the existing broader matrix is an appropriate foundation if it adds explicit paired comparison to the tail-only control for the affected prefix cases. Confirm 3/4 and nearby prefix boundaries, offset zero/nonzero, style/metadata normalization before Enter, both cover modes and following retain/oldBody effects, unequal-cache admission, no input/output alias leaks and unchanged unsupported operand/read order. Preserve the same-realm/raw-sink/import binding and first-failure repairs. No general framework or another app workload is needed to answer that semantic question.

## 🚧 Before production and landing

Passing a separately reviewed real-cache prefix check plus the appropriately paired broader semantic matrix would justify drafting the narrow combined implementation. It would **not alone establish readiness for production/merge**. A concrete implementation must retain installer/package/hash/upgrade guards and previous-version negative controls, apply the relevant maintained tests to its exact generated bytes, and obtain feasible local checks and two independent exact-head source reviews. No additional scratch success may silently replace those integration obligations.

Guard-inclusive native cost versus pause attribution, original mobile timing contracts, full semantics and current-head hosted acceptance remain unresolved under their existing requirements. Earlier failed/inconclusive observations remain preserved; neither this result nor a prefix draft renews any closed component/window allowance or authorizes a third runtime experiment. Owner/Collaborator retain content/history/ownership guarantees; Operator gains bounded mechanism evidence; Link guest authority remains unchanged. Scope remains SPN-146 and separately authorized SPN-090 only.
