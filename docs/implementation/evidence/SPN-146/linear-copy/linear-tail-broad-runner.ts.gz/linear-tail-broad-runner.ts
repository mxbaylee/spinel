// A small separate boundary matrix supplements the unchanged existing assertions.
for(const format of ['es','cjs'] as const) selected.push({name:`${format}: tail admission boundaries and normalization ownership`,work:async()=>{
 const {patched,currentPatched}=prepareDocsPatch(await readBuild(format),format);
 for(const length of [4,5,6,7,9])for(let position=0;position<length;position++)for(const offset of [0,7])for(const cover of [core.UpdateDocsAttributeType.COVER,core.UpdateDocsAttributeType.REPLACE]){
  const scenario=paragraphSequence(position,length,cover,offset);
  const historyStart=length>5?2:0;
  const before=measuredFlush(currentPatched,scenario.states.slice(historyStart),scenario.states,true);
  const after=measuredFlush(patched,scenario.states.slice(historyStart),scenario.states,true);
  assertNativePreservation(before.output,after.output,scenario,`${format}/${length}/${position}/${offset}/${cover}`,historyStart);
  if(length-position<=4)assert.deepEqual(after.counts,before.counts,'Unadmitted short tails retain exact primitive work');
 }
 for(const repetitions of [0,1,3])for(const equalStyle of [false,true]){
  const decorate=(body:any,enter:boolean)=>{if(equalStyle)body.textRuns[0].ts={bl:1,cl:{rgb:'#123456'}};
   if(!enter)for(let i=0;i<repetitions;i++){
    const normalized=new core.ActionIterator([{t:core.TextXActionType.INSERT,len:1,body}]).next(1) as any;
    for(const key of Reflect.ownKeys(body))delete body[key];Object.assign(body,normalized.body);
   }
  };
  const scenario=paragraphSequence(4,16,core.UpdateDocsAttributeType.REPLACE,7,decorate);
  const before=flush(currentPatched,scenario.states,scenario.states,true);
  const after=flush(patched,scenario.states,scenario.states,true);
  assertNativePreservation(before,after,scenario,`${format}/normalizations${repetitions}/sameStyle${equalStyle}`);
  assert.deepEqual(ownDataShape({input:scenario.states,output:after}),ownDataShape({input:scenario.states,output:before}),'Input/output alias topology and own descriptors');
  const shape=ownDataShape(scenario.states),expected=structuredClone(after);
  ((after.changes[0].redoState.actions as any)[1].e.find((v:any)=>v.t==='i')).body.dataStream='changed';
  assert.deepEqual(ownDataShape(scenario.states),shape,'Output mutation cannot change source');
  assert.deepEqual(flush(patched,scenario.states,scenario.states,true),expected,'Independent invocation does not reuse mutated output');
 }
}});
const began=performance.now();let primary:unknown;
try {
 assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:'/Users/mxbaylee/projects/spinel-spn-146',encoding:'utf8'}).trim(),'8b6828196266f1fac6c46e2cc16b16321db72cf7');
 matrixReport.scriptSha256=matrixHash(await readFile('/tmp/spn146-investigation/linear-tail-broad.ts'));
 assert.equal(matrixHash(await readFile('/Users/mxbaylee/projects/spinel-spn-146/scripts/dependencies/patch-univer-docs.test.ts')),'8cad4e5eb989281b840632a74f5654c15dc4db7be11f38c38d4390250f065901');
 assert.equal(matrixHash(await readFile('/Users/mxbaylee/projects/spinel-spn-146/scripts/dependencies/patch-univer-docs.ts')),'81bd730d7975fb0d176e3657a740218a9131fce1a52e4af9665ce61334b784a8');
 assert.equal(matrixHash(await readFile('/Users/mxbaylee/projects/spinel/node_modules/@univerjs/core/lib/es/index.js')),'a019e7eb8b2ba235c7cfd54a19c262377a90c25aca13e5c2e0671a43b709e434');
 assert.equal(await realpath(fileURLToPath(import.meta.resolve('@univerjs/core'))),await realpath('/Users/mxbaylee/projects/spinel/node_modules/@univerjs/core/lib/es/index.js'));
 assert.equal(selected.length,16);
 for(const {name,work} of selected){
  assert.ok(performance.now()-began<60000);const row:any={name,status:'attempted',beforeFlushes:matrixReport.attemptedFlushes};matrixReport.tests.push(row);
  try{await work();row.status='passed';}catch(error){row.status='failed';throw error;}
  finally{row.afterFlushes=matrixReport.attemptedFlushes;}
 }
 assert.equal(matrixReport.attemptedFlushes,matrixReport.completedFlushes);matrixReport.complete=true;
}catch(error){primary=error;matrixReport.failure=error instanceof Error?error.stack:String(error);
 try{const bytes=serialize(recent);if(bytes.length>4*1024*1024)throw new Error('counterexample-size-limit');
 await writeFile('/tmp/spn146-investigation/linear-tail-broad-counterexample.bin',bytes,{flag:'wx'});
 matrixReport.counterexample={bytes:bytes.length,sha256:matrixHash(bytes),scope:'Last three flush calls; may not cover direct helper failures'};
 }catch(error){matrixReport.counterexampleUnavailable=String(error);}
}finally{
 matrixReport.elapsedMs=performance.now()-began;
 try{await writeFile('/tmp/spn146-investigation/linear-tail-broad-result.json',JSON.stringify(matrixReport,null,2)+'\n',{flag:'wx'});}
 catch(error){primary??=error;matrixReport.persistenceFailure=String(error);}
}
console.log(JSON.stringify(matrixReport));if(primary)process.exitCode=1;
