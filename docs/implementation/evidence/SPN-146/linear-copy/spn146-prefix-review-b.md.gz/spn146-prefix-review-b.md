# 🔎 SPN-146 isolated prefix probe — exact-script review B

**No concrete blocker found for one declared at-most-16-flush lower-layer falsification on the reviewed script**, under the existing serial 60-second/2-GiB/normal-pressure guard. No execution was performed by B. This is not production, browser/runtime or merge admission.

## 📌 Reviewed identity and delta

Read the maintained prospective prefix section, generator/body and generated executable, and compared the complete generated delta against the admitted successful tail-only script. HEAD remains `8b6828196266f1fac6c46e2cc16b16321db72cf7`.

- Generated `linear-prefix.ts`: `eb7857629500a4b3dacec76073db2e3ebb71af69892d8903351f4f98d0f4a727`.
- Generator: `64fa9f1be69d640816195fc1bff61cc67c41af74e47114c9c5f66312fbfedb42`.
- Body: `1ea2e3733e022cc5b01fca0d780af3c1eb99fe05451909e2166aaa48bb5190cf`.

The fixture, same-realm evaluator, raw sinks, partial-publication/cleanup ownership and primitive measurement prefix are unchanged from the reviewed tail probe. Script and source guards pin the original patched native bytes, fixture/patch, actual imported ES Core, checked CJS Core bytes and retained entry/pairs. The tail-building function is byte-identical in the generated delta. The new baseline is that successful tail-only transformation, while the candidate adds only the prefix transformation. Retained variant hashes will allow outcome reconciliation against tail-only ES `3b6b5e87…` and CJS `3d320408…`; the source is already fixed by the pinned input plus reviewed transformation.

## 🧩 Narrow semantic question

The single-match replacement changes only the `else` of the existing `prefix < 4` branch within the full qualified single-Enter path. It does not introduce a generic insert-prefix admission rule. It constructs a new TextX, retains the first original absolute offset when present, normalizes each insert-only leaf with public `ActionIterator.next(1)` and pushes through public TextX. The prefix/Enter JSONX composition remains in the same order, followed by the unchanged final head/tail composition. Tiny-head null folding, undo and unsupported fallbacks are unchanged.

This is a properly isolated question about removing balanced prefix revisits with the successful tail held fixed. Normalization idempotence, raw metadata and alias preservation remain things to falsify; public API use is not proof of equivalence.

## 🧪 Discriminating controls and bounds

The script pins four completed/sequence pairs and verifies the expected first Enter index in **both** decoded cache arrays: 544→7, 672→9, 1440→23 and 1984→3. Existing full-branch hit checks then require one successful admission per history/collaboration phase. Together with the unchanged full predicate, this connects the expected position to the affected branch rather than merely assuming all captures are eligible.

For the first three pairs, every phase must strictly reduce all four preregistered counters—TextX compositions, iterator calls, counted body slices and instrumented clone allocations. For 1984, every phase's **complete counter dictionary must remain equal**, preserving the ineligible tiny-head negative. This is six eligible matched comparisons plus two negative comparisons across formats, or 16 flushes total. It is not a threshold adjustment to either closed runtime experiment.

All pairs still require complete raw publications/order, input nonmutation, own descriptors/plain-prototype shape and combined input/output alias topology. Each attempt is recorded before invocation; returned/completed calls are separate; counters and phases survive failures. Successful V8 proofs are exclusive-created and capped at 512 KiB each/4 MiB aggregate. Main-body and cleanup-only failures retain bounded partial publications or explicit unavailability; original failures take precedence over cleanup/persistence failures. Primitive wrappers restore the original Core methods. No installed bytes are written.

Both manager formats execute ES Core; checking CJS Core bytes is not CJS-runtime coverage. The local elapsed assertions are accounting checks; the external watchdog is mandatory to stop synchronous work, including source construction and evidence finalization. Stop on the first source, semantic, ownership, work or resource failure. Preserve it; no repair-and-repeat of a semantic counterexample is admitted.

## 🚧 What remains afterward

A pass would support only the separately reviewed broader **tail-only versus combined** semantic matrix, including prefix 3/4 and nearby lengths, zero/nonzero offsets, metadata/style normalization before Enter, both cover modes, following retain/oldBody interactions, unequal caches, independent mutations and unsupported operand/read order. The prior tail-only broader pass does not credit a new prefix implementation automatically.

No prefix production edit, installer upgrade, current-head CI or browser speedup is demonstrated by this admission. Guard-inclusive native cost, original latency contracts and all prior failed/inconclusive outcomes remain unresolved. The count criterion cannot establish GC, historical pause causality or overall application benefit. Scope stays within SPN-146's existing XL outcome; SPN-090 remains the only other authorized ticket. No additional framework is needed for this finite question.
