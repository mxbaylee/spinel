# 🧪 SPN-146 prefix outcome and paired broader matrix — review B

**The retained first prefix probe supports the proposed broader semantic check. No concrete execution blocker found in exact broader script `7ef166e3848b0e12264fc3fec2e594ccb9b5ccd0090a4d79c3d0a363de5cb7ee` for one run under the existing serial 60-second/2-GiB/normal-pressure guard.** This is lower-layer admission only; no production or runtime waiver. B executed neither probe nor matrix.

## ✅ Static retained outcome

Read the complete small result, watchdog and log terminal, and checked file hashes. Result SHA-256 is `f98a2dbe544b471929f5161287eb8ac0c867235f5d73c58822cb4f6620dfe989`; watchdog is `7c2f9a2e58034a35e3a8ad6a9592d5aae99154067298b92a6627d09d18a2df5b`.

The receipt identifies admitted executable `eb7857629500a4b3dacec76073db2e3ebb71af69892d8903351f4f98d0f4a727`, source `8b6828196266f1fac6c46e2cc16b16321db72cf7`, 16 attempted/completed flushes, no errors/cleanup failures and 1,529,904 retained proof bytes. Body time is 620.485 ms; the guard passed in **1,236 ms, peak 323,936 KiB, pressure 1**. These durations do not measure comparative application performance.

Every row records passed/verified variants, expected Enter index 7/9/23/3 and one qualified branch hit in each phase. For both manager formats, aggregate allocations across the two phases are **4,502→3,956; 5,132→4,300; 10,088→6,708; 3,360→3,360**. The actual phase dictionaries confirm strict reductions of all four declared counters in each eligible phase and complete unchanged dictionaries for the index-3 negative. Recorded proof and graph hashes match within every pair. This review reconciles those receipts; it does **not** claim a new independent read/hash/deserialization of the 16 binary members.

The result isolates prefix work against the successful tail-only baseline. It is evidence of the intended primitive-work mechanism on these captures, not attribution of historical pauses or native wall-clock benefit. The ineligible control remains a pass by exact equality, not a dropped unfavorable sample.

## 📌 Broader script identity and meaningful delta

Inspected generator `9f243ae90b6a18ffbacbf39c7445460fb322eed7e7c5ab6ca7c1e1a2eb326a7c`, setup `872a7a18ede3d74883ec841e40bdc5fa151db3a0e2f9f9c7b71ca45db292cb3b`, runner `acd428825ec30aa4d24c85c3706f62d6b20fde6a090e5b7869c60e3958e0e675` and full generated delta from the successful tail-only matrix.

The baseline wrapper now returns `currentPatched: tailOnly` and `patched: prefixPrototype(tailOnly)`, records all three generated identities, and retains the pinned original/current source guards. The narrow prefix builder and tail transformation match the reviewed first prefix probe. No generic admission, null tiny-head fold, Enter join, final tail join, undo or fallback change is introduced.

Moving the metadata and following-retain/oldBody cases from Enter position 3 to **4**, while moving their comparator from constant-guard to **tail-only**, is necessary and correctly implemented: those cases now reach the new prefix path and isolate its effect. The mutation target moves with the Enter state. Native original raw/applied checks remain; artificial old-body cases retain their native-composition oracle. The existing all-position and ownership groups continue comparing against native originals and earlier controls rather than weakening equality.

The custom boundary group pairs tail-only and combined outputs across the fixed lengths/positions/offsets/cover modes with unequal history caches. It demands exact primitive dictionaries when neither cache can enter the changed path and strict aggregate reductions where collaboration can enter it. Normalization/style cases at prefix 4 compare raw alias/descriptor shapes, mutate output and check a later independent call. Unsupported bridge operand/read and idle/segment/remote/pre-Undo assertions remain selected.

**Nonblocking measurement limit:** custom boundary counters aggregate history and collaboration. With history starting two states later, a position-4 collaboration prefix can be eligible while history's prefix is 2. The aggregate reduction proves neither a per-phase reduction nor history-only exact-work equality in that asymmetric case. Preserve that wording. Raw output parity covers both caches; the earlier real-pair probe supplies phase-separated work evidence for its matched shapes. This does not prevent the matrix from answering its broader semantic question, but its report must not overstate aggregate measurements as phase attribution.

## 🧹 Bounds and admission

The previously reviewed setup repairs remain: same-realm manager/helper construction with known terminal symbols, raw sinks, actual Core import realpath binding, primary-preserving cleanup in both wrapped and direct fixture scopes, partial failed-publication retention, bounded last-three-call failure artifact, exclusive output creation and original-error preservation across persistence failure. The 16 selected top-level groups are sequential and stop at first failure; wrapped-flush counts do not include direct helper/idle-triggered calls. No installer tests or installed package writes are selected. Both syntax formats execute ES Core, not independent CJS Core runtime coverage.

The external guard remains mandatory; local top-level elapsed assertions cannot interrupt synchronous loops. A resource kill/incomplete report is a failed or incomplete execution, never acceptance. Preserve the first source/setup/semantic/ownership/work/resource failure; no automatic retry or oracle adjustment is admitted.

A successful paired matrix could support a concrete narrow implementation proposal with maintained regressions and package/installer/upgrade integration checks on exact generated bytes. It would not complete SPN-146, explain historical maxima, satisfy guard-inclusive runtime qualification or waive current-head CI/native acceptance. All closed failed/inconclusive observations remain intact. No additional framework or broader feature is needed for this matrix. Owner/Collaborator metadata/history/ownership and Link guest authority remain protected; Operator receives bounded mechanism evidence only.
