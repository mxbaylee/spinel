# ⚡ SPN-146 linear tail plan review B

**Support preparation of the narrow scratch prototype and its exact-script review. This plan alone admits no execution, production change or renewed runtime allowance.** The question follows from an identifiable remaining copy mechanism and is distinct from the closed component/window experiments. I found no need for a broader framework or a different public API at this stage.

Read-only review of `/tmp/spn146-linear-tail-plan.md`, current `prepareDocsPatch` qualification and composition branches, SPN-121's own-undefined finding, and the installed public Core implementations of ActionIterator/TextX. No code, dependencies, runtime, browser, converter or retained-data replay was changed or executed.

## 🔎 Source basis and precise boundary

Current qualification admits the branch only for redo, a single qualified Enter and a sufficiently long tail. It checks the full plain-data graph, exact action/body constraints, same unit/segment and the offsets of every eligible insertion. The append-contiguous condition is stronger than the generic insert-prefix guard, which also permits prepend shapes. That stronger full branch must remain the sole admission point; the new assembly cannot be called merely because `docInsertPrefixLength` accepted a range.

In the inspected public Core, ActionIterator.next slices the body and deep-clones its returned action. TextX.push deep-clones its operand and applies specific action-merging rules, including the own-key-sensitive data-stream-only insert merge. Balanced composition can revisit previously normalized leaves at multiple internal nodes. Avoiding those revisits while retaining each leaf's native normalization and push behavior is a concrete mechanistic question. It does not follow that normalization is idempotent or that eliminating visits benefits browser latency.

The generated script must resolve one important ambiguity: `next(1)` must operate on the **qualified insert leaf**, not on a state's original retain-plus-insert action list, whose first next call would consume retain. Keep the tail's original first absolute-offset retain, the exact `['body', {et: 'text-x', e: ...}]` envelope and the unchanged final head/tail JSONX composition. Do not reinterpret the offset relative to the new head. Do not copy the full list's later retains into the accumulated tail; their semantic displacement is exactly what append qualification permits the proposed assembly to omit. Source review must verify this distinction before any execution.

Keep tiny-head behavior, initial null fold, Enter retain/style operation, undo path, fallback operand/read order, cache and publication untouched. No new path for prepend, noncontiguous, structural or merely superficially similar actions is admitted. Final serialization must remain owned by the invocation, not returned/shared from input cache objects or reused across flushes.

## 🧪 First falsification is useful but deliberately insufficient

The four retained browser cache pairs are a useful first check of actual shapes that motivated this investigation. Exactly four pairs × ES/CJS × current/prototype gives the declared maximum 16 manager flushes. The existing fixture is the appropriate lowest layer: it exposes actual history/collaboration composition and publication rather than testing a detached string concatenator.

Before execution, pin generated manager/native/Core/fixture/input/script identities and show both variants use the same source except the proposed qualified tail construction. Bind pair hash `e7768818642407ee6f559e251f49f9f408fb95e1ba317e1e9d92053134e97fb5`. Verify both variants actually enter the intended branch and retain their per-phase outputs/work observations, so a bypass or fallback cannot masquerade as a favorable result.

Require complete raw equality, own-property presence, publication order, input/descriptor nonmutation and fixture-owned cleanup. Preserve and check output ownership/alias behavior, not only JSON text or final applied content: a shared style/body object can remain value-equal until later mutation. Node serialization is useful for undefined/shared graph retention, but equality evidence must be explicit about what descriptor/prototype/reference relations it checks. No new shallow canonicalization, stripping undefined fields or replacing absent fields is permitted to make outputs agree.

The concrete work criterion should identify which counters must decrease on every matched pair and which must remain unchanged. At minimum, each relevant phase's repeated tail iterator/body-slice/deep-clone work must be attributable to this changed construction, with unchanged guard/admission and publication behavior. Do not use a reduced aggregate that hides an increase in the target phase or report a lower-bound operand count as measured allocations. Guard cost is outside these counters, and a 16-flush pass has no wall-clock, GC, historical maximum or browser-headroom implication.

A first semantic/ownership failure closes this construction under the stated plan. A successful first check permits only a separately reviewed broader matrix. That next matrix must cover normalized-once versus repeatedly normalized bodies, missing/own-undefined/empty metadata, style variation and preservation markers, tail lengths and Enter positions, unequal caches, independent calls and unsupported shapes. The current guard allows more than the four real records; a pass on those records is not a proof over that domain. These remaining controls need not be executed before this explicitly preliminary falsification, but cannot be skipped before production admission.

## 🧹 Bounds, complexity and disposition

One serial 60-second/2-GiB/normal-pressure process, fixed observation count, no warmup/filtering/retry, complete first-failure retention and fixture cleanup are appropriate. First setup/hash/semantic/ownership/resource failures must remain distinguishable. Exact generated-script inspection must include partial setup and primary-versus-cleanup/persistence error ownership, not just the successful pair comparator. No installed package writes, fresh install, browser or converter is needed.

Using existing public iterator/push semantics is simpler and safer than duplicating native normalization. The proposal becomes over-complex if it adds a persistent normalization cache, parallel metadata merger, special cleanup framework or general-purpose alternate composer; none is needed to answer this question. Preserving the unchanged full qualifier is essential even if it limits the eventual gain.

Operator gains a bounded mechanism falsification; Owner and Collaborator retain exact metadata/history/content and ownership guarantees; Link guest authority remains unchanged. SPN-146 stays XL and unaccepted. Its two component criteria failures, no-comparable-event diagnostics, resource failures and original timing violations remain intact; neither this plan nor a local pass restarts those closed allowances. SPN-090 is the only other authorized ticket.

**Disposition:** proceed only to concrete scratch-script preparation/review with the boundary and proof requirements above. No execution, production candidate, runtime-benefit claim or merge approval is granted here.
