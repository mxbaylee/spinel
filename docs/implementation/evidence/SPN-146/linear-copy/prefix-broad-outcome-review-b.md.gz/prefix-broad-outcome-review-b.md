# ✅ SPN-146 paired prefix matrix — outcome and qualification view B

The first paired broader matrix passed on the exact reviewed executable. The combined change now has meaningful lower-layer semantic evidence and a measured reduction of a different native-work mechanism. **Preparing one explicitly preregistered qualification of the new production candidate is justified in principle.** This is not execution admission for an unwritten/unreviewed candidate, and no old failure or acceptance requirement is waived.

## 📌 Retained outcome

Static readback only; B did not replay the matrix. Executable SHA-256 is `7ef166e3848b0e12264fc3fec2e594ccb9b5ccd0090a4d79c3d0a363de5cb7ee`, matching the admission. Result is `1adaf64ae0a09fcdda0e5f1737d766e241a712f6cbce3de51023e96155ecca97`; watchdog is `9faed331358a1237ef2a44335da97e02b4dfb93117d0fc4cfbaa04e4ebb4a56c`.

All **16 selected groups** passed, with **1,862 attempted/completed wrapped flushes**, no cleanup errors and no recorded primary/persistence failure. Direct helper and idle-triggered work is additional coverage, not counted as wrapped calls. Body elapsed was **16,980.354 ms**; the guard passed in **17,563 ms, peak 411,888 KiB, normal pressure**. These durations are accounting, not comparative latency evidence.

Recorded combined native identities are ES `e47c9319b3c85c737add0e7807edbc27aeafcc81b81dd6ad870058e4fe3da093` and CJS `4ade808be25d9aed4122d1ab254a07802c89065c06cac42f9dec60fe2f2d286f`. The result preserves original/current and tail-only identities separately. The matrix's paired boundary, metadata and following-retain/oldBody tests therefore concern tail-only versus combined behavior; native original comparisons, unsupported read/operand contracts and ownership checks remain. Both manager formats still execute ES Core. Unequal-cache boundary work counts are aggregate, not phase attribution; the first retained-pair probe separately supplies per-phase evidence for its actual captures.

## 🔬 Why a changed-candidate qualification is distinct

The exhausted scan-reuse candidate removed repeated qualification scans while retaining balanced native composition. This proposal instead removes repeated native leaf normalization/copying inside fully qualified tail and prefix ranges, keeping the guard, tiny-head null fold and Enter/final joins. The separate tail and prefix probes measured the incremental mechanisms, including an unchanged tiny-prefix negative, and the broader matrices retained strict raw semantics rather than weakening an oracle. This is a substantive candidate change, not the old experiment with a more favorable threshold, environment, window or sample selection.

Those facts justify asking the unresolved **guard-inclusive native whole-flush** question again for the new algorithm. They do not answer it. Guard cost, other native work, controlled sink limitations and runtime variation can still erase the primitive-count gain. The original pause fraction and exact historical causes remain unknown.

## 🧪 Necessary prospective bounds

Before execution, commit the concrete production integration with exact generated-byte/installer/upgrade controls and maintained semantic tests, record feasible checks/resource limitations, and obtain the two required independent exact-head reviews. If factoring changes the scratch bytes, explicitly bind and validate the resulting production bytes rather than crediting the scratch hash automatically.

The new plan should pin the exact `8b682819… → reviewed candidate` trigger once, source/tested-tree and harness identities, and the same original comparator algorithm used in the previous component protocol. The transition's old Git head is not a reason to silently replace the comparator with that failed candidate. Retain the same four inputs, formats, two fixed counterbalanced orders, **32 observations/16 matched comparisons**, Linux environment, 4× throttle, controlled callbacks, complete trace/profile/clock/GC interpretation and existing limits. Every comparison must still meet **at least 20% and at least 1 ms whole-flush reduction**. No averaging, selective omission, warmup/filter/retry or pause subtraction may rescue a failed criterion.

A capture/resource/analyzer failure is incomplete; any failed fixed comparison is failed/inconclusive under the established disposition. Preserve all observations and first errors and close the allowance on either outcome. Known nonduration GC context must remain honestly distinguished from measured duration, with no unsupported GC-absence claim. This would qualify a component cost contributor, not prove the cause of an earlier application pause.

Qualification-first ordering is reasonable if the prospective workflow/routing clearly assigns that stage and keeps later full current-head acceptance pending. It must not be implemented by repeatedly running, cancelling and renewing the same application acceptance workloads. If ordinary required work is selected, preserve its exact terminal disposition; a component pass cannot substitute for any missing/failed gate. The concrete plan must specify that ordering before publication.

## 🚧 Still required

No fresh runtime allowance is granted by this outcome report alone. Even a qualifying component result would leave current-head full application/native/selected CI and the original unprofiled p95/max, idle, content/history and authority obligations intact. Neither a later green CI nor this matrix retroactively changes previous failures. Operator gets a more discriminating candidate question; Owner/Collaborator retain metadata/history/ownership contracts; Link guest authority is unchanged. The complete outcome remains XL and unaccepted; scope remains SPN-146 and SPN-090 only.
