# 🧪 SPN-146 broader tail-only matrix — review B

Read-only review of the plan, generator, setup, runner and generated source. No matrix, test, browser or production operation was executed by B. This review concerns one bounded semantic falsification, not implementation or runtime admission.

## 🔎 Coverage and scope

The selected seven existing test bodies per format and two new boundary tests are a meaningful next layer after the four real-cache pairs. They retain raw publications and valid applied/sequential oracles; cover all 32 paragraph positions, COVER/REPLACE, ownership and independent calls, differing caches, absent/undefined/empty metadata, Enter following-retain/old-body variants, unsupported bridges/read order and native idle/segment/remote/pre-Undo boundaries. Artificial old-body cases correctly use native composition as their oracle without inventing authored histories.

The added lengths 4/5/6/7/9, every position, offsets 0/7 and both cover modes exercise admission and tiny-head/tail edges. Slicing history independently for lengths above five makes cache qualification differ. The 0/1/3 public normalization passes and identical/alternating styles test the proposed reduction in normalization frequency; output mutation and a subsequent independent call expose sharing. Retaining the old admitted-work operand equality test would incorrectly forbid the intentional algorithm change; excluding it while retaining unsupported fallback operand/read checks is appropriate.

This is tail-only: full admission, balanced head, Enter and final join remain unchanged. No prefix optimization is silently included. The seven-body name filter and final count of 16 provide a finite sequential selection. Unselected installer tests are not executed; imported installer functions are not called by the selected matrix. The full generated fixture is larger than the executed scope, but reusing established tests is preferable to a new general matrix framework.

## 🚧 Findings and repairs

Initial supplied generated identity was `1178ee6ca2e922ff165967024d70649d641c5d6329f6746d2fc32bb91096c2e1`. Three pre-execution gaps were reported and repaired before any matrix execution:

1. Raw reference sinks plus separate VM realms could cause prototype-sensitive equality and explicit host-prototype ownership assertions to fail for harness reasons. The repaired evaluator executes both manager and direct composer regions in the same realm, accepts only known terminal symbols and preserves the original assertions.
2. The outer flush wrapper previously retained only input and error for a failure inside `baseFlush`. Available history/collaboration/publication arrays are now captured before main or cleanup failure escapes, so the bounded last-three-call counterexample can contain the failed publication.
3. Hashing the donor Core file did not alone bind the bare import used by the generated script. The runner now compares the actual imported ES Core realpath to that hashed donor file.

These repairs were verified on generated `c89be136f6f57b39d22bfcdb3c92283c10be30e071371e500f632cfd12f42227`, builder `0509775eed0d6ca9c3156c89fbfcb558b1980c5662fa593c5bea288f4438b495`, setup `b9c7a424dab8f67516da61fa270283128da0e7156f84a815e83f138256872e7b` and runner `b11aa802206973167faea74de9e5e9e54b68f2599b144d70ec3c00cb3a6a4827`.

**One remaining first-cause correction is required before admission on that identity:** the selected native idle/segment/remote/pre-Undo test uses a direct fixture and `try/finally { f.close(); }`, bypassing the repaired `baseFlush`. A close failure can replace an earlier assertion failure. Give that one selected direct scope the same primary-error preservation and cleanup-failure recording. Do not expand the change into unused test bodies or a new lifecycle framework.

## 📏 Execution and evidence limits

The existing serial 60-second/2-GiB/normal-pressure guard must cover the entire script. Local elapsed checks at top-level boundaries cannot interrupt synchronous case loops. The top-level matrix is finite but includes many flushes; 16 means selected tests, not 16 calls. Attempted/completed flush counts cover the wrapped helper, while direct helper/fixture calls are outside that accounting. Describe the counters accordingly.

The bounded failure artifact retains the last three wrapped flush calls, up to 4 MiB, with an explicit unavailability record if serialization/persistence fails. It does not promise a complete counterexample for direct helper failures. Keep the full primary test stack/status and source identities in those cases. A guard kill may leave only external logs/watchdog evidence, not a normally finalized matrix report; it remains incomplete, never a pass. A generator/setup failure before matrix execution is distinct from a semantic failure after execution starts. The preserved EEXIST setup event must not be erased or described as a semantic retry.

Same-realm evaluation removes harness-only prototype differences; it is not a sandbox. Only pinned, locally trusted public manager/helper source is evaluated. Both manager formats execute with verified ES Core, not distinct CJS Core runtime coverage. Raw ownership/descriptor checks are stronger than value-only JSON comparisons but do not establish every possible admitted shape or browser behavior. A pass can support proposing the narrow production tail change with subsequent exact-head review; it cannot establish latency benefit, historical pause causality or satisfy unresolved hosted/runtime acceptance.

Operator gains bounded semantic evidence; Owner/Collaborator retain exact metadata, history and ownership; Link guest authority is unchanged. Scope remains SPN-146 plus separately authorized SPN-090. Existing failed/inconclusive component/window results and timing criteria remain intact. No prefix variant or renewed runtime allowance is admitted here.

## ✅ Final repaired admission

Read back generated `69e642d1a0326a796ad145c54043bd5de1ef3b93f2e1739608ab0bec5a2ed129` and builder `d376f2d2b34d5887f18a0cf6d0e35f263fc50bc4e9e7ff1f6ccc160b63fdfa81`; setup and runner remain the identities above. The selected direct fixture now captures its first error, records available direct publications and preserves that error if cleanup also fails. Cleanup-only failure still throws and is recorded. The residual finding is resolved. The supplementary `directPartial` JSON is diagnostic context, not the lossless V8 counterexample or a replacement for own-undefined/alias proof.

**No remaining concrete blocker found for one execution of this exact tail-only matrix under the stated serial 60-second/2-GiB/normal-pressure guard.** All setup corrections preceded execution and the original equality assertions remain. Stop at the first failure; do not reinterpret a semantic counterexample as a reason to relax the oracle or renew the matrix. Preserve complete first-failure/source/watchdog receipts, including any external abort. No test was run by B. This admits only this finite lower-layer matrix—not prefix optimization, production implementation, native/runtime experimentation or merge acceptance.
