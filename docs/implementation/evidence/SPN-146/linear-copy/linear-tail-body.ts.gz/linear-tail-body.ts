import {serialize} from 'node:v8';
import {execFileSync} from 'node:child_process';
import {realpath} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
function instantiate(source:string, context:Record<string,unknown>, _options:unknown){
 assert.ok(source.endsWith('\nDocStateChangeManagerService;'));
 return Function(...Object.keys(context),source.replace(/\nDocStateChangeManagerService;$/, '\nreturn DocStateChangeManagerService;'))(...Object.values(context));
}
let activeCounts:Record<string,number>={},phaseCounts:any[]=[],branchHits=0;
const root='/Users/mxbaylee/projects/spinel-spn-146';
const hash=(b:string|Buffer)=>createHash('sha256').update(b).digest('hex');
const report:any={diagnosticOnly:true,scope:'One native normalization/push per qualified append-tail leaf; no runtime or production acceptance.',complete:false,results:[],attemptedFlushes:0,completedFlushes:0,cleanupFailures:[],executionCore:'ES Core for both ES/CJS manager regions; CJS Core hash verified, not executed',proofBytes:0};
const began=performance.now();let primary:unknown;
function prototype(source:string,format:Format){
 const json=format==='es'?'JSONX':'_univerjs_core.JSONX',prefix=format==='es'?'':'_univerjs_core.';
 const before=`\t\treturn ${json}.compose(head, composeRange(prefix + 1, states.length));`;
 const after=`\t\tconst tail = new ${prefix}TextX();
\t\tconst firstEdits = states[prefix + 1][key].actions[1].e;
\t\tif (firstEdits.length === 2) tail.push(firstEdits[0]);
\t\tfor (let index = prefix + 1; index < states.length; index++) {
\t\t\tconst edits = states[index][key].actions[1].e;
\t\t\tconst leaf = edits[edits.length - 1];
\t\t\ttail.push(new ${prefix}ActionIterator([leaf]).next(1));
\t\t}
\t\treturn ${json}.compose(head, ["body", { et: "text-x", e: tail.serialize() }]);`;
 assert.equal(source.split(before).length,2);return source.replace(before,after);
}
function instrument(source:string){
 const marker='if (key === "redoState" && states.length - prefix > 4 && canComposeDocParagraphTail(states, key, prefix)) {';
 assert.equal(source.split(marker).length,2);return source.replace(marker,marker+' __linearTick();');
}
try{
 report.source=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
 assert.equal(report.source,'8b6828196266f1fac6c46e2cc16b16321db72cf7');
 report.scriptSha256=hash(await readFile('/tmp/spn146-investigation/linear-tail.ts'));
 for(const [name,path] of [['fixture','scripts/dependencies/patch-univer-docs.test.ts'],['patch','scripts/dependencies/patch-univer-docs.ts']] as const)
  assert.equal(hash(await readFile(root+'/'+path)),expectedSourceHashes[name]);
 report.sourceHashes=expectedSourceHashes;
 report.coreImport=await realpath(fileURLToPath(import.meta.resolve('@univerjs/core')));
 assert.equal(report.coreImport,await realpath('/Users/mxbaylee/projects/spinel/node_modules/@univerjs/core/lib/es/index.js'));
 const entry=await readFile('/tmp/spn146-linux-hosted/component/source/entry.ts','utf8');assert.equal(hash(entry),'79623afaae1cbc83ac3767f48f2567d90cf343caf0080fc0539d44ec3f6f29c4');
 const match=entry.match(/^const pairs=(.*);$/m);assert.ok(match);const pairs=JSON.parse(match[1]);
 assert.equal(hash(JSON.stringify(pairs)),'e7768818642407ee6f559e251f49f9f408fb95e1ba317e1e9d92053134e97fb5');
 assert.deepEqual(pairs.map((p:any)=>[p.completed,p.sequences]),[[544,[32,33]],[672,[40,41]],[1440,[88,89]],[1984,[122,123]]]);
 for(const format of ['es','cjs'] as const){
  assert.equal(hash(await readFile(`/Users/mxbaylee/projects/spinel/node_modules/@univerjs/core/lib/${format}/index.js`)),format==='es'?'a019e7eb8b2ba235c7cfd54a19c262377a90c25aca13e5c2e0671a43b709e434':'ae2326c195fa7aa89be7199dd2a838d8f267f05c9dfee449a33c5ceae4d4a132');
  const current=prepareDocsPatch(await readBuild(format),format).patched;
  assert.equal(hash(current),format==='es'?'110890e889ac362b22a4c38bafd1ebb4e7cf82e8107d4524bdb86ff7fe6bd7c3':'58edceea5e1fb66ff1a83ec0a92707cf6f8d741aab87eb922d9c7e021f99207d');
  for(const pair of pairs){
   const row:any={format,completed:pair.completed,sequences:pair.sequences,variants:[]};report.results.push(row);
   let previous:any;
   for(const [variant,native] of [['current',current],['prototype',prototype(current,format)]] as const){
    assert.ok(performance.now()-began<60_000);report.active={format,completed:pair.completed,variant};branchHits=0;phaseCounts=[];
    const record:any={variant,sourceSha256:hash(native),status:'attempted',verified:false};row.variants.push(record);report.attemptedFlushes++;activeCounts={};
    try {
     const history=decodeCapture(pair.history),collaboration=decodeCapture(pair.collaboration);assert.equal(history.length,32);assert.equal(collaboration.length,32);
     const result=measuredFlush(instrument(native),history,collaboration,true);report.completedFlushes++;
     const graph=ownDataShape({history,collaboration,output:result.output});
     const raw=serialize({history,collaboration,output:result.output});
     assert.ok(raw.length<=512*1024 && report.proofBytes+raw.length<=4*1024*1024,'Bounded retained raw outputs');
     const file=`linear-tail-${format}-${pair.completed}-${variant}.bin`;
     await writeFile('/tmp/spn146-investigation/'+file,raw,{flag:'wx'});report.proofBytes+=raw.length;
     record.proof={file,bytes:raw.length,sha256:hash(raw),encoding:'Node v8.serialize; preserves values/undefined/reference graph; descriptors compared in memory'};
     record.graphShapeSha256=hash(JSON.stringify(graph,(key,value)=>{
      if(key==='prototype') {assert.ok(value===null||value===Object.prototype||value===Array.prototype,'Plain same-realm prototype only');return value===null?'null':value===Object.prototype?'Object.prototype':'Array.prototype';}
      return value===undefined?{type:'undefined'}:value;
     }));
     assert.deepEqual(phaseCounts.map(x=>x.phase),['history','collaboration']);assert.equal(branchHits,2);
     for(const phase of phaseCounts)assert.equal(phase.hits,1);
     assert.equal(result.output.history.length,1);assert.equal(result.output.changes.length,1);
     if(variant==='current')previous={result,graph};else {
      assert.deepEqual(result.output,previous.result.output,'Complete raw publications/order, including own undefined properties');
      assert.deepEqual(graph,previous.graph,'Own descriptors/prototype shape and input/output alias topology');
     }
     record.verified=true;record.status='passed';
    } catch(error){record.status='failed';record.failure=error instanceof Error?error.stack:String(error);throw error;}
    finally {record.counts={...activeCounts};record.phases=structuredClone(phaseCounts);record.branchHits=branchHits;}

   }
   const [old,next]=row.variants;
   for(let phase=0;phase<2;phase++)for(const key of ['textCompose','iteratorNext','bodySlices','allocations'])
    assert.ok(next.phases[phase].counts[key]<old.phases[phase].counts[key],`${format}/${pair.completed}/${old.phases[phase].phase}/${key}: strict repeated-work reduction`);
  }
 }
 assert.equal(report.attemptedFlushes,16);assert.equal(report.completedFlushes,16);assert.equal(report.cleanupFailures.length,0);assert.ok(performance.now()-began<60_000);report.complete=true;
}catch(error){primary=error;report.failure=error instanceof Error?error.stack:String(error);}
finally{
 report.elapsedMs=performance.now()-began;
 try{await writeFile('/tmp/spn146-investigation/linear-tail-result.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});}
 catch(error){report.persistenceFailure=String(error);primary??=error;}
}
console.log(JSON.stringify(report));if(primary)process.exitCode=1;
