# ⚡ SPN-146 linear tail — independent retained outcome review B

## ✅ Bounded outcome

The admitted first falsification **passed its stated semantic and primitive-work criteria on all four retained cache pairs, in both manager formats**. This supports preparing the separately reviewed broader semantic matrix. It does not qualify a production patch, establish native runtime improvement or renew any closed browser/component/window allowance.

I ran one artifact-only verification through the shared serial runner and 60-second/2-GiB/normal-pressure guard: **273 ms, peak 90,016 KiB**, passed first execution. No manager, probe, browser, converter or provider call was replayed. Source was not edited.

Proof/helper/log/watchdog: `/tmp/spn146-linear-tail-audit-b.{json,ts,log}` and `/tmp/spn146-linear-tail-audit-b-watchdog.json`. The proof binds the exact result bytes and all 16 binary members.

## 📌 Identity and evidence

The result identifies source `8b6828196266f1fac6c46e2cc16b16321db72cf7` and admitted generated script `9d2ca7399d4f1d12c204587ac13b1ba1e9bcc9b103f6b15e1137ba7f1eab2c33`; I independently checked the latter against the retained executable. The script pins fixture `8cad4e5e…`, patch `81bd730d…`, current native ES `110890e8…`/CJS `58edceea…`, retained entry and pair identities. Prototype ES is `3b6b5e87245fde1a2c9c94d10c8df1c4340485c79c49265f5cd5c07874036236`; all complete variant identities remain in the result.

The original execution records 16 attempted/16 completed calls, eight matched pairs, no primary/persistence failure, no cleanup failures, and 643.114 ms body elapsed. Its outer watchdog passed in **1,330 ms, peak 315,632 KiB, pressure 1**. Body duration is accounting, not a comparative timing measurement.

All **16 retained V8 binaries, totaling 1,529,904 bytes**, satisfy their recorded sizes/SHA-256 and the per-member/aggregate ceilings. Each current/prototype pair is byte-identical, not merely JSON-equivalent. Independently decoded combined inputs/output compare equal, including own-undefined values and repeated-reference topology; each input side has 32 states and each output has one history and one collaboration publication. Recorded graph-shape hashes match pairwise. Descriptor and plain-prototype checks were executed in the original probe before serialization; V8 binaries do not independently reconstruct the original descriptor flags, so this audit does not claim to re-prove those checks solely from deserialization.

Each phase has exactly one intended branch hit, ordered history then collaboration. Both phases of every pair strictly reduce all four preregistered counters: TextX composition, iterator calls, counted body slices and instrumented clone allocations. Per-phase allocations are identical across ES/CJS manager variants:

- Completed 544: **4,043 → 2,251**.
- Completed 672: **4,155 → 2,566**.
- Completed 1440: **5,380 → 5,044**.
- Completed 1984: **3,876 → 1,680**.

These are primitive observations in the controlled service fixture. They omit full guard cost, other allocation mechanisms and application subscribers. Both manager syntax formats use ES Core; CJS Core bytes were checked but its runtime was not separately executed. The pass neither explains a historical pause nor establishes GC, browser-headroom or latency benefit.

## 🧪 Next semantic boundary: tail only

The next question should retain this exact tail construction and expand coverage, before combining it with another optimization. Use the existing manager/ownership fixture with a preregistered finite matrix: all Enter positions that admit the branch, tail-length thresholds, initial offsets, tiny-head boundaries, COVER/REPLACE, independently varying history/collaboration caches, and repeated independent invocations. Include absent versus own-undefined versus empty metadata, preservation markers, adjacent identical/different styles and native normalized-once versus repeatedly normalized bodies. Unsupported/prepend/noncontiguous/accessor/descriptor shapes must preserve the old fallback operand and read order.

Require raw publication/own-property/alias/descriptor parity, input nonmutation, complete applied snapshot equivalence where a valid original snapshot exists, and downstream mutation isolation. A V8 equality check is valuable but cannot replace the explicit descriptor and output-ownership controls. Preserve the previous current algorithm as the semantic/work control and make a first counterexample visible; do not strip fields or relax equality to rescue the hypothesis. Do not construct an alleged original snapshot for the four retained browser caches whose complete initial snapshot was not captured.

## 🔎 Separate prefix hypothesis

**Preparing a separate narrow hypothesis is justified; executing or implementing it is not admitted by this review.** Current source explicitly balances `composeRange(0, prefix)` when `prefix >= 4`, inside the full single-Enter branch, then composes the Enter and tail. Thus repeated normalization/copying in that already-qualified head is a concrete source mechanism. The smaller improvement at 1440 is consistent with substantial work remaining outside the shortened tail, but phase-wide counters alone do not attribute every remaining operation to the balanced head or establish it as the runtime bottleneck.

The precise future question is: with the successful linear-tail variant held fixed, can an independently constructed linear **prefix** replace only that `prefix >= 4` balanced range, preserving the first absolute retain and each insert's public normalization/push semantics, while keeping `JSONX.compose(prefixResult, EnterAction)` and the final head/tail join in the same order? Compare tail-only against tail-plus-prefix so the prefix effect is isolated; do not compare only original versus combined and attribute the entire difference to the head.

The full single-Enter qualifier must remain the authority. A generic insert-prefix result by itself admits shapes the full append-contiguous predicate excludes. Keep `prefix < 4`'s original null fold exactly; avoid accidentally introducing or removing null composition for the optimized non-null range. Test the boundary at 3/4, offset zero/nonzero, prefix metadata interacting with Enter's following style retain and `oldBody`, both cover modes, and unequal cache positions. Raw normalization idempotence and aliasing remain falsification targets, not consequences of public API use. Retain separate head/Enter/final-join evidence if the next question attributes work to those segments.

## 🚧 Remaining disposition

Owner and Collaborator gain exact metadata/history preservation evidence on the sampled shapes; Operator gains a bounded work-mechanism result; Link guest authority is untouched. The complete XL outcome remains pending. Original timing violations, both inconclusive component criteria and failed/no-comparable-event/resource-limited window attempts remain unchanged. This pass authorizes no third component experiment, phone/browser run, threshold adjustment, production acceptance or merge.
