# ⚡ SPN-146 linear tail scratch-script review B

**Hold execution for the two failure-retention/cleanup corrections below.** The construction is appropriately narrow for the declared first falsification, but the inspected script does not yet retain and clean up every attempted observation as claimed. This is an execution-admission review, not a source grade or production/runtime approval. No probe, tests, browser, converter or dependency mutation was executed by B.

## 📌 Reviewed identity

Read the plan and prior B plan review, the actual current qualifier/composer, generated fixture/measurement implementation and these exact scratch files:

- `build-linear-tail.ts`: SHA-256 `3d516c0435ef17e22fab6cb95970a0044c5a2ad03f39138b2925ffe547da88b3`.
- `linear-tail-body.ts`: `56ee25af03cc3180238e48c486497d0cb93a8c4244938b535ae2a6f048e04670`.
- Generated `linear-tail.ts`: `70ec0c8616e31ce1e301642a45e63fb895502ee89dbc39ec9298dfbb06914da3`.

The generated source checks HEAD `8b6828196266f1fac6c46e2cc16b16321db72cf7`, fixture `8cad4e5e…`, patch `81bd730d…`, exact current native ES/CJS hashes, Core bytes/import realpath, retained entry `79623afa…`, pair hash `e7768818…` and all four completed/sequence identities. The fixed nested loops contain at most 16 manager calls; failure exits the outer protected body. The externally declared serial 60-second/2-GiB/normal-pressure watchdog remains necessary: local elapsed assertions do not interrupt synchronous composition.

## 🚧 Required corrections before execution

1. **Protect instrumentation setup with the fixture's cleanup owner.** Generated `flush()` creates the fixture, then reads/asserts and installs both phase wrappers before entering its `try`. A missing method or setup exception therefore bypasses `fixture.close()`. Move that wrapper setup inside the existing protected `try`; keep the primary-versus-cleanup error handling. No new cleanup abstraction is necessary.

2. **Retain the attempted variant before work can fail.** The variant record is currently appended only after `measuredFlush()` and `ownDataShape()` return, while `report.flushes` also increments only after successful return. A semantic/nonmutation assertion within `flush()`, manager exception, cleanup failure or graph-construction failure loses the attempted variant's counters/phase hits and makes the count appear to exclude the failed manager call. Create a `started` variant record before invocation, distinguish attempted from returned/completed calls, and retain the available counts, phase records, branch hits and failure in a `finally`/catch path. Capture available raw publication evidence before a later parity assertion can throw. Retain an output fingerprint using a lossless representation or bounded lossless output, not ordinary JSON that erases own-undefined fields. The report currently persists no output or graph identity at all, despite doing those comparisons in memory. A failure must remain a failed falsification, not trigger repair-and-replay.

The outer report write correctly uses `wx`, preserves the original error when persistence fails and emits a secondary persistence field to stdout. Core primitive instrumentation is restored in `finally`. These existing protections should remain unchanged.

## 🔎 Construction and measurement assessment

The sole replacement is the qualified branch's tail construction. The full single-Enter predicate and append-contiguous offset checks remain in place, as do tiny-head folding, head construction, undo/fallback and final native JSONX composition. It takes only the last insert leaf of each qualified tail state, calls public `ActionIterator([leaf]).next(1)`, pushes through public TextX and retains the first absolute offset. It does not accidentally consume the original retain with `next(1)` or reinterpret offsets relative to the head. This is a legitimate question about repeated normalization/copying, not permission to weaken the guard.

One branch hit in each history/collaboration phase, exact phase order and complete raw publication equality are meaningful bypass negatives. Strict reductions of `textCompose`, `iteratorNext`, `bodySlices` and instrumented clone allocations in **both phases of every pair** prevent an aggregate win from hiding a phase regression. These are observed primitive counters, not total allocations, guard-inclusive cost, CPU time or GC measurements. `cloneVisits` is retained but not a separate reduction criterion. The one-shot counter wraps public ES Core methods and restores them after each call.

Using the same realm for both variants avoids a false prototype mismatch from separate VM realms and is reasonable for the hash-bound manager region. The source is trusted pinned local code; the external watchdog replaces the unused VM timeout. Both ES and CJS **manager syntax variants execute against imported ES Core** through the same context; hashing CJS Core does not mean its runtime was exercised. The result must disclose that boundary.

Raw service sinks preserve aliases instead of cloning them away. Combined input/output `ownDataShape()` tracks repeated-reference topology, own keys and descriptors, while the fixture checks input nonmutation, cleared caches and normal cleanup. Its prototype member is compared structurally by `assert.deepEqual`; it is not an explicit strict prototype-object identity proof, nor does it traverse prototype graphs through the same alias map. For these fully guarded plain-data captures this is not a separate execution blocker, but describe the evidence precisely rather than claiming arbitrary full prototype identity. No production prototype mutation is proposed.

## 🧪 Scope after repair

Once the two concrete corrections are read back on new exact script hashes, this remains a useful first, bounded lower-layer falsification. A pass can support only the already declared broader semantic/ownership counterexample matrix. It cannot prove normalization idempotence across every admitted metadata shape or substitute for missing/own-undefined/empty metadata, style, tail-length, short-head, unequal-cache, independent-call and unsupported-input controls.

No new persistent cache, generic composer or framework is needed. Operator gains a bounded mechanism test; Owner/Collaborator retain raw metadata/history and ownership requirements; Link guest authority is unchanged. The complete XL outcome remains unaccepted: prior inconclusive component criteria, failed resource/window observations and original latency violations remain preserved. This script grants no additional browser allowance, historical-cause claim, runtime-benefit claim or merge approval.

## 🔁 Repaired-script readback

Read builder `0aee34dccae2017ac853dcae520a1a2165458fe7630a999ba32b4be375ef70c7`, body `20ccb28b5fa9e3912f3da5ed8763ccfb907a3392b03780c5dc0ef116b3fd9ba6` and generated script `853db8b16ed5a9f17e5c15518727e4cc3e96ed4ac16700f9e867979944d2a3d0`, without execution.

Wrapper setup is now inside the fixture cleanup owner. Each variant is appended before its attempt, completed calls are separate, and its final counter/phase/branch observations survive exceptions. Successful combined input/output values are retained using bounded V8 serialization, exact bytes/hash and exclusive file creation; graph fingerprints explicitly require plain same-realm prototypes. ES-Core execution scope is disclosed. These resolve the original findings for normal returns and main-body failures.

**One small residual failure path remains before admission:** when `fixture.close()` is itself the first failure, it throws from `finally` after the main catch. Available publication arrays are therefore not captured, and the failed variant gets neither raw evidence nor an explicit unavailable marker. Reuse the bounded partial-publication capture in that cleanup-error branch; preserve the cleanup error as first cause and capture errors as secondary/unavailable. No extra execution or framework is needed. Main-body failure followed by cleanup failure already retains its first cause correctly.

## ✅ Final exact-script admission

Final readback: builder `92853ea8e5412622981b4176999a8f7ad946e41220eb0ce960fb09f31e3fc928`, unchanged body `20ccb28b5fa9e3912f3da5ed8763ccfb907a3392b03780c5dc0ef116b3fd9ba6`, generated executable `9d2ca7399d4f1d12c204587ac13b1ba1e9bcc9b103f6b15e1137ba7f1eab2c33`; repository HEAD remains `8b6828196266f1fac6c46e2cc16b16321db72cf7`.

The shared `capturePartial()` is bounded and idempotent, runs from both the main catch and cleanup catch, and preserves an existing capture or explicit unavailability without double-counting bytes. A cleanup-only failure now retains available publication evidence or marks it unavailable while remaining the first failure. Earlier body failures still take precedence over cleanup failure. The residual finding is resolved.

**No remaining concrete blocker found for exactly one declared, at-most-16-flush lower-layer falsification on these scripts**, through the existing serialized 60-second/2-GiB/normal-pressure guard. Stop on the first source, semantic, ownership, work-criterion or resource failure; retain it and do not renew the attempt. The exact per-phase strict counter criteria and all identity/output guards remain unchanged. This admission does not authorize a production edit, browser/runtime experiment, acceptance waiver or merge. No execution was performed by B; the original findings and intermediate identities above remain preserved.
