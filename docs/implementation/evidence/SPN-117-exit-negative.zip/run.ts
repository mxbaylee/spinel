import assert from 'node:assert/strict';
import { spawn, type ChildProcess } from 'node:child_process';
import { appendFileSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const root = '/tmp/spn117-negative-control';
const repository = '/workspace/scratch/662fdaf2c600/spinel-spn117';
const node = '/tmp/node-v26.12.1-linux-x64/bin/node';
const started = performance.now();
const manifest: Record<string, unknown> = {
  purpose: 'One intentional server-exit negative control; expected Playwright exit 1, zero retries.',
  node: process.version,
  started: new Date().toISOString(),
  maximumDurationMs: 120_000,
};
const persist = () => writeFileSync(join(root, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
persist();
const children = new Set<ChildProcess>();
const killOwned = (child: ChildProcess) => {
  if (child.pid && child.exitCode === null && child.signalCode === null) {
    // These detached process groups contain only children created by this probe.
    try { process.kill(-child.pid, 'SIGKILL'); } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ESRCH') throw error;
    }
  }
};
const deadline = setTimeout(() => {
  for (const child of children) killOwned(child);
  manifest.failure = '120-second negative-control deadline exceeded';
  persist();
  process.exit(1);
}, 120_000);

try {
  const appArgs = [
    '--max-old-space-size=512', '--max-semi-space-size=8',
    '--no-turbo-fast-api-calls', 'server/index.ts', '--dev', '--no-open',
  ];
  manifest.serverCommand = [node, ...appArgs];
  const env = {
    ...process.env,
    DATABASE_PATH: join(root, 'app.sqlite'),
    PORT: '0',
    HOST: '127.0.0.1',
    VITE_SYNC_EVIDENCE: '0',
    VITE_DOC_SELECTION_EVIDENCE: '0',
    VITE_DOC_RESPONSIVENESS_EVIDENCE: '0',
  };
  delete env.APP_ORIGIN;
  const app = spawn(node, appArgs, { cwd: repository, env, detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
  children.add(app);
  manifest.serverPid = app.pid;
  persist();
  let appOutput = '';
  app.stdout!.on('data', (chunk: Buffer) => {
    appOutput += chunk.toString();
    appendFileSync(join(root, 'server.stdout.log'), chunk);
  });
  app.stderr!.on('data', (chunk: Buffer) => appendFileSync(join(root, 'server.stderr.log'), chunk));
  const appClosed = new Promise<{ code: number | null; signal: NodeJS.Signals | null }>((resolve) => {
    app.once('close', (code, signal) => {
      const exit = { code, signal };
      manifest.serverExit = exit;
      persist();
      resolve(exit);
    });
  });
  const url = await new Promise<string>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Development server readiness timed out')), 30_000);
    app.once('error', reject);
    app.once('close', () => {
      clearTimeout(timer);
      reject(new Error('Development server exited before readiness'));
    });
    app.stdout!.on('data', () => {
      const match = appOutput.match(/Spinel is running at (http:\/\/[^\s]+)/);
      if (match) {
        clearTimeout(timer);
        resolve(match[1]);
      }
    });
  });
  manifest.readyUrl = url;
  const healthy = await fetch(`${url}/sign-in`, { signal: AbortSignal.timeout(10_000) });
  const body = await healthy.text();
  assert.equal(healthy.status, 200);
  assert.match(healthy.headers.get('content-type') ?? '', /text\/html/);
  assert.ok(body.includes('<div id="root">'));
  manifest.readinessRequest = { method: 'GET', path: '/sign-in', status: healthy.status, htmlCharacters: body.length };
  persist();

  manifest.intentionalSignal = 'SIGKILL';
  persist();
  killOwned(app);
  const appExit = await appClosed;
  assert.equal(appExit.code, null);
  assert.equal(appExit.signal, 'SIGKILL');

  const verifyArgs = [
    '--max-old-space-size=256', '--max-semi-space-size=8',
    join(repository, 'node_modules/@playwright/test/cli.js'),
    'test', '--config', join(root, 'playwright.config.ts'),
  ];
  manifest.verificationCommand = [node, ...verifyArgs];
  persist();
  const verification = spawn(node, verifyArgs, {
    cwd: repository, env: { ...process.env, SPN117_NEGATIVE_URL: url },
    detached: true, stdio: ['ignore', 'pipe', 'pipe'],
  });
  children.add(verification);
  verification.stdout!.on('data', (chunk: Buffer) => appendFileSync(join(root, 'verification.stdout.log'), chunk));
  verification.stderr!.on('data', (chunk: Buffer) => appendFileSync(join(root, 'verification.stderr.log'), chunk));
  const verificationExit = await new Promise<{ code: number | null; signal: NodeJS.Signals | null }>((resolve, reject) => {
    verification.once('error', reject);
    verification.once('close', (code, signal) => resolve({ code, signal }));
  });
  manifest.verificationExit = verificationExit;
  persist();
  assert.equal(verificationExit.code, 1);
  assert.equal(verificationExit.signal, null);
  const report = JSON.parse(readFileSync(join(root, 'playwright-report.json'), 'utf8'));
  const tests: Array<{ results: Array<{ retry: number; status: string; errors: Array<{ message: string }> }> }> = [];
  const walk = (suite: { specs?: Array<{ tests: typeof tests }>; suites?: unknown[] }) => {
    for (const spec of suite.specs ?? []) tests.push(...spec.tests);
    for (const child of suite.suites ?? []) walk(child as Parameters<typeof walk>[0]);
  };
  for (const suite of report.suites) walk(suite);
  assert.equal(tests.length, 1);
  assert.equal(tests[0].results.length, 1);
  const failed = tests[0].results[0];
  assert.equal(failed.retry, 0);
  assert.equal(failed.status, 'failed');
  assert.ok(failed.errors.some((error) => error.message.includes('ECONNREFUSED')));
  assert.equal(report.stats.unexpected, 1);
  assert.equal(report.stats.flaky, 0);
  manifest.verification = {
    expectedFailureObserved: true,
    testCount: tests.length,
    attemptCount: tests[0].results.length,
    retry: failed.retry,
    status: failed.status,
    errors: failed.errors.map((error) => error.message),
  };
  manifest.parentHarnessPassed = true;
  console.log(JSON.stringify(manifest.verification));
} catch (error) {
  manifest.parentHarnessPassed = false;
  manifest.failure = error instanceof Error ? error.stack : String(error);
  console.error(manifest.failure);
  process.exitCode = 1;
} finally {
  clearTimeout(deadline);
  for (const child of children) killOwned(child);
  manifest.elapsedMs = Math.round(performance.now() - started);
  manifest.finished = new Date().toISOString();
  persist();
}
