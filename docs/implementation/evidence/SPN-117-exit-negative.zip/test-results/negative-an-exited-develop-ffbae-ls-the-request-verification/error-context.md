# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: negative.spec.ts >> an exited development server fails the request verification
- Location: ../../../../tmp/spn117-negative-control/negative.spec.ts:3:5

# Error details

```
AggregateError: apiRequestContext.get: connect ECONNREFUSED ::1:32887
connect ECONNREFUSED 127.0.0.1:32887
Call log:
  - → GET http://localhost:32887/sign-in
    - user-agent: Playwright/1.64.1 (x64; ubuntu 24.04) node/26.12
    - accept: */*
    - accept-encoding: gzip,deflate,br

```