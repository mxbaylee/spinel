export default {
  testDir: '/tmp/spn117-negative-control',
  testMatch: 'negative.spec.ts',
  outputDir: '/tmp/spn117-negative-control/test-results',
  workers: 1,
  retries: 0,
  maxFailures: 1,
  timeout: 10_000,
  reporter: [
    ['line'],
    ['json', { outputFile: '/tmp/spn117-negative-control/playwright-report.json' }],
  ],
};
