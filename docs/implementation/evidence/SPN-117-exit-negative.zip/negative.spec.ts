import { test } from '/workspace/scratch/662fdaf2c600/spinel-spn117/node_modules/@playwright/test/index.mjs';

test('an exited development server fails the request verification', async ({ request }) => {
  // Intentionally uncaught: the negative control requires an actual failed test.
  await request.get(`${process.env.SPN117_NEGATIVE_URL}/sign-in`, {
    timeout: 5000,
    maxRetries: 0,
  });
});
