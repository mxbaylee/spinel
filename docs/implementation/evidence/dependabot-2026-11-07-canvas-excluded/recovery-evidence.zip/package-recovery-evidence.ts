import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { copyFileSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { basename, join, resolve } from 'node:path';
const root = resolve('../evidence');
const staging = join(root, 'recovery-archive');
const output = resolve('docs/implementation/evidence/dependabot-2026-11-07-canvas-excluded');
mkdirSync(staging, { recursive: true });
mkdirSync(output, { recursive: true });
const hash = (value: Buffer) => createHash('sha256').update(value).digest('hex');
const inventory = (directory: string): { path: string; bytes: number; sha256: string }[] => readdirSync(directory).sort().map((name) => {
  const bytes = readFileSync(join(directory, name));
  return { path: name, bytes: bytes.length, sha256: hash(bytes) };
});
const failures = [];
for (const attempt of [1, 2]) {
  const zip = join(root, `pr273-failed-doc-pdfs-attempt${attempt}.zip`);
  const names = execFileSync('unzip', ['-Z', '-1', zip], { encoding: 'utf8' }).trim().split('\n');
  assert(names.every((name) => !name.includes('/') && !name.includes('..')), 'Artifact must contain plain filenames');
  const extracted = join(root, `failed-doc-attempt${attempt}`);
  mkdirSync(extracted, { recursive: true });
  execFileSync('unzip', ['-o', '-qq', zip, '-d', extracted]);
  const records = inventory(extracted);
  const preserved = records.filter(({ path }) => /^(mixed-image-paragraph-|header-image-section-geometry-)/.test(path));
  const destination = join(staging, `failed-attempt${attempt}`);
  mkdirSync(destination, { recursive: true });
  for (const record of preserved) copyFileSync(join(extracted, record.path), join(destination, record.path));
  failures.push({ source: '6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce', run: 42339972597, attempt,
    job: attempt === 1 ? 128319772669 : 128336288557, artifact: attempt === 1 ? 13563204574 : 13565591779,
    originalZipSha256: hash(readFileSync(zip)), records, preservedAffectedFixtures: preserved,
  });
}
writeFileSync(join(staging, 'failed-artifact-inventories.json'), JSON.stringify(failures, null, 2) + '\n');
const local = [];
for (const relative of ['output/pdf/spn-101-candidate', 'output/pdf/spn-102']) {
  const files = inventory(resolve(relative));
  local.push({ directory: relative, source: '5255360f5ceef31673f2b48f1da9afe12aa7c6e2',
    pdfCount: files.filter((file) => file.path.endsWith('.pdf')).length,
    renderedPageCount: files.filter((file) => file.path.endsWith('.png')).length, files });
}
writeFileSync(join(staging, 'local-pdf-inventory.json'), JSON.stringify(local, null, 2) + '\n');
const fresh = join(staging, 'fresh-local-geometry');
mkdirSync(fresh, { recursive: true });
for (const name of readdirSync('output/pdf/spn-102').filter((name) => /^(mixed-image-paragraph-|header-image-section-geometry-)/.test(name))) {
  copyFileSync(join('output/pdf/spn-102', name), join(fresh, name));
}
copyFileSync('output/pdf/spn-102/mixed-image-paragraph-18-1.png', join(output, 'mixed-image-boundary.png'));
copyFileSync('output/pdf/spn-102/header-image-section-geometry-0-1.png', join(output, 'header-image-boundary.png'));
const retained = [
  'prior-pr-body.md', 'prior-recovery-comments.json', 'prior-baseline-refs.json', 'prior-artifacts.json',
  'failed-lib-attempt1.log', 'failed-lib-attempt2.log', 'baseline-preparation.json', 'final-integrity.json',
  'prepare-baselines.ts', 'final-integrity.ts', 'watchdog.ts', 'package-recovery-evidence.ts',
  ...['install', 'native-pdf', 'typecheck', 'lint', 'comparison-controls', 'backlog', 'final-wiring-typecheck', 'final-wiring-lint']
    .flatMap((name) => [`${name}.log`, `${name}.json`]),
];
for (const name of retained) copyFileSync(join(root, name), join(staging, basename(name)));
const readme = `# PR #273 Canvas-exclusion recovery evidence\n\nThis archive preserves historical failures and new local evidence separately.\nOriginal source: 6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce.\nRestored dependency/application source: 5255360f5ceef31673f2b48f1da9afe12aa7c6e2.\nFinal baseline wiring is recorded by final-integrity.json and comparison-controls.\nThe final reviewed and hosted identities are recorded in the PR description.\n\nfailed-attempt1/ and failed-attempt2/ contain all retained PDF/PNG outputs\nfrom the two failing fixtures in the corresponding hosted artifacts. Their\ncomplete original ZIP inventories/hashes are in failed-artifact-inventories.json.\nThe archive does not copy unrelated successful output from those failed runs.\n\nfresh-local-geometry/ contains the complete new output of those same fixtures.\nlocal-pdf-inventory.json inventories every PDF and rendered page produced by\nthe five-file focused local run; counts are generated files, not new test cases.\nThe other native PDFs are supplementary local outputs, not copied into this ZIP.\n\nBoth original failed job logs are retained unmodified. No old hosted pass or\nold review qualifies the new source; fresh hosted acceptance remains required.\nAll local workloads use the unchanged serial runner and 2 GiB / 8 minute limit.\n\nThe two original full Doc ZIPs were retrieved and matched their GitHub SHA-256\ndigests before extraction. Their original artifact IDs and digests remain here.\n`;
writeFileSync(join(staging, 'README.md'), readme);
execFileSync('zip', ['-q', '-r', join(output, 'recovery-evidence.zip'), '.'], { cwd: staging });
const summary = { archiveSha256: hash(readFileSync(join(output, 'recovery-evidence.zip'))),
  archiveBytes: readFileSync(join(output, 'recovery-evidence.zip')).length,
  failureFiles: failures.map(({ attempt, records, preservedAffectedFixtures }) => ({ attempt, inventoried: records.length, preserved: preservedAffectedFixtures.length })),
  local: local.map(({ directory, pdfCount, renderedPageCount }) => ({ directory, pdfCount, renderedPageCount })),
};
writeFileSync(join(root, 'recovery-archive-summary.json'), JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify(summary));
