import { spawn } from 'node:child_process';
import { appendFileSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';

const [prefix, command, ...args] = process.argv.slice(2);
if (!prefix || !command) throw new Error('Usage: watchdog.ts evidence-prefix command ...args');
if (process.version !== 'v26.13.0') throw new Error(`Unexpected runtime ${process.version}`);
const availableKiB = () => Number(readFileSync('/proc/meminfo', 'utf8').match(/^MemAvailable:\s+(\d+)/m)?.[1] ?? 0);
const initialAvailableKiB = availableKiB();
if (initialAvailableKiB < 2 * 1024 * 1024) throw new Error('Insufficient system memory headroom; workload not started');
const startedAt = new Date().toISOString();
const started = performance.now();
writeFileSync(`${prefix}.log`, '');
const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'] });
for (const stream of [child.stdout, child.stderr]) stream.on('data', (chunk: Buffer) => {
  appendFileSync(`${prefix}.log`, chunk);
  process.stdout.write(chunk);
});
let peakKiB = 0;
let minimumAvailableKiB = initialAvailableKiB;
let aborted: string | null = null;
let descendants = new Set<number>();
const known = new Set<number>();
function sample() {
  const rows = readdirSync('/proc').filter((name) => /^\d+$/.test(name)).flatMap((name) => {
    try {
      const status = readFileSync(`/proc/${name}/status`, 'utf8');
      return [[Number(name), Number(status.match(/^PPid:\s+(\d+)/m)![1]), Number(status.match(/^VmRSS:\s+(\d+)/m)?.[1] ?? 0)]];
    } catch { return []; }
  });
  descendants = new Set([process.pid]);
  let added = true;
  while (added) {
    added = false;
    for (const [pid, ppid] of rows) if (descendants.has(ppid) && !descendants.has(pid)) {
      descendants.add(pid); known.add(pid); added = true;
    }
  }
  const rss = rows.reduce((sum, [pid, , memory]) => sum + (descendants.has(pid) ? memory : 0), 0);
  peakKiB = Math.max(peakKiB, rss);
  minimumAvailableKiB = Math.min(minimumAvailableKiB, availableKiB());
  if (!aborted && (rss > 2 * 1024 * 1024 || performance.now() - started > 480000 || minimumAvailableKiB < 2 * 1024 * 1024)) {
    aborted = rss > 2 * 1024 * 1024 ? 'process tree exceeded 2 GiB' : minimumAvailableKiB < 2 * 1024 * 1024 ? 'system memory pressure' : 'eight minute deadline';
    // The direct child is scripts/serial.ts; its handler kills its task-owned process group.
    child.kill('SIGTERM');
    for (const pid of descendants) if (pid !== process.pid && pid !== child.pid) {
      try { process.kill(pid, 'SIGTERM'); } catch {}
    }
  }
}
const timer = setInterval(sample, 100);
child.on('error', (error) => { aborted = String(error); });
child.on('close', (code, signal) => {
  clearInterval(timer);
  const evidence = { startedAt, finishedAt: new Date().toISOString(), node: process.version,
    cwd: process.cwd(), command, args, elapsedMs: Math.round(performance.now() - started),
    limitKiB: 2 * 1024 * 1024, deadlineMs: 480000, sampleIntervalMs: 100,
    initialAvailableKiB, minimumAvailableKiB, peakKiB, observedProcesses: known.size,
    code, signal, aborted };
  writeFileSync(`${prefix}.json`, JSON.stringify(evidence, null, 2) + '\n');
  process.stdout.write(JSON.stringify(evidence) + '\n');
  process.exit(aborted ? 75 : code ?? 1);
});
