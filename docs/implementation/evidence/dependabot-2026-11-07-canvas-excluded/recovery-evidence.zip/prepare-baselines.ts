import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';

const git = (...args: string[]) => execFileSync('git', args, { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
const hash = (text: string) => createHash('sha256').update(text).digest('hex');
const paths = git('ls-tree', '-r', '--name-only', 'HEAD').trim().split('\n').filter((path) => /^(package.json|lib\/[^/]+\/package.json)$/.test(path));
assert.equal(paths.length, 8);
const keys = ['dependencies', 'devDependencies', 'peerDependencies', 'optionalDependencies', 'peerDependenciesMeta', 'overrides'];
const maps = (manifest: Record<string, unknown>) => Object.fromEntries(keys.map((key) => [key, manifest[key] ?? null]));
const lock = readFileSync('package-lock.json', 'utf8');
const candidateLock = JSON.parse(lock);
const acceptedLock = JSON.parse(git('show', 'origin/main:package-lock.json'));
const canvasRecords = Object.keys(candidateLock.packages).filter((path) => path.includes('node_modules/@napi-rs/canvas'));
assert.equal(canvasRecords.length, 12);
for (const path of canvasRecords) assert.deepEqual(candidateLock.packages[path], acceptedLock.packages[path], path);
const candidateRoot = JSON.parse(readFileSync('package.json', 'utf8'));
assert.equal(candidateRoot.devDependencies['@napi-rs/canvas'], '1.0.11');
assert.equal(candidateRoot.devDependencies['@storybook/react-vite'], '10.6.5');
assert.equal(candidateRoot.devDependencies['@types/node'], '26.6.6');
assert.equal(candidateRoot.dependencies['@aws-sdk/client-s3'], '3.1161.0');
assert.equal(readFileSync('.nvmrc', 'utf8').trim(), '26.13.0');
assert.equal(candidateRoot.scripts.postinstall.split(' && ').length, 5);
const definitions = [
  { name: 'responsiveness', parent: 'b21979c3fdb78e3736d7ded0f7b91f44d45e5968', ref: 'ci-baseline/doc-responsiveness-canvas-excluded-2026-11-07' },
  { name: 'callback', parent: 'dd6b3f397ea89c9eb024fcbe9f52d77b865d45d4', ref: 'ci-baseline/doc-callback-canvas-excluded-2026-11-07' },
];
const inputs = definitions.map((definition) => {
  const contents: Record<string, string> = {};
  for (const path of ['package.json', 'lib/print/package.json']) {
    const before = git('show', `${definition.parent}:${path}`);
    assert.equal(before.split('"@napi-rs/canvas": "1.1.0"').length, 2);
    contents[path] = before.replace('"@napi-rs/canvas": "1.1.0"', '"@napi-rs/canvas": "1.0.11"');
    const original = JSON.parse(before);
    const changed = JSON.parse(contents[path]);
    for (const key of keys) { delete original[key]; delete changed[key]; }
    assert.deepEqual(changed, original, `${definition.name} nondependency fields in ${path}`);
  }
  contents['package-lock.json'] = lock;
  for (const path of paths) {
    const baseline = JSON.parse(contents[path] ?? git('show', `${definition.parent}:${path}`));
    assert.deepEqual(maps(baseline), maps(JSON.parse(readFileSync(path, 'utf8'))), `${definition.name}: ${path}`);
  }
  assert.equal(JSON.parse(contents['package.json']).scripts.postinstall.split(' && ').length, 3);
  return { ...definition, baseTree: git('rev-parse', `${definition.parent}^{tree}`).trim(), contents };
});
writeFileSync('../evidence/baseline-inputs.json', JSON.stringify(inputs));
writeFileSync('../evidence/baseline-preparation.json', JSON.stringify({
  originalHead: git('rev-parse', 'HEAD').trim(), base: git('rev-parse', 'origin/main').trim(),
  candidateLockSha256: hash(lock), manifestPaths: paths, canvasRecords,
  candidatePostinstall: candidateRoot.scripts.postinstall,
  baselines: inputs.map(({ name, parent, ref, baseTree, contents }) => ({ name, parent, ref, baseTree,
    files: Object.entries(contents).map(([path, content]) => ({ path, sha256: hash(content) })),
    historicalPostinstall: JSON.parse(contents['package.json']).scripts.postinstall,
    allManifestMapsMatch: true, nondependencyManifestFieldsPreserved: true,
  })),
}, null, 2) + '\n');
console.log(JSON.stringify({ manifestCount: paths.length, canvasRecords: canvasRecords.length, candidateLockSha256: hash(lock), baselines: inputs.map(({ name, parent, ref }) => ({ name, parent, ref })) }));
