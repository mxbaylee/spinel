# PR #273 Canvas-exclusion recovery evidence

This archive preserves historical failures and new local evidence separately.
Original source: 6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce.
Restored dependency/application source: 5255360f5ceef31673f2b48f1da9afe12aa7c6e2.
Final baseline wiring is recorded by final-integrity.json and comparison-controls.
The final reviewed and hosted identities are recorded in the PR description.

failed-attempt1/ and failed-attempt2/ contain all retained PDF/PNG outputs
from the two failing fixtures in the corresponding hosted artifacts. Their
complete original ZIP inventories/hashes are in failed-artifact-inventories.json.
The archive does not copy unrelated successful output from those failed runs.

fresh-local-geometry/ contains the complete new output of those same fixtures.
local-pdf-inventory.json inventories every PDF and rendered page produced by
the five-file focused local run; counts are generated files, not new test cases.
The other native PDFs are supplementary local outputs, not copied into this ZIP.

Both original failed job logs are retained unmodified. No old hosted pass or
old review qualifies the new source; fresh hosted acceptance remains required.
All local workloads use the unchanged serial runner and 2 GiB / 8 minute limit.

The two original full Doc ZIPs were retrieved and matched their GitHub SHA-256
digests before extraction. Their original artifact IDs and digests remain here.
