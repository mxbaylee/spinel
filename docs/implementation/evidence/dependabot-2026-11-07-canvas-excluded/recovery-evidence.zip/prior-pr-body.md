## What changes

Combine the four compatible updates that Dependabot opened after [#268](https://github.com/mxbaylee/spinel/pull/268) landed. That earlier integration already landed Storybook core 10.6.5, the grouping policy, the narrow restore HTTP observer correction and bounded memory-refusal diagnostics. This follow-up starts from its squash commit `757ab68e3146845f501773f7abfafe45c034e15f`.

**Reviewed candidate:** `6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce`  
**Tree:** `4316acf8771217166f06b256851e4dd9b49dde63`  
**Base:** `757ab68e3146845f501773f7abfafe45c034e15f`

| Superseded after landing | Update | Separate preparation commit |
| --- | --- | --- |
| #269 | `@storybook/react-vite` 10.6.2 → 10.6.5, aligning the renderer/builder/DOM shim with core | `971f3269193282767963c3b7c9ef44573c59dd5f` |
| #270 | `@types/node` 26.6.5 → 26.6.6, retaining Node 26.13.0 | `358fb75ec0d60c65b23b4371df52b3e94dd472a5` |
| #271 | `@napi-rs/canvas` 1.0.11 → 1.1.0 in root and print workspace, with all platform packages | `25ea51e27620c4a3a48d9aad4b46d84cc6476f56` |
| #272 | `@aws-sdk/client-s3` 3.1160.0 → 3.1161.0 and its AWS/Smithy transitive updates | `0770dbefaec0c1500230f8403779b2800129d5b1` |

The final preparation commit aligns historical comparison inputs and retains the decision/evidence record. The four updates have disjoint dependency-field changes; all 44 changed installed-package records, plus root and print-workspace records, are retained. No new dependency family, application feature, guard relaxation or test skip is introduced.

[Maintained decision and verification contract](https://github.com/mxbaylee/spinel/blob/6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce/docs/implementation/dependabot-2026-11-07.md).

## How it was verified

### Local evidence

Node **26.13.0**, the repository serial runner, and the unchanged **2 GiB / eight-minute process-tree watchdog** were used. Local preparation `be82b4c30c358db6558ecb7ddc44351ff2cbaac9` and GitHub preparation `0770dbefaec0c1500230f8403779b2800129d5b1` have identical dependency/application tree `2a84ee73c0b643879b87b1377fd93e29d6daaf32`. Subsequent source changes only pin the new historical SHAs and add the evidence record. Local final commit `93336c9a5a4b894e8428047fd47ba09fd7d08cae` and the reviewed GitHub commit have identical final tree `4316acf8771217166f06b256851e4dd9b49dde63`.

| Check | Observed result | Time | Peak process-tree RSS |
| --- | --- | --- | --- |
| Clean `npm ci` | Passed, 499 packages; all five guarded Univer patchers passed | 15.147 s | 1,284,036 KiB |
| Native Sheet, Doc and PDF geometry tests | 34/34 tests, three files, no failures/skips | 47.227 s | 962,612 KiB |
| Strict typecheck after baseline wiring | Passed | 7.025 s | 2,011,540 KiB |
| Dependency boundary, lint and format | Passed; no Pro dependencies in eight manifests or lock | 25.770 s | 816,184 KiB |
| Callback comparison, responsiveness and CI-plan controls | 66/66 tests, no failures/skips | 1.223 s | 450,524 KiB |
| Backlog | Passed, 23 open tickets; existing nonblocking length/grooming notices | 0.792 s | 326,936 KiB |
| PR shape against `origin/main`, using this exact title | Passed | 0.794 s | 335,480 KiB |
| Diff whitespace and baseline integrity | Passed | — | — |

[Durable local evidence ZIP](https://github.com/mxbaylee/spinel/blob/6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce/docs/implementation/evidence/dependabot-2026-11-07/local-evidence.zip) contains installation/native/type/lint/control logs, watchdog measurements, both visual-review receipts, full page/output inventories and hashes, and the baseline-integrity audit. ZIP SHA-256: `7f5e7c4d730bacbeaa25b4b2877051649e2c1da34206b509207a90e77d04b27f`. Backlog/PR-shape results are recorded above. Scratch paths in receipts identify the original review context, not permanent download links.

### Matching historical comparisons

| Comparison | Historical parent | New dependency-only source | Retention ref |
| --- | --- | --- | --- |
| Doc responsiveness | `6ee50161c9eeeb7296ffb282d7ae52abd9e61d1b` | `b21979c3fdb78e3736d7ded0f7b91f44d45e5968` | `ci-baseline/doc-responsiveness-dependabot-2026-11-07` |
| Doc callback lifetimes | `48dc8d4698129d5c7748ff2dac3b5d18cb0bcd6b` | `dd6b3f397ea89c9eb024fcbe9f52d77b865d45d4` | `ci-baseline/doc-callback-dependabot-2026-11-07` |

Each historical descendant changes exactly `package.json`, `lib/print/package.json` and `package-lock.json`. All eight root/workspace dependency maps match the candidate; both complete locks are byte-identical to it, SHA-256 `58b5f0766a2ca79c7fca32eaba8b486b40151e6c759e2e17fcbbc3ecb2e35e43`. Historical nondependency manifest fields are unchanged, including **three** original postinstall patchers; main's additional two patchers are not copied backward. Existing application behavior, workloads, permitted overlays, attribution checks, sample counts, first-attempt policy and budgets remain intact. The two prior #268 retention refs remain preserved.

This also addresses an observed failure on the unintegrated S3 PR: [#272 run 42337619628](https://github.com/mxbaylee/spinel/actions/runs/42337619628), desktop responsiveness job `128299141511` and callback job `128299141491`, failed baseline `npm ci` with `EUSAGE` because candidate lock `@aws-sdk/client-s3@3.1161.0` was overlaid onto the historical manifest pinned to `3.1160.0`. No browser comparison ran there. The new immutable baseline commits supply matching manifest inputs without changing historical application source.

### Hosted acceptance contract — pending at opening

This is a new dependency set. Earlier #268 green results and local checks do **not** qualify it for merge. Keep the PR draft until this exact reviewed source passes:

- All seven required gates: **Backlog, Pull request, Lint, Typecheck, Unit tests, Lib tests, Playwright smoke**.
- Every worker selected by the immutable CI plan, including production/development browser shards, native synchronization/permissions, phone owner coverage, both historical comparisons and first-attempt sized restore.
- Storybook build plus all selected rendering/state/interaction views; desktop Chrome/Firefox/Safari native persistence and restart acceptance.
- Actual DigitalOcean Spaces backup/catalog/restore and cleanup. A Dependabot missing-secret availability probe is not accepted as provider validation.
- Fresh hosted native PDF artifacts, complete worker/result identities, no missing selected work or hidden flaky/retried pass.

Source/shared-dependency and workflow routing remain broad. No changes to retries, `failOnFlakyTests`, workloads, memory/CPU/PID/swap limits, timeouts, resource guards, completeness/cropping assertions, cleanup or access boundaries. If a selected worker fails, preserve its first failure and investigate; no blind rerun, budget increase or skipped check is authorized.

The unintegrated #269/#271 Storybook aggregates also rejected cancelled classification/build jobs. Those inspected failures do not show a rendered assertion failure; they are not acceptance evidence. This PR must execute its own complete selected Storybook run.

## Designs and screenshots

**No product UI or design change. Agent review only.** Canvas changes its default text renderer, so its actual print output received focused visual compatibility review. The existing native fixture assertions cover text measurement, PDF geometry, font isolation, complete content, continuation, resource failure and cleanup. No renderer-mode override or test weakening was needed.

Nonimplementing reviewer `new_canvas_compat` inspected **26 fresh Sheet PDFs / all 39 pages**, with original-size page sheets and enlarged text/seam details. Nonimplementing reviewer `remaining_compatibility` inspected **43 fresh Doc PDFs / all 115 pages**, plus six selected pages independently rendered with Poppler. All source output hashes remained unchanged. Both report no unexpected clipping, missing glyph/content, broken image continuation, unexplained blank page, margin artifact or watermark. Sparse pages, native image gaps and the deliberately split tall glyph match their test contracts.

The reviewed render source is `be82b4c30c358db6558ecb7ddc44351ff2cbaac9`, equivalent to preparation tree `2a84ee73c0b643879b87b1377fd93e29d6daaf32`; rendering inputs and application source are unchanged at the final candidate. The fixtures were generated **2026-11-07 04:24:49–04:25:36 UTC**. This is fixture review, not a pixel comparison with Canvas 1.0.11, cross-platform proof, physical-print validation or a hosted result.

<details>
<summary>Five unchanged, commit-pinned example pages</summary>

**Sheet faces, color, underline and fallback glyphs — 595 × 842 page pixels.**

![Sheet font faces and fallback glyphs](https://raw.githubusercontent.com/mxbaylee/spinel/6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce/docs/implementation/evidence/dependabot-2026-11-07/sheet-rich-fonts.png)

**Sheet wrapping — complete text through “final sentinel.”**

![Complete wrapped Sheet text](https://raw.githubusercontent.com/mxbaylee/spinel/6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce/docs/implementation/evidence/dependabot-2026-11-07/sheet-wrapped-text.png)

**Doc faces, heading and nested list — 450 × 525 page pixels.**

![Doc heading, font faces and nested list](https://raw.githubusercontent.com/mxbaylee/spinel/6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce/docs/implementation/evidence/dependabot-2026-11-07/doc-rich-fonts.png)

**Doc long-text tail — page 18 retains `PARA-067` through `PARA-069`.**

![Last Doc paragraph page](https://raw.githubusercontent.com/mxbaylee/spinel/6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce/docs/implementation/evidence/dependabot-2026-11-07/doc-long-text-tail.png)

**Doc image continuation — final blue band and following sentinel.**

![Doc image continuation tail](https://raw.githubusercontent.com/mxbaylee/spinel/6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce/docs/implementation/evidence/dependabot-2026-11-07/doc-image-continuation-tail.png)

</details>

## Independent review

Two independent, nonimplementing reviewers assessed the complete committed candidate before the first validation push. Neither received the other's score or a desired result. Both reviewed exact source **`6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce`**, tree **`4316acf8771217166f06b256851e4dd9b49dde63`**, against base **`757ab68e3146845f501773f7abfafe45c034e15f`**.

| Reviewer | Scope /35 | Correctness, data and access /25 | Evidence /20 | CI/operations /10 | Maintainability and complexity /10 | Total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `followup_review_a` | 35 | 25 | 19 | 9 | 10 | **98/100** |
| `followup_review_b` | 35 | 25 | 20 | 10 | 10 | **100/100** |

**Reviewer A:** no blocking implementation findings. Independently reconstructed the exact conflict-free four-PR lock union, verified changed dependency/peer/engine ranges, both dependency-only historical descendants and eight manifest maps, wiring and fail-closed gates, the 18-member evidence archive and all 223 original PDF/PNG inventory hashes. Personally inspected the five durable PNGs. Deductions: one evidence point because synthetic Canvas fixture review does not include a direct old/new pixel comparison; one operations point because the new historical descendants still require hosted install/build and conclusive observations. These are disclosed evidence limits, with no identified source defect. Full hosted acceptance remains a merge requirement. Three source-PR SHA transcription typos in the external receipt were corrected before publication; the reviewed source, findings and score did not change.

**Reviewer B:** no deductions, blocking findings or actionable implementation findings. Independently reviewed the complete source/lock diff, repository rules/personas, public dependency API/peer contracts, baseline ancestry and exact three-file scope, preserved historical scripts, CI selection/aggregation, local receipts, all 18 archived members and all 160 original Doc-output hashes. Personally inspected and byte-verified the five durable PNGs. Confirmed the old S3 manifest/overlaid-lock mismatch and its dependency-only repair. Did not claim personal inspection of every PDF page or rerun heavy tests.

**Over-complexity:** both found none. Immutable dependency-only descendants and small source-reference edits are proportional to the reproduced baseline installation failure; no alternate resolver, speculative abstraction or guard bypass was added. No unresolved reviewer blocker remains. These are pre-push reviews, **not hosted passes or permission to merge before acceptance**. Any source/base change requires revalidation on the new exact candidate.

## Split out and decided

- **Caddy #238 remains open and excluded.** Run `41489208790`, job `125428711693`, first post-restore member startup failed generically before content/offline assertions. Its retry did not establish the rejected boot stage or exception; Caddy causation remains unproved. Capture bounded boot stage/exception evidence with a first-failure trace and a deliberate negative control, then resolve the observed cause. Stale-branch bookkeeping is not that repair.
- **Univer #240 remains open and excluded.** Its current rebased head `60dbe37d71ade271f65dc44c235ca7a4ab7dc71a` still fails with core 1.3.1 against `@spinel/presence-ui`'s exact 1.1.0 peer: [run 42338254627 / job 128299975151](https://github.com/mxbaylee/spinel/actions/runs/42338254627/job/128299975151), `npm ci` / `ERESOLVE`. Some other peers were advanced or widened by the bot, but the remaining exact peers and five guarded SDK patchers still require explicit migration work. #223 / SPN-099 removes a core patch while retaining 1.1.0, so it is related prerequisite work, not completed 1.3.1 compatibility.
- **Original main memory refusal remains preserved.** [Run 42329786250 / job 128273632235](https://github.com/mxbaylee/spinel/actions/runs/42329786250/job/128273632235) reported `restore-prep-planned-candidate-reconcile-memory-headroom`. The original artifact is preserved by #268; its later memory snapshot did not establish the exact rejecting sample. The bounded diagnostics and unchanged guard remain in place. No historical cause or OOM kill is inferred from a later passing candidate.
- **Future grouping is already on main.** Related minor/patch families, isolated coordinated Univer groups, separate other majors, existing security handling and schedules/cooldowns stay unchanged by this follow-up.

The candidate has **12 changed files, 401 insertions / 231 deletions**, including the shared lock and six binary evidence files; **172 counted text lines** after the repository's lockfile exclusion. Scope is one coherent dependency cohort plus the comparison/evidence work necessary to validate it. No backlog ticket is introduced under the dependency-title exception. All four personas and their tradeoffs are recorded in the maintained decision: patched and recoverable operations; complete Owner exports; stable Collaborator editing/access; immediate document-scoped Link guest revocation.

## Run checkpoint

Branch `codex/dependabot-followup-2026-11-07`, source `6d73d8dcc9a63904bbd1c8d299eb3e7799cea8ce`, base `757ab68e3146845f501773f7abfafe45c034e15f`. #268 is merged; #242 is closed after landing. The four new bot PRs remain open until this candidate lands. Local preparation is complete; the independent reviews above precede the first validation push. Hosted runs/plan/result identities, measurements, first-failure dispositions, the tested merge tree and final landing identity will be recorded after actual acceptance. The final evidence update may itself trigger a post-merge metadata run; that run does not substitute for the acceptance that qualified the merged source.
