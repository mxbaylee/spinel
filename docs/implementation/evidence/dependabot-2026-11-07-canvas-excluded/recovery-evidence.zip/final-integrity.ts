import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
const git = (...args: string[]) => execFileSync('git', args, { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 }).trimEnd();
const show = (ref: string, path: string) => execFileSync('git', ['show', `${ref}:${path}`], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
const hash = (text: string) => createHash('sha256').update(text).digest('hex');
const base = '757ab68e3146845f501773f7abfafe45c034e15f';
const candidateText = readFileSync('package-lock.json', 'utf8');
const candidate = JSON.parse(candidateText);
const baseLock = JSON.parse(show(base, 'package-lock.json'));
const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);
const changed = (a: typeof candidate, b: typeof candidate) => [...new Set([...Object.keys(a.packages), ...Object.keys(b.packages)])].filter((path) => path !== '' && !same(a.packages[path], b.packages[path])).sort();
const sources = [
  { pr: 269, head: '971f3269193282767963c3b7c9ef44573c59dd5f' },
  { pr: 270, head: 'bf718aa9ef0d71e4afda501e637207df830ebcc7' },
  { pr: 272, head: '3d1b01701a017df39ae655b5fd7228b905ad4c2b' },
];
const union = new Set<string>();
const contributions = sources.map((source) => {
  const lock = JSON.parse(show(source.head, 'package-lock.json'));
  const paths = changed(baseLock, lock);
  for (const path of paths) {
    assert(!union.has(path), `Unexpected overlap: ${path}`);
    union.add(path);
    assert.deepEqual(candidate.packages[path], lock.packages[path], `${source.pr}: ${path}`);
  }
  return { ...source, changedInstalledRecords: paths };
});
assert.equal(union.size, 32);
assert.deepEqual(changed(baseLock, candidate), [...union].sort());
assert.equal(readFileSync('lib/print/package.json', 'utf8'), show(base, 'lib/print/package.json'));
const manifestPaths = git('ls-tree', '-r', '--name-only', base).split('\n').filter((path) => /^(package.json|lib\/[^/]+\/package.json)$/.test(path));
const keys = ['dependencies', 'devDependencies', 'peerDependencies', 'optionalDependencies', 'peerDependenciesMeta', 'overrides'];
const maps = (value: Record<string, unknown>) => Object.fromEntries(keys.map((key) => [key, value[key] ?? null]));
const baselines = [
  { name: 'responsiveness', parent: 'b21979c3fdb78e3736d7ded0f7b91f44d45e5968', head: 'e4d361f0ce3c08d4a1e80b000e29f2c2f28f6670' },
  { name: 'callback', parent: 'dd6b3f397ea89c9eb024fcbe9f52d77b865d45d4', head: 'f609961e4a2460bae0feedb62cedd722af270e86' },
].map((source) => {
  assert.equal(git('rev-parse', `${source.head}^`), source.parent);
  assert.deepEqual(git('diff', '--name-only', source.parent, source.head).split('\n'), ['lib/print/package.json', 'package-lock.json', 'package.json']);
  assert.equal(show(source.head, 'package-lock.json'), candidateText);
  for (const path of manifestPaths) {
    const before = JSON.parse(show(source.parent, path));
    const after = JSON.parse(show(source.head, path));
    assert.deepEqual(maps(after), maps(JSON.parse(readFileSync(path, 'utf8'))));
    for (const key of keys) { delete before[key]; delete after[key]; }
    assert.deepEqual(after, before);
  }
  assert.equal(JSON.parse(show(source.head, 'package.json')).scripts.postinstall.split(' && ').length, 3);
  assert(readFileSync('.github/workflows/ci.yml', 'utf8').includes(`ref: ${source.head}`));
  return { ...source, tree: git('rev-parse', `${source.head}^{tree}`), manifestMaps: manifestPaths.length, lockSha256: hash(candidateText), preservedHistoricalScripts: true, onlyThreeDependencyFilesChanged: true };
});
assert(readFileSync('scripts/ci/doc-callback-comparison.ts', 'utf8').includes(baselines[1].head));
const unchangedTests = ['lib/print/doc-multiple-images.test.ts', 'lib/print/doc-story-geometry.test.ts'];
for (const path of unchangedTests) assert.equal(readFileSync(path, 'utf8'), show(base, path));
const record = { base, dependencyPreparation: '5255360f5ceef31673f2b48f1da9afe12aa7c6e2', candidateLockSha256: hash(candidateText),
  contributions, exactly32InstalledRecordChanges: true, printManifestEqualsMain: true, unchangedTests, baselines,
  priorRefs: JSON.parse(readFileSync('../evidence/prior-baseline-refs.json', 'utf8')),
};
writeFileSync('../evidence/final-integrity.json', JSON.stringify(record, null, 2) + '\n');
console.log(JSON.stringify({ manifestMaps: manifestPaths.length, installedRecords: union.size, lockSha256: hash(candidateText), baselines: baselines.map(({ name, head }) => ({ name, head })) }));
