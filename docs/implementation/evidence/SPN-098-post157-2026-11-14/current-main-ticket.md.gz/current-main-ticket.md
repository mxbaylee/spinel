---
id: SPN-098
emoji: 📨
effort: L
impact_owner: M
impact_collaborator: M
impact_operator: M
score: 22
depends_on: []
decisions: []
---

# 📨 SPN-098 Send user feedback with diagnostic context

## Story

As the [Owner](../product/personas.md#owner) or Collaborator, I want to send feedback from Spinel with relevant diagnostic context, so that the Operator can discover and reproduce issues without me assembling a separate report.

## Scenarios

### Send feedback

Given I am signed in with an everyday account,
When I submit a short feedback message,
Then it is persisted as a feedback event in the shared diagnostics store with verified user identity, authorized file context when present, route template and correlation/build metadata,
And success appears only after persistence; failure keeps my draft and allows retry without duplicate reports.

### Compare a report with the same period of system activity

Given stored feedback belongs to an account,
When the Operator opens the admin user list,
Then the accessible feedback flag offers **Download user metrics** and **Download system metrics** without displaying report text or document details,
And the downloads contain all retained user-attributed rows and all system rows respectively, from one snapshot and the same displayed server-receipt-time span.

### Clear feedback deliberately

Given stored feedback and diagnostic observations,
When the Operator confirms Truncate diagnostics,
Then feedback is deleted along with logs and the flags refresh to reflect remaining/new records; cancellation changes nothing.

## Rules

- Required validation on candidate `2204b8c4` failed the named supervisor scenarios. Retain the [first failure, successful comparator and causal uncertainty](../implementation/SPN-157.md#-retained-first-failure-and-comparator). SPN-157's [full-contract audit disposition](../implementation/SPN-157.md#-full-contract-audit-disposition-and-conditional-landing) accepts bounded non-recurrence with historical cause unknown; it does not claim causal repair or replace this ticket's own current-head reviews and gates. Its exact feedback-source native evidence is retained in the audit. Agent decision, 2026-11-14; dependency removal is conditional on SPN-157 landing.

- PR #227 remains draft pending fresh feedback-source validation. SPN-135 supplies a guarded native-work mitigation and complete idle-path acceptance; its historical failure remains valid and causally unattributed. Integrate the landed repair and retain fresh feedback-source validation plus this ticket’s independent reviews/CI before merge. [Completed prerequisite evidence](../implementation/SPN-135.md#current-candidate-acceptance-and-retained-failure-disposition), agent judgment following independent review, 2026-11-02.

- Follow [sustainable testing](../testing.md); keep the Verify plan and progress evidence current. [Policy](../implementation/SPN-115.md#guidance-for-every-open-ticket-and-progress-checkpoint), owner 2026-11-01.

- Effort L, full-scope review 2026-10-29: Estimate the durable feedback flow and both complete, consistent exports together. Prove paired snapshot/window completeness, temporary-space bounds and expiry/truncate/revocation behavior before UI expansion; no inbox or general analytics/query service. [All-ticket assessment](../implementation/grooming-2026-10-29.md#all-ticket-effort-and-impact-review).

- Owner direction, chat 2026-10-22; [decisions and privacy boundaries](../implementation/SPN-098.md). This is a separate consumer of SPN-032, not an expansion of the collaboration protocol.
- Add the [two scoped exports](../implementation/SPN-098.md#paired-user-and-system-downloads), owner chat 2026-10-29. The default span covers all retained rows attributed to that user, including feedback; the user export includes frontend and attributed backend rows, while the system export includes every actor and unattributed system row within that same span. Preserve full rows, not aggregates.
- Reuse the diagnostics store and one immutable snapshot watermark/generation for both downloads. Include window, counts and known collection/drop/retention limits; no silent truncation. Expired context stays unavailable; an empty user selection does not authorize an unrelated system-wide export. Retain bounded preparation/transfer, Operator/session/generation rechecks, cancellation and cleanup.
- A flag means stored feedback exists, not unread or unresolved status. Keep the UI to its two download actions and truthful state; no query panel, inbox or remote SQL endpoint. Downloads remain Operator-only, including system rows attributed to other users.
- Explicitly submitted feedback text is allowed; never attach document text, formulas, screenshots, titles, secrets or raw URLs automatically. Tell the sender their message and page context go to the server Operator. Server derives actor identity and verifies file access; no user impersonation or everyday-account reads of another user's feedback.
- A submission is acknowledged only after durable storage. Bound message size/rate and handle storage limits with a visible failure, preserving the draft; never silently drop feedback under the best-effort log policy. Idempotent retry cannot duplicate a report or resurrect a report deleted by truncation.
- Confirm truncation deletes feedback as well as logs and cannot be undone. A successful clear removes pre-clear buffered/retried reports and resets flags; newly submitted reports can make flags appear again. Failed flag loading is unknown, not evidence of no reports.
- Submitted feedback survives SPN-110's observation TTL, while remaining subject to explicit truncation; its old metrics need not survive. Preserve flags, durable acknowledgments and generation fencing in either implementation order. New instrumentation and TTL remain separate tickets; this ticket exports what was actually collected.
- Use the [admin handoff](../design/admin.md#user-feedback-handoff-spn-098), existing controls and [production stories](../implementation/storybook-production-migration.md#migrate-stories-with-their-ui-tickets). Keep keyboard/touch, draft, pending, failure, empty/expired context and cancellation states; independent light/dark/phone review remains required. L effort reflects the coordinated durable-feedback and paired-export boundaries; do not expand into a feedback-management system.

## Out of scope

- Anonymous/Link guest feedback, automatic content capture, attachments, replies, notifications, resolution/read tracking, an in-product agent, arbitrary time-range queries and a feedback inbox/viewer.

## Verify

- Extend `src/server/diagnostics/` store/routes fixtures for durable idempotence, authorization and paired snapshot membership; use controlled receipt times and isolated accounts. Reuse `e2e/diagnostics.spec.ts` patterns for failed-draft retention and actual downloads, waiting for persistence and closing download/snapshot resources.
- Integration owns boundary/race/TTL cases; browser coverage owns the user and Operator flows. Track diagnostics/auth, snapshot/export, retention and fixture dependencies in routing; retain exact exported row/window metadata and failure cleanup evidence without real feedback or secrets.

- Unit: durable/idempotent submissions, identity/access, limits and truncate races; exact user/system membership, receipt-time boundaries, shared snapshot/watermark, ingestion/TTL between downloads, empty or old-feedback-only spans, explicit export failure and cleanup. Other users' rows appear only in the Operator's system export.
- Browser: submit as Owner/Collaborator, retain a failed draft, download both artifacts from the Operator's user flag and compare their rows/window/metadata, expire context, truncate and refresh flags, reject unauthorized reads/mutations. Review production stories in light/dark/phone; leave no owned obsolete example.
