# 🔬 SPN-143 read-only capability checkpoint

Prepared while SPN-142 adc86fc8 validation is queued. SPN-143 registration has
not landed; no implementation, local trace parsing/compression benchmark,
browser execution or diagnostic workflow has been performed for SPN-143.

## Observed authority and evidence

The retained failed baseline completed behavior348.004s and awaited
Tracing.tracingComplete until the420s deadline. No baseline raw stream exists.
The actual fixture creates the completion promise before Tracing.end, so the
retained source does not show a simple late-listener race. Its unresolved event
promise has no abort/closed-session rejection; owned CDP/fixture cleanup is in a
later finally reached only after collection settles. This is an observed
ownership gap, not proof that it caused the protocol delay.

Pinned Chromium156.0.8078.4 source was fetched read-only from Gitiles (the web
reader could not open the tag, but raw format=TEXT succeeded). SHA256SUMS pins
local decoded copies; original BSD headers remain. In tracing_handler.cc End,
ReturnAsStream+gzip creates a compressed endpoint with background priority.
The compressed endpoint queues compression/finalization on a sequenced
BEST_EFFORT task runner, uses default zlib compression, and forwards final
completion after deflate finalization. Only then does OnTraceToStreamComplete
emit the protocol event. Therefore browser-side compression is one concrete
stage on the event's critical path; the failure journal does not isolate that
stage from source flush/JSON conversion/scheduling.

Sources:
- https://chromium.googlesource.com/chromium/src/+/refs/tags/156.0.8078.4/content/browser/devtools/protocol/tracing_handler.cc
- https://chromium.googlesource.com/chromium/src/+/refs/tags/156.0.8078.4/content/browser/tracing/tracing_controller_impl_data_endpoint.cc
- https://chromedevtools.github.io/devtools-protocol/tot/Tracing/

The already accepted2b mobile pair has589390098/596624241 uncompressed trace
bytes (candidate/baseline), compressed30799811/32556712 bytes; completion waits
91.492/86.669s before~0.52/0.56s stream reads and~9.47/9.81s parsing. These are
existing-run descriptive observations, not a causal benchmark or new execution.
Exact source events827928/960994 are retained. See accepted-pair-phases.json;
its source is the archived accepted pair, not the failed baseline's absent trace.

## Candidate question, not a selected repair

Could preserving ReturnAsStream/full JSON/categories/workload/buffer/throttle but
requesting uncompressed protocol transport, then compressing losslessly in a
bounded Node pipeline, remove the browser's background compression wait without
weakening capture or attribution? Protocol transport compression is separate
from measurement categories/content. Any proposal must distinguish protocol
completion compression from persisted artifact compression and hash both raw
transport and stored bytes; never label locally compressed bytes as the original
browser gzip. Preserve existing420s acceptance and all baseline/candidate caps.
A larger transferred payload/storage/CPU cost must be counted, bounded and
measured, not hidden. Every event, malformed stream, metadata/trailer and exact
source artifact must retain current validation.

Separately, completion wait/stream/output and fixture cleanup need explicit
ownership on abort/failure. Deadline interruption cannot leave an unresolved
event promise preventing owned cleanup or replace the primary failure. Normal
successful collection/cleanup must finish within the unchanged acceptance
budget; post-failure cleanup may not turn a timed-out test into a pass. Reuse
existing helpers/hooks rather than introducing a general lifecycle framework.

Next after registration lands: independently assess this bounded hypothesis;
if admitted, prospectively declare one finite diagnostic that discriminates
compression from remaining flush/serialization cost and verifies owned cleanup,
with exact baseline/candidate source and limits. Do not run an unchanged assertion
or select a production transport change based only on the above source inspection.
No probe specification or execution is authorized by this note alone.

## Additional source-derived constraints

Current retainDocCallbackTrace records a progress event for each1MiB IO.read.
A~600MB raw transport could therefore overflow the existing128-event journal,
even though the gzip path needs only~30 chunks. Any transport probe/candidate must
preserve bounded, useful phase/first-failure evidence and final byte count without
dropping the initial behavioral phases merely because transport compression
changes. This is a concrete integration constraint, not permission to enlarge the
journal unboundedly or remove progress evidence. Reuse the existing observer.

The pinned handler's Disable path stops/resets an active tracing session. Public
client cleanup still needs explicit CDP/context ownership and bounded settlement;
this internal observation is not proof that every outstanding stream disappears
on detach or that JavaScript continuation cleanup ran. Known handles require one
owned close; late handle behavior, listener removal, pending writes/compressor
settlement and fixture closure need deterministic failure controls before native
validation. Never use Promise.race alone to abandon live owned work.

The comparator currently derives retained-file decompression directly from
trace.completion.streamCompression. A transport/storage split must change that
explicitly and fail closed on missing/mismatched provenance, not merely rename
the file or change a constant. Recompute raw byte length/hash from the stored
artifact after decompression and retain complete envelope/event validation and
analysis equality. Current source/trace hashes and source-attribution kinds remain
mandatory. This is additional read-only dependency accounting, not implementation.
