import { createReadStream, createWriteStream } from 'node:fs';
import { writeFile, rm } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { Transform, Writable } from 'node:stream';
import { pipeline, finished } from 'node:stream/promises';
import { createGunzip, createGzip } from 'node:zlib';
import assert from 'node:assert/strict';

const root = '/tmp/spn143-probe';
const output = `${root}/stored.json.gz`;
const started = performance.now();
const owned: Array<ReturnType<typeof createReadStream> | Transform | Writable> = [];
const counters: Record<string, { bytes: number; sha256?: string }> = {};
const signal = AbortSignal.timeout(120_000);
function measured(name: string, limit: number) {
  const state = { bytes: 0, sha256: undefined as string | undefined };
  counters[name] = state;
  const hash = createHash('sha256');
  const stream = new Transform({
    highWaterMark: 64 * 1024,
    transform(chunk, _encoding, callback) {
      state.bytes += chunk.length;
      if (state.bytes > limit) return callback(new Error(`${name} exceeds declared byte bound`));
      hash.update(chunk);
      callback(null, chunk);
    },
    flush(callback) { state.sha256 = hash.digest('hex'); callback(); },
  });
  owned.push(stream);
  return stream;
}
function keep<T extends (typeof owned)[number]>(stream: T): T { owned.push(stream); return stream; }
let failure: unknown;
let cleanupError: unknown;
let ownsOutput = false;
let compressedAt = 0;
try {
  const destination = keep(createWriteStream(output, { flags: 'wx', highWaterMark: 64 * 1024 }));
  destination.once('open', () => { ownsOutput = true; });
  await pipeline(
    keep(createReadStream(`${root}/input.json.gz`, { highWaterMark: 64 * 1024 })),
    measured('originalGzip', 32_556_712),
    keep(createGunzip({ chunkSize: 64 * 1024 })),
    measured('receivedRaw', 768 * 1024 * 1024),
    keep(createGzip({ level: 1, chunkSize: 64 * 1024 })),
    measured('storedGzip', 128 * 1024 * 1024),
    destination,
    { signal },
  );
  compressedAt = performance.now();
  assert.equal(counters.originalGzip.bytes, 32_556_712);
  assert.equal(counters.originalGzip.sha256, '5e4eb36be8be53658a70b7997c1bc5a5cd28fe14d0c5730884ebbbdddf343e08');
  assert.equal(counters.receivedRaw.bytes, 596_624_241);
  await pipeline(
    keep(createReadStream(output, { highWaterMark: 64 * 1024 })),
    keep(createGunzip({ chunkSize: 64 * 1024 })),
    measured('decodedStoredRaw', 768 * 1024 * 1024),
    keep(new Writable({ write(_chunk, _encoding, callback) { callback(); } })),
    { signal },
  );
  assert.deepEqual(counters.decodedStoredRaw, counters.receivedRaw);
  assert.ok(owned.every((stream) => stream.destroyed && stream.closed), 'Every owned stream settled/closed');
} catch (error) {
  failure = error;
  for (const stream of owned) stream.destroy();
  await Promise.allSettled(owned.map((stream) => finished(stream, { cleanup: true })));
  if (ownsOutput) {
    try { await rm(output, { force: true }); }
    catch (error) { cleanupError = error; }
  }
}
const result = {
  outcome: failure ? 'failed' : 'passed', node: process.version,
  totalMs: performance.now() - started,
  recompressMs: compressedAt ? compressedAt - started : null,
  counters, allStreamsClosed: owned.every((stream) => stream.destroyed && stream.closed),
  ownsOutput, cleanupError: cleanupError ? String(cleanupError) : null,
  failure: failure ? String(failure) : null,
  limits: 'One retained full trace; streaming losslessness/local feasibility only. No Chromium/CDP/native timing or historical cause established.',
};
await writeFile(`${root}/result.json`, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
if (failure) process.exitCode = 1;
