# 📡 SPN-143 — historical callback trace completion

## Registration and scope

**2026-11-04 · Registration only; no implementation or acceptance claimed ·
agent judgment under the owner's request to continue SPN-120 repair.**

An overlooked closed-PR body edit triggered CI 41899145584 attempt 1 for accepted
SPN-134 event head `97b0db550385b51cdbc8f0543aaa21524c1e05dc`. Actual candidate
checkout was squash `13b74ecea5f2552627ff638be9413ad4754ef581`; both have tree
`dfeb3d10b8367f2edf331a0bfc76bc8a2ac70a9b`. Mobile callback job 126816804086 failed
its pair: baseline timed out at420046.4 ms, candidate passed. Artifact 13359363775
has original ZIP SHA256
`dab3dbf42fd5cbb8c2f90b796636d3a61b608f1f948e06f40cf3c3ffeae0b463`.
Baseline is immutable `0e1df4725d9eccb77574d25e3eecdf678fe6ff44`.

SPN-134's diagnostic contract worked. All16 paragraphs/2086 inputs completed;
native content, caret, zoom and application route-disposal assertions passed.
Behavior completed 348004.1 ms, Tracing.end returned by 348013.8 ms, then the journal
remained at trace-completion until the420000 ms overall deadline. The awaited
operation was `Tracing.tracingComplete`, approximately72032.6 ms later. There is
no baseline stream, completed attribution/source collection, CDP detach or
fixture-cleanup completion evidence. Ordinary route disposal does not establish
owned fixture cleanup. Missing comparator fields do not demonstrate actual browser
errors, trace-data loss or product-data loss. Why Chromium had not delivered the
event is unknown; typing's share of the deadline is descriptive, not causal.

The old failed pair stays failed. SPN-134's declared validation41891902390 and
SPN-142's declared first candidate 41916623281 retain their independently complete
pairs; neither repairs this recurrence. No unchanged assertion retry is authorized.
Earlier uninstrumented failures retain their original unknown interrupted operation;
this new phase localization cannot be projected backward onto them.

### 🧭 Outcome, alternatives and personas

Keep this independent **XL** outcome separate from SPN-142's native composition,
SPN-141's L storage and SPN-140's L constructor work. Scope includes trace protocol
and deadline investigation, justified collection/cleanup implementation, deterministic
negative controls, exact native attribution/behavior proof, resource ownership,
full hosted acceptance and integration into blocked PRs. A small eventual diff
would not reduce the uncertainty/verification estimate. SPN-134 completed bounded
diagnostics, not a guarantee of historical collection reliability. Reopening its
completed diagnostic contract or silently attaching this to storage would hide
the remaining work. Register the follow-up in the current SPN-142 PR as allowed by
process.md; implementation may start only after this registration reaches main.

SPN-141 waits on **both SPN-142 and SPN-143**, then SPN-140 and SPN-120 retain
fresh integrated acceptance. Closing SPN-142 removes only its own dependency.
Current SPN-142 callback gates must still pass; this owner cannot waive a failure
on its future candidate. Registering this ticket completes no repair or launch
prerequisite. Do not count shared progress instrumentation twice.

Operator gains bounded, trustworthy evidence and accountable cleanup; Owner and
Collaborator keep complete editing/history/content and unchanged callback budgets;
Link guest keeps prompt access revocation and the same selected access checks.
All four favor a concrete investigation over chance reruns, a larger budget,
smaller workload, weaker trace categories or accepting an incomplete baseline.

### 🔬 First capability checkpoint and verification plan

First inspect the retained source, phase journal and trace completion/stream
lifecycle without another browser execution. Establish who owns each listener,
CDP session, stream, output and fixture, and how the overall deadline interrupts
them. Identify one supported, discriminating hypothesis before choosing any native
probe. Record source/instrumentation, finite count/budget, stop condition and
owned cleanup prospectively; reassess scope if the boundary requires architecture
or a different protocol. No probe or solution is selected by this registration.

Reuse `e2e/doc-responsiveness-callback-trace.ts`, progress/source helpers and the
existing callback spec. Extend `scripts/ci/doc-callback-trace.test.ts`, progress,
source and comparison controls only for meaningful contracts. Fail closed for
missing/late completion, incomplete streams, parse/source failure, cancellation
and unconfirmed cleanup; preserve the original failure when cleanup also fails.
Retain desktop/mobile paired owners and source/shared-dependency selection in the
existing CI plan and aggregates. Do not add a parallel blanket benchmark.

Acceptance needs the unchanged immutable baseline/full workload/trace categories,
callback caps, content/caret/zoom/disposal and access boundaries, original budgets,
first attempts and complete source/trace/cleanup evidence. New code needs feasible
local checks, two independent exact-head scores above95, and all selected current
CI gates. Diagnostic/profile runs cannot substitute for acceptance. Final PR or
maintained evidence preserves exact identities, first failures, reviews and
limitations; transient artifacts only supplement them.

### 📦 Durable first-failure evidence

[Immutable failed pair, progress/terminal records, source/trace package, useful
synthetic failure screenshots and independent disposition](https://github.com/mxbaylee/spinel/tree/67aef6cb7e4d2a58b778a8ab36c1cb8a82d1007f/docs/review-assets/spn-142-first-candidate-2b173b29/receipt-runs)
retain46 byte/hash-verified non-SQLite callback members, including the complete
candidate trace and built sources/maps. No baseline trace existed to preserve.
Only disposable fixture database files were omitted. The archive also retains
the accepted2b callback pairs separately, with their limitations; they cannot
turn this failed pair into a pass. Independent agent review inspected the native
My files screenshot/context as evidence of route disposal, not cleanup completion.

## 🔬 Capability checkpoint: lossless local transport storage

**2026-11-04 · Prospective, before execution · agent judgment.** Registration
landed in SPN-142 squash `eb32117f5d09c28cd411063256db6d645335ae8a`.
Read-only inspection found the completion listener is installed before Tracing.end,
but has no cancellation/session-close settlement. Later owned cleanup can remain
unreached while that event is pending. This is an ownership gap, not a proven
cause of Chromium's delay.

Pinned Chromium156.0.8078.4 [handler](https://chromium.googlesource.com/chromium/src/+/refs/tags/156.0.8078.4/content/browser/devtools/protocol/tracing_handler.cc)
and [endpoint](https://chromium.googlesource.com/chromium/src/+/refs/tags/156.0.8078.4/content/browser/tracing/tracing_controller_impl_data_endpoint.cc)
show gzip finalization on a BEST_EFFORT sequenced runner before the completion
event is delivered. Compression is one dependency; producer flush, serialization,
scheduling and event delivery remain uncertain. The existing accepted2b mobile
baseline had596624241 raw bytes,32556712 gzip bytes and86.669s completion wait.
Those observations belong to another successful capture, not the absent failed trace.

Declare exactly **one** local feasibility probe on that immutable baseline trace,
retained in archive `67aef6cb7e4d2a58b778a8ab36c1cb8a82d1007f`, original gzip SHA256
`5e4eb36be8be53658a70b7997c1bc5a5cd28fe14d0c5730884ebbbdddf343e08`.
The question is whether a bounded Node pipeline can losslessly store this complete
raw byte stream, not whether gzip caused the old timeout. On Node26.12.1, stream
the existing gzip through gunzip, raw SHA256/count, gzip level1, stored SHA256/count
and an exclusively created file; then stream-decode that file and require identical
raw hash/count. No whole-trace buffering or event parsing. All input/output/zlib
streams use64KiB chunks/backpressure. Limits:120s total, normal memory pressure,
2GiB combined process tree under the existing serialized watchdog,768MiB raw and
128MiB output. Stop on the first mismatch, truncation, resource or cleanup failure;
retain it, delete failed partial output, and authorize no automatic second sample.
Script SHA256 before execution:
`63398b41875dff37399fee0b7fa08106635c9b16a7b983afb27d2d42a50dbd8d`.

A pass admits a narrow candidate for uncompressed protocol transport with explicit
local gzip storage provenance, bounded progress and owned interruption/cleanup.
It establishes neither browser timing nor overall native feasibility. Existing
selected desktop/mobile historical-pair CI owns actual CDP transfer, total cost,
complete source attribution and the unchanged420s deadline on the reviewed candidate.
No separate native diagnostic workflow or repeated assertion run is added. A failed
pair stops acceptance. Reviewer B independently accepted this separation of local
capability from native acceptance; source authority and local feasibility do not
claim historical causality.

Before validation, extend existing lowest-layer controls for lossless Unicode/chunk
boundaries, explicit raw/stored hashes and format agreement, missing/late completion,
known/late stream handles, stream/parse failures, cancellation and first-error-preserving
cleanup. Keep the128-event journal bounded without losing early phases to roughly
600 raw1MiB reads. Reuse existing helper/spec/comparator and CI selection. No new
product behavior, generic lifecycle framework, reduced trace categories, timeout
extension or acceptance waiver. Operator benefits from accountable collection;
Owner/Collaborator retain content/history/callback contracts; Link guest retains
unchanged access verification. Full outcome remains XL.

Reviewer A caught an exclusive-output ownership bug before execution: EEXIST must
not delete a pre-existing file, cleanup failure must not hide the first failure,
and destroyed streams must settle/close before unlink. The revised probe records
exclusive-open ownership, awaits closure and retains secondary cleanup errors.
An external watchdog kill requires inspecting and cleaning this probe’s known
partial output after process termination; no JavaScript cleanup is assumed then.
No probe has run at this checkpoint.
