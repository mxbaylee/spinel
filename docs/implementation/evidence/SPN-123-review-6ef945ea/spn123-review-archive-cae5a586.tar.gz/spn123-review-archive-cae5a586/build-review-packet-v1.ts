import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { gunzipSync } from 'node:zlib';
const root=process.cwd();
const head='cae5a58689b049e4f62c3a815482e21bb5212f49';
const base='c525aa933505d6e78b8fdd7a89940d87506d5cb3';
const out='/tmp/spn123-review-packet-cae5a586';
const archive='/tmp/spn123-review-archive-cae5a586';
const git=(...args:string[])=>execFileSync('git',args,{encoding:'utf8',maxBuffer:64*1024*1024});
if(git('rev-parse','HEAD').trim()!==head||git('status','--porcelain').trim()) throw Error('Source must be exact and clean');
mkdirSync(out,{recursive:true});mkdirSync(archive,{recursive:true});
const hash=(data:string|Buffer)=>createHash('sha256').update(data).digest('hex');
const changed=new Set(git('diff','--no-renames','--name-only',base,head).trim().split('\n'));
const contexts=new Set([
 'docs/run-backlog.md','docs/todo/process.md','docs/product/personas.md','docs/testing.md','docs/development.md',
 'docs/implementation/README.md','docs/implementation/backlog-workflow.md','docs/implementation/grooming-2026-10-29.md',
 'docs/implementation/grooming-2026-11-02.md','docs/implementation/grooming-2026-11-14.md',
 ...['098','110','115','140','141','144','146','149','157','160'].map(id=>`docs/implementation/SPN-${id}.md`),
 'docs/implementation/SPN-157-contract-audit.md',
]);
const policies=new Set(['AGENTS.md','docs/run-backlog.md','docs/todo/process.md','docs/implementation/backlog-workflow.md']);
function blind(text:string, path:string):string {
 if(policies.has(path)) return text;
 let rubricTable=false;
 return text.split('\n').map(line=>{
  if(/^\s*[+ -]?\|/.test(line)&&/Reviewer.*(?:Scope|Correctness|Maintainability)|(?:Scope|Correctness).*Maintainability/i.test(line)) rubricTable=true;
  else if(!/^\s*[+ -]?\|/.test(line)) rubricTable=false;
  if(rubricTable) line=line.replace(/(?<=\|)[^|]*\d[^|]*(?=\|)/g,' [historical assessment withheld] ');
  return line
   .replace(/\b\d{1,3}\s*\/\s*100\b/g,'[historical assessment withheld]')
   .replace(/\b(?:35\/35|25\/25|20\/20|10\/10)\b/g,'[assessment component withheld]')
   .replace(/\b(scope|correctness|regression|workflow(?:\/operations)?|operations|operational usability|maintainability)\s*[:=]?\s*(35|25|20|10)\b/gi,'$1 [assessment component withheld]')
   .replace(/\b([AB])\s*(100|9[0-9])\b/g,'$1 [historical assessment withheld]')
   .replace(/\b(both|to)\s*100\b/g,'$1 [historical assessment withheld]')
   .replace(/\*\*100\*\*/g,'**[historical assessment withheld]**')
   .replace(/((?:scored?|grades?|assessment|rating)[^\n\d]{0,30})(?:100|[6-9][0-9])\b/gi,'$1[historical assessment withheld]')
   .replace(/(grades?)\s*\d{2}(?:\/\d{2})+/gi,'$1 [historical assessments withheld]')
   .replace(/\b(UI|UX|proposal-maintainability|maintainability)\s*(?:[:=]\s*)?(?:100|[6-9][0-9])\b/g,'$1 [historical assessment withheld]')
   .replace(/\b\d{1,2}(?:\/\d{1,2}){3,4}(?:\/\[assessment component withheld\])?/g, value=>value.split('/').filter(x=>/^\d+$/.test(x)).every(x=>+x<=35)?'[historical rubric vector withheld]':value);
 }).join('\n');
}
const files:any[]=[];const omitted:any[]=[];const decoded:any[]=[];
for(const row of git('ls-tree','-rlz',head).split('\0').filter(Boolean)){
 const match=/^\d+ blob ([a-f0-9]+)\s+(\d+)\t(.+)$/s.exec(row);if(!match)continue;
 const [,blob,size,path]=match;
 const selected=!path.startsWith('docs/')||changed.has(path)||contexts.has(path)||path.startsWith('docs/todo/');
 if(!selected){omitted.push({path,blob,size:+size,reason:'unchanged contextual documentation/evidence; request an assessment-free copy if needed'});continue;}
 const data=readFileSync(join(root,path));
 if(createHash('sha1').update(`blob ${data.length}\0`).update(data).digest('hex')!==blob)throw Error('Blob mismatch '+path);
 const binary=data.includes(0)||/\.(?:gz|zip|png|webp|jpg|jpeg|pdf|bundle|mp4|woff2?|ico)$/.test(path);
 if(binary){
  omitted.push({path,blob,size:+size,sha256:hash(data),reason:'original binary/archive retained; inventory only, never prior numerical report input'});
  if(path.endsWith('.gz')&&path.includes('SPN-123')){
   const text=gunzipSync(data).toString('utf8');
   let copy=blind(text,path);
   if(path.endsWith('spn123-pr220-original.json.gz')){
    // Keep prior PR findings and identities readable, without passing its raw JSON-escaped body.
    const source=JSON.parse(text);const parts:string[]=[];
    function collect(v:any){if(v&&typeof v==='object')for(const [k,x]of Object.entries(v)){if((k==='body'||k==='description')&&typeof x==='string')parts.push(x);else if(k==='text'&&typeof x==='string'){try{collect(JSON.parse(x));}catch{}}else collect(x);}}
    collect(source);copy=blind(parts.join('\n\n'), 'prior-pr-body.md');
   }
   const dest='decoded-evidence/'+path.slice('docs/implementation/evidence/'.length).replace(/\.gz$/,'')+(path.endsWith('.json.gz')?'.txt':'');
   mkdirSync(dirname(join(out,dest)),{recursive:true});writeFileSync(join(out,dest),copy);
   decoded.push({path,destination:dest,archiveSha256:hash(data),originalDecodedSha256:hash(text),copySha256:hash(copy)});
  }
  continue;
 }
 const text=data.toString('utf8');
 const mask=path.startsWith('docs/')&&!/\.(?:ts|tsx)$/.test(path)||path.endsWith('.md');
 const copy=mask?blind(text,path):text;
 const dest=join(out,'source',path);mkdirSync(dirname(dest),{recursive:true});writeFileSync(dest,copy);
 files.push({path,blob,originalSha256:hash(data),copySha256:hash(copy),masked:copy!==text});
}
const originalDiff=git('diff','--no-renames','--full-index',base,head);
writeFileSync(join(archive,'candidate.original.diff'),originalDiff);
const diff=originalDiff.split(/(?=^diff --git )/m).map(chunk=>{
 const path=/^diff --git a\/(.*?) b\/(.*?)\n/.exec(chunk)?.[2]??'';
 return path.startsWith('docs/')&&!/\.(?:ts|tsx)$/.test(path)||path.endsWith('.md')?blind(chunk,path):chunk;
}).join('');
writeFileSync(join(out,'candidate.diff'),diff);
const ticket=git('show',`${base}:docs/todo/SPN-123.md`);writeFileSync(join(out,'base-ticket.md'),ticket);
const extras=['spn123-final-policy.ts','spn123-final-policy.log','spn123-final-policy.json','spn123-final-policy-v2.ts','spn123-final-policy-v2.log','spn123-final-policy-v2.json','spn123-final-policy-v2-result.json'];
for(const name of extras){const data=readFileSync('/tmp/spinel-dependabot-2026-11-11/'+name);mkdirSync(join(out,'postcommit-evidence'),{recursive:true});writeFileSync(join(out,'postcommit-evidence',name),data);}
writeFileSync(join(archive,'pr220.original.json'),readFileSync('/tmp/spinel-dependabot-2026-11-11/spn123-pr220-original.json'));
const manifest={head,base,tree:git('rev-parse','HEAD^{tree}').trim(),files,decoded,omitted,originalDiffSha256:hash(originalDiff),copyDiffSha256:hash(diff),baseTicketSha256:hash(ticket),policy:'Executable source is exact. Historical numerical assessments masked only in external documentation copies. Original binary archives inventoried, relevant gzip logs decoded and masked. All originals remain untouched. Manual scan required.'};
writeFileSync(join(out,'source-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
writeFileSync(join(archive,'source-manifest.original-copy.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({out,archive,files:files.length,masked:files.filter(x=>x.masked).map(x=>x.path),decoded:decoded.length,omitted:omitted.length}));
