import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { gunzipSync } from 'node:zlib';
const root=process.cwd();
const head='6ef945eae3168da7f3706088dc7c2b78fad39cd5';
const base='ec42f0741415e4e712395fb47c30b911bc4e64ea';
const out='/tmp/spn123-review-packet-6ef945ea';
const archive='/tmp/spn123-review-archive-6ef945ea';
const git=(...args:string[])=>execFileSync('git',args,{encoding:'utf8',maxBuffer:64*1024*1024});
if(git('rev-parse','HEAD').trim()!==head||git('status','--porcelain').trim()) throw Error('Source must be exact and clean');
mkdirSync(out,{recursive:true});mkdirSync(archive,{recursive:true});
const hash=(data:string|Buffer)=>createHash('sha256').update(data).digest('hex');
const changed=new Set(git('diff','--no-renames','--name-only',base,head).trim().split('\n'));
const contexts=new Set([
 'docs/run-backlog.md','docs/todo/process.md','docs/product/personas.md','docs/testing.md','docs/development.md',
 'docs/implementation/README.md','docs/implementation/backlog-workflow.md','docs/implementation/grooming-2026-10-29.md',
 'docs/implementation/grooming-2026-11-02.md','docs/implementation/grooming-2026-11-14.md',
 ...['098','110','115','140','141','144','146','149','157','160'].map(id=>`docs/implementation/SPN-${id}.md`),
 'docs/implementation/SPN-157-contract-audit.md',
]);
const policies=new Set(['AGENTS.md','docs/run-backlog.md','docs/todo/process.md','docs/implementation/backlog-workflow.md']);
function blind(text:string, path:string):string {
 if(policies.has(path)||path==='.github/pull_request_template.md'||path.startsWith('docs/todo/')) return text;
 let rubricTable=false;
 return text.split('\n').map(line=>{
  if(/^\s*[+ -]?\|/.test(line)&&/Reviewer.*(?:Scope|Correctness|Maintainability)|(?:Scope|Correctness).*Maintainability/i.test(line)) rubricTable=true;
  else if(!/^\s*[+ -]?\|/.test(line)) rubricTable=false;
  if(rubricTable) line=line.split('|').map(cell=>/^\s*\*{0,2}\d{1,3}(?:\/\d{1,3})?\*{0,2}\s*$/.test(cell)?' [historical assessment withheld] ':cell).join('|');
  if (/Scope.*acceptance|Correctness|Regression confidence|Meaningful regression|Delivered workflow|Workflow and usability|Maintainability/i.test(line))
    line=line.replace(/\b\d{1,2}\/(?:35|25|20|10)\b/g,'[historical component assessment withheld]');
  if (/Source-review deductions:/i.test(line)) line=line.replace(/one point/g,'[historical point allocation withheld]').replace(/and one for/g,'and [historical point allocation withheld] for');
  line=line.replace(/\b(Deduct)\s+\d+\b/gi,'$1 [historical point allocation withheld]')
    .replace(/\b\d+\s+(correctness|regression)\s+points\b/gi,'[historical point allocation withheld] $1 points');
  if (/Points recoverable/i.test(line)) line=line.replace(/[+]\d+|\b\d+\b/g,'[historical point allocation withheld]');
  return line
   .replace(/\b\d{1,2}(?:\/\d{1,2}){4}\b/g, value=>value.split('/').every(x=>+x<=35)?'[historical rubric vector withheld]':value)
   .replace(/(grades?)\s*\d{2}(?:\/\d{2})+/gi,'$1 [historical assessments withheld]')
   .replace(/(?<!\d)\d{1,3}\s*\/\s*100\b/g,(value, offset)=>/above\s*|at least\s*/i.test(line.slice(Math.max(0,offset-12),offset))?value:'[historical assessment withheld]')
   .replace(/\b([AB])\s*(100|[1-9][0-9])\b/g,'$1 [historical assessment withheld]')
   .replace(/\b(UI|UX|proposal-maintainability|maintainability)\s*(?:[:=]\s*)?(?:100|[1-9][0-9])\b/g,'$1 [historical assessment withheld]')
   .replace(/((?:scored|graded|regraded|rating|assessment|grades?)[^\n\d]{0,30})(100|[1-9][0-9])\b/gi,(whole,prefix)=>/above|at least|threshold/i.test(prefix)?whole:prefix+'[historical assessment withheld]');
 }).join('\n');
}

const original=git('diff','--no-renames','--full-index','cae5a586',head);
const copy=original.split(/(?=^diff --git )/m).map(chunk=>{
 const path=/^diff --git a\/(.*?) b\/(.*?)\n/.exec(chunk)?.[2]??'';
 return path.startsWith('docs/')&&!/\.(?:ts|tsx)$/.test(path)||path.endsWith('.md')?blind(chunk,path):chunk;
}).join('');
writeFileSync(join(out,'review-delta.diff'),copy);
writeFileSync(join(out,'delta-manifest.json'),JSON.stringify({from:'cae5a58689b049e4f62c3a815482e21bb5212f49',to:head,originalSha256:hash(original),copySha256:hash(copy),masked:original!==copy},null,2)+'\n');
