import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import { coveragePlan, suiteIds, verifyCoverage } from './plan.ts';
const base = 'a'.repeat(40),
  head = 'b'.repeat(40);
const pr = (action = 'synchronize', labels: string[] = [], changes?: unknown) => ({
  action,
  changes,
  pull_request: {
    base: { sha: base },
    head: { sha: head },
    labels: labels.map((name) => ({ name })),
  },
});
const all = (plan: ReturnType<typeof coveragePlan>) =>
  Object.fromEntries(suiteIds.map((id) => [id, plan.suites[id].selected ? 'success' : 'skipped']));

test('every PR edit runs full validation, including title/body, base and ambiguous payloads', () => {
  for (const changes of [
    { title: { from: 'Old title' } },
    { body: { from: null } },
    { title: { from: '' }, body: { from: '' } },
    { base: { ref: { from: 'main' } } },
    { title: { from: 'Old' }, base: {} },
    undefined,
    {},
    [],
    { title: {} },
    { title: { from: null } },
    { body: { from: '', surprise: true } },
    { unknown: { from: '' } },
  ]) {
    for (const paths of [['docs/notes.md'], ['src/server/auth/session.ts'], null]) {
      const plan = coveragePlan('pull_request', pr('edited', [], changes), paths, head);
      assert.equal(plan.mode, 'full');
      assert.ok(suiteIds.every((id) => plan.suites[id].selected));
      // A later text edit must revalidate rather than hide failed base/code evidence.
      assert.throws(
        () =>
          verifyCoverage(
            plan,
            'success',
            {
              ...all(plan),
              'doc-responsiveness': 'failure',
            },
            suiteIds,
          ),
        /Incomplete coverage/,
      );
    }
  }
});

test('service changes keep candidate correctness and all existing broad checks without historical comparisons', () => {
  const plan = coveragePlan('pull_request', pr(), ['src/server/auth/passkeys.ts']);
  for (const id of [
    'typecheck',
    'unit-tests',
    'playwright-run',
    'container-smoke',
    'sync-transition',
    'doc-responsiveness',
    'doc-callback-lifetimes',
  ] as const)
    assert.equal(plan.suites[id].selected, true, id);
  assert.equal(plan.suites['responsiveness-baseline'].selected, false);
  assert.equal(plan.suites['callback-baseline'].selected, false);
  assert.equal(plan.suites['lib-test-run'].selected, false);
  assert.equal(plan.suites['phone-compatibility'].selected, false);
});

test('the opt-in SPN-146 A/B stays tested without widening to full or performance coverage', () => {
  const experiment = [
    '.github/workflows/patch-ab.yml',
    'scripts/ci/patch-ab/toggle.ts',
    'scripts/ci/patch-ab/summarize.ts',
    'scripts/ci/patch-ab.test.ts',
  ];
  const plan = coveragePlan('pull_request', pr(), experiment, head);
  assert.equal(plan.mode, 'targeted');
  for (const id of ['unit-tests', 'lint', 'typecheck'] as const)
    assert.equal(plan.suites[id].selected, true, id);
  for (const id of [
    'restore-timing',
    'responsiveness-baseline',
    'callback-baseline',
    'lib-test-run',
    'phone-compatibility',
  ] as const)
    assert.equal(plan.suites[id].selected, false, id);
  // Each experiment path alone, including the workflow file, still runs the script tests, lint and typecheck.
  for (const path of experiment) {
    const alone = coveragePlan('pull_request', pr(), [path], head);
    assert.equal(alone.mode, 'targeted', path);
    for (const id of ['unit-tests', 'lint', 'typecheck'] as const)
      assert.equal(alone.suites[id].selected, true, `${path} ${id}`);
  }
  // Neighbouring workflow and CI script paths keep their full-coverage rule.
  for (const path of ['.github/workflows/browserstack.yml', 'scripts/ci/patch-ab-other.ts'])
    assert.equal(coveragePlan('pull_request', pr(), [path], head).mode, 'full', path);
  assert.equal(
    coveragePlan('pull_request', pr(), [...experiment, 'web/App.tsx'], head).mode,
    'targeted',
  );
  assert.equal(
    coveragePlan('pull_request', pr(), [...experiment, 'scripts/ci/plan.ts'], head).mode,
    'full',
  );
});

test('sized restore participates in the immutable plan and fails closed', () => {
  for (const path of [
    'src/server/auth/store.ts',
    'e2e/restore-browser.acceptance.ts',
    'web/BackupRestore.tsx',
    'scripts/ci/plan.ts',
    'unrecognized/input.ts',
  ]) {
    const plan = coveragePlan('pull_request', pr(), [path], head);
    assert.equal(plan.suites['restore-timing'].selected, true, path);
    for (const status of [undefined, 'skipped', 'failure', 'cancelled'])
      assert.throws(
        () =>
          verifyCoverage(plan, 'success', { ...all(plan), 'restore-timing': status }, [
            'restore-timing',
          ]),
        /Incomplete coverage restore-timing/,
      );
  }
  assert.equal(
    coveragePlan('pull_request', pr(), ['docs/backups.md'], head).suites['restore-timing'].selected,
    false,
  );
  const workflow = readFileSync(new URL('../../.github/workflows/ci.yml', import.meta.url), 'utf8');
  assert.match(workflow, /restore_timing: \$\{\{ steps.changes.outputs.restore_timing \}\}/);
  assert.match(workflow, /if: needs.changes.outputs.restore_timing == 'true'/);
  assert.match(workflow, /"restore-timing":"\$\{\{ needs.restore-timing.result \}\}"/);
  assert.match(workflow.slice(workflow.indexOf('  playwright:\n')), /restore-timing,/);
});

test('dependency closure and unknown paths fail closed, including old rename/deleted sides', () => {
  for (const path of [
    'web/nativeDocInput.ts',
    'src/server/history/restore.ts',
    'src/server/sync/http.ts',
    'server/database.ts',
    'package-lock.json',
    '.nvmrc',
    'vite.config.ts',
    'e2e/doc-responsiveness.spec.ts',
    'e2e/doc-responsiveness-callback-progress.ts',
    'e2e/doc-responsiveness-callback-proto.ts',
    'e2e/doc-responsiveness-callback-converter.ts',
    'scripts/ci/doc-trace-processor.ts',
    'scripts/dependencies/patch-univer-docs.ts',
  ]) {
    const plan = coveragePlan('pull_request', pr(), [path, 'docs/deleted.md']);
    assert.equal(plan.suites['responsiveness-baseline'].selected, true, path);
    assert.equal(plan.suites['callback-baseline'].selected, true, path);
  }
  for (const path of ['unrecognized/runtime.ts', 'docs/unknown.json', 'src/new-domain.ts']) {
    const plan = coveragePlan('pull_request', pr(), [path]);
    assert.equal(plan.mode, 'full');
    assert.ok(suiteIds.every((id) => plan.suites[id].selected));
  }
  for (const path of [
    'lib/sync-server/store.ts',
    'package-lock.json',
    'scripts/dependencies/patch-univer-core.ts',
  ])
    assert.equal(coveragePlan('pull_request', pr(), [path]).suites['lib-test-run'].selected, true);
});

test('labels only add coverage; removal recomputes automatic requirements', () => {
  const paths = ['src/server/workspace/grants.ts'];
  const ordinary = coveragePlan('pull_request', pr('unlabeled'), paths);
  for (const label of ['ci-performance', 'ci-full']) {
    const added = coveragePlan('pull_request', pr('labeled', [label]), paths);
    for (const id of suiteIds)
      if (ordinary.suites[id].selected) assert.equal(added.suites[id].selected, true, id);
    assert.equal(added.suites['responsiveness-baseline'].selected, true);
  }
  const removed = coveragePlan('pull_request', pr('unlabeled'), ['web/docHistory.ts']);
  assert.equal(removed.suites['responsiveness-baseline'].selected, true);
  const docsPerformance = coveragePlan('pull_request', pr('labeled', ['ci-performance']), [
    'docs/notes.md',
  ]);
  assert.equal(docsPerformance.suites['doc-responsiveness'].selected, true);
  assert.equal(docsPerformance.suites['callback-baseline'].selected, true);
});

test('main ranges, scheduled/manual backstops, unknown events and missing ranges', () => {
  const main = coveragePlan('push', { before: base, after: head }, [
    'src/server/backup/service.ts',
  ]);
  assert.equal(main.base, base);
  assert.equal(main.head, head);
  assert.equal(main.suites['unit-tests'].selected, true);
  for (const name of ['schedule', 'workflow_dispatch', 'unknown']) {
    const plan = coveragePlan(name, {}, []);
    assert.equal(plan.mode, 'full');
    assert.ok(
      suiteIds.filter((id) => id !== 'pull-request').every((id) => plan.suites[id].selected),
    );
  }
  for (const [event, paths] of [
    [pr(), null],
    [pr(), []],
    [{}, ['docs/notes.md']],
  ] as const)
    assert.equal(
      coveragePlan('pull_request', event, paths === null ? null : [...paths]).mode,
      'full',
    );
});

test('aggregates require selected success and explicit inapplicable skipped; known regression remains red', () => {
  const plan = coveragePlan('pull_request', pr(), ['src/server/auth/session.ts']);
  const result = all(plan);
  assert.equal(verifyCoverage(plan, 'success', result, suiteIds).length, suiteIds.length);
  for (const status of [undefined, 'failure', 'cancelled', 'skipped', '']) {
    assert.throws(
      () => verifyCoverage(plan, 'success', { ...result, 'doc-responsiveness': status }, suiteIds),
      /Incomplete coverage/,
    );
  }
  assert.throws(() =>
    verifyCoverage(plan, 'success', { ...result, 'lib-test-run': 'success' }, suiteIds),
  );
  for (const classification of ['failure', 'cancelled', 'skipped', ''])
    assert.throws(() => verifyCoverage(plan, classification, result, suiteIds));
  for (const malformed of [null, {}, { ...plan, suites: {} }, { ...plan, mode: 'metadata' }])
    assert.throws(() => verifyCoverage(malformed, 'success', result, suiteIds));
});

test('workflow keeps seven static code names and protected edit concurrency', () => {
  const workflow = readFileSync(new URL('../../.github/workflows/ci.yml', import.meta.url), 'utf8');
  for (const name of [
    'Backlog',
    'Lint',
    'Typecheck',
    'Unit tests',
    'Lib tests',
    'Playwright smoke',
  ])
    assert.ok(workflow.includes(`name: ${name}\n`), name);
  assert.match(workflow, /name: Pull request\n/);
  assert.ok(!workflow.includes('Metadata only'));
  assert.ok(!workflow.includes("outputs.mode == 'metadata'"));
  assert.match(workflow, /format\('event-\{0\}', github.run_id\)/);
  assert.match(workflow, /cancel-in-progress:.*github.event.action == 'synchronize'/);
  assert.match(workflow, /types: \[opened, edited, synchronize, reopened, labeled, unlabeled\]/);
  assert.match(workflow, /workflow_dispatch:/);
  assert.match(workflow, /schedule:/);
  assert.ok(!workflow.includes('needs.changes.outputs.docs_only'));
});

test('phone ownership removes only eight ordinary cases from instrumented duplicate runs', () => {
  const spec = readFileSync(new URL('../../e2e/doc-mobile.spec.ts', import.meta.url), 'utf8');
  assert.equal(spec.match(/@phone-ordinary/g)?.length, 4); // 3 zoom + 1 formulas + 2 upgrades + 2 traditional
  for (const title of [
    'phone guest Doc reader cannot write',
    'phone Doc typing keeps the rendered caret',
    'a peer-protocol page-layout change preserves',
  ]) {
    const start = spec.indexOf(title);
    assert.ok(start >= 0);
    assert.ok(!spec.slice(start, spec.indexOf('async', start)).includes('@phone-ordinary'));
  }
  const config = readFileSync(new URL('../../playwright.config.ts', import.meta.url), 'utf8');
  assert.match(config, /SPINEL_CI_FULL_COMPATIBILITY === 'false'/);
  assert.equal(config.match(/grepInvert: syncExclusions/g)?.length, 2);
});
