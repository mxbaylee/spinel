import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';

type Point = { x: number; y: number };
type Pointer = Point & { screenX: number; screenY: number; trusted: boolean; target: boolean };
type Observation = {
  moved: Pointer | null;
  clicked: Pointer | null;
  events: unknown[];
  ready: boolean;
};

const cursorMethod = 'CGEventGetLocation(CGEventCreate(NULL))';
const cursorCoordinates = 'Quartz global display';
type ObservationFailurePhase = 'move-observation-failure' | 'click-observation-failure';
type CursorPhase = 'before-move-post' | 'after-move-post' | ObservationFailurePhase;

export function validateSafariCursorSnapshot(value: unknown, phase: CursorPhase) {
  assert.ok(value && typeof value === 'object', 'Missing native cursor snapshot.');
  const snapshot = value as Record<string, unknown>;
  assert.equal(snapshot.method, cursorMethod);
  assert.equal(snapshot.coordinateSpace, cursorCoordinates);
  assert.equal(snapshot.phase, phase);
  assert.ok(typeof snapshot.time === 'string' && Number.isFinite(Date.parse(snapshot.time)));
  assert.equal(new Date(snapshot.time).toISOString(), snapshot.time);
  assert.equal(typeof snapshot.available, 'boolean');
  if (snapshot.available) {
    const point = snapshot.point as Point | undefined;
    assert.ok(point && Number.isFinite(point.x) && Number.isFinite(point.y));
    assert.equal(snapshot.error, undefined);
  } else {
    assert.ok(typeof snapshot.error === 'string' && snapshot.error.length > 0);
    assert.equal(snapshot.point, undefined);
  }
}

// Read without activating or repairing focus: a changed native target must fail.
export const safariPointerIdentityScript = String.raw`
function run(argv) {
  var pid = Number(argv[0]), windowId = Number(argv[1]), tabIndex = Number(argv[2]);
  var app = Application(pid), target = app.windows.byId(windowId);
  var state = { pid: pid, windowId: target.id(), tabIndex: target.currentTab().index(),
    frontmost: app.frontmost(), frontWindowId: app.windows[0].id(),
    visible: target.visible(), minimized: target.miniaturized(), bounds: target.bounds() };
  if (!state.frontmost || state.frontWindowId !== windowId || state.windowId !== windowId ||
      state.tabIndex !== tabIndex || !state.visible || state.minimized)
    throw new Error('The owned Safari pointer target changed: ' + JSON.stringify(state));
  return JSON.stringify(state);
}`;

export type PointerBoundary = {
  evaluate<T>(expression: string): Promise<T>;
  identity(): Promise<{
    bounds: { x: number; y: number; width: number; height: number };
    [key: string]: unknown;
  }>;
  post(mode: 'move' | 'click', point: Point, evidence: Record<string, unknown>): Promise<void>;
  snapshot(phase: ObservationFailurePhase): Promise<unknown>;
  poll<T>(read: () => Promise<T>, accept: (value: T) => boolean, label: string): Promise<T>;
  record(evidence: Record<string, unknown>): Promise<void>;
};

// Observe only coordinates, trust and target membership. No text, URL or user data.
export function pointerObserver(key: string, selector: string, point: Point, screen: Point) {
  return `(() => {
    const key = ${JSON.stringify(key)}, selector = ${JSON.stringify(selector)};
    const point = ${JSON.stringify(point)}, screen = ${JSON.stringify(screen)};
    const element = document.querySelector(selector);
    if (!(element instanceof HTMLElement)) throw new Error('The pointer target disappeared.');
    const initial = element.getBoundingClientRect();
    const geometry = () => { const rect = element.getBoundingClientRect();
      return { x: rect.x, y: rect.y, width: rect.width, height: rect.height }; };
    const state = globalThis[key] = { moved: null, clicked: null, events: [], geometry };
    state.ready = () => element.isConnected && document.querySelector(selector) === element &&
      ['x', 'y', 'width', 'height'].every(name => geometry()[name] === initial[name]) &&
      document.hasFocus() && document.visibilityState === 'visible' &&
      !!element.getClientRects().length && !element.matches(':disabled, [aria-disabled="true"]') &&
      element.contains(document.elementFromPoint(point.x, point.y));
    if (!state.ready()) throw new Error('The pointer target is obscured, unfocused or disconnected.');
    state.observe = event => {
      const value = { x: event.clientX, y: event.clientY, screenX: event.screenX, screenY: event.screenY,
        trusted: event.isTrusted, target: element.contains(event.target) };
      if (state.events.length < 16) state.events.push({ type: event.type, ...value });
      // An unrelated mousemove cannot calibrate the posted screen point.
      if (event.type === 'mousemove' && value.trusted && value.screenX === screen.x && value.screenY === screen.y)
        state.moved = value;
      if (event.type === 'mousedown' && !state.clicked) state.clicked = value;
    };
    addEventListener('mousemove', state.observe, true);
    addEventListener('mousedown', state.observe, true);
  })()`;
}

export async function clickSafariPointer(
  boundary: PointerBoundary,
  selector: string,
  point: Point,
) {
  const key = `__spinelPointer_${randomUUID().replaceAll('-', '')}`;
  const quoted = JSON.stringify(key);
  const evidence: Record<string, unknown> = {
    time: new Date().toISOString(),
    point,
    phase: 'identity',
  };
  let failure: unknown;
  let installed = false;
  const read = () =>
    boundary.evaluate<Observation>(`(() => {
    const state = globalThis[${quoted}];
    if (!state) throw new Error('The pointer observer document changed.');
    return { moved: state.moved, clicked: state.clicked, events: state.events, geometry: state.geometry(), ready: state.ready() };
  })()`);
  try {
    const identity = await boundary.identity();
    evidence.identity = identity;
    const { x, y, width, height } = identity.bounds;
    assert.ok([x, y, width, height].every(Number.isFinite) && width > 0 && height > 0);
    const screen = { x: Math.round(x + width / 2), y: Math.round(y + height / 2) };
    evidence.calibration = screen;
    evidence.phase = 'observer-install';
    // Cleanup also runs when installation fails after publishing the page marker.
    installed = true;
    await boundary.evaluate(pointerObserver(key, selector, point, screen));
    evidence.phase = 'move-post';
    const movePost = {};
    evidence.movePost = movePost;
    await boundary.post('move', screen, movePost);
    evidence.phase = 'move-observation';
    const movedState = await boundary.poll(
      read,
      (value) => !!value.moved,
      'Safari did not receive matching native pointer movement',
    );
    evidence.movement = movedState;
    const moved = movedState.moved!;
    assert.ok(moved.trusted);
    const click = { x: screen.x + point.x - moved.x, y: screen.y + point.y - moved.y };
    assert.ok([click.x, click.y].every(Number.isFinite));
    evidence.click = click;
    evidence.phase = 'target-revalidation';
    evidence.beforeClick = await boundary.identity();
    assert.deepEqual(evidence.beforeClick, identity, 'The owned Safari pointer window changed.');
    const beforeClick = await read();
    evidence.target = beforeClick;
    assert.ok(beforeClick.ready, 'The pointer target is no longer visible, focused or unobscured.');
    assert.equal(beforeClick.clicked, null, 'Unexpected input arrived before the native click.');
    evidence.phase = 'click-post';
    const clickPost = {};
    evidence.clickPost = clickPost;
    await boundary.post('click', click, clickPost);
    evidence.phase = 'click-observation';
    const clickedState = await boundary.poll(
      read,
      (value) => !!value.clicked,
      'Safari did not receive the native pointer click',
    );
    evidence.clickObservation = clickedState;
    const clicked = clickedState.clicked!;
    assert.ok(clicked.trusted && clicked.target, 'The native click did not reach the target.');
    assert.ok(
      Math.abs(clicked.x - point.x) <= 1 && Math.abs(clicked.y - point.y) <= 1,
      'The native click reached the wrong page coordinates.',
    );
    assert.ok(
      Math.abs(clicked.screenX - click.x) <= 1 && Math.abs(clicked.screenY - click.y) <= 1,
      'The observed click does not match the posted screen coordinates.',
    );
    evidence.phase = 'identity-revalidation';
    evidence.afterClick = await boundary.identity();
    assert.deepEqual(evidence.afterClick, identity, 'The owned Safari pointer window changed.');
    evidence.phase = 'delivered';
  } catch (error) {
    failure = error;
    evidence.error = String(error).slice(0, 2000);
    evidence.failureAt = new Date().toISOString();
    if (evidence.phase === 'move-observation' || evidence.phase === 'click-observation') {
      // These passive diagnostics follow the failed observation; they never
      // extend its acceptance window, repair focus, or replay a posted action.
      const phase = `${evidence.phase}-failure` as const;
      const time = new Date().toISOString();
      try {
        evidence.failureCursor = await boundary.snapshot(phase);
        validateSafariCursorSnapshot(evidence.failureCursor, phase);
      } catch (diagnosticError) {
        evidence.failureCursorError = String(diagnosticError).slice(0, 2000);
        evidence.failureCursor ??= {
          method: cursorMethod,
          coordinateSpace: cursorCoordinates,
          phase,
          time,
          available: false,
          error: evidence.failureCursorError,
        };
      }
      try {
        evidence.failureIdentity = await boundary.identity();
      } catch (diagnosticError) {
        evidence.failureIdentityError = String(diagnosticError).slice(0, 2000);
      }
    }
  } finally {
    if (installed) {
      try {
        evidence.finalObservation = await read();
      } catch (error) {
        evidence.observationError = String(error).slice(0, 2000);
        failure ??= error;
      }
      try {
        await boundary.evaluate(`(() => {
          const state = globalThis[${quoted}];
          if (state) {
            removeEventListener('mousemove', state.observe, true);
            removeEventListener('mousedown', state.observe, true);
            delete globalThis[${quoted}];
          }
        })()`);
        evidence.observerRemoved = true;
      } catch (error) {
        evidence.cleanupError = String(error).slice(0, 2000);
        failure ??= error;
      }
    }
    evidence.status = failure ? 'failed' : 'passed';
    try {
      await boundary.record(evidence);
    } catch (error) {
      failure ??= error;
    }
  }
  if (failure) throw failure;
}

// A fresh default event supplies an independent cursor snapshot, as used by
// WebRTC's macOS cursor monitor. Apple's creation prose does not promise current
// cursor state; this observation is not a native or DOM delivery acknowledgment.
// time marks the read attempt, including when a read is unavailable.
const safariCursorSnapshotFunction = String.raw`
        function cursorSnapshot(phase) {
          var snapshot = { method: ${JSON.stringify(cursorMethod)},
            coordinateSpace: ${JSON.stringify(cursorCoordinates)}, phase: phase,
            time: new Date().toISOString(), available: false };
          console.log('pointer: cursor snapshot ' + phase);
          try {
            var event = $.CGEventCreate($());
            if (!event || (typeof event.isNil === 'function' && event.isNil()))
              throw new Error('Quartz did not return a nonnil default event.');
            var location = $.CGEventGetLocation(event);
            var point = { x: Number(location.x), y: Number(location.y) };
            if (!Number.isFinite(point.x) || !Number.isFinite(point.y))
              throw new Error('Quartz returned a nonfinite default-event location.');
            snapshot.point = point;
            snapshot.available = true;
          } catch (error) {
            snapshot.error = String(error).slice(0, 2000);
          }
          console.log('pointer: cursor snapshot result ' + JSON.stringify(snapshot));
          return snapshot;
        }
`;

// One read only: no posting, focus repair or polling after an observation failure.
export const safariPointerSnapshotScript = String.raw`
        ObjC.import('CoreGraphics');
        ${safariCursorSnapshotFunction}
        function run(argv) {
          var phase = argv[0];
          if (phase !== 'move-observation-failure' && phase !== 'click-observation-failure')
            throw new Error('Expected an observation failure phase.');
          return JSON.stringify(cursorSnapshot(phase));
        }
`;

// Quartz sends real native input; a move owns one posted and two snapshot events,
// while a click owns only its two posted events. The helpers are short-lived.
// Do not CFRelease through JXA: a prior native crash followed a successful post.
export const safariPointerPostScript = String.raw`
        console.log('pointer: importing frameworks');
        ObjC.import('CoreGraphics');
        console.log('pointer: frameworks imported');
        ${safariCursorSnapshotFunction}
        function run(argv) {
          var point = { x: Number(argv[1]), y: Number(argv[2]) };
          console.log('pointer: preflight');
          if (typeof $.CGPreflightPostEventAccess !== 'function')
            ObjC.bindFunction('CGPreflightPostEventAccess', ['bool', []]);
          var permitted = $.CGPreflightPostEventAccess();
          console.log('pointer: post-event access ' + permitted);
          if (!permitted) throw new Error('The native input host is not permitted to post pointer events.');
          var types = argv[0] === 'move' ? [$.kCGEventMouseMoved] : [$.kCGEventLeftMouseDown, $.kCGEventLeftMouseUp];
          var result = { mode: argv[0], point: point, posted: types.length };
          types.forEach(function(type) {
            console.log('pointer: creating event ' + type);
            var event = $.CGEventCreateMouseEvent($(), type, point, $.kCGMouseButtonLeft);
            console.log('pointer: validating event ' + type);
            // CGEventRef is an opaque C pointer; JXA can expose Ref without ObjC's isNil.
            if (!event || (typeof event.isNil === 'function' && event.isNil()))
              throw new Error('Quartz did not return a nonnil bridged event: ' + Automation.getDisplayString(event, true));
            var actualType = Number($.CGEventGetType(event));
            if (actualType !== Number(type))
              throw new Error('Quartz event type differs: expected ' + type + ', received ' + actualType);
            var location = $.CGEventGetLocation(event);
            var actualPoint = { x: Number(location.x), y: Number(location.y) };
            console.log('pointer: validated event ' + actualType + ' at ' + JSON.stringify(actualPoint));
            if (actualPoint.x !== point.x || actualPoint.y !== point.y)
              throw new Error('Quartz event location differs: expected ' + JSON.stringify(point) + ', received ' + JSON.stringify(actualPoint));
            if (argv[0] === 'move') result.cursorBefore = cursorSnapshot('before-move-post');
            console.log('pointer: posting event ' + type);
            $.CGEventPost($.kCGHIDEventTap, event);
            console.log('pointer: posted event ' + type);
            if (argv[0] === 'move') result.cursorAfter = cursorSnapshot('after-move-post');
          });
          return JSON.stringify(result);
        }
`;
