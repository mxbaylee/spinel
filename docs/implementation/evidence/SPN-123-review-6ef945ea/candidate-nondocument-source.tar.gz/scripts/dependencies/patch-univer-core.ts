/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Modified for Spinel: repair paragraph REPLACE composition, keep custom ranges
 * canonical after every update, stop adding a custom range from emitting a
 * negative retain, and let a REPLACE style's falsy keys win over a concurrent
 * COVER style, in open-source @univerjs/core 1.3.1. No @univerjs-pro
 * package is read or modified.
 * It also schedules Univer's immediate macrotasks on one shared MessageChannel
 * instead of constructing a channel per call (SPN-146: about 47,000 per typing
 * run, and each one is browser-heap garbage that lengthens every major GC).
 * Known difference: a cancelled task stays queued (closure included) until its
 * message is delivered one macrotask later, and keeps a Node loop alive until then.
 * Temporary: SPN-099 removes this once upstream ships the fixes. The custom
 * range fixes are https://github.com/dream-num/univer/pull/7938; if upstream
 * takes another direction, follow it rather than keep this patch.
 * Source: packages/core/src/docs/data-model/text-x/{utils,action-iterator,transform-utils}.ts,
 * packages/core/src/docs/data-model/text-x/apply-utils/{common,update-apply}.ts and
 * packages/core/src/docs/data-model/text-x/build-utils/text-x-utils.ts and
 * packages/core/src/common/request-immediate-macro-task.ts, tag v1.3.1.
 */
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const formats = {
  es: {
    sha256: '84945d2f297af99bf4c83a79928ef05a7aab03ab70c2249e2f32ec8262af831e',
    merge: 'merge',
  },
  cjs: {
    sha256: '3eb778711d5d1ce5517d2e0758caeecb4e181718931c6923b6d89c87ff0d452c',
    merge: '(0, lodash_es.merge)',
  },
} as const;

/** The original function, byte for byte, as shipped in 1.3.1 (es and cjs are identical here). */
const upstreamMacroTask = `function requestImmediateMacroTask(callback) {
	const channel = new MessageChannel();
	let cancelled = false;
	const close = () => {
		channel.port1.onmessage = null;
		channel.port1.close();
		channel.port2.close();
	};
	const handler = () => {
		if (!cancelled) {
			cancelled = true;
			close();
			callback();
		}
	};
	channel.port1.onmessage = handler;
	channel.port2.postMessage(null);
	return () => {
		if (cancelled) return;
		cancelled = true;
		close();
	};
}`;
/**
 * Modified for Spinel (SPN-146): one channel for every call. Each post still yields one later macrotask and
 * messages arrive in order, so a call runs after the ones before it, as before. Cancelling marks the entry;
 * its message is consumed and skipped. In Node the port is kept referenced only while a task is pending, so a
 * pending task still keeps the process alive and an idle one does not. A cancelled entry is not removed: it
 * (and its callback's closure) stays queued and keeps the Node loop alive until its own message is delivered,
 * which happens in the next macrotask, so the delay is bounded to one turn. The upstream helper closed its
 * channel on cancel instead. This text is hashed and patched in verbatim, so the function body is left as is
 * and this behaviour is covered in patch-univer-core.test.ts rather than changed here.
 */
export const pooledMacroTask = `// Modified for Spinel: one shared MessageChannel instead of one per call (SPN-146).
const pendingMacroTasks = [];
let macroTaskChannel;
function requestImmediateMacroTask(callback) {
	if (!macroTaskChannel) {
		macroTaskChannel = new MessageChannel();
		macroTaskChannel.port1.onmessage = () => {
			const entry = pendingMacroTasks.shift();
			if (pendingMacroTasks.length === 0) macroTaskChannel.port1.unref?.();
			if (entry && !entry.cancelled) {
				entry.cancelled = true;
				entry.callback();
			}
		};
	}
	const entry = { callback, cancelled: false };
	pendingMacroTasks.push(entry);
	macroTaskChannel.port1.ref?.();
	macroTaskChannel.port2.postMessage(null);
	return () => {
		entry.cancelled = true;
	};
}`;

/**
 * `pooledChannel: false` leaves the upstream function in place. It exists for the SPN-146 A/B only
 * (scripts/ci/patch-ab/core-channel.ts); the installed build always uses the default.
 */
export function patchCore(
  source: string,
  format: keyof typeof formats,
  { pooledChannel = true }: { pooledChannel?: boolean } = {},
): string {
  const spec = formats[format];
  const before = `paragraphs.push(${spec.merge}(thisParagraph, otherParagraph));`;
  const after = `// Modified for Spinel: REPLACE clears removed attributes, retaining stable identity.
\t\t\tif (coverType === 1) {
\t\t\t\tparagraphs.push({ ...Tools.deepClone(otherParagraph), paragraphId: otherParagraph.paragraphId ?? thisParagraph.paragraphId });
\t\t\t} else {
\t\t\t\t${before}
\t\t\t}`;
  const replacements = [
    [before, after],
    [
      '} else if (thisStart < otherStart) {\n\t\t\tparagraphs.push(Tools.deepClone(thisParagraph));',
      '} else if (thisStart < otherStart) {\n\t\t\tif (coverType !== 1 || otherBody.paragraphs == null) paragraphs.push(Tools.deepClone(thisParagraph));',
    ],
    [
      'if (thisIndex < thisParagraphs.length) paragraphs.push(...thisParagraphs.slice(thisIndex));',
      'if ((coverType !== 1 || otherBody.paragraphs == null) && thisIndex < thisParagraphs.length) paragraphs.push(...thisParagraphs.slice(thisIndex));',
    ],
    [
      'if (paragraphs.length) retBody.paragraphs = paragraphs;',
      'if (paragraphs.length || (coverType === 1 && otherBody.paragraphs != null)) retBody.paragraphs = paragraphs;',
    ],
  ];
  replacements.push([
    'body: getBodySliceForSplitTextXAction(nextAction.body, offset, offset + length, false)',
    `body: {
      ...getBodySliceForSplitTextXAction(nextAction.body, offset, offset + length, false),
      // Modified for Spinel: an explicit empty REPLACE array clears the sliced range.
      ...(nextAction.t === "r" && nextAction.coverType === 1 && nextAction.body.paragraphs != null
        ? { paragraphs: getParagraphsSlice(nextAction.body, offset, offset + length) ?? [] } : {})
    }`,
  ]);
  // Each patch edits one function, and its targets must occur exactly once there.
  // A region runs from `from` to `to`, or to the end of the source file `to` is in.
  const regions: { from: string; to: string; toFileEnd?: true; replacements: string[][] }[] = [
    {
      from: 'function composeBody(',
      to: 'var ActionIterator = class',
      toFileEnd: true,
      replacements,
    },
    {
      from: 'function mergeContinuousRanges(',
      to: 'function splitCustomRangesByIndex(',
      replacements: [
        [
          'if (ranges.length <= 1) return ranges;',
          `// Modified for Spinel: one range is renamed to its root id like any other.
\tif (ranges.length === 0) return ranges;`,
        ],
      ],
    },
    {
      from: 'function updateCustomRanges(',
      to: 'function updateCustomDecorations(',
      replacements: [
        [
          'if (!updateDataCustomRanges) return [];',
          `// Modified for Spinel: a retain without ranges still splits them at its
\t// edges above, so join the pieces again, as a retain with ranges does.
\tif (!updateDataCustomRanges) {
\t\tbody.customRanges = mergeContinuousRanges(body.customRanges);
\t\treturn [];
\t}`,
        ],
      ],
    },
    {
      from: 'function transformTextRuns(',
      to: 'function transformCustomRanges(',
      replacements: [
        [
          'for (const key of keys) if (originStyle[key]) delete newTs[key];',
          `// Modified for Spinel: a winning REPLACE style's falsy keys, such as
					// \`bl: 0\`, also win over the losing COVER's, as its truthy ones do.
					for (const key of keys) if (originStyle[key] !== void 0) delete newTs[key];`,
        ],
      ],
    },
    {
      from: 'function addCustomRangeTextX(',
      to: 'function isAtomicContainerDeleted(',
      replacements: [
        [
          'const rangeStartIndex = Math.min(',
          `// Modified for Spinel: each piece grows to swallow the ranges it meets,
\t\t\t// so the piece before a paragraph can already cover an existing range
\t\t\t// that runs past it. The next piece met the same range and started
\t\t\t// back at its start, before the cursor: a negative retain. It now
\t\t\t// starts at the cursor, and is dropped when nothing is left of it.
\t\t\tconst rangeStartIndex = Math.max(cursor, Math.min(`,
        ],
        [
          '_relativeCustomRanges.startIndex) ?? Infinity, startIndex);',
          '_relativeCustomRanges.startIndex) ?? Infinity, startIndex));',
        ],
        [
          '_relativeCustomRanges2.endIndex) ?? -Infinity, endIndex);',
          `_relativeCustomRanges2.endIndex) ?? -Infinity, endIndex);
\t\t\tif (rangeEndIndex < rangeStartIndex) return;`,
        ],
      ],
    },
  ];
  const macroTask: [string, string] = [upstreamMacroTask, pooledMacroTask];
  // Idempotent, but never silently patch a different upstream version or local edit.
  const original = [...regions.flatMap((region) => region.replacements), macroTask].reduce(
    (text, [old, replacement]) => text.replace(replacement, old),
    source,
  );
  if (createHash('sha256').update(original).digest('hex') !== spec.sha256)
    throw new Error(
      `Unrecognized @univerjs/core ${format} build; review the core patch before installing.`,
    );
  const patched = regions.reduce((text, { from, to, toFileEnd, replacements: edits }) => {
    const start = text.indexOf(from);
    const stop = text.indexOf(to, start);
    const end = toFileEnd ? text.indexOf('//#endregion', stop) : stop;
    if (start < 0 || stop < 0 || end < 0) throw new Error(`Core patch region ${from} not found.`);
    const body = edits.reduce(
      (part, [old, replacement]) => {
        if (part.split(old).length !== 2)
          throw new Error('Core patch target must occur exactly once.');
        return part.replace(old, replacement);
      },
      text.slice(start, end),
    );
    return text.slice(0, start) + body + text.slice(end);
  }, original);
  if (!pooledChannel) return patched;
  // The sha256 gate above fixes the macrotask function to one occurrence in the upstream build.
  return patched.replace(upstreamMacroTask, pooledMacroTask);
}

export async function patchInstalledCore(root: string) {
  const directory = resolve(root, 'node_modules/@univerjs/core');
  const metadata = JSON.parse(await readFile(resolve(directory, 'package.json'), 'utf8'));
  if (metadata.version !== '1.3.1')
    throw new Error('Upgrading @univerjs/core: do SPN-099 first (docs/todo/SPN-099.md).');
  // Validate both formats before making either change.
  const updates = await Promise.all(
    Object.keys(formats).map(async (format) => {
      const path = resolve(directory, 'lib', format, 'index.js');
      const source = await readFile(path, 'utf8');
      return { path, source, patched: patchCore(source, format as keyof typeof formats) };
    }),
  );
  for (const { path, source, patched } of updates)
    if (source !== patched) await writeFile(path, patched);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url))
  await patchInstalledCore(resolve(import.meta.dirname, '../..'));
