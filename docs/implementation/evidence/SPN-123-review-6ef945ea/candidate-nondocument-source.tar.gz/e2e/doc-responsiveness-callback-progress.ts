import { renameSync, writeFileSync } from 'node:fs';
import { rename, writeFile } from 'node:fs/promises';

type Lifecycle = 'page-crash' | 'page-close' | 'context-close' | 'browser-disconnected';
type Failure =
  | Lifecycle
  | 'operation'
  | 'input-observation'
  | 'trace'
  | 'trace-output-cleanup'
  | 'detach'
  | 'fixture-cleanup'
  | 'manifest-persistence';

/** Preserve a primary fixture error if writing its evidence also fails. */
export async function persistCallbackManifest(
  path: string,
  evidence: Record<string, unknown>,
  primary: unknown,
) {
  try {
    await writeFile(`${path}.tmp`, JSON.stringify(evidence, null, 2) + '\n');
    await rename(`${path}.tmp`, path);
  } catch {
    evidence.manifestPersistenceError = true;
    evidence.passed = false;
    return primary ?? new Error('Callback acceptance manifest could not be persisted.');
  }
  return primary;
}

export interface CallbackObservation {
  progress: ReturnType<typeof callbackProgress>;
  detach: () => void;
  abort: () => void;
  interrupt: () => Promise<unknown>;
  done?: Promise<void>;
  rejectManifest?: () => Promise<void>;
}

/** Own partial setup and evidence failures outside the timed observation body. */
export async function runOwnedObservation(
  work: () => Promise<void>,
  ownership: {
    progress: ReturnType<typeof callbackProgress>;
    primaryFailure: () => unknown;
    detach: () => Promise<void>;
    close: () => Promise<void>;
  },
) {
  let failure: unknown;
  try {
    await work();
  } catch (error) {
    failure = ownership.primaryFailure() ?? error;
    ownership.progress.failed('operation');
  }
  const cleanup = await Promise.allSettled([
    Promise.resolve().then(ownership.detach),
    Promise.resolve().then(ownership.close),
  ]);
  for (const [index, result] of cleanup.entries())
    if (result.status === 'rejected') {
      failure ??= result.reason;
      ownership.progress.failed(index === 0 ? 'detach' : 'fixture-cleanup');
    }
  if (ownership.progress.persistenceFailure)
    failure ??= new Error('Observation progress persistence failed.');
  if (ownership.progress.firstFailure)
    failure ??= new Error(`Observation lifecycle failed: ${ownership.progress.firstFailure.kind}`);
  if (failure) throw failure;
}

/** A timeout remains durable even if owned teardown cannot finish. */
export async function settleCallbackObservation(observation: CallbackObservation, status: string) {
  observation.progress.terminal(status);
  if (status !== 'passed') {
    observation.abort();
    await observation.interrupt();
    await observation.done?.catch(() => {});
    await observation.rejectManifest?.();
    observation.progress.terminal(status);
  }
}

/** Node-side observations survive a test-body timeout without querying the renderer.
 * This is diagnostic evidence only: it cannot replace native acceptance results. */
export function callbackProgress(path: string) {
  const started = performance.now();
  let cleanupExpected = false;
  let phase = 'fixture';
  const events: Array<{
    atMs: number;
    phase: string;
    kind: string;
    count?: number;
    expected?: boolean;
  }> = [];
  let firstFailure: { atMs: number; phase: string; kind: string } | null = null;
  let droppedEvents = 0;
  let terminal: string | null = null;
  let persistenceFailure: { atMs: number; phase: string; code: string } | null = null;
  const record = (kind: string, extra: { count?: number; expected?: boolean } = {}) => {
    events.push({ atMs: performance.now() - started, phase, kind, ...extra });
    // Fixed memory/disk bound even if a broken target emits repeated lifecycle events.
    if (events.length > 128) {
      events.shift();
      droppedEvents++;
    }
    try {
      // Keep the previous complete checkpoint if a write or rename fails. The
      // fixed temporary path bounds abandoned storage to one additional file.
      writeFileSync(
        `${path}.tmp`,
        JSON.stringify({
          schema: 1,
          phase,
          firstFailure,
          persistenceFailure,
          terminal,
          droppedEvents,
          events,
        }) + '\n',
      );
      renameSync(`${path}.tmp`, path);
    } catch (error) {
      const code = (error as NodeJS.ErrnoException)?.code;
      persistenceFailure ??= {
        atMs: performance.now() - started,
        phase,
        code: ['ENOSPC', 'ENOENT', 'EACCES', 'EIO', 'EROFS', 'EMFILE', 'ENFILE', 'EISDIR'].includes(
          code ?? '',
        )
          ? code!
          : 'unknown',
      };
      // Never throw from a lifecycle listener or bypass the owned-resource
      // cleanup. The test body/terminal hook reject missing evidence afterward.
    }
  };
  const fail = (kind: string) => {
    firstFailure ??= { atMs: performance.now() - started, phase, kind };
    record(kind);
  };
  record('started');
  return {
    phase(name: string, count?: number) {
      phase = name;
      record('phase', count === undefined ? {} : { count });
    },
    failed(kind: Failure) {
      fail(kind);
    },
    lifecycle(kind: Lifecycle) {
      const expected = cleanupExpected && (kind === 'page-close' || kind === 'context-close');
      if (!expected) firstFailure ??= { atMs: performance.now() - started, phase, kind };
      record(kind, { expected });
    },
    cleanup() {
      cleanupExpected = true;
      phase = 'fixture-cleanup';
      record('phase');
    },
    terminal(status: string) {
      terminal = status;
      if (status !== 'passed') fail(status);
      else record('terminal');
    },
    get firstFailure() {
      return firstFailure;
    },
    get persistenceFailure() {
      return persistenceFailure;
    },
  };
}
