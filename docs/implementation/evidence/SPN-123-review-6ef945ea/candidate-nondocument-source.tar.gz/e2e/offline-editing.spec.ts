import { randomUUID } from 'node:crypto';
import { expect, test } from '@playwright/test';
import type { Page, Request } from '@playwright/test';
import type { IDocumentData } from '@univerjs/core';
import { DOCS_NORMAL_EDITOR_UNIT_ID_KEY, DocumentFlavor, LocaleType } from '@univerjs/core';
import { docFormulas } from '@spinel/doc-formulas';
import { SyncServer } from '@spinel/sync-server';
import sharp from 'sharp';
import { COOKIE_NAME } from '../src/server/auth/store.ts';
import { SheetStore } from '../src/server/workspace/sheets.ts';
import { SQLiteSyncStorage } from '../src/server/sync/store.ts';
import type { NativeWrite } from './sync-network.ts';
import {
  attention,
  copy,
  edit,
  fixture,
  matchesServer,
  nativeInput,
  pending,
  savedLocally,
  saveStatus,
  selectCell,
  stored,
  synced,
  usableCanvas,
} from './offline-fixture.ts';
import { beginWriting, textPoint } from './doc-touch.ts';

async function phoneText(page: Page, unitId: string) {
  return page.evaluate((id) => {
    let text: string | undefined;
    const receive = (event: Event) => {
      const evidence = (event as CustomEvent<{ unitId: string; text: string }>).detail;
      if (evidence.unitId === id) text = evidence.text;
    };
    window.addEventListener('spinel-doc-selection-evidence', receive);
    try {
      // The existing evidence observer reads the live native model, including
      // its still-offline queue. It exposes no writable selection or document.
      window.dispatchEvent(new Event('spinel-doc-selection-read'));
    } finally {
      window.removeEventListener('spinel-doc-selection-evidence', receive);
    }
    return text;
  }, unitId);
}

test.describe('downloaded native editors', () => {
  test.setTimeout(180_000);

  for (const kind of ['doc', 'sheet'] as const)
    test(`a prepared ${kind} viewer upgrades in place and can save new offline work`, async ({
      browser,
      baseURL,
    }, info) => {
      const f = await fixture(browser, baseURL!, info, kind, { actor: 'viewer' });
      try {
        await f.download();
        await expect(saveStatus(f.page)).toHaveText('View only on this device.');
        const before = await f.read();
        const prepared = (await stored(f.page, f.actor.id, f.item.id))!;
        expect(prepared.bundle).toMatchObject({
          access: 'viewer',
          readOnly: true,
          unitId: f.unitId,
        });
        const canvas =
          kind === 'doc'
            ? f.page.getByLabel('Document canvas', { exact: true })
            : f.page.locator('canvas[id^="univer-sheet-main-canvas_"]');
        const mounted = (await canvas.elementHandle())!;
        let navigations = 0;
        f.page.on('framenavigated', (frame) => {
          if (frame === f.page.mainFrame()) navigations++;
        });
        const granted = await f.control.request.put(`/api/items/${f.item.id}/sharing`, {
          headers: { Origin: baseURL! },
          data: { userId: f.viewer.id, role: 'editor' },
        });
        expect(granted.status(), await granted.text()).toBe(200);
        await expect(saveStatus(f.page)).toHaveText(
          'Synced. All changes are saved on the server and this device.',
          { timeout: 5_000 },
        );
        expect(await canvas.evaluate((node, original) => node === original, mounted)).toBe(true);
        expect(navigations).toBe(0);
        const promoted = (await stored(f.page, f.actor.id, f.item.id))!;
        expect(promoted.bundle).toMatchObject({
          access: 'editor',
          readOnly: false,
          unitId: f.unitId,
        });
        expect(promoted.bundle.snapshot).toEqual(prepared.bundle.snapshot);
        expect(await f.read()).toEqual(before);

        await f.network.setOffline(true);
        const text = 'Work after a viewer upgrade 7314';
        await edit(f.page, kind, text);
        await savedLocally(f.page);
        expect(pending((await stored(f.page, f.actor.id, f.item.id))!.outbox?.checkpoint)).toBe(
          true,
        );
        expect(await f.read()).toEqual(before);
        await f.network.setOffline(false);
        await synced(f.page);
        const committed = await f.read();
        expect(committed.revision).toBeGreaterThan(before.revision);
        if (kind === 'doc') expect(committed.snapshot.body!.dataStream.split(text)).toHaveLength(2);
        else
          expect(
            committed.snapshot.sheets[committed.snapshot.sheetOrder[0]].cellData?.[0]?.[3]?.v,
          ).toBe(text);
        await matchesServer(f.page, committed);
        expect(await canvas.evaluate((node, original) => node === original, mounted)).toBe(true);
        expect(navigations).toBe(0);
        expect(f.errors).toEqual([]);
      } finally {
        await f.close();
      }
    });

  test('last-copy removal waits for its editor to close and preserves another live editor with pending input', async ({
    browser,
    baseURL,
  }, info) => {
    const f = await fixture(browser, baseURL!, info, 'sheet');
    try {
      await f.download();
      const before = await f.read();
      const other = f.workspace.create(f.owner.id, {
        name: 'Undownloaded live Doc',
        kind: 'doc',
        parentId: null,
      });
      const prepared = await f.control.request.post(`/api/items/${other.id}/collaboration`, {
        headers: { Origin: baseURL! },
        data: {},
      });
      expect(prepared.status(), await prepared.text()).toBe(200);
      const otherUnitId = (await prepared.json()).unitId as string;
      const readOther = async () => {
        const response = await f.control.request.get(
          `/sync-api/items/${other.id}/snapshot?unitId=${encodeURIComponent(otherUnitId)}`,
        );
        expect(response.status(), await response.text()).toBe(200);
        return (await response.json()) as { revision: number; snapshot: IDocumentData };
      };
      const otherPage = await f.context.newPage();
      await otherPage.goto(`/?item=${other.id}`);
      await expect(saveStatus(otherPage)).toHaveText('All changes saved.', { timeout: 30_000 });
      const otherBefore = await readOther();
      const otherCanvas = await otherPage
        .locator('.univer-container canvas')
        .first()
        .elementHandle();
      const held: NativeWrite[] = [];
      f.network.interceptWrites((write) => {
        held.push(write);
      });
      const text = 'Pending in another editor 628';
      await edit(otherPage, 'doc', text);
      await expect.poll(() => held.length).toBeGreaterThan(0);
      await expect(saveStatus(otherPage)).not.toHaveText('All changes saved.');

      const canvas = await f.page.locator('.univer-container canvas').first().elementHandle();
      await f.page.getByRole('button', { name: 'Document actions', exact: true }).click();
      await f.page.getByRole('menuitem', { name: 'Remove from device', exact: true }).click();
      const dialog = f.page.getByRole('dialog', { name: 'Offline availability', exact: true });
      await expect(dialog.getByRole('alert')).toHaveText(
        'Close this document in every tab before changing its device copy.',
      );
      expect(
        await f.page
          .locator('.univer-container canvas')
          .first()
          .evaluate((node, original) => node === original, canvas!),
      ).toBe(true);
      await dialog.getByRole('button', { name: 'Done', exact: true }).click();
      await f.page.getByRole('button', { name: 'Back to files', exact: true }).click();
      await f.page
        .getByRole('button', { name: `More actions for ${f.item.name}`, exact: true })
        .click();
      await f.page.getByRole('menuitem', { name: 'Remove from device', exact: true }).click();
      await expect(
        f.page.getByRole('status').filter({ hasText: `${f.item.name} was removed` }),
      ).toHaveText(`${f.item.name} was removed from this device.`);
      expect(
        await f.page.evaluate(() => localStorage.getItem('spinel.offline.account')),
      ).toBeNull();
      expect(await stored(f.page, f.actor.id, f.item.id)).toBeUndefined();
      // Starting another same-account tab after the last removal must not
      // rotate the account cancellation token under a live pending editor.
      const thirdPage = await f.context.newPage();
      await thirdPage.goto('/');
      await expect(
        thirdPage.getByRole('button', { name: `More actions for ${other.name}`, exact: true }),
      ).toBeVisible();
      expect(
        await otherPage
          .locator('.univer-container canvas')
          .first()
          .evaluate((node, original) => node === original, otherCanvas!),
      ).toBe(true);
      expect(await copy(otherPage, 'doc')).toContain(text);
      expect(await readOther()).toEqual(otherBefore);
      await f.network.drainWrites();
      f.network.interceptWrites(undefined);
      for (const write of held) expect(write.forward()).toBe(true);
      await expect(saveStatus(otherPage)).toHaveText('All changes saved.', { timeout: 30_000 });
      const otherCommitted = await readOther();
      expect(otherCommitted.revision).toBe(otherBefore.revision + 1);
      expect(otherCommitted.snapshot.body!.dataStream.split(text)).toHaveLength(2);
      await matchesServer(otherPage, otherCommitted);
      await f.page.goto(f.href);
      await expect(saveStatus(f.page)).toHaveText('All changes saved.', { timeout: 30_000 });
      await edit(f.page, 'sheet', '753');
      await expect(saveStatus(f.page)).toHaveText('All changes saved.', { timeout: 30_000 });
      await expect.poll(async () => (await f.read()).revision).toBe(before.revision + 1);
      const committed = await f.read();
      const firstSheet = committed.snapshot.sheetOrder[0];
      expect(committed.snapshot.sheets[firstSheet].cellData?.[0]?.[3]?.v).toBe(753);
      await matchesServer(f.page, committed);
      expect(f.errors).toEqual([]);
    } finally {
      await f.close();
    }
  });

  test('editing IMAGE formulas offline makes no external image request while normal formulas still calculate', async ({
    browser,
    baseURL,
  }, info) => {
    const f = await fixture(browser, baseURL!, info, 'sheet');
    const requests: string[] = [];
    f.context.on('request', (request) => {
      if (new URL(request.url()).hostname === 'tracker.invalid') requests.push(request.url());
    });
    try {
      await f.download();
      const baseline = await f.read();
      await f.network.setOffline(true);
      await edit(f.page, 'sheet', 'Offline before IMAGE', 'D1');
      await savedLocally(f.page);
      const formula = `=IMAGE("https://tracker.invalid/offline-${randomUUID()}.png")`;
      await edit(f.page, 'sheet', formula, 'E1');
      await savedLocally(f.page);
      // A later ordinary calculation proves the native calculation pipeline
      // ran after the image edit. Only derived external image loading is blocked.
      await edit(f.page, 'sheet', '=1+2', 'F1');
      await savedLocally(f.page);
      await expect.poll(async () => (await copy(f.page, 'sheet', 'F1')).trim()).toBe('3');
      const checkpoint = (await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint;
      expect(
        checkpoint.buffer
          .flat()
          .some(
            (mutation) =>
              mutation.id === 'sheet.mutation.set-range-values' &&
              mutation.params.cellValue?.[0]?.[4]?.f === formula,
          ),
      ).toBe(true);
      expect(requests).toEqual([]);
      await f.page.reload();
      await savedLocally(f.page);
      await expect.poll(async () => (await copy(f.page, 'sheet', 'F1')).trim()).toBe('3');
      expect(requests).toEqual([]);
      expect(await f.read()).toEqual(baseline);
      expect(f.errors).toEqual([]);
    } finally {
      await f.close();
    }
  });

  test('a clean downloaded editor refreshes after more than 128 durable revisions and accepts the next edit', async ({
    browser,
    baseURL,
  }, info) => {
    const f = await fixture(browser, baseURL!, info, 'sheet');
    const store = new SQLiteSyncStorage(f.auth);
    // Another writer commits through the actual native engine and SQLite
    // retention adapter while this browser is offline, without UI debug writes.
    const writer = new SyncServer(store, { authorize() {} });
    try {
      await f.download();
      const baseline = await f.read();
      const firstSheet = baseline.snapshot.sheetOrder[0];
      await f.network.setOffline(true);
      for (let index = 1; index <= 129; index++)
        await writer.submit(
          {
            unitId: f.unitId,
            actorId: f.owner.id,
            mutationId: `offline-retention-${index}`,
            baseRevision: baseline.revision + index - 1,
            mutations: [
              {
                id: 'sheet.mutation.set-range-values',
                params: {
                  unitId: f.unitId,
                  subUnitId: firstSheet,
                  cellValue: { 0: { 0: { v: index } } },
                },
              },
            ],
          },
          undefined,
        );
      expect(store.load(f.unitId)!.retainedFrom).toBeGreaterThan(baseline.revision);
      const advanced = await f.read();
      expect(advanced.revision).toBe(baseline.revision + 129);
      expect(pending((await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint)).toBe(
        false,
      );
      await f.network.setOffline(false);
      await synced(f.page);
      await matchesServer(f.page, advanced);
      const refreshed = (await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint;
      expect(refreshed.revision).toBe(advanced.revision);
      expect(pending(refreshed)).toBe(false);
      await edit(f.page, 'sheet', '624');
      await synced(f.page);
      const committed = await f.read();
      expect(committed.revision).toBe(advanced.revision + 1);
      expect(committed.snapshot.sheets[firstSheet].cellData?.[0]?.[3]?.v).toBe(624);
      await matchesServer(f.page, committed);
      expect(f.errors).toEqual([]);
    } finally {
      await writer.close();
      await f.close();
    }
  });

  for (const { kind, phone } of [
    { kind: 'sheet', phone: false },
    { kind: 'doc', phone: false },
    { kind: 'doc', phone: true },
  ] as const)
    test(`${phone ? 'phone doc' : kind}: durable edits survive two offline reloads and reconnect exactly once`, async ({
      browser,
      baseURL,
    }, info) => {
      const f = await fixture(browser, baseURL!, info, kind, {
        images: kind === 'sheet',
        phone,
        ...(phone ? { flavor: DocumentFlavor.MODERN, zoomRatio: 0.5 } : {}),
      });
      try {
        await f.download();
        const baseline = await f.read();
        if (kind === 'sheet') await matchesServer(f.page, baseline);
        const captured = f.network.outgoing.filter((frame) => frame.type === 'submit').length;
        await f.network.setOffline(true);
        const text = kind === 'doc' ? 'Offline text once 731' : '731';
        if (phone) {
          // A cold offline launch must mount a usable mobile native editor.
          // Chromium drives browser key input here; this is not an OS keyboard check.
          await f.page.reload();
          await usableCanvas(f.page);
          await savedLocally(f.page);
          const region = f.page.getByRole('region', { name: 'Doc document', exact: true });
          await expect(region).toHaveAttribute('data-mobile', 'true');
          await matchesServer(f.page, baseline);
          await region.getByRole('button', { name: 'Edit', exact: true }).tap();
          await beginWriting(f.page);
          await f.page.keyboard.type(text);
        } else {
          // The desktop cases keep editing the mounted editor just downloaded.
          await edit(f.page, kind, text);
        }
        await savedLocally(f.page);
        const beforeReload = (await stored(f.page, f.actor.id, f.item.id))!.outbox!;
        if (phone)
          await expect
            .poll(() => phoneText(f.page, f.unitId))
            .toBe(text + baseline.snapshot.body!.dataStream);
        expect(pending(beforeReload.checkpoint)).toBe(true);
        expect(beforeReload).toMatchObject({
          account: f.actor.id,
          item: f.item.id,
          unitId: f.unitId,
        });
        for (let reload = 0; reload < 2; reload++) {
          await f.page.reload();
          await usableCanvas(f.page);
          await savedLocally(f.page);
          if (phone) {
            const theme = reload === 0 ? 'light' : 'dark';
            await f.page.emulateMedia({ colorScheme: theme });
            await expect(f.page.locator('html')).toHaveAttribute('data-theme', theme);
            await textPoint(f.page);
            await expect
              .poll(() => phoneText(f.page, f.unitId))
              .toBe(text + baseline.snapshot.body!.dataStream);
            expect((await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint).toEqual(
              beforeReload.checkpoint,
            );
            await f.page
              .getByRole('button', { name: 'Save details: Saved locally', exact: true })
              .tap();
            await expect(
              f.page.getByRole('dialog', { name: 'Save details', exact: true }),
            ).toContainText('Saved on this device — waiting to sync.');
          } else expect(await copy(f.page, kind)).toContain(text);
          await f.page.screenshot({
            path: info.outputPath(
              `spn-053-offline-${phone ? 'doc-phone' : kind}-reload-${reload + 1}.png`,
            ),
            animations: 'disabled',
          });
          if (phone)
            await f.page.getByRole('button', { name: 'Close save details', exact: true }).tap();
          expect((await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint.buffer).toEqual(
            beforeReload.checkpoint.buffer,
          );
        }
        if (kind === 'sheet') {
          const pixels = async () => {
            const { data, info: image } = await sharp(
              await f.page.locator('.univer-container').screenshot(),
            )
              .removeAlpha()
              .raw()
              .toBuffer({ resolveWithObject: true });
            const colors = [
              [255, 153, 0],
              [34, 85, 238],
              [34, 187, 102],
            ];
            const counts = [0, 0, 0];
            for (let offset = 0; offset < data.length; offset += image.channels)
              colors.forEach((color, index) => {
                if (color.every((value, channel) => Math.abs(data[offset + channel] - value) < 12))
                  counts[index]++;
              });
            return counts.every((count) => count > 1000);
          };
          await expect.poll(pixels, { timeout: 25_000 }).toBe(true);
        }
        if (phone) expect(await f.read()).toEqual(baseline);
        await f.network.setOffline(false);
        await synced(f.page);
        const committed = await f.read();
        expect(committed.revision).toBe(baseline.revision + 1);
        expect(pending((await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint)).toBe(
          false,
        );
        expect((await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint.revision).toBe(
          committed.revision,
        );
        if (kind === 'sheet') expect(committed.snapshot.sheets.tab.cellData?.[0]?.[3]?.v).toBe(731);
        else expect(committed.snapshot.body!.dataStream.split(text)).toHaveLength(2);
        if (phone) {
          expect(committed.snapshot.body!.dataStream).toBe(
            text + baseline.snapshot.body!.dataStream,
          );
          expect(committed.snapshot.documentStyle).toEqual(baseline.snapshot.documentStyle);
          expect(committed.snapshot.settings).toEqual(baseline.snapshot.settings);
        }
        await matchesServer(f.page, committed);
        const writes = f.network.outgoing
          .filter((frame) => frame.type === 'submit')
          .slice(captured);
        expect(new Set(writes.map((frame) => frame.mutationId)).size).toBe(1);
        if (phone) {
          expect(beforeReload.checkpoint.sent).toBeNull();
          expect(beforeReload.checkpoint.inflight).toEqual([]);
          // Ordinary key events queue several native mutations offline. The
          // unchanged base must send that exact durable batch once on reconnect.
          expect(writes[0].mutations).toEqual(beforeReload.checkpoint.buffer.flat());
        }
        expect(
          f.db
            .prepare('SELECT count(*) AS n FROM spinel_sync_revisions WHERE unit_id=?')
            .get(f.unitId)!.n,
        ).toBe(1);
        await f.network.setOffline(true);
        await f.network.setOffline(false);
        await synced(f.page);
        expect(await f.read()).toEqual(committed);
        await f.page.reload();
        await synced(f.page);
        await matchesServer(f.page, committed);
        expect(f.errors).toEqual([]);
      } finally {
        await f.close();
      }
    });

  test('a traditional downloaded phone Doc retains its editor grant and queued edits while locally read-only', async ({
    browser,
    baseURL,
  }, info) => {
    const f = await fixture(browser, baseURL!, info, 'doc', {
      actor: 'editor',
      phone: true,
      flavor: DocumentFlavor.TRADITIONAL,
    });
    const region = f.page.getByRole('region', { name: 'Doc document', exact: true });
    const note = 'Edit on a larger screen. This Doc keeps its page layout.';
    try {
      // Queue an ordinary native edit on the larger screen before reopening
      // the same real device copy through its coarse-pointer phone fallback.
      await f.page.setViewportSize({ width: 1440, height: 1100 });
      await f.download();
      await expect(region).toHaveAttribute('data-mobile', 'false');
      const baseline = await f.read();
      await f.network.setOffline(true);
      const text = 'Queued before phone read mode 946';
      await edit(f.page, 'doc', text);
      await savedLocally(f.page);
      const before = (await stored(f.page, f.actor.id, f.item.id))!;
      expect(before.bundle).toMatchObject({ access: 'editor', readOnly: false });
      expect(pending(before.outbox!.checkpoint)).toBe(true);

      await f.page.setViewportSize({ width: 390, height: 844 });
      await f.page.reload();
      await usableCanvas(f.page);
      await expect(region).toHaveAttribute('data-mobile', 'true');
      await savedLocally(f.page);
      await expect(region.getByText(note, { exact: true })).toBeVisible();
      await expect(region.getByRole('button', { name: 'Edit', exact: true })).toHaveCount(0);
      await expect(region.getByRole('button', { name: 'Format', exact: true })).toHaveCount(0);
      await expect
        .poll(() => phoneText(f.page, f.unitId))
        .toBe(text + baseline.snapshot.body!.dataStream);
      const point = await textPoint(f.page);
      await f.page.touchscreen.tap(point.x, point.y);
      await f.page.touchscreen.tap(point.x, point.y);
      await expect(nativeInput(f.page)).not.toBeFocused();
      await f.page.keyboard.type('FORBIDDEN PHONE EDIT');
      await savedLocally(f.page);
      expect((await stored(f.page, f.actor.id, f.item.id))!.outbox).toEqual(before.outbox);
      expect(await phoneText(f.page, f.unitId)).toBe(text + baseline.snapshot.body!.dataStream);
      expect(await f.read()).toEqual(baseline);
      expect(f.network.outgoing.filter((frame) => frame.type === 'submit')).toEqual([]);
      for (const theme of ['light', 'dark'] as const) {
        await f.page.emulateMedia({ colorScheme: theme });
        await expect(f.page.locator('html')).toHaveAttribute('data-theme', theme);
        await f.page
          .getByRole('button', { name: 'Save details: Saved locally', exact: true })
          .tap();
        await expect(
          f.page.getByRole('dialog', { name: 'Save details', exact: true }),
        ).toContainText('Saved on this device — waiting to sync.');
        await f.page.screenshot({
          path: info.outputPath(`spn-053-offline-doc-phone-traditional-${theme}.png`),
          animations: 'disabled',
        });
        await f.page.getByRole('button', { name: 'Close save details', exact: true }).tap();
      }

      await f.network.setOffline(false);
      await synced(f.page);
      const committed = await f.read();
      expect(committed.revision).toBe(baseline.revision + 1);
      expect(committed.snapshot.body!.dataStream).toBe(text + baseline.snapshot.body!.dataStream);
      expect(committed.snapshot.documentStyle).toEqual(baseline.snapshot.documentStyle);
      expect(committed.snapshot.settings).toEqual(baseline.snapshot.settings);
      await matchesServer(f.page, committed);
      const after = (await stored(f.page, f.actor.id, f.item.id))!;
      expect(after.bundle).toMatchObject({ access: 'editor', readOnly: false });
      expect(pending(after.outbox!.checkpoint)).toBe(false);
      const writes = f.network.outgoing.filter((frame) => frame.type === 'submit');
      expect(new Set(writes.map((frame) => frame.mutationId)).size).toBe(1);
      // Check the app's scheduled authorization responses, not a fabricated
      // viewer grant, after the retained outbox has synchronized normally.
      for (let check = 0; check < 2; check++) {
        const response = await f.page.waitForResponse(
          (response) =>
            response.request().method() === 'POST' &&
            new URL(response.url()).pathname === `${f.prefix}/collaboration`,
          { timeout: 10_000 },
        );
        expect(response.status()).toBe(200);
        expect((await response.json()).access).toBe('editor');
      }
      await synced(f.page);
      await expect(region.getByText(note, { exact: true })).toBeVisible();
      expect(await f.read()).toEqual(committed);
      expect(f.errors).toEqual([]);
    } finally {
      await f.close();
    }
  });

  test('Doc Formula definitions survive offline edits and reloads while reconnect rechecks source access', async ({
    browser,
    baseURL,
  }, info) => {
    const f = await fixture(browser, baseURL!, info, 'doc');
    try {
      const source = f.workspace.create(f.editor.id, {
        name: 'OfflineInputs',
        kind: 'sheet',
        parentId: null,
      });
      const secret = 784512309;
      new SheetStore(f.workspace).save(f.editor.id, source.id, {
        revision: 0,
        writeId: randomUUID(),
        snapshot: {
          id: source.id,
          name: source.name,
          appVersion: '1.1.0',
          locale: LocaleType.EN_US,
          styles: {},
          sheetOrder: ['summary'],
          sheets: {
            summary: {
              id: 'summary',
              name: 'Summary',
              rowCount: 100,
              columnCount: 10,
              cellData: { 0: { 0: { v: secret } } },
            },
          },
        },
      });
      f.workspace.share(f.editor.id, source.id, f.owner.id, 'viewer');
      await f.page.goto(f.href);
      await expect(saveStatus(f.page)).toHaveText('All changes saved.', { timeout: 30_000 });
      await edit(f.page, 'doc', 'Formula context');
      await f.page.keyboard.press('Control+End');
      await f.page.keyboard.press('Enter');
      await expect
        .poll(async () => (await f.read()).snapshot.body?.dataStream)
        .toContain('Formula context\r');
      await expect(saveStatus(f.page)).toHaveText('All changes saved.', { timeout: 30_000 });
      await f.page.getByRole('button', { name: 'Document actions', exact: true }).click();
      await f.page.getByRole('menuitem', { name: 'Insert formula', exact: true }).click();
      const insert = f.page.getByRole('dialog', { name: 'Insert formula', exact: true });
      await insert.getByLabel('Formula', { exact: true }).fill('=OfflineInputs.Summary.A1');
      await insert.getByRole('button', { name: 'Insert formula', exact: true }).click();
      await expect(insert).not.toBeVisible({ timeout: 20_000 });
      await expect.poll(async () => docFormulas((await f.read()).snapshot.body).length).toBe(1);
      await expect(saveStatus(f.page)).toHaveText('All changes saved.', { timeout: 30_000 });
      await f.download();
      const baseline = await f.read();
      const definitions = docFormulas(baseline.snapshot.body).map((formula) => formula.definition);
      expect(definitions).toHaveLength(1);
      const openPanel = async () => {
        const panel = f.page.getByRole('dialog', { name: 'Formulas', exact: true });
        if (!(await panel.isVisible())) {
          const localButton = f.page.getByRole('button', { name: 'Formulas', exact: true });
          if (await localButton.count()) await localButton.click();
          else {
            await f.page.getByRole('button', { name: 'Document actions', exact: true }).click();
            await f.page.getByRole('menuitem', { name: 'Formulas', exact: true }).click();
          }
        }
        return panel;
      };
      let panel = await openPanel();
      await expect(panel.getByText(String(secret), { exact: true })).toBeVisible({
        timeout: 20_000,
      });
      await panel.getByRole('button', { name: 'Close dialog', exact: true }).click();
      await f.network.setOffline(true);
      const text = 'Offline Formula note 605 ';
      await edit(f.page, 'doc', text);
      await savedLocally(f.page);
      for (let reload = 0; reload < 2; reload++) {
        await f.page.reload();
        await usableCanvas(f.page);
        await savedLocally(f.page);
        expect(await copy(f.page, 'doc')).toContain(text);
        panel = await openPanel();
        await expect(panel.getByText('Result unavailable', { exact: true })).toBeVisible();
        await expect(panel.getByText(String(secret), { exact: true })).toHaveCount(0);
        expect(JSON.stringify(await stored(f.page, f.actor.id, f.item.id))).not.toContain(
          String(secret),
        );
        await f.page.screenshot({
          path: info.outputPath(`spn-053-offline-formulas-reload-${reload + 1}.png`),
          animations: 'disabled',
        });
        await panel.getByRole('button', { name: 'Close dialog', exact: true }).click();
      }
      f.workspace.share(f.editor.id, source.id, f.owner.id, null);
      await f.network.setOffline(false);
      await synced(f.page);
      const committed = await f.read();
      expect(committed.revision).toBe(baseline.revision + 1);
      expect(docFormulas(committed.snapshot.body).map((formula) => formula.definition)).toEqual(
        definitions,
      );
      await matchesServer(f.page, committed);
      panel = await openPanel();
      await expect(
        panel.getByText('You need access to this formula’s sources', { exact: true }),
      ).toBeVisible({ timeout: 20_000 });
      await expect(panel.getByText(String(secret), { exact: true })).toHaveCount(0);
      f.workspace.share(f.editor.id, source.id, f.owner.id, 'viewer');
      await expect(panel.getByText(String(secret), { exact: true })).toBeVisible({
        timeout: 20_000,
      });
      expect(JSON.stringify(await stored(f.page, f.actor.id, f.item.id))).not.toContain(
        String(secret),
      );
      expect(f.errors).toEqual([]);
    } finally {
      await f.close();
    }
  });

  test('a crash after durable acknowledgement but before local cleanup retains attention without duplicate replay', async ({
    browser,
    baseURL,
  }, info) => {
    const f = await fixture(browser, baseURL!, info, 'doc');
    try {
      // SPN-054 normally recovers this queue as a copy. Keep exercising the
      // original retained-checkpoint guarantee when publication is unavailable.
      await f.context.route('**/api/items/offline-recovery', (route) =>
        route.fulfill({ status: 503, json: { error: 'Recovery is temporarily unavailable.' } }),
      );
      await f.download();
      const baseline = await f.read();
      await f.network.setOffline(true);
      await edit(f.page, 'doc', 'Crash survives once 942');
      await savedLocally(f.page);
      await f.page.evaluate(
        ({ itemId, revision }) => {
          const put = IDBObjectStore.prototype.put;
          IDBObjectStore.prototype.put = function (value: any, key?: IDBValidKey) {
            if (
              this.name === 'items' &&
              value.itemId === itemId &&
              value.outbox?.checkpoint?.revision > revision &&
              !value.outbox.checkpoint.sent &&
              !value.outbox.checkpoint.buffer.length
            ) {
              sessionStorage.setItem('spinel-test-cleanup-aborted', '1');
              this.transaction.abort();
              throw new DOMException(
                'Simulated termination before cleanup committed',
                'AbortError',
              );
            }
            return key === undefined ? put.call(this, value) : put.call(this, value, key);
          };
        },
        { itemId: f.item.id, revision: baseline.revision },
      );
      await f.network.setOffline(false);
      await expect.poll(() => f.network.incoming.some((frame) => frame.type === 'ack')).toBe(true);
      await expect
        .poll(() => f.page.evaluate(() => sessionStorage.getItem('spinel-test-cleanup-aborted')))
        .toBe('1');
      const disk = (await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint;
      expect(disk.revision).toBe(baseline.revision);
      expect(disk.sent).not.toBeNull();
      const committed = await f.read();
      expect(committed.revision).toBe(baseline.revision + 1);
      // End the renderer after proving the server accepted the edit and its
      // cleanup transaction did not commit. The next renderer has no fault hook.
      await f.page.close();
      const reopened = await f.context.newPage();
      await reopened.goto(f.href);
      await attention(reopened);
      expect(await copy(reopened, 'doc')).toContain('Crash survives once 942');
      const retained = (await stored(reopened, f.actor.id, f.item.id))!.outbox!.checkpoint;
      expect(retained.sent).toEqual(disk.sent);
      expect(retained.failure).toBe('stale');
      await reopened.reload();
      await attention(reopened);
      expect(await f.read()).toEqual(committed);
      expect(committed.snapshot.body!.dataStream.split('Crash survives once 942')).toHaveLength(2);
      expect(
        f.db
          .prepare('SELECT count(*) AS n FROM spinel_sync_revisions WHERE unit_id=?')
          .get(f.unitId)!.n,
      ).toBe(1);
    } finally {
      await f.close();
    }
  });

  test('a cold offline editor retains its expired cross-sheet draft through unrelated storage events', async ({
    browser,
    baseURL,
  }, info) => {
    const f = await fixture(browser, baseURL!, info, 'sheet');
    try {
      await f.download();
      const sheet = f.page.getByRole('region', { name: 'Sheet document', exact: true });
      // A Sheet has both a cell editor and a formula-bar editor. This scenario
      // must focus the actual cell draft, including after a cross-sheet switch.
      const cellInput = f.page.locator(
        `[id="__editor_${DOCS_NORMAL_EDITOR_UNIT_ID_KEY}"][contenteditable="true"][data-u-comp="editor"]`,
      );
      await sheet.locator('[data-u-comp="sheet-bar-append-button"]').first().click();
      await expect(sheet.getByRole('tablist', { name: 'Sheet tabs' }).getByRole('tab')).toHaveCount(
        2,
      );
      await synced(f.page);
      const baseline = await f.read();
      const [first, second] = baseline.snapshot.sheetOrder.map(
        (id) => baseline.snapshot.sheets[id]!,
      );
      await sheet.getByRole('tab', { name: first.name, exact: true }).click();
      await f.network.setOffline(true);
      await f.page.reload();
      await usableCanvas(f.page);
      await savedLocally(f.page);
      // Native first-visit selection during formula reference mode belongs to
      // IRefSelectionsService, while typing checks the ordinary sheet selection.
      // Establish that normal selection through the real UI before the draft.
      await sheet.getByRole('tab', { name: second.name, exact: true }).click();
      await expect(sheet.getByRole('tab', { name: second.name, exact: true })).toHaveAttribute(
        'aria-selected',
        'true',
      );
      await selectCell(f.page, 'A1');
      await expect(sheet.locator('[data-u-comp="defined-name"] input')).toHaveValue('A1');
      await sheet.getByRole('tab', { name: first.name, exact: true }).click();
      await edit(f.page, 'sheet', '730', 'E1');
      await savedLocally(f.page);
      const retained = (await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint;
      const submitted = f.network.outgoing.filter((frame) => frame.type === 'submit').length;
      await selectCell(f.page, 'D1');
      await f.page.keyboard.insertText('=SUM(');
      await sheet.getByRole('tab', { name: second.name, exact: true }).click();
      await expect(sheet.getByRole('tab', { name: second.name, exact: true })).toHaveAttribute(
        'aria-selected',
        'true',
      );
      await cellInput.focus();
      await expect(cellInput).toBeFocused();
      await f.page.keyboard.insertText('A1)');
      await expect(
        f.page.getByText(
          'The range is protected, and you do not have edit permission. To edit, please contact the creator.',
          { exact: true },
        ),
      ).toHaveCount(0);
      const copyDraft = async () => {
        const sentinel = `not-copied-${randomUUID()}`;
        await f.page.evaluate((text) => navigator.clipboard.writeText(text), sentinel);
        await cellInput.focus();
        await f.page.keyboard.press('Control+a');
        await f.page.keyboard.press('Control+c');
        await expect
          .poll(() => f.page.evaluate(() => navigator.clipboard.readText()))
          .not.toBe(sentinel);
        return f.page.evaluate(() => navigator.clipboard.readText());
      };
      const draft = await copyDraft();
      expect(draft).toContain('=SUM(');
      expect(draft).toContain('A1)');
      await f.page.keyboard.press('End');
      const cookie = (await f.context.cookies()).find((entry) => entry.name === COOKIE_NAME)!;
      f.auth.revokeSession(f.auth.session(cookie.value)!.token_hash);
      await f.network.setOffline(false);
      const warning = 'Your sign-in ended. Copy the unfinished cell text before signing in again.';
      await expect(saveStatus(f.page)).toHaveText(warning);
      await expect
        .poll(() => f.page.evaluate(() => localStorage.getItem('spinel.offline.account')))
        .toBeNull();
      const other = await f.context.newPage();
      await other.goto('/sign-in');
      await expect(other.getByRole('button', { name: 'Sign in with a passkey' })).toBeVisible();
      await f.page.evaluate(() => {
        const changed = (event: StorageEvent) => {
          if (event.key !== 'spinel-test-benign-preference') return;
          window.removeEventListener('storage', changed);
          document.documentElement.setAttribute('data-spinel-storage-observed', 'true');
        };
        window.addEventListener('storage', changed);
      });
      await other.evaluate(() => localStorage.setItem('spinel-test-benign-preference', 'dark'));
      await expect(f.page.locator('html')).toHaveAttribute('data-spinel-storage-observed', 'true');
      await other.close();
      // Confirming while on the other sheet must not hide and then lose the
      // original draft when native sheet activation completes asynchronously.
      await cellInput.focus();
      await f.page.keyboard.press('Enter');
      await expect(saveStatus(f.page)).toHaveText(warning);
      expect(await copyDraft()).toBe(draft);
      expect((await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint.buffer).toEqual(
        retained.buffer,
      );
      expect(f.network.outgoing.filter((frame) => frame.type === 'submit')).toHaveLength(submitted);
      expect(await f.read()).toEqual(baseline);
      await f.page.screenshot({
        path: info.outputPath('spn-053-offline-expired-cell-input.png'),
        animations: 'disabled',
      });
      await f.network.setOffline(true);
      const blocked = await f.context.newPage();
      await blocked.goto(f.href);
      await expect(
        blocked.getByRole('heading', { name: "You're offline", exact: true }),
      ).toBeVisible();
      await expect(blocked.locator('.univer-container canvas')).toHaveCount(0);
      await blocked.close();
      await f.network.setOffline(false);
      // After copying, Escape explicitly discards only the unfinished draft.
      // The earlier durable queue remains and can finish the sign-in handoff.
      await cellInput.focus();
      await f.page.keyboard.press('Escape');
      await f.page.getByRole('button', { name: /^Save details:/ }).click();
      await f.page.getByRole('button', { name: 'Continue to sign-in', exact: true }).click();
      await expect(f.page).toHaveURL(/\/sign-in(?:\?|$)/);
      expect(pending((await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint)).toBe(true);
    } finally {
      await f.close();
    }
  });

  test('a failed local write never claims saved and retry commits it while still offline', async ({
    browser,
    baseURL,
  }, info) => {
    const f = await fixture(browser, baseURL!, info, 'sheet');
    try {
      await f.download();
      await f.network.setOffline(true);
      await f.page.evaluate((itemId) => {
        const put = IDBObjectStore.prototype.put;
        sessionStorage.setItem('spinel-test-quota', '1');
        IDBObjectStore.prototype.put = function (value: any, key?: IDBValidKey) {
          if (
            this.name === 'items' &&
            value.itemId === itemId &&
            value.outbox &&
            sessionStorage.getItem('spinel-test-quota')
          )
            throw new DOMException('Simulated storage quota failure', 'QuotaExceededError');
          return key === undefined ? put.call(this, value) : put.call(this, value, key);
        };
      }, f.item.id);
      await edit(f.page, 'sheet', '593');
      await expect(saveStatus(f.page)).toHaveText(
        'Changes could not be saved on this device. Keep this tab open and retry saving.',
      );
      expect(pending((await stored(f.page, f.actor.id, f.item.id))?.outbox?.checkpoint)).toBe(
        false,
      );
      expect(f.network.outgoing.filter((frame) => frame.type === 'submit')).toEqual([]);
      await f.page.evaluate(() => sessionStorage.removeItem('spinel-test-quota'));
      await f.page.getByRole('button', { name: 'Save details: Not saved', exact: true }).click();
      await f.page.getByRole('button', { name: 'Retry saving', exact: true }).click();
      await savedLocally(f.page);
      await f.page.keyboard.press('Escape');
      await f.page.reload();
      await savedLocally(f.page);
      expect(await copy(f.page, 'sheet')).toContain('593');
      await f.network.setOffline(false);
      await synced(f.page);
      expect((await f.read()).snapshot.sheets.first.cellData?.[0]?.[3]?.v).toBe(593);
    } finally {
      await f.close();
    }
  });

  test('a viewer download stays read-only without an outbox', async ({
    browser,
    baseURL,
  }, info) => {
    const f = await fixture(browser, baseURL!, info, 'sheet', { actor: 'viewer' });
    try {
      await f.download();
      const baseline = await f.read();
      await f.network.setOffline(true);
      await f.page.reload();
      await expect(saveStatus(f.page)).toHaveText('View only on this device.', { timeout: 30_000 });
      await expect(f.page.getByRole('button', { name: 'Bold', exact: true })).toBeDisabled();
      await selectCell(f.page, 'D1');
      await f.page.keyboard.insertText('Forbidden');
      await f.page.keyboard.press('Enter');
      expect(pending((await stored(f.page, f.actor.id, f.item.id))?.outbox?.checkpoint)).toBe(
        false,
      );
      await f.network.setOffline(false);
      await expect(saveStatus(f.page)).toHaveText('View only on this device.');
      expect(await f.read()).toEqual(baseline);
      expect(f.network.outgoing.filter((frame) => frame.type === 'submit')).toEqual([]);
    } finally {
      await f.close();
    }
  });

  test('another account cookie cannot replay the downloading account outbox or expose it in a new tab', async ({
    browser,
    baseURL,
  }, info) => {
    const f = await fixture(browser, baseURL!, info, 'doc');
    try {
      await f.download();
      const baseline = await f.read();
      await f.network.setOffline(true);
      await edit(f.page, 'doc', 'Owner private offline sentence');
      await savedLocally(f.page);
      const original = (await stored(f.page, f.owner.id, f.item.id))!.outbox!;
      // This account also has edit access, so authorization alone cannot stop
      // the wrong account from sending the first account's private queue.
      await f.context.addCookies([f.cookie(f.editor.id)]);
      await f.network.setOffline(false);
      await attention(f.page);
      expect(f.network.outgoing.filter((frame) => frame.type === 'submit')).toEqual([]);
      expect(await f.read()).toEqual(baseline);
      let accountChecks = 0;
      f.page.on('request', (request) => {
        if (new URL(request.url()).pathname === '/api/auth/session') accountChecks++;
      });
      const other = await f.context.newPage();
      await other.goto(f.href);
      await expect(saveStatus(other)).toHaveText('All changes saved.', { timeout: 30_000 });
      await expect(
        f.page.getByRole('heading', { name: 'This tab is locked.', exact: true }),
      ).toBeVisible();
      await expect(f.page.locator('.univer-container canvas')).toHaveCount(0);
      await expect(f.page.getByText(f.item.name, { exact: true })).toHaveCount(0);
      expect(accountChecks).toBe(0);
      const retained = (await stored(other, f.owner.id, f.item.id))!.outbox!;
      expect(retained.account).toBe(f.owner.id);
      expect(retained.checkpoint.buffer).toEqual(original.checkpoint.buffer);
      expect((await f.read()).snapshot.body!.dataStream).not.toContain(
        'Owner private offline sentence',
      );
      expect(await other.evaluate(() => localStorage.getItem('spinel.offline.account'))).not.toBe(
        f.owner.id,
      );
    } finally {
      await f.close();
    }
  });

  test('a native Space child retains exact scope through replay and an explicit unavailable sibling', async ({
    browser,
    baseURL,
  }, info) => {
    const f = await fixture(browser, baseURL!, info, 'doc', { space: true, actor: 'editor' });
    try {
      const sibling = f.spaces.createChild(f.owner.id, f.root!.id, {
        name: 'Not downloaded',
        kind: 'doc',
        parentId: f.root!.id,
      }).item;
      await f.download();
      const baseline = await f.read();
      await f.network.setOffline(true);
      await edit(f.page, 'doc', 'Prepared child local edit');
      await savedLocally(f.page);
      await f.page.reload();
      await usableCanvas(f.page);
      await savedLocally(f.page);
      expect(await copy(f.page, 'doc')).toContain('Prepared child local edit');
      await f.page.screenshot({
        path: info.outputPath('spn-053-offline-space-doc-reload.png'),
        animations: 'disabled',
      });
      const record = (await stored(f.page, f.actor.id, f.item.id))!.outbox!;
      expect(record).toMatchObject({
        account: f.editor.id,
        spaceId: f.root!.id,
        item: f.item.id,
        unitId: f.unitId,
      });
      await f.page.goto(`/spaces/${f.root!.id}?item=${sibling.id}`);
      await expect(
        f.page.getByRole('status').filter({ hasText: 'This page needs a connection.' }),
      ).toContainText('It has not been prepared in this Space');
      await expect(f.page.locator('.univer-container')).toHaveCount(0);
      await f.page.goto(f.href);
      await savedLocally(f.page);
      await f.network.setOffline(false);
      await synced(f.page);
      const committed = await f.read();
      expect(committed.revision).toBe(baseline.revision + 1);
      expect(committed.snapshot.body!.dataStream.split('Prepared child local edit')).toHaveLength(
        2,
      );
      await matchesServer(f.page, committed);
      expect((await f.control.request.get(`/api/items/${f.item.id}/offline-bundle`)).status()).toBe(
        404,
      );
    } finally {
      await f.close();
    }
  });

  test('preparing a Space child during a held metadata access check keeps its native editor and durable edits', async ({
    browser,
    baseURL,
  }, info) => {
    const f = await fixture(browser, baseURL!, info, 'doc', { space: true, actor: 'editor' });
    let releaseMetadata = () => {};
    const withheld = new Promise<void>((resolve) => {
      releaseMetadata = resolve;
    });
    try {
      const openPreparation = async (name: string) => {
        await f.page.getByRole('button', { name: 'Document actions', exact: true }).click();
        await f.page.getByRole('menuitem', { name: 'Offline copies', exact: true }).click();
        const dialog = f.page.getByRole('dialog', { name: 'Offline copies', exact: true });
        const button = dialog.getByRole('button', {
          name: `Make ${name} available offline on this device`,
        });
        await expect(button).toBeVisible();
        await expect(button).toBeEnabled();
        return {
          dialog,
          async prepare() {
            await button.click();
            await expect(dialog.getByRole('status')).toHaveText(
              `${name} is available offline on this device.`,
              { timeout: 120_000 },
            );
          },
        };
      };
      // Cache the real public runtime through another child's download first.
      // The held check keeps its real 2.5-second deadline; only this target's
      // first publication, not the public asset transfer, must cross it.
      const sibling = f.spaces.createChild(f.owner.id, f.root!.id, {
        name: 'Prepared sibling',
        kind: 'doc',
        parentId: f.root!.id,
      }).item;
      await f.page.goto(`/spaces/${f.root!.id}?item=${sibling.id}`);
      await expect(saveStatus(f.page)).toHaveText('All changes saved.', { timeout: 30_000 });
      await expect
        .poll(() => f.page.evaluate(() => Boolean(navigator.serviceWorker.controller)))
        .toBe(true);
      const siblingPreparation = await openPreparation(sibling.name);
      await siblingPreparation.prepare();
      await synced(f.page);
      await siblingPreparation.dialog
        .getByRole('button', { name: 'Close dialog', exact: true })
        .click();

      await f.page.goto(f.href);
      await expect(saveStatus(f.page)).toHaveText('All changes saved.', { timeout: 30_000 });
      expect(await stored(f.page, f.actor.id, f.item.id)).toBeUndefined();
      const baseline = await f.read();
      const canvas = await f.page.locator('.univer-container canvas').first().elementHandle();
      // Open the controls before holding the access check, so menu rendering
      // does not consume its deadline. Only publication crosses the response.
      const targetPreparation = await openPreparation(f.item.name);
      let held:
        | {
            request: Request;
            status: number;
            data: { item: { id: string; access: string }; live: { unitId: string } };
          }
        | undefined;
      let intercepted = false;
      await f.context.route(`${baseURL}${f.prefix}`, async (route) => {
        if (route.request().method() !== 'GET' || intercepted) return route.continue();
        intercepted = true;
        const response = await route.fetch();
        held = {
          request: route.request(),
          status: response.status(),
          data: await response.json(),
        };
        await withheld;
        await route.fulfill({ response });
      });
      await expect.poll(() => held?.status).toBe(200);
      expect(held!.data).toMatchObject({
        item: { id: f.item.id, access: 'editor' },
        live: { unitId: f.unitId },
      });
      const metadataRequest = held!.request;
      await targetPreparation.prepare();
      // This status proves the same mounted session activated its device copy
      // before the older { item, live } response is delivered.
      await synced(f.page);
      const delivered = f.page.waitForResponse(
        (response) => response.request() === metadataRequest,
      );
      const rechecked = f.page.waitForResponse(
        (response) =>
          response.request().method() === 'POST' &&
          new URL(response.url()).pathname === `${f.prefix}/collaboration`,
        { timeout: 10_000 },
      );
      releaseMetadata();
      // An expired/aborted request would miss the actual race, so require the
      // held real response to finish before accepting the fresh scoped check.
      const [deliveredResponse, checked] = await Promise.all([delivered, rechecked]);
      expect(await deliveredResponse.finished()).toBeNull();
      expect(checked.status()).toBe(200);
      expect(checked.request().headers()['x-spinel-offline-account']).toBe(f.actor.id);
      expect(await checked.json()).toMatchObject({
        user: { id: f.actor.id },
        access: 'editor',
        unitId: f.unitId,
      });
      await targetPreparation.dialog
        .getByRole('button', { name: 'Close dialog', exact: true })
        .click();
      await synced(f.page);
      expect(
        await f.page
          .locator('.univer-container canvas')
          .first()
          .evaluate((node, original) => node === original, canvas!),
      ).toBe(true);
      expect(await f.read()).toEqual(baseline);
      expect(pending((await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint)).toBe(
        false,
      );

      await f.network.setOffline(true);
      const text = 'Prepared during a pending access check 728.';
      await edit(f.page, 'doc', text);
      await savedLocally(f.page);
      const outbox = (await stored(f.page, f.actor.id, f.item.id))!.outbox!;
      expect(outbox).toMatchObject({
        account: f.actor.id,
        spaceId: f.root!.id,
        item: f.item.id,
        unitId: f.unitId,
      });
      expect(pending(outbox.checkpoint)).toBe(true);
      expect(await f.read()).toEqual(baseline);
      await f.network.setOffline(false);
      await synced(f.page);
      const committed = await f.read();
      expect(committed.revision).toBe(baseline.revision + 1);
      expect(committed.snapshot.body!.dataStream).toBe(text + baseline.snapshot.body!.dataStream);
      await matchesServer(f.page, committed);
      expect(pending((await stored(f.page, f.actor.id, f.item.id))!.outbox!.checkpoint)).toBe(
        false,
      );
      expect(f.errors).toEqual([]);
    } finally {
      releaseMetadata();
      await f.close();
    }
  });

  for (const change of ['revoked', 'viewer', 'trashed', 'restored'] as const)
    test(`a prepared Space child with ${change} live access/generation preserves its outbox without replay`, async ({
      browser,
      baseURL,
    }, info) => {
      const f = await fixture(browser, baseURL!, info, 'doc', { space: true, actor: 'editor' });
      try {
        // Failed recovery must preserve SPN-053's exact original queue/scope;
        // successful copies for these cases are covered in offline-recovery.
        await f.context.route('**/api/items/offline-recovery', (route) =>
          route.fulfill({ status: 503, json: { error: 'Recovery is temporarily unavailable.' } }),
        );
        await f.download();
        const baseline = await f.read();
        let checkpointId = '';
        if (change === 'restored') {
          const named = await f.control.request.post(`${f.prefix}/history`, {
            headers: { Origin: baseURL! },
            data: { name: 'Before offline' },
          });
          expect(named.status(), await named.text()).toBe(201);
          checkpointId = (await named.json()).version.id;
        }
        await f.network.setOffline(true);
        await edit(f.page, 'doc', `Keep ${change} offline edit`);
        await savedLocally(f.page);
        const original = (await stored(f.page, f.actor.id, f.item.id))!.outbox!;
        if (change === 'revoked' || change === 'viewer')
          f.spaces.share(
            f.owner.id,
            f.root!.id,
            f.editor.id,
            change === 'revoked' ? null : 'viewer',
          );
        else if (change === 'trashed') {
          const removed = await f.control.request.delete(f.prefix, {
            headers: { Origin: baseURL! },
            data: {},
          });
          expect(removed.status(), await removed.text()).toBe(200);
        } else {
          const restored = await f.control.request.post(
            `${f.prefix}/history/${checkpointId}/restore`,
            { headers: { Origin: baseURL! }, data: { unitId: f.unitId, requestId: randomUUID() } },
          );
          expect(restored.status(), await restored.text()).toBe(200);
        }
        // Restoring deliberately purges the previous server generation. Verify
        // the replacement's durable state, not that an obsolete row survives.
        const activeUnit =
          change === 'restored'
            ? ((await (await f.control.request.get(f.prefix)).json()).live.unitId as string)
            : f.unitId;
        const durableBefore = f.db
          .prepare('SELECT unit_id,revision,snapshot FROM spinel_sync_units WHERE unit_id=?')
          .get(activeUnit);
        await f.network.setOffline(false);
        await attention(f.page);
        expect(f.network.outgoing.filter((frame) => frame.type === 'submit')).toEqual([]);
        const retained = (await stored(f.page, f.actor.id, f.item.id))!.outbox!;
        expect(retained).toMatchObject({
          account: f.actor.id,
          spaceId: f.root!.id,
          item: f.item.id,
          unitId: f.unitId,
        });
        expect(retained.checkpoint.buffer).toEqual(original.checkpoint.buffer);
        expect(retained.checkpoint.revision).toBe(baseline.revision);
        expect(
          f.db
            .prepare('SELECT unit_id,revision,snapshot FROM spinel_sync_units WHERE unit_id=?')
            .get(activeUnit),
        ).toEqual(durableBefore);
        if (change === 'restored') {
          const metadata = await (await f.control.request.get(f.prefix)).json();
          expect(metadata.live.unitId).not.toBe(f.unitId);
          expect((await f.read(metadata.live.unitId)).snapshot.body!.dataStream).not.toContain(
            `Keep ${change} offline edit`,
          );
        }
      } finally {
        await f.close();
      }
    });
});
