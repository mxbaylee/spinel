import { resolve } from 'node:path';
import { applicationPolicy } from './application-policy.ts';
import { MaintenanceSupervisor } from '../src/server/maintenance/supervisor.ts';
import { supervisorDiagnostics } from '../src/server/diagnostics/supervisor.ts';

const root = process.env.SPINEL_MAINTENANCE_ROOT;
if (!root)
  throw new Error(
    'Set SPINEL_MAINTENANCE_ROOT to an existing private directory outside workspace and diagnostics storage.',
  );
const publicPort = Number(process.env.SPINEL_MAINTENANCE_PORT ?? 3002);
if (!Number.isInteger(publicPort) || publicPort < 0 || publicPort > 65535)
  throw new Error('SPINEL_MAINTENANCE_PORT must be a valid loopback port.');
const databasePath = resolve(process.env.DATABASE_PATH ?? 'data/spinel.sqlite');
const diagnostics = supervisorDiagnostics(databasePath, process.env.SPINEL_IMAGE);
const supervisor = await MaintenanceSupervisor.open({
  root,
  databasePath,
  publicPort,
  development: process.argv.includes('--dev'),
  applicationPolicy: applicationPolicy(Number(process.env.PORT ?? 3000)),
  diagnostics: diagnostics.sink,
}).catch(async (error: unknown) => {
  await diagnostics.close();
  throw error;
});
console.log(
  `Spinel recovery control is available on 127.0.0.1:${supervisor.publicAddress().port}.`,
);
console.log('Use the recovery CLI to verify, start under maintenance, and resume the workspace.');
let stopping = false;
async function shutdown() {
  if (stopping) return;
  stopping = true;
  try {
    await supervisor.close();
  } catch {
    console.error(
      'Recovery control could not prove complete shutdown. Maintenance remains required.',
    );
    process.exitCode = 1;
  } finally {
    await diagnostics.close();
  }
}
process.on('SIGINT', () => {
  void shutdown();
});
process.on('SIGTERM', () => {
  void shutdown();
});
