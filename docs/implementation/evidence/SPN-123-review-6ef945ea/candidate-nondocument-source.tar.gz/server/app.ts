import { appearanceRoutes } from '../src/server/appearance/routes.ts';
import { assertSyncTransitionReady } from '../src/server/sync/transition.ts';
import { profileAvatarRoutes } from '../src/server/profileAvatar.ts';
import express from 'express';
import { socialPreviewRoutes } from '../src/server/socialPreview.ts';
import { escapeMarkup } from '../src/shared/markup.ts';
import { spaceReviewReturnPath, spaceReviewSignInPath } from '../src/shared/spaceReviewRoute.ts';
import type { Request } from 'express';
import { mcpRoutes } from '../src/server/mcp/routes.ts';
import { assistantOAuthRoutes } from '../src/server/auth/oauthRoutes.ts';
import { AssistantOAuth } from '../src/server/auth/oauth.ts';
import { pwaRoutes } from '../src/server/pwa.ts';
import { guestRoutes } from '../src/server/workspace/guestRoutes.ts';
import { readFile } from 'node:fs/promises';
import { createHttpServer } from './http.ts';
import { resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import { DiagnosticsStore } from '../src/server/diagnostics/store.ts';
import { RuntimeDiagnostics } from '../src/server/diagnostics/runtime.ts';
import { isMaintenanceDiagnosticEvent } from '@spinel/diagnostics';
import { diagnosticsRoutes } from '../src/server/diagnostics/routes.ts';
import { diagnosticsConfiguration } from '../src/server/diagnostics/configuration.ts';
import { HealthJobs } from '../src/server/health/jobs.ts';
import { HealthMonitor } from '../src/server/health/monitor.ts';
import { healthRoutes } from '../src/server/health/routes.ts';
import { BackupService } from '../src/server/backup/service.ts';
import { backupRoutes } from '../src/server/backup/routes.ts';
import { restoreRoutes } from '../src/server/backup/restore-routes.ts';
import type { RestoreController } from '../src/server/backup/restore-control.ts';
import { captureTerminalRestoreFingerprint } from '../src/server/backup/restore-drain.ts';
import { restoreSnapshotFingerprint } from '../src/server/backup/inventory.ts';
import { openDatabase } from './database.ts';
import { AuthStore } from '../src/server/auth/store.ts';
import { authRoutes, cookieToken } from '../src/server/auth/routes.ts';
import { workspaceRoutes } from '../src/server/workspace/routes.ts';
import { spaceRoutes } from '../src/server/workspace/space-routes.ts';
import { spaceNativeRoutes } from '../src/server/workspace/space-native-routes.ts';
import { WorkspaceStore } from '../src/server/workspace/store.ts';
import { migrateSpaceSchema } from '../src/server/workspace/space-schema.ts';
import { TrashStore, startTrashCleanup } from '../src/server/workspace/trash.ts';
import { HistoryStore } from '../src/server/history/store.ts';
import { CollaborationStore } from '../src/server/collaboration/service.ts';
import { attachSync } from '../src/server/sync/transport.ts';
import { assertRestoreAuthority } from '../src/server/maintenance/restore-authority.ts';
import type { RestoreAuthority } from '../src/shared/maintenance.ts';
import type { MaintenanceBridge } from '../src/shared/maintenance.ts';
import { MaintenanceGate, ShutdownError } from '../src/server/maintenance/gate.ts';
import { maintenanceRoutes } from '../src/server/maintenance/routes.ts';
import { assertNoPendingRestore } from '../src/server/maintenance/restore-barrier.ts';
import {
  fileIdentity,
  sameFile,
  canonicalDatabasePath,
} from '../src/server/maintenance/journal.ts';

import {
  consumeRestoreOpening,
  sameRestoreTrialReference,
} from '../src/server/maintenance/restore-trial.ts';
import type { RestoreOpening } from '../src/server/maintenance/restore-trial.ts';

export const projectRoot = resolve(import.meta.dirname, '..');
/** Below the supervisor's 15 s stop budget, leaving time to close stores. */
const SHUTDOWN_DRAIN_MS = 10_000;

export interface AppOptions {
  databasePath: string;
  origin?: string;
  development?: boolean;
  staticDirectory?: string;
  backupConfigPath?: string;
  image?: string;
  /** Spaces are enabled by default; false explicitly closes every Space boundary. */
  spaceReview?: boolean;
  /** Only the deployment supervisor can provide live recovery control. */
  maintenance?: MaintenanceBridge;
  restoreController?: RestoreController;
  /** Internal bounded rehearsal/trial only; never a browser-supplied setting. */
  restoreMaximumBytes?: number;
  /** Opaque capability supplied only by the complete inherited-ownership handoff. */
  restoreOpening?: RestoreOpening;
}

export async function createApp(input: AppOptions) {
  const options = { ...input };
  const databasePath = canonicalDatabasePath(options.databasePath);
  if (options.restoreOpening !== undefined && options.databasePath !== databasePath)
    throw new Error('Restore opening requires its exact canonical target.');
  const trial =
    options.restoreOpening !== undefined
      ? await consumeRestoreOpening(options.restoreOpening, databasePath, {
          origin: options.origin ?? 'http://localhost:3000',
          image: options.image ?? '',
          spacesEnabled: options.spaceReview !== false,
          staticDirectory: resolve(options.staticDirectory ?? resolve(projectRoot, 'dist')),
          consequencesVersion: 1,
        })
      : undefined;
  if (!trial) assertNoPendingRestore(databasePath);
  else {
    const state = options.maintenance?.adminStatus(),
      actual = options.maintenance?.status();
    if (
      options.development ||
      !state?.available ||
      !actual?.available ||
      !['starting', 'paused'].includes(state.phase) ||
      !['starting', 'paused'].includes(actual.phase) ||
      state.epoch !== trial.epoch ||
      actual.epoch !== trial.epoch ||
      state.generationId !== trial.generationId ||
      Date.now() >= trial.deadline
    )
      throw new Error('Restore trial has no matching closed application state.');
  }
  let trialClosed = !!trial,
    trialEnding = false;
  let diagnostics: DiagnosticsStore | undefined;
  const maintenance = new MaintenanceGate(
    options.maintenance,
    () => trialClosed,
    (event) => {
      if (isMaintenanceDiagnosticEvent(event)) diagnostics?.recordMaintenance(event);
    },
  );
  const database = openDatabase(options.databasePath);
  const startupMark = () =>
    JSON.stringify({
      changes: database.prepare('SELECT total_changes() AS n').get()!.n,
      schema: database.prepare('PRAGMA schema_version').get()!.schema_version,
    });
  // Capture before constructors. Equal final content alone could hide a write
  // followed by an undo, or a temporary schema change during initialization.
  let initialMark: string | null = null;
  let originalMaximumPages: number | undefined;
  let initialEpoch: string | undefined;
  let initialGeneration: string | undefined;
  let startupStayedClosed = !!options.maintenance;
  const observeTrialAdmission = () => {
    const state = options.maintenance?.adminStatus(),
      actual = maintenance.status;
    if (
      !state?.available ||
      !actual.available ||
      maintenance.running ||
      !['starting', 'paused'].includes(state.phase) ||
      !['starting', 'paused'].includes(actual.phase) ||
      state.epoch !== initialEpoch ||
      actual.epoch !== initialEpoch ||
      state.generationId !== initialGeneration
    )
      startupStayedClosed = false;
  };
  const app = express();
  app.disable('x-powered-by');
  // Runs before every auth, metadata, static and health handler. The sync upgrade
  // handler and all background work independently consult this same closed gate.
  app.use((_request, response, next) => {
    if (!trialClosed) {
      next();
      return;
    }
    response
      .status(503)
      .set('Cache-Control', 'no-store')
      .json({ code: 'maintenance', error: 'Workspace recovery is being verified.' });
  });
  const server = createHttpServer(app);
  app.use(profileAvatarRoutes());
  let vite: import('vite').ViteDevServer | undefined;
  let stopCleanup = () => {};
  let backups: BackupService | undefined;
  let collaboration: CollaborationStore | undefined;
  let history: HistoryStore | undefined;
  let realtime: ReturnType<typeof attachSync> | undefined;
  let purgeTimer: ReturnType<typeof setInterval> | undefined;
  let healthTimer: ReturnType<typeof setInterval> | undefined;
  let runtimeDiagnostics: RuntimeDiagnostics | undefined;
  let unsubscribeMaintenance = () => {};
  let unsubscribeTrialObservation = () => {};
  let draining: Promise<void> | undefined;

  try {
    const maximumBytes = trial?.maximumBytes ?? options.restoreMaximumBytes;
    if (maximumBytes !== undefined) {
      const maximum = maximumBytes,
        status = maintenance.status;
      const pageSize = Number(database.prepare('PRAGMA page_size').get()!.page_size);
      const pages = Number(database.prepare('PRAGMA page_count').get()!.page_count);
      if (
        !status.available ||
        !['starting', 'paused'].includes(status.phase) ||
        !Number.isSafeInteger(maximum) ||
        maximum < 4096 ||
        maximum > 8 * 1024 ** 3 ||
        pages * pageSize > maximum
      )
        throw new Error('Invalid restore startup resource boundary.');
      originalMaximumPages = Number(
        database.prepare('PRAGMA max_page_count').get()!.max_page_count,
      );
      if (!Number.isSafeInteger(originalMaximumPages) || originalMaximumPages < pages)
        throw new Error('Invalid original database growth boundary.');
      database.exec(
        `PRAGMA cache_size=-2048; PRAGMA temp_store=FILE; PRAGMA max_page_count=${Math.floor(maximum / pageSize)}`,
      );
    }
    if (options.maintenance) {
      initialMark = startupMark();
      initialEpoch = maintenance.status.epoch;
      initialGeneration = options.maintenance.adminStatus().generationId;
      observeTrialAdmission();
      // Subscribe before constructors/awaits: a later return to paused cannot
      // rehabilitate a process that already admitted ordinary work.
      unsubscribeTrialObservation = options.maintenance.subscribe(observeTrialAdmission);
    }
    diagnostics = new DiagnosticsStore(
      diagnosticsConfiguration(options.databasePath, options.image),
    );
    if (diagnostics.status().available) runtimeDiagnostics = new RuntimeDiagnostics();
    const jobs = new HealthJobs({
      observe: ({ job, success, durationMs, runId }) => {
        diagnostics!.emit(
          {
            name: 'job.result',
            details: {
              job: job === 'history-maintenance' ? 'history-prune' : job,
              outcome: success ? 'success' : 'failure',
              durationMs,
            },
          },
          { component: 'health', runId },
        );
      },
    });
    assertSyncTransitionReady(database);
    const auth = new AuthStore(database);
    app.get('/api/maintenance', (_request, response) => {
      response.set('Cache-Control', 'no-store').json(maintenance.status);
    });
    app.use(
      '/api/admin/maintenance',
      maintenanceRoutes(auth, options.maintenance, options.origin ?? 'http://localhost:3000'),
    );
    const admit = maintenance.middleware();
    app.use((request, response, next) => {
      // Session and exact guest metadata lookups are read-only. Keep current
      // Operator authority and guest expiry/revocation visible during a pause.
      // Other reads can prepare native data or update auth metadata and gate.
      // Express routing is case-insensitive, so these matches are too: `/API/…`
      // must not reach an `/api` route without admission.
      if (
        (request.method === 'GET' &&
          (/^\/api\/auth\/session$/i.test(request.path) ||
            /^\/api\/guest\/[a-f\d-]{36}\/?$/i.test(request.path))) ||
        !/^\/(?:api(?:\/|$)|sync-api(?:\/|$)|mcp(?:\/|$)|authorize(?:\/|$)|register(?:\/|$)|token(?:\/|$)|revoke(?:\/|$))/i.test(
          request.path,
        )
      ) {
        next();
        return;
      }
      admit(request, response, next);
    });
    app.use(
      '/api/auth',
      authRoutes(auth, options.origin ?? 'http://localhost:3000', async () => {
        await realtime?.revalidate();
      }),
    );
    const spaceReview = options.spaceReview !== false;
    const workspace = new WorkspaceStore(auth, { spacesEnabled: spaceReview });
    // Rebuild the pre-production item schema before native document services start.
    migrateSpaceSchema(database);
    const origin = options.origin ?? 'http://localhost:3000';
    const oauth = new AssistantOAuth(auth, origin);
    app.use(assistantOAuthRoutes(oauth));
    collaboration = new CollaborationStore(workspace, options.databasePath, {
      spaceReview,
      observePurge: () => jobs.begin('collaboration-purge'),
      diagnostics: (event, context, actorId) => {
        if (!actorId.startsWith('guest:')) diagnostics!.record(event, context, actorId);
      },
    });
    history = new HistoryStore(
      workspace,
      collaboration,
      () => jobs.begin('history-maintenance'),
      (event, context, actorId) => diagnostics!.record(event, context, actorId),
    );
    app.use('/mcp', mcpRoutes(workspace, collaboration, origin));
    realtime = attachSync(server, app, workspace, collaboration, origin, maintenance);
    // Retired protocol paths must not fall through to the application shell.
    // Stale tabs cannot re-enter a second collaboration backend after cutover.
    app.use(
      ['/universer-api', '/guest-api', '/space-api', '/guest-space-api'],
      (_request, response) => {
        response
          .set('Cache-Control', 'no-store')
          .status(404)
          .json({ error: 'Reload Spinel to continue.' });
      },
    );
    workspace.links.recover();
    app.use(guestRoutes(workspace, collaboration, origin, (id) => realtime!.privacyChanged(id)));
    app.use(
      '/api/guest-spaces/:spaceId/items/:itemId',
      spaceNativeRoutes(workspace, collaboration, origin, { spaceReview, guest: true }),
    );
    app.use('/api/guest-spaces', spaceRoutes(workspace, origin, { spaceReview, guest: true }));
    app.use('/api/appearance', appearanceRoutes(workspace, origin));
    app.use('/api', (request, response, next) => {
      response.set('Cache-Control', 'no-store');
      if (!auth.session(cookieToken(request))?.user_id) {
        response.status(401).json({ error: 'Sign in to continue.', redirect: '/sign-in' });
        return;
      }
      next();
    });

    app.use('/api', (_request, response, next) => {
      response.once('finish', () => {
        void realtime?.revalidate().catch(() => {});
      });
      next();
    });
    app.use('/api', diagnosticsRoutes(workspace, diagnostics, origin));
    app.use(
      '/api/items',
      workspaceRoutes(auth, origin, workspace, collaboration, history, (event, context, actorId) =>
        diagnostics!.record(event, context, actorId),
      ),
    );
    app.use(
      '/api/spaces/:spaceId/items/:itemId',
      spaceNativeRoutes(workspace, collaboration, origin, {
        spaceReview,
        history,
        diagnostics: (event, context, actorId) => diagnostics!.record(event, context, actorId),
      }),
    );
    app.use('/api/spaces', spaceRoutes(workspace, origin, { spaceReview }));
    stopCleanup = startTrashCleanup(
      new TrashStore(workspace),
      () => jobs.begin('trash-expiry'),
      () => jobs.begin('space-trash-expiry'),
      (work) => {
        maintenance.job(work);
      },
    );
    await (maintenance.job(() => collaboration!.purgeDeleted()) ?? Promise.resolve()).catch(() =>
      console.error('Collaboration purge failed; retained generations will retry.'),
    );
    purgeTimer = setInterval(() => {
      void (maintenance.job(() => collaboration!.purgeDeleted()) ?? Promise.resolve()).catch(() =>
        console.error('Collaboration purge failed; retained generations will retry.'),
      );
    }, 60_000);
    purgeTimer.unref();
    backups = new BackupService(database, {
      databasePath: options.databasePath,
      origin: options.origin ?? 'http://localhost:3000',
      configPath: options.backupConfigPath,
      image: options.image,
      restoreController: options.restoreController,
      spacesEnabled: spaceReview,
      observe: () => {
        const started = Date.now(),
          runId = randomUUID();
        return (success) =>
          diagnostics!.emit(
            {
              name: 'job.result',
              details: {
                job: 'backup',
                outcome: success ? 'success' : 'failure',
                durationMs: Math.max(0, Date.now() - started),
              },
            },
            { component: 'health', runId },
          );
      },
    });
    database.setMaintenanceGate(maintenance);
    diagnostics.setMaintenanceGate(maintenance);
    const health = new HealthMonitor({
      applicationPath: options.databasePath,
      diagnosticsPath: diagnostics.path,
      jobs,
      editorConnections: () => realtime!.connectionCount(),
      logicalDatabaseBytes: () =>
        Number(database.prepare('PRAGMA page_count').get()?.page_count) *
        Number(database.prepare('PRAGMA page_size').get()?.page_size),
    });
    app.use(healthRoutes(auth, health));
    const sampleHealth = async () => {
      const sample = await health.sample();
      runtimeDiagnostics?.sample(diagnostics!.emit);
      for (const [scope, value] of [
        ['process', sample.memory.processRssBytes],
        ['host', sample.memory.systemUsedBytes],
        ['container', sample.memory.containerUsedBytes],
      ] as const)
        if (value !== null)
          diagnostics!.emit(
            {
              name: 'runtime.memory',
              metric: { kind: 'gauge', unit: 'bytes', value },
              details: { scope },
            },
            { component: 'health' },
          );
      diagnostics!.emit(
        {
          name: 'runtime.connections',
          metric: { kind: 'gauge', unit: 'count', value: sample.editorConnections },
          details: {},
        },
        { component: 'health' },
      );
      for (const store of ['application', 'diagnostics'] as const) {
        const size = sample[store];
        if (!size) continue;
        for (const [part, value] of [
          ['database', size.databaseBytes],
          ['wal', size.walBytes],
        ] as const)
          diagnostics!.emit(
            {
              name: 'storage.bytes',
              metric: { kind: 'gauge', unit: 'bytes', value },
              details: { store, part },
            },
            { component: 'health' },
          );
      }
      if (sample.storage.freeBytes !== null)
        diagnostics!.emit(
          {
            name: 'storage.free',
            metric: { kind: 'gauge', unit: 'bytes', value: sample.storage.freeBytes },
            details: {},
          },
          { component: 'health' },
        );
    };
    const collectHealth = () => {
      void (maintenance.job(sampleHealth) ?? Promise.resolve()).catch(() => {});
    };
    collectHealth();
    healthTimer = setInterval(collectHealth, 60_000);
    healthTimer.unref();
    app.use('/api/admin/backups', backupRoutes(auth, backups, origin));
    app.use('/api/admin/restores', restoreRoutes(auth, backups.restores, origin));
    app.get('/api/health', (_request, response) => {
      database.prepare('SELECT 1').get();
      response.json({ status: 'ok' });
    });
    app.use('/api', (_request, response) => {
      response.status(404).json({ error: 'Not found' });
    });

    app.use(pwaRoutes());
    app.use(socialPreviewRoutes(workspace.links));
    // Only configured origin and authorized preview metadata, never request hosts.
    const pageMetadata = (html: string, request: Request) => {
      const preview = request.path.startsWith('/share/')
        ? workspace.links.preview(request.params.id, request.query.preview)
        : undefined;
      const title = preview ? `${preview.name} — Spinel` : 'Spinel';
      const image = preview
        ? `/share/${encodeURIComponent(String(request.params.id))}/preview.png?preview=${encodeURIComponent(String(request.query.preview))}`
        : '/social-preview.png';
      const values: Record<string, string> = {
        TITLE: title,
        IMAGE: new URL(image, origin).href,
        DESCRIPTION: preview
          ? `A ${preview.kind === 'space' ? 'Space' : preview.kind === 'sheet' ? 'spreadsheet' : 'document'} shared with you on Spinel.`
          : 'Your private workspace for documents and spreadsheets.',
        IMAGE_ALT: preview
          ? `${preview.kind === 'space' ? 'Space' : preview.kind === 'sheet' ? 'Spreadsheet' : 'Document'}: ${preview.name}. Shared on Spinel.`
          : "Spinel's faceted pink heart. A little space for your big ideas. Documents and spreadsheets, together.",
      };
      return html.replace(
        /__SPINEL_(TITLE|IMAGE|DESCRIPTION|IMAGE_ALT)__/g,
        (_placeholder, key: string) => escapeMarkup(values[key]),
      );
    };

    const pages = [
      '/sign-in',
      '/connect',
      '/setup',
      '/recover-admin',
      '/invite',
      '/',
      '/settings',
      '/profile',
      '/admin',
      '/preview',
      '/share/:id',
      ...(spaceReview
        ? ['/spaces', '/spaces/:spaceId', '/review/spaces', '/review/spaces/:spaceId']
        : []),
    ];
    app.get(pages, (request, response, next) => {
      response.set('Cache-Control', 'no-store');
      if (request.path === '/connect' || request.path === '/sign-in') {
        response.set('Content-Security-Policy', "frame-ancestors 'none'");
        response.set('X-Frame-Options', 'DENY');
      }
      if (
        request.path === '/connect' ||
        (request.path === '/sign-in' && request.query.connect !== undefined)
      ) {
        response.set('Referrer-Policy', 'no-referrer');
        next();
        return;
      }
      if (
        request.path === '/invite' ||
        request.path === '/recover-admin' ||
        request.path.startsWith('/share/')
      ) {
        response.set('Referrer-Policy', 'no-referrer');
        next();
        return;
      }
      if (request.path === '/setup') {
        response.set('Referrer-Policy', 'no-referrer');
        if (auth.userCount()) {
          response
            .status(409)
            .type('text')
            .send('This instance is already claimed. Setup is closed.');
          return;
        }
        next();
        return;
      }
      if (request.path === '/settings') {
        response.redirect(302, '/profile' + request.originalUrl.slice('/settings'.length));
        return;
      }
      const session = auth.session(cookieToken(request));
      const user = session?.user_id ? auth.user(session.user_id) : undefined;
      if (/^\/(?:review\/)?spaces(?:\/|$)/.test(request.path) && user?.is_admin) {
        response.status(404).type('text').send('Not found');
        return;
      }
      if (/^\/admin\/?$/i.test(request.path) && !user?.is_admin) {
        response.status(404).type('text').send('Not found');
        return;
      }
      if (!user && request.path !== '/sign-in') {
        response.redirect(
          (spaceReview && spaceReviewSignInPath(new URL(request.originalUrl, origin))) ||
            '/sign-in',
        );
        return;
      }
      if (
        user &&
        (request.path === '/sign-in' ||
          (user.is_admin && request.path === '/') ||
          (!user.is_admin && request.path === '/admin'))
      ) {
        response.redirect(
          user.is_admin
            ? '/admin'
            : (spaceReview && spaceReviewReturnPath(new URL(request.originalUrl, origin))) || '/',
        );
        return;
      }
      next();
    });
    if (options.development) {
      // Vite's native compiler otherwise sizes its pools from the host CPU
      // count. Bound its default parallelism beside the live collaboration
      // runtime and return freed native arenas promptly so a cold editor load
      // leaves room for the PDF child. Apply before loading the native compiler.
      process.env.ROLLDOWN_WORKER_THREADS ??= '2';
      process.env.RAYON_NUM_THREADS ??= '2';
      process.env.MIMALLOC_PURGE_DELAY ??= '0';
      const { createServer: createViteServer } = await import('vite');
      vite = await createViteServer({
        configFile: resolve(projectRoot, 'vite.config.ts'),
        // Node 24 can load this TypeScript config without watched temporary bundles.
        configLoader: 'native',
        server: {
          middlewareMode: true,
          hmr: { server },
          // Vite otherwise discovers the repository root and exposes private SQLite
          // files through /@fs/. Only browser source and dependencies are public.
          fs: {
            strict: true,
            allow: [
              resolve(projectRoot, 'web'),
              resolve(projectRoot, 'src/shared'),
              resolve(projectRoot, 'src/ui'),
              resolve(projectRoot, 'node_modules'),
            ],
            deny: [
              '.env',
              '.env.*',
              '*.{crt,pem}',
              '**/.git/**',
              '**/*.sqlite',
              '**/*.sqlite-*',
              resolve(options.databasePath),
              `${resolve(options.databasePath)}-*`,
            ],
          },
        },
        appType: 'custom',
      });
      // Pages go before Vite, which treats extensionless URLs as modules and would
      // serve web/setup.ts as source for /setup.
      app.get(pages, async (request, response) => {
        const template = await readFile(resolve(projectRoot, 'web/index.html'), 'utf8');
        const html = await vite!.transformIndexHtml(request.originalUrl, template);
        response.type('html').send(pageMetadata(html, request));
      });
      app.use(vite.middlewares);
    } else {
      const directory = options.staticDirectory ?? resolve(projectRoot, 'dist');
      // Fail at startup with a useful error instead of serving a broken dashboard.
      const html = await readFile(resolve(directory, 'index.html'), 'utf8');
      app.get(pages, (request, response) => {
        response.type('html').send(pageMetadata(html, request));
      });
      app.get('/service-worker.js', (_request, response) => {
        response.set('Cache-Control', 'no-store').sendFile(resolve(directory, 'service-worker.js'));
      });
      app.use(
        '/assets',
        express.static(resolve(directory, 'assets'), { dotfiles: 'deny', index: false }),
      );
    }
    app.use((request, response) => {
      if (!auth.session(cookieToken(request))?.user_id) {
        response.redirect('/sign-in');
        return;
      }
      response.status(404).type('text').send('Not found');
    });
    await backups.start();
    history.start();
    unsubscribeMaintenance =
      options.maintenance?.subscribe((status) => {
        realtime?.maintenance(status);
        if (status.phase !== 'draining' || draining) return;
        draining = (async () => {
          try {
            // Downloads, imports and backup preparation can run for minutes.
            // Cancel them so the bounded drain covers ordinary writes only.
            maintenance.cancelLongWork();
            await maintenance.drain();
            database.assertQuiescent();
            await diagnostics?.drainMaintenance();
            if (
              maintenance.status.phase === 'draining' &&
              maintenance.status.epoch === status.epoch
            )
              options.maintenance!.drained(status.epoch);
          } catch {
            options.maintenance!.fail('drain-failed');
          }
        })().finally(() => {
          draining = undefined;
        });
      }) ?? (() => {});
  } catch (error) {
    runtimeDiagnostics?.close();
    unsubscribeTrialObservation();
    unsubscribeMaintenance();
    stopCleanup();
    clearInterval(purgeTimer);
    clearInterval(healthTimer);
    await realtime?.close();
    await history?.close();
    await collaboration?.close();
    await backups?.close();
    await vite?.close();
    database.close();
    await diagnostics?.close();
    throw error;
  }

  function verifyPausedRestore(expected: {
    fingerprint: string;
    epoch: string;
    generationId: string;
  }) {
    observeTrialAdmission();
    const state = options.maintenance?.adminStatus();
    if (
      !startupStayedClosed ||
      !database.isOpen ||
      !state?.available ||
      !['starting', 'paused'].includes(state.phase) ||
      maintenance.pending ||
      initialMark === null ||
      expected.epoch !== initialEpoch ||
      state.epoch !== initialEpoch ||
      expected.generationId !== initialGeneration ||
      state.generationId !== initialGeneration ||
      !/^[a-f0-9]{64}$/.test(expected.fingerprint) ||
      startupMark() !== initialMark
    )
      throw new Error('The restore trial did not retain its prepared startup state.');
    database.assertQuiescent();
    database.exec('BEGIN');
    try {
      if (restoreSnapshotFingerprint(database) !== expected.fingerprint)
        throw new Error('The restore trial differs from its prepared snapshot.');
      database.exec('COMMIT');
    } catch (error) {
      database.exec('ROLLBACK');
      throw error;
    }
  }

  return {
    server,
    maintenance,
    /** Private live-child check. No verification is renewed and nothing is written. */
    verifyRestoreAuthority(proof: RestoreAuthority) {
      if (!database.isOpen || !maintenance.running)
        throw new Error('Restore authority requires the current running application.');
      assertRestoreAuthority(database, proof);
    },
    /** Private readiness and release; neither method is mounted on HTTP. */
    verifyPausedRestore,
    restoreTrial: trial ? structuredClone(trial) : undefined,
    releaseRestoreTrial(reference: unknown) {
      if (!trial || trialEnding || !database.isOpen || !sameRestoreTrialReference(reference, trial))
        throw new Error('Restore release has no matching trial.');
      if (!trialClosed) return; // Same-outcome retry reports completion without renewing authority.
      if (Date.now() >= trial.deadline) throw new Error('Restore release expired.');
      assertNoPendingRestore(databasePath);
      if (!sameFile(fileIdentity(databasePath), trial.identity))
        throw new Error('Restore target changed.');
      verifyPausedRestore({
        fingerprint: trial.output.fingerprint,
        epoch: trial.epoch,
        generationId: trial.generationId,
      });
      if (Date.now() >= trial.deadline) throw new Error('Restore release expired.');
      if (originalMaximumPages !== undefined)
        maintenance.initialize(() =>
          database.exec(`PRAGMA max_page_count=${originalMaximumPages}`),
        );
      assertNoPendingRestore(databasePath);
      if (Date.now() >= trial.deadline) throw new Error('Restore release expired.');
      startupStayedClosed = false;
      unsubscribeTrialObservation();
      trialClosed = false;
    },
    async close(options?: {
      /** Private supervised restore shutdown. Resolve only after the parent has
       * durably accepted the final witness for its exact pending challenge. */
      acceptRestoreWitness?: (fingerprint: string) => Promise<void>;
    }) {
      trialEnding = true;
      startupStayedClosed = false;
      unsubscribeTrialObservation();
      runtimeDiagnostics?.close();
      unsubscribeMaintenance();
      stopCleanup();
      clearInterval(purgeTimer);
      clearInterval(healthTimer);
      // No new admission after shutdown begins. Existing leases still own their
      // writes while the bounded drain runs; stopping sockets is not a drain.
      maintenance.stopAdmission();
      // A restart is not maintenance; stopped jobs must not say it was.
      maintenance.cancelLongWork(new ShutdownError());
      // Shutdown must finish inside the supervisor's SIGTERM→SIGKILL budget
      // (STOP_MS, 15 s), so it drains for less than a maintenance pause does.
      await maintenance.drain(SHUTDOWN_DRAIN_MS);
      database.assertQuiescent();
      await diagnostics?.drainMaintenance();
      await realtime?.close();
      await vite?.close();
      if (server.listening) {
        await new Promise<void>((resolveClose, reject) => {
          server.close((error) => (error ? reject(error) : resolveClose()));
          server.closeAllConnections();
        });
      }
      await backups?.close();
      await history?.close();
      await (
        maintenance.status.available
          ? Promise.resolve()
          : (collaboration?.purgeDeleted() ?? Promise.resolve())
      ).catch(() =>
        console.error(
          'Collaboration purge incomplete; retained generations will retry after startup.',
        ),
      );
      await collaboration?.close();
      maintenance.stop();
      try {
        if (options?.acceptRestoreWitness) {
          const fingerprint = captureTerminalRestoreFingerprint(database);
          // No SQLite transaction remains open while waiting for persistence.
          await options.acceptRestoreWitness(fingerprint);
        }
      } finally {
        try {
          database.close();
        } finally {
          await diagnostics?.close();
        }
      }
    },
  };
}
