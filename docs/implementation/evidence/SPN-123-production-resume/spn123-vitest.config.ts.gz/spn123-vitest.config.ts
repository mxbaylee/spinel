import base from '/Users/mxbaylee/projects/spinel-spn-123-production/vitest.config.ts';
export default {
  ...base,
  cacheDir: '/tmp/spinel-dependabot-2026-11-11/spn123-vitest-cache',
};
