The historical mobile callback check completed357 seconds of behavior before timing out awaiting `Tracing.tracingComplete` under JSON transport. Its internal browser cause remains unknown. This change captures the same full native trace as protobuf, retains the original bytes, and performs guarded pinned Perfetto conversion inside the existing420-second deadline.

It preserves the historical baseline,16 paragraphs/2086 inputs, throttle, six categories,1GiB non-overwriting buffer, native behavior, candidate callback caps and cleanup. Original protobuf and derived JSON have separate identities; framing, conversion, parser statistics, source attribution and process/file cleanup must all agree. No acceptance retry, extended deadline or reduced workload is used.

## ✅ Source, integration and independent reviews

- Reviewed source `968649bdec92469e8761d6e09ed7f6900c79abc0`; base `89d93c8b23db65d3fe6a83d1853acc716c024b80`.
- Tested merge `9e27273f7b616dd48b641f544fac1ab1cb72b13a`; independently equal source/tested tree `5552cf754b509ac4ce8f2857c08ea24509304722`.
- Two independent nonimplementing reviewers, `/root/spn120_review_a` and `/root/spn120_review_b`, each graded this exact source **100/100** (35/25/20/10/10), with no blockers, before synchronization. **Agent review only.** No product UI changed.
- Local full lint/dependencies/format passed17.633s/748208KiB under normal pressure; backlog/index/title/whitespace and16 retained evidence payloads passed. Runtime/tests/workflows/dependencies are byte-identical to the previously accepted7b06d751 source, whose125 local controls and12-root types remain exact-code evidence. Current hosted jobs provide fresh full-project and native acceptance.

The earlier b8f28a80 source scored95/95 and was not pushed. Paired-converter-authority and primary/cleanup-failure findings were repaired, including simultaneous child-exit/output-close failure. The next source7b passed every selected check and independent owner review, with [complete immutable acceptance](https://github.com/mxbaylee/spinel/tree/02541cea2c28adadb988394be84515effa205b22/docs/review-assets/spn-144-acceptance-7b06d751). Before merge, main advanced with the documentation-only registration of SPN-145/146. The final guard caught the conflict; no merge was attempted. The generated index was regenerated, both allocations preserved and this integrated commit reviewed and validated afresh. Old green jobs provide no current-head gate credit.

## 🔎 Fresh first-attempt validation

**All33 CI jobs and all seven required gates passed on the reviewed source.** Required jobs: Pull request127040194590, Backlog127040403735, Lint127040403718, Typecheck127040403799, Unit tests127043117830, Lib tests127043930217 and Playwright smoke127048534067. No selected worker is absent, skipped, cancelled or failed.

CI [41965105059](https://github.com/mxbaylee/spinel/actions/runs/41965105059), attempt1, and Storybook [41965105108](https://github.com/mxbaylee/spinel/actions/runs/41965105108), attempt1, name the reviewed source. The synchronize-event plan conservatively selects all15 suites because immutable range/event labels were unavailable. Canonical digest `ca6d9ecff29351cbb20b78b4e592d73bbc0c39280db55adeae2d105d77dc44c9` binds aggregate coverage. Storybook's eight selected jobs passed; only optional Pages publication jobs are inapplicable.

## 📡 Full callback acceptance

Both fresh baseline/candidate pairs passed and were independently audited:

- **Desktop:** job127040403721/artifact13386678808; baseline114.455s and candidate94.811s. Completion waits6.151/6.144s; owned cleanup114.285/94.693s. Both complete within420s.
- **Mobile:** job127040403830/artifact13387424096; baseline380.154s and candidate280.097s, leaving39.846/139.903s measured headroom. Behavior298.964/198.543s, completion waits10.528/11.218s, conversion39.219/39.514s, queries7.514/7.558s and cleanup379.927/279.937s. Complete original protobuf482446682/488897326bytes and full derived JSON605081079/594106209bytes remain separately hash-bound.

Every observation retains the same pinned Linux Perfetto v59.1 authority, full original framing/hash checks, complete derived-event parsing, native content/caret/zoom/disposal, clean parser statistics, closed converter children, removed working files and settled fixture cleanup. Both candidates meet caps4/1/1 with zero final pending and zero post-disposal target work. Historical baselines remain intentionally unbounded. Reviewers streamed full byte/framing/hash checks and reproduced comparisons from retained analysis; CI owns complete raw-event parsing and attribution. Outer framing does not claim inner protobuf semantic validation.

The39.846s mobile baseline margin is a measured limitation. Current feasibility does not establish a causal speedup, explain every historical delay or guarantee future timing tails cannot recur.

## ⏱️ Separate unprofiled responsiveness acceptance

Desktop job127040403708/artifact13387857563 passes all11 retry0 cases, independently audited by A. Candidate plain1/2/3 capacity maxima22.4/32.0/15.2ms, idle0.6/0.6/0.8ms, input-to-frame p9535.3/36.3/36.4ms, longest tasks55/71/52ms and browser-local drains301.6/324.5/305.2ms meet unchanged limits. Complete66-group history/content/access and boundary checks pass. The terminal six-state drain is timer-owned in plain1 and policy-idle-owned in plain2/3; actual ownership is preserved rather than inferred.

Mobile job127040403777/artifact13388331298 passes all11 retry0 cases, independently audited by B. Candidate plain1/2/3 capacity p9517.2/15.5/18.3ms, maxima20.3/19.4/37.0ms, actual policy-idle spans1.6/2.0/1.5ms, input-to-frame p9559.1/59.5/59.1ms, longest tasks130/116/130ms and browser-local drains335.8/308.2/368.0ms meet unchanged mobile limits. All18 artifact members, eight metric records, complete66-group history/content/access, continuation, composition and revocation pass. Clock uncertainty1065.9/1065.5ms and unavailable exact candidate containing-task attribution remain explicit.

These owners independently retain raw timing, full66-group history, exact sender/peer/saved content, actual terminal drain ownership, continuation, composition and revocation. Sampled profiles, uncertain clock brackets and unavailable exact candidate containing-task attribution do not replace raw budgets or establish SPN-144 editor-performance gains. Mobile emulation/composition events do not prove physical-device/IME behavior.

## 📦 Durable evidence and first failures

[Immutable current-source acceptance archive](https://github.com/mxbaylee/spinel/tree/ec71f258d270d0b46c23f35b6e5d1fbda6675414/docs/review-assets/spn-144-acceptance-968649bd), preserved by tag `archive/spn-144-acceptance-968649bd`:319 payloads/630000301bytes plus manifest SHA-256 `8c2912a64c40c1beab5fdcbd1749113a0be46da8c811d72b642b48e2d07a653b`. Independent publication verification passed on its first execution, confirming the remote tag, all320 Git blobs, every payload hash, both81-member callback sets and both18-member responsiveness sets.

The archive retains complete original responsiveness ZIPs and extracted records, exact run/job/plan/aggregate evidence, source and owner reviews, original protobuf/derived JSON captures, conversion receipts and source/maps. Oversized callback ZIP containers are replaced by all81 non-SQLite members per pair, with all93 original member CRC/size/hash identities retained. Twelve disposable synthetic SQLite members per pair are explicitly excluded. No trace, source map or failure record is filtered. `SHA256SUMS` binds every retained payload.

The [maintained investigation](https://github.com/mxbaylee/spinel/blob/968649bdec92469e8761d6e09ed7f6900c79abc0/docs/implementation/SPN-144.md), [original124-payload manifest](https://github.com/mxbaylee/spinel/blob/968649bdec92469e8761d6e09ed7f6900c79abc0/docs/implementation/evidence/SPN-144/manifest.json) and [integration receipts](https://github.com/mxbaylee/spinel/blob/968649bdec92469e8761d6e09ed7f6900c79abc0/docs/implementation/evidence/SPN-144-main-integration/local.json) preserve every first capability/converter/verifier failure and concrete repair. The retained1249-event fixture is unchanged except two converter-duration metadata counters. Reviewer-only failures—an obsolete derived-trace filename, the earlier mobile zoom expectation and a nonexistent lint banner expectation—are preserved with their corrected source-based checks. No browser/converter was rerun for those audit repairs.

SPN-141 source403bd8c1 remains failed in its [immutable original record](https://github.com/mxbaylee/spinel/tree/eb51a5554244520593c66b7638f9eeff1d32fbb5/docs/review-assets/spn-141-deadline-blocker-403bd8c1): behavior357.090s, timeout420.040s awaiting completion, no stream/read/parser work started. SPN-143 cleanup succeeded. Passing current observations do not retroactively pass that pair or establish its historical root cause.

## 🧾 Landing and remaining integration

Squash-merged as `2f442317dd2e1c188ae4a810ac094fd1162a4a2a` on2026-11-05 at04:36:22UTC, with parent `89d93c8b23db65d3fe6a83d1853acc716c024b80` and exact accepted tree `5552cf754b509ac4ce8f2857c08ea24509304722`. GitHub's closed/merged state and local tree are verified. Immediately before merge, actual remote main, PR head/base, all43 CI/Storybook check records, mergeability and absence of review/comment blockers were rechecked; expected-head squash used the exact reviewed968 commit.

GitHub removed the remote implementation branch. After rechecking heads and open PR ownership, the obsolete local implementation/tracking refs and both tested-merge helper refs were deleted with expected-head guards. The implementation worktree is clean and detached at968; immutable registration and both acceptance archives remain preserved. No ticket-created implementation/review/integration/evidence branch remains, and no access-blocked cleanup is outstanding.

This final description is written once after landing. Its redundant metadata-triggered CI is not acceptance credit and will be deliberately cancelled with terminal receipts retained alongside subsequent integration evidence; no repeated description-edit loop or accepted-run rerun is intended. Separate main-push validation is distinct from the accepted PR run above.

SPN-141, then SPN-140 and SPN-120 require fresh integrated-source local verification, exact-head independent review and their own selected native/CI acceptance. SPN-120 retains its fresh24-case finite audit. This prerequisite supplies no substitute gate credit for those sources.
