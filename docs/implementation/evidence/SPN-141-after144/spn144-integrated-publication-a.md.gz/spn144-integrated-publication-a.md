# 📦 SPN-144 integrated archive publication verification — reviewer A

**Publication integrity passed on the first verifier execution.** The remote tag `archive/spn-144-acceptance-968649bd` resolves to exact immutable commit `ec71f258d270d0b46c23f35b6e5d1fbda6675414`, prefix `docs/review-assets/spn-144-acceptance-968649bd`.

## 🔎 Every blob and retained member

The exact archive tree contains **320 regular blobs**: **319 payloads totaling630,000,301 bytes**, plus `SHA256SUMS`. Manifest SHA256 is `8c2912a64c40c1beab5fdcbd1749113a0be46da8c811d72b642b48e2d07a653b`.

Independently streamed every archived Git blob, recomputed its Git SHA1 identity and manifest SHA256, and compared length/hash with the frozen local input. All320 blob identities and local bytes match. The manifest and tree have identical unique file sets, with no extras or missing payloads; the entire selected frozen-file set agrees. No frozen input was modified.

Both full callback packages contain exactly81 retained non-SQLite members each, matching every original member-proof length/hash, with complete original `spn144-trace.pftrace.gz` and derived `spn144-derived.json.gz` for baseline and candidate. Each original93-member ZIP has12 explicitly omitted disposable SQLite members whose exact identities remain recorded. Only the oversized ZIP containers themselves are excluded from Git; no trace, source/map, receipt, progress, comparison or failure record is filtered. Both responsiveness packages retain all18 members each, and their complete ZIP hashes/lengths also match.

Mutable CI and Storybook polling snapshots are excluded by exact names, while final runs/jobs, plan, aggregate artifacts and all four owner/final reviews are retained. Every individual blob is below100MiB. The verifier did not rely solely on the builder's assertions or a local tag: it queried the remote ref and consumed the actual committed blobs.

## 🔗 Accepted-source evidence retained

Archived identities bind source `968649bdec92469e8761d6e09ed7f6900c79abc0`, base `89d93c8b23db65d3fe6a83d1853acc716c024b80`, tested merge `9e27273f7b616dd48b641f544fac1ab1cb72b13a`, and equal source/tested tree `5552cf754b509ac4ce8f2857c08ea24509304722`. Actual source/tested tree identities were independently rechecked.

Terminal CI41965105059 attempt1 retains all33 successful jobs and the exact seven successful gates; Storybook41965105108 is terminal success on the same source. Both final independent acceptance reports are complete. Full current desktop/mobile callback and responsiveness acceptance is retained, including the39.846s mobile baseline deadline margin, actual timer/policy-idle ownership, profile/physical-device limitations and distinct historical failure dispositions. Prior7b acceptance supplies no current-head gate credit.

## 🧪 Execution and landing boundary

Verification passed first execution under serialized2GiB watchdog in **8,733ms**, sampled peak **292,896KiB**, normal pressure. No helper failure, browser/converter rerun, benchmark or profile-event reanalysis occurred. The adapted verifier uses the correct current derived-trace filename and exact current archive/source identities.

External supporting files: `/tmp/spn144-integrated-publication-check-a.ts`, `/tmp/spn144-integrated-publication-a.json`, `.log`, and `-watchdog.json`. All live proof/report outputs remain outside frozen `/tmp/spn144-integrated-hosted`.

No publication or acceptance blocker remains. Concrete final receipt archive URL readback and fresh source/base/check/review/thread/mergeability guards remain separate landing conditions. Actual squash/tree readback, canonical posted receipt and scoped obsolete-ref cleanup have not been claimed by this report. Historical failures and unknown causes remain unchanged; present acceptance does not guarantee future timing tails.

## 🔗 Final concrete receipt readback

Read `/tmp/spn144-integrated-final-body.md` after publication-link substitution. Its URL names the exact verified commit/prefix; tag,319 payloads/630000301bytes, manifest SHA256, all320 blobs and first-execution verification claims match this independent proof. No CI/mobile/archive marker remains; only `PENDING_MERGE_CLEANUP` reserves future actions. Receipt SHA256: `e9e3031009c6a89e16dc8f04102cbc09dce37e736a882b34e9f3607921820358`. The concrete publication-link condition is satisfied. No source, acceptance, publication or receipt-fact blocker remains; fresh guards and actual squash/posted-receipt/cleanup are the remaining landing steps. Frozen archive inputs remain untouched.
