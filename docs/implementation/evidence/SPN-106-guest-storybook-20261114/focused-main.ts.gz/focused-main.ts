import config from '../../.storybook/main.ts';
export default { ...config, stories: ['../../web/DocMobile.stories.tsx'] };
