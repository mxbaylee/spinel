// Disposable diagnostic only. No repository/runtime implementation changes.
// Three fixed pairs, then both server-death negatives; no request/scenario retries.
import assert from 'node:assert/strict';
import { fork } from 'node:child_process';
import { createRequire } from 'node:module';
import { once } from 'node:events';
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { randomUUID } from 'node:crypto';
import { performance } from 'node:perf_hooks';

const checkout = '/Users/mxbaylee/.codex/worktrees/spn-118-final-integration/spinel';
const dependencyRoot = '/Users/mxbaylee/projects/spinel';
const require = createRequire(`${dependencyRoot}/package.json`);
const output = '/tmp/spn118-b7bd03f-failure/keepalive-probe-result.json';
const expected = 'synthetic snapshot retained exactly';
const holdMs = 6200;

if (process.argv[2] === 'server') {
  const express = require('express');
  const { createHttpServer } = await import(pathToFileURL(`${checkout}/server/http.ts`).href);
  const app = express();
  const server = createHttpServer(app);
  const nonce = randomUUID();
  const ids = new WeakMap();
  let nextId = 0;
  const emit = (event: string, fields = {}) => {
    if (process.connected) process.send?.({ event, at: Date.now(), ...fields });
  };
  server.on('connection', (socket: import('node:net').Socket) => {
    const id = ++nextId;
    ids.set(socket, id);
    emit('connection', { id });
    socket.on('timeout', () => emit('socket-timeout', { id }));
    socket.on('close', (hadError) => emit('socket-close', { id, hadError }));
    socket.on('error', (error: NodeJS.ErrnoException) => emit('socket-error', { id, code: error.code }));
  });
  app.get(['/snapshot', '/health'], (req: import('node:http').IncomingMessage, res: any) => {
    const id = ids.get(req.socket);
    emit('request', { id, path: req.url, connection: req.headers.connection });
    res.on('finish', () => emit('response-finished', { id, path: req.url }));
    res.json({ nonce, pid: process.pid, content: expected, socketId: id });
  });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const address = server.address();
  assert(address && typeof address !== 'string');
  emit('ready', { port: address.port, nonce, pid: process.pid,
    keepAliveTimeout: server.keepAliveTimeout,
    keepAliveTimeoutBuffer: server.keepAliveTimeoutBuffer });
  // Independent upper bound even if the diagnostic parent disappears.
  setTimeout(() => process.exit(99), 30_000).unref();
} else {
  assert.equal(process.version, 'v26.12.1');
  const version = JSON.parse(readFileSync(require.resolve('playwright-core/package.json'), 'utf8')).version;
  assert.equal(version, '1.64.1');
  const { request } = require('playwright-core');
  const records: unknown[] = [];
  const startedAt = Date.now();
  const report = { schema: 1, source: 'b7bd03fce8ebd168f9dfba1e6d7203b59cbc2ba1',
    node: process.version, playwright: version, holdMs, pairs: 3,
    mechanism: 'Client event-loop hold across an unmodified server idle close; forced scheduling, not historical proof',
    runtime: 'Local Node APIRequestContext only; no browser, app database, auth or BrowserStack',
    startedAt, records };
  const persist = () => writeFileSync(output, JSON.stringify(report, null, 2));
  const sanitize = (error: unknown) => String(error).split('\n').slice(0, 2).join('\n');
  const bounded = async <T>(promise: Promise<T>, ms: number, label: string): Promise<T> => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    try { return await Promise.race([promise, new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${label} exceeded ${ms}ms`)), ms);
    })]); } finally { clearTimeout(timer); }
  };
  async function run(pair: number | 'negative', close: boolean) {
    const record: any = { pair, connection: close ? 'close' : 'default', events: [], result: null };
    records.push(record);
    const child = fork(fileURLToPath(import.meta.url), ['server'], {
      execArgv: ['--max-old-space-size=96'], stdio: ['ignore', 'ignore', 'pipe', 'ipc'],
    });
    let stderr = '';
    child.stderr?.on('data', (v) => { stderr = (stderr + String(v)).slice(-4096); });
    const exited = new Promise<void>((resolve) => child.once('exit', (code, signal) => {
      record.exit = { code, signal, at: Date.now() }; resolve();
    }));
    const ready = new Promise<any>((resolve, reject) => {
      child.on('message', (event: any) => {
        if (record.events.length < 100) record.events.push(event);
        if (event.event === 'ready') resolve(event);
      });
      child.once('error', reject);
      child.once('exit', (code) => reject(new Error(`Server exited before readiness: ${code}`)));
    });
    let context: any;
    let health: any;
    try {
      const server = await bounded(ready, 5000, 'server ready');
      assert.equal(server.keepAliveTimeout, 5000);
      assert.equal(server.keepAliveTimeoutBuffer, 1000);
      const baseURL = `http://127.0.0.1:${server.port}`;
      context = await request.newContext({ baseURL, timeout: 3000 });
      health = await request.newContext({ baseURL, timeout: 3000 });
      const options = { maxRetries: 0, ...(close ? { headers: { Connection: 'close' } } : {}) };
      const read = async (client: any, url: string, opts: unknown) => {
        const response = await client.get(url, opts);
        assert.equal(response.status(), 200);
        const value = await response.json();
        assert.equal(value.nonce, server.nonce);
        assert.equal(value.pid, server.pid);
        assert.equal(value.content, expected);
        const headers = response.headers();
        await response.dispose();
        return { at: Date.now(), value, headers: {
          connection: headers.connection, keepAlive: headers['keep-alive'],
        } };
      };
      record.healthBefore = await read(health, '/health', { headers: { Connection: 'close' }, maxRetries: 0 });
      record.warm = await read(context, '/snapshot', options);
      if (pair === 'negative') {
        assert(child.kill('SIGKILL'));
        await bounded(exited, 3000, 'server death');
      } else {
        record.holdStartedAt = Date.now();
        const before = performance.now();
        // Deliberately delay client FIN/timeout processing. Server runs separately.
        Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, holdMs);
        record.heldMs = performance.now() - before;
      }
      try { record.observed = await read(context, '/snapshot', options); record.result = 'success'; }
      catch (error) { record.result = 'error'; record.error = sanitize(error); }
      if (pair !== 'negative') {
        record.healthAfter = await read(health, '/health', { headers: { Connection: 'close' }, maxRetries: 0 });
        assert.equal(child.exitCode, null);
        assert.equal(child.signalCode, null);
        if (close) assert.equal(record.result, 'success');
      } else assert.equal(record.result, 'error', 'Dead owned server must not produce success');
    } catch (error) { record.probeError = sanitize(error); }
    finally {
      const cleanupErrors: string[] = [];
      for (const client of [context, health]) if (client) {
        try { await bounded(client.dispose(), 3000, 'context disposal'); }
        catch (error) { cleanupErrors.push(sanitize(error)); }
      }
      if (child.exitCode === null && child.signalCode === null) child.kill('SIGTERM');
      try { await bounded(exited, 3000, 'server cleanup'); }
      catch (error) { cleanupErrors.push(sanitize(error)); child.kill('SIGKILL'); await bounded(exited, 3000, 'server kill'); }
      if (cleanupErrors.length) record.cleanupErrors = cleanupErrors;
      if (stderr) record.stderr = stderr;
      persist();
      console.log(JSON.stringify({ pair, connection: record.connection, result: record.result,
        error: record.error, probeError: record.probeError, cleanupErrors }));
    }
  }
  persist();
  // Fixed count/order declared before execution. Do not extend on a negative result.
  for (let pair = 1; pair <= 3; pair++) {
    await run(pair, false);
    await run(pair, true);
  }
  await run('negative', false);
  await run('negative', true);
  Object.assign(report, { finishedAt: Date.now() });
  persist();
  if (records.some((r: any) => r.probeError || r.cleanupErrors?.length)) process.exitCode = 1;
}
