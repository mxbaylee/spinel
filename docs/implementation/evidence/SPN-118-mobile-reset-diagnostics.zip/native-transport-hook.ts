// Disposable observational preload. No retries, timeout changes or request mutation.
import { channel } from 'node:diagnostics_channel';
import { openSync, writeSync, closeSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
import type { ClientRequest, IncomingMessage, ServerResponse, Server } from 'node:http';
import type { Socket } from 'node:net';

const directory = process.env.SPN118_TRANSPORT_LOG_DIRECTORY;
if (directory) {
  const fd = openSync(`${directory}/${process.pid}.jsonl`, 'wx', 0o600);
  const queue: string[] = [];
  let count = 0;
  let dropped = 0;
  let writeErrors = 0;
  let closed = false;
  const socketIds = new WeakMap<Socket, number>();
  const requestIds = new WeakMap<object, number>();
  const servers = new WeakSet<Server>();
  let nextSocket = 0;
  let nextRequest = 0;
  const flush = () => {
    if (closed || !queue.length) return;
    try { writeSync(fd, queue.join('')); queue.length = 0; }
    catch { writeErrors++; queue.length = 0; }
  };
  const log = (event: string, values: Record<string, unknown> = {}) => {
    if (count >= 5000) { dropped++; return; }
    count++;
    queue.push(JSON.stringify({ event, pid: process.pid, at: Date.now(), mono: performance.now(), ...values }) + '\n');
  };
  const socketState = (s: Socket) => ({ localPort: s.localPort, remotePort: s.remotePort,
    destroyed: s.destroyed, readyState: s.readyState, timeout: s.timeout,
    bytesRead: s.bytesRead, bytesWritten: s.bytesWritten });
  const observeSocket = (s: Socket | null | undefined) => {
    if (!s) return null;
    let id = socketIds.get(s);
    if (id) return id;
    id = ++nextSocket;
    socketIds.set(s, id);
    log('socket-observed', { id, ...socketState(s) });
    s.on('timeout', () => log('socket-timeout', { id, ...socketState(s) }));
    s.once('end', () => log('socket-end', { id, ...socketState(s) }));
    s.once('close', (hadError) => log('socket-close', { id, hadError, ...socketState(s) }));
    // No error listener: preserve the original error/unhandled-error behavior.
    return id;
  };
  const requestId = (r: object) => {
    let id = requestIds.get(r);
    if (!id) { id = ++nextRequest; requestIds.set(r, id); }
    return id;
  };
  const pathKind = (raw: string | undefined) => {
    const p = (raw ?? '').split('?')[0];
    if (/^\/api\/items\/[^/]+\/doc$/.test(p)) return '/api/items/:id/doc';
    if (p === '/sign-in') return '/sign-in';
    if (p.startsWith('/sync-api/')) return '/sync-api/[redacted]';
    if (p.startsWith('/api/')) return '/api/[redacted]';
    return '/[redacted]';
  };
  const clientTarget = (request: ClientRequest) =>
    /^(localhost|127\.0\.0\.1):3108$/.test(String(request.getHeader('host') ?? ''));
  const client = (event: string, message: { request: ClientRequest; response?: IncomingMessage; error?: NodeJS.ErrnoException }) => {
    const { request, response, error } = message;
    if (!clientTarget(request)) return;
    const id = requestId(request);
    log(event, { id, method: request.method, path: pathKind(request.path),
      socket: observeSocket(request.socket), reusedSocket: request.reusedSocket,
      destroyed: request.destroyed, writableFinished: request.writableFinished,
      status: response?.statusCode, connection: response?.headers.connection,
      keepAlive: response?.headers['keep-alive'], errorCode: error?.code });
    if (event === 'client-created') {
      request.once('socket', (socket: Socket) => log('client-socket', {
        id, socket: observeSocket(socket), reusedSocket: request.reusedSocket, ...socketState(socket),
      }));
      request.once('close', () => log('client-close', { id, destroyed: request.destroyed,
        reusedSocket: request.reusedSocket, socket: request.socket ? socketIds.get(request.socket) : null }));
    }
  };
  for (const [name, event] of [
    ['http.client.request.created', 'client-created'],
    ['http.client.request.start', 'client-start'],
    ['http.client.request.error', 'client-error'],
    ['http.client.response.finish', 'client-response'],
  ]) channel(name).subscribe((message) => client(event, message as Parameters<typeof client>[1]));
  const server = (event: string, message: { request: IncomingMessage; response: ServerResponse; socket: Socket; server: Server }) => {
    const { request, response, socket, server } = message;
    if (socket.localPort !== 3108) return;
    if (!servers.has(server)) {
      servers.add(server);
      log('server-observed', { keepAliveTimeout: server.keepAliveTimeout,
        keepAliveTimeoutBuffer: server.keepAliveTimeoutBuffer, requestTimeout: server.requestTimeout,
        headersTimeout: server.headersTimeout });
      server.once('close', () => log('server-close'));
    }
    log(event, { id: requestId(request), socket: observeSocket(socket), method: request.method,
      path: pathKind(request.url), status: response.statusCode,
      complete: request.complete, destroyed: request.destroyed,
      connection: request.headers.connection, ...socketState(socket) });
  };
  channel('http.server.request.start').subscribe((message) => server('server-request', message as Parameters<typeof server>[1]));
  channel('http.server.response.finish').subscribe((message) => server('server-response', message as Parameters<typeof server>[1]));
  channel('child_process').subscribe((message) => {
    const child = (message as { process?: import('node:child_process').ChildProcess }).process;
    if (!child) return;
    log('child-spawn', { childPid: child.pid });
    child.once('exit', (code, signal) => log('child-exit', { childPid: child.pid, code, signal }));
  });
  log('process-start', { node: process.version, parentPid: process.ppid });
  const timer = setInterval(flush, 1000);
  timer.unref();
  process.on('uncaughtExceptionMonitor', (error: NodeJS.ErrnoException, origin) => {
    log('uncaught-exception', { errorCode: error.code, name: error.name, origin }); flush();
  });
  process.once('exit', (code) => {
    log('process-exit', { code, dropped, writeErrors }); flush();
    closed = true; closeSync(fd);
  });
}
