import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createContext, runInContext } from 'node:vm';

const startedAt = new Date().toISOString();
const started = performance.now();
const deadline = setTimeout(() => {
  console.error('Diagnostic exceeded its 10-second deadline.');
  process.exit(1);
}, 10_000);
try {
  const directory = dirname(fileURLToPath(import.meta.url));
  const repo = resolve(directory, '../spinel');
  const require = createRequire(join(repo, 'package.json'));
  const bundlePath = join(repo, 'node_modules/playwright-core/lib/coreBundle.js');
  const parserPath = join(repo, 'node_modules/playwright/lib/transform/babelBundle.js');
  const packageInfo = JSON.parse(
    readFileSync(join(repo, 'node_modules/playwright-core/package.json'), 'utf8'),
  );
  const parserPackage = JSON.parse(
    readFileSync(join(repo, 'node_modules/playwright/package.json'), 'utf8'),
  );
  assert.equal(process.version, 'v26.13.0');
  assert.equal(packageInfo.version, '1.64.1');
  assert.equal(parserPackage.version, packageInfo.version);
  const bundle = readFileSync(bundlePath, 'utf8');
  const { babelParse, traverse } = require(parserPath);
  const ast = babelParse(bundle, bundlePath, false);
  const methods: any[] = [];
  traverse(ast, {
    enter(path: any) {
      const node = path.node;
      if (
        (node.type === 'ClassMethod' || node.type === 'ObjectMethod') &&
        node.key.type === 'Identifier' &&
        node.key.name === 'waitForFunctionExpression'
      )
        methods.push(path);
    },
  });
  assert.equal(methods.length, 1, 'Locate exactly one installed waitForFunctionExpression method.');
  const arrows: any[] = [];
  methods[0].traverse({
    CallExpression(path: any) {
      const { callee, arguments: args } = path.node;
      if (
        callee.type === 'MemberExpression' &&
        !callee.computed &&
        callee.object.type === 'Identifier' &&
        callee.object.name === 'injectedScript' &&
        callee.property.type === 'Identifier' &&
        callee.property.name === 'evaluateHandle'
      ) {
        assert.equal(args[0].type, 'ArrowFunctionExpression');
        arrows.push(args[0]);
      }
    },
  });
  assert.equal(arrows.length, 1, 'Locate exactly one installed browser polling function.');
  const arrow = arrows[0];
  const pollerSource = bundle.slice(arrow.start, arrow.end);
  const sha256 = (bytes: string) => createHash('sha256').update(bytes).digest('hex');

  function start(expression: string) {
    const queue: Array<() => void> = [];
    const callbackKinds: string[] = [];
    const sandbox = {
      calls: 0,
      ready: false,
      done: false,
      outcome: undefined as unknown,
      failure: null as string | null,
      expression,
      injected: {
        utils: {
          builtins: {
            requestAnimationFrame(callback: () => void) {
              callbackKinds.push('requestAnimationFrame');
              queue.push(callback);
            },
            setTimeout(callback: () => void, milliseconds: number) {
              callbackKinds.push(`setTimeout:${milliseconds}`);
              queue.push(callback);
            },
          },
        },
      },
      next: undefined as undefined | (() => void),
    };
    const context = createContext(sandbox, { microtaskMode: 'afterEvaluate' });
    runInContext(
      `globalThis.poll = (${pollerSource})(injected, {
        expression, isFunction: true, polling: undefined, arg: undefined
      });
      poll.result.then(
        value => { globalThis.done = true; globalThis.outcome = value; },
        error => { globalThis.done = true; globalThis.failure = String(error); }
      );`,
      context,
      { timeout: 100 },
    );
    return { context, sandbox, queue, callbackKinds };
  }

  const asynchronous = start('async () => { globalThis.calls += 1; return false; }');
  assert.equal(asynchronous.sandbox.failure, null);
  assert.equal(asynchronous.sandbox.done, true);
  assert.equal(asynchronous.sandbox.outcome, false);
  assert.equal(asynchronous.sandbox.calls, 1);
  assert.equal(asynchronous.queue.length, 0);
  const asyncFalse = {
    settled: asynchronous.sandbox.done,
    resolvedValue: asynchronous.sandbox.outcome,
    predicateCalls: asynchronous.sandbox.calls,
    queuedPolls: asynchronous.queue.length,
    callbackKinds: asynchronous.callbackKinds,
  };

  const synchronous = start('() => { globalThis.calls += 1; return globalThis.ready; }');
  assert.equal(synchronous.sandbox.failure, null);
  assert.equal(synchronous.sandbox.done, false);
  assert.equal(synchronous.sandbox.calls, 1);
  assert.equal(synchronous.queue.length, 1);
  const syncFalse = {
    settled: synchronous.sandbox.done,
    predicateCalls: synchronous.sandbox.calls,
    queuedPolls: synchronous.queue.length,
    callbackKinds: [...synchronous.callbackKinds],
  };
  synchronous.sandbox.ready = true;
  synchronous.sandbox.next = synchronous.queue.shift();
  runInContext('next()', synchronous.context, { timeout: 100 });
  assert.equal(synchronous.sandbox.failure, null);
  assert.equal(synchronous.sandbox.done, true);
  assert.equal(synchronous.sandbox.outcome, true);
  assert.equal(synchronous.sandbox.calls, 2);
  assert.equal(synchronous.queue.length, 0);
  const syncThenTrue = {
    settled: synchronous.sandbox.done,
    resolvedValue: synchronous.sandbox.outcome,
    predicateCalls: synchronous.sandbox.calls,
    queuedPolls: synchronous.queue.length,
  };

  const receipt = {
    startedAt,
    finishedAt: new Date().toISOString(),
    elapsedMs: Math.round(performance.now() - started),
    node: process.version,
    package: { name: packageInfo.name, version: packageInfo.version },
    bundle: { path: bundlePath, sha256: sha256(bundle) },
    extraction: {
      method: 'Unique AST method and injectedScript.evaluateHandle first-arrow argument',
      parser: { package: parserPackage.name, version: parserPackage.version, path: parserPath },
      sourceStartLine: arrow.loc.start.line,
      sourceEndLine: arrow.loc.end.line,
      sha256: sha256(pollerSource),
    },
    diagnosticSha256: sha256(readFileSync(fileURLToPath(import.meta.url), 'utf8')),
    bounds: { vmExecutionMs: 100, diagnosticDeadlineMs: 10_000, manuallyExecutedCallbacks: 1 },
    asyncFalse,
    syncFalse,
    syncThenTrue,
    conclusion: 'The installed poller settles an async false predicate without scheduling another poll; a synchronous false predicate remains pending and repolls until true.',
    limitations: 'Node VM execution of the exact installed Playwright polling algorithm only. No browser, service worker, network, or activation integration was executed.',
  };
  writeFileSync(join(directory, 'playwright-polling-diagnostic.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify(receipt, null, 2));
} finally {
  clearTimeout(deadline);
}
