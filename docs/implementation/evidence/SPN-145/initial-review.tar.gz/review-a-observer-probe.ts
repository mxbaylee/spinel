import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { readFile, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import { startOfflineUpgradeObservation, upgradeTraceBuffer } from '../spinel/e2e/offline-upgrade-observation.ts';

const directory = resolve('../validation/review-a-observer-probe');
await mkdir(directory, { recursive: true });
const worker = { cat: 'ServiceWorker', name: 'ServiceWorkerVersion::Request', ph: 'b', ts: 1 };
const results: Record<string, unknown>[] = [];
for (const mode of ['success', 'original-and-detach-error', 'missing-terminal', 'missing-category'] as const) {
  class CDP extends EventEmitter {
    detached = false;
    sent: string[] = [];
    async send(method: string) {
      this.sent.push(method);
      if (method === 'Tracing.getCategories') return { categories: mode === 'missing-category' ? [] : ['ServiceWorker'] };
      if (method === 'Tracing.end') {
        this.emit('Tracing.dataCollected', { value: [worker, { ...worker, ph: 'e', ts: 2 }] });
        if (mode !== 'missing-terminal') this.emit('Tracing.tracingComplete', { dataLossOccurred: false });
      }
      return {};
    }
    async detach() {
      this.detached = true;
      if (mode === 'original-and-detach-error') throw new Error('detach failure');
    }
  }
  const cdp = new CDP();
  const context = new EventEmitter();
  const browser = { newBrowserCDPSession: async () => cdp, version: () => 'read-only-probe' };
  const file = resolve(directory, mode + '.json');
  const info = { outputPath: () => file, project: { name: 'offline-upgrade' }, testId: mode, retry: 0 };
  const first = mode === 'original-and-detach-error' ? new Error('original failure') : undefined;
  const began = performance.now();
  let failure: unknown;
  try {
    const observation = await startOfflineUpgradeObservation(browser as never, context as never, info as never, { tested: 'ac42137cf8e16a906df4e20ab430fa446f4a4152' });
    observation.mark('probe');
    const request = { serviceWorker: () => ({ url: () => 'http://localhost/service-worker.js' }), method: () => 'GET', url: () => 'http://localhost/assets/a.js?secret=omitted' };
    context.emit('request', request);
    context.emit('requestfinished', request);
    await observation.finish(first);
  } catch (error) { failure = error; }
  const receipt = JSON.parse(await readFile(file, 'utf8'));
  assert.equal(receipt.complete, mode === 'success');
  assert.equal(cdp.detached, true);
  assert.deepEqual(cdp.eventNames(), []);
  assert.deepEqual(context.eventNames(), []);
  if (mode === 'success') {
    assert.equal(failure, undefined);
    assert.equal(receipt.requests[0].path, 'http://localhost/assets/a.js');
    assert.deepEqual(receipt.pendingRequestsAtStop, []);
  } else assert.ok(failure);
  if (first) {
    assert.ok(failure instanceof AggregateError);
    assert.equal(failure.errors[0], first);
    assert.match(String(failure.errors[1]), /detach failure/);
  }
  const elapsedMs = Math.round(performance.now() - began);
  assert.ok(elapsedMs < 6500, 'Collection and cleanup stayed inside their bound plus scheduling margin');
  results.push({ mode, elapsedMs, complete: receipt.complete, sent: cdp.sent, firstFailure: receipt.firstFailure, collectionFailures: receipt.collectionFailures });
}
for (const events of [[{cat: 'ServiceWorker'}], [worker, {}], [worker, {cat: 'ServiceWorker', name: 7, ph: null, ts: 'invalid'}]]) {
  const buffer = upgradeTraceBuffer();
  buffer.append(events);
  const result = buffer.result({ dataLossOccurred: false });
  results.push({mode: 'malformed-object-probe', events, complete: result.complete, malformed: result.malformed, workerEvents: result.workerEvents});
}
console.log(JSON.stringify(results, null, 2));
