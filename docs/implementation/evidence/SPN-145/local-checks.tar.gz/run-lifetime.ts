import { writeFile } from 'node:fs/promises';
import { chromium } from '../spinel/node_modules/playwright/index.mjs';
import { verifyUpgradeResponseLifetime } from '../spinel/e2e/offline-upgrade-lifetime.ts';

const entries: Record<string, unknown>[] = [];
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true });
let failure: unknown;
try {
  await verifyUpgradeResponseLifetime(browser, '/workspace/scratch/cece61e42934/validation/legacy-build', '/workspace/scratch/cece61e42934/validation/previous-build', (entry) => { entries.push(entry); console.log(JSON.stringify(entry)); });
} catch (error) {
  failure = error;
  console.error(error);
} finally {
  await browser.close();
  await writeFile(process.argv[2], JSON.stringify({ entries, failure: failure ? String(failure) : null }, null, 2) + '\n');
}
if (failure) process.exitCode = 1;
