import fs from 'node:fs';
import { createRequire } from 'node:module';
import { runInNewContext } from 'node:vm';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import assert from 'node:assert/strict';
import { prepareDocsPatch } from '/Users/mxbaylee/projects/spinel-spn-142/scripts/dependencies/patch-univer-docs.ts';
const root='/Users/mxbaylee/projects/spinel-spn-142';
const require=createRequire(root+'/package.json');
const core=require('@univerjs/core');
const hash=(v:string|Buffer)=>createHash('sha256').update(v).digest('hex');
const raw=fs.readFileSync('/tmp/spn142-investigation/captured-caches.json');
assert.equal(hash(raw),'714376723b3ef6a048796f7a1903a58181098960960cecb111e22e0594a2e7c8');
const capture=JSON.parse(raw.toString());assert.equal(capture.captures.length,8);
const decode=(v:any):any=>{if(v.kind==='undefined')return undefined;if(v.kind==='value')return v.value;const out:any=v.kind==='array'?[]:{};for(const[k,c]of v.entries)out[k]=decode(c);return out;};
const caches=capture.captures.map(decode);
const chronological={history:caches.flatMap((e:any)=>e.history),collaboration:caches.flatMap((e:any)=>e.collaboration)};
const cases=[...caches.map((cache:any,i:number)=>({name:'original-'+i,cache})),...Array.from({length:32},(_,p)=>({name:'paragraph-position-'+p,cache:{history:chronological.history.slice(129-p,161-p),collaboration:chronological.collaboration.slice(129-p,161-p)}}))];
const results:any[]=[];const builds:any[]=[];
function measure(fn:Function,states:any[],key:string){
 const clone=core.Tools.deepClone,next=core.ActionIterator.prototype.next;const counts={cloneVisits:0,allocations:0,iteratorNext:0};
 core.Tools.deepClone=function(v:any){counts.cloneVisits++;if(this.isDefine(v)&&(this.isRegExp(v)||this.isDate(v)||this.isArray(v)||this.isObject(v)))counts.allocations++;return Reflect.apply(clone,this,[v]);};
 core.ActionIterator.prototype.next=function(...a:any[]){counts.iteratorNext++;return Reflect.apply(next,this,a);};
 try{return{actions:fn(states,key),counts};}finally{core.Tools.deepClone=clone;core.ActionIterator.prototype.next=next;}
}
for(const format of ['es','cjs'] as const){
 const installed=fs.readFileSync(root+'/node_modules/@univerjs/docs/lib/'+format+'/index.js','utf8');
 const {patched:source}=prepareDocsPatch(installed,format);
 const start=source.indexOf('function hasOnlyDocInsertKeys('),end=source.indexOf('const IDocStateChangeInterceptorService =',start);assert.ok(start>0&&end>start);
 const helper=source.slice(start,end);const json=format==='es'?'JSONX':'_univerjs_core.JSONX';const clone=format==='es'?'Tools.deepClone':'_univerjs_core.Tools.deepClone';
 const current=runInNewContext(helper+';composeDocStateActions;',{...core,_univerjs_core:core,Object,Array});
 const guardStart=helper.indexOf('function canCombineDocDeletes'),guardEnd=helper.indexOf('function composeDocStateActions',guardStart);
 const guard=helper.slice(guardStart,guardEnd);
 assert.ok(guard.includes('for (const state of states)'));
 const prefix=guard.replace('canCombineDocDeletes','docDeletePrefixLength').replace('if (states.length < 2) return false;','if (states.length < 2) return 0;').replace('for (const state of states) {','for (let index = 0; index < states.length; index++) {\nconst state = states[index];').replaceAll('return false;','return index;').replace('return true;','return states.length;');
 const old=`if (canCombineDocDeletes(states, key)) {\n\t\tconst result = ${clone}(states[states.length - 1][key].actions);\n\t\tconst edits = result[1].e;\n\t\tedits[edits.length - 1].len = states.length;\n\t\treturn result;\n\t}`;
 assert.equal(helper.split(old).length,2);
 const experiment=helper.replace(guard,prefix).replace(old,`const prefixLength = docDeletePrefixLength(states,key);\nif(prefixLength>=2){\nlet result=${clone}(states[prefixLength-1][key].actions);\nconst edits=result[1].e;edits[edits.length-1].len=prefixLength;\nfor(let index=prefixLength;index<states.length;index++)result=${json}.compose(result,states[index][key].actions);\nreturn result;\n}`);
 fs.writeFileSync('/tmp/spn142-investigation/experiment-'+format+'.txt',experiment);
 builds.push({format,installedSha256:hash(installed),patchedSha256:hash(source),helperSha256:hash(helper),experimentSha256:hash(experiment)});
 const candidate=runInNewContext(experiment+';composeDocStateActions;',{...core,_univerjs_core:core,Object,Array});
 for(const {name,cache}of cases)for(const scope of ['history','collaboration'])for(const key of ['redoState','undoState']){
  const states=cache[scope].slice();if(key==='undoState')states.reverse();assert.equal(states.length,32);
  const before=structuredClone(states),control=measure(current,states,key);assert.ok(isDeepStrictEqual(states,before));
  const after=measure(candidate,states,key);assert.ok(isDeepStrictEqual(states,before));
  results.push({format,name,scope,key,equal:isDeepStrictEqual(control.actions,after.actions),current:control.counts,experiment:after.counts});
 }
}
const paragraphs=Array.from({length:16},(_,i)=>`Line ${i+1}: Read the whole paragraph, including the far right edge. `+'Keep the original page size and all of this text when navigating.');
const input=paragraphs.join('\r');assert.equal(input.length,2086);
const group=input.slice(384,416);assert.equal(group.length,32);
const report={diagnosticOnly:true,source:'7679351822caaa9535d73d656191f2a6597a3380',patchSha256:hash(fs.readFileSync(root+'/scripts/dependencies/patch-univer-docs.ts')),captureSource:capture.source,captureSha256:hash(raw),builds,failedWorkloadMapping:{states:[385,416],input:group,enterZeroBased:group.indexOf('\r'),undoDeletePrefixLength:31-group.indexOf('\r'),limitation:'Source arithmetic, not the failed interval cache or cause'},cases:results.length,equal:results.filter(x=>x.equal).length,results};
fs.writeFileSync('/tmp/spn142-investigation/results.json',JSON.stringify(report,null,2)+'\n');
assert.equal(report.cases,320);assert.equal(report.equal,320);
console.log(JSON.stringify({...report,results:results.filter(x=>x.format==='es'&&x.scope==='history'&&x.key==='undoState'&&['paragraph-position-5','paragraph-position-0','paragraph-position-30','paragraph-position-31'].includes(x.name))},null,2));
