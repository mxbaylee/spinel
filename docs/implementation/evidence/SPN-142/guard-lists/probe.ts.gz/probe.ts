/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Modified for Spinel: execute the pinned public Doc state manager region
 * against real JSONX/TextX operations and controlled service endpoints/timers.
 * Original bundle bytes are semantic and primitive-work negative controls.
 * Source: packages/docs/src/services/doc-state-change-manager.service.ts,
 * dream-num/univer v1.1.0. No Pro package is read or modified.
 */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { resolve } from 'node:path';
import { test } from 'node:test';
import { runInNewContext } from 'node:vm';
import { gunzipSync } from 'node:zlib';
import * as core from '@univerjs/core';
import type { IDocumentData, JSONXActions } from '@univerjs/core';
import type {
  DocStateChangeManagerService,
  IDocStateChangeInfo,
  IDocStateChangeParams,
} from '@univerjs/docs';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { patchInstalledDocs, prepareDocsPatch } from '/Users/mxbaylee/projects/spinel-spn-142/scripts/dependencies/patch-univer-docs.ts';
import type {
  NativeDocFlushManager,
  NativeDocFlushObservation,
} from '/Users/mxbaylee/projects/spinel-spn-142/src/ui/nativeDocFlush.ts';

type Format = 'es' | 'cjs';
type State = IDocStateChangeParams;
type Side = State['redoState'] & { unitId: string; segmentId?: string; trigger?: string };
type Entry = {
  unitID: string;
  undoMutations: { id: string; params: Side }[];
  redoMutations: { id: string; params: Side }[];
};
type Manager = Pick<
  DocStateChangeManagerService,
  | 'getStateCache'
  | 'setStateCache'
  | 'clearHistory'
  | 'flushPendingChanges'
  | 'docStateChange$'
  | 'dispose'
>;
type Request = (snapshot: IDocumentData) => JSONXActions;
const unitId = 'composition-doc';
const readBuild = (format: Format) =>
  readFile(
    `/Users/mxbaylee/projects/spinel-spn-142/node_modules/@univerjs/docs/lib/${format}/index.js`,
    'utf8',
  );

// Lossless native capture encoding preserves own undefined fields and arrays.
function decodeCapture(value: any): any {
  if (value.kind === 'undefined') return undefined;
  if (value.kind === 'value') return value.value;
  assert.ok(value.kind === 'array' || value.kind === 'object');
  const result: any = value.kind === 'array' ? [] : {};
  for (const [key, child] of value.entries) {
    if (Array.isArray(result) && key === 'length') result.length = decodeCapture(child);
    else
      Object.defineProperty(result, key, {
        value: decodeCapture(child),
        writable: true,
        enumerable: true,
        configurable: true,
      });
  }
  return result;
}

function clock() {
  let now = 0;
  let nextId = 1;
  const pending = new Map<number, { at: number; callback: () => void }>();
  return {
    count: () => pending.size,
    now: () => now,
    elapse(milliseconds: number) {
      now += milliseconds;
    },
    setTimeout(callback: () => void, delay: number) {
      const id = nextId++;
      pending.set(id, { at: now + delay, callback });
      return id;
    },
    clearTimeout(id: number) {
      pending.delete(id);
    },
    tick(milliseconds: number) {
      now += milliseconds;
      for (const [id, task] of pending) {
        if (task.at > now) continue;
        pending.delete(id);
        task.callback();
      }
    },
  };
}

function managerFixture(
  source: string,
  costs: { history?: number; historyError?: Error; collaboration?: number } = {},
) {
  const marker = '//#region src/services/doc-state-change-manager.service.ts\n';
  const start = source.indexOf(marker);
  const end = source.indexOf('//#endregion', start);
  assert.ok(start >= 0 && end > start, 'Execute the actual hash-verified manager region.');
  const timers = clock();
  const contextCore = { ...core, Inject: () => () => {}, Optional: () => () => {} };
  listPhase = 'initialization';
  const ManagerClass = runInNewContext(
    `${source.slice(start + marker.length, end)}\nDocStateChangeManagerService;`,
    {
      __spn142List: countList,
      ...contextCore,
      Object,
      Array,
      performance: { now: timers.now },
      ...timers,
      BehaviorSubject,
      takeUntil,
      _univerjs_core: contextCore,
      rxjs: { BehaviorSubject, takeUntil },
      DocStateEmitService: {},
      _defineProperty: (object: Record<string, unknown>, key: string, value: unknown) => {
        object[key] = value;
        return object;
      },
      __decorate: (_decorators: unknown, constructor: unknown) => constructor,
      __decorateParam: () => () => {},
    },
    { filename: 'docs.installed-state-manager.js', timeout: 1000 },
  );
  listPhase = 'flush';
  const input = new Subject<IDocStateChangeInfo>();
  const history: Entry[] = [];
  const changes: State[] = [];
  const publication: { kind: string; history: number; collaboration: number }[] = [];
  const commands = new Set<(command: { id: string }) => void>();
  let manager: Manager;
  const observe = (kind: string) => {
    const cache = manager.getStateCache(unitId);
    publication.push({
      kind,
      history: cache.history.length,
      collaboration: cache.collaboration.length,
    });
  };
  manager = new ManagerClass(
    {
      pushUndoRedo(entry: Entry) {
        timers.elapse(costs.history ?? 0);
        if (costs.historyError) throw costs.historyError;
        observe('history');
        history.push(structuredClone(entry));
      },
    },
    {
      beforeCommandExecuted(listener: (command: { id: string }) => void) {
        commands.add(listener);
        return { dispose: () => commands.delete(listener) };
      },
    },
    { getCurrentUnitOfType: () => ({ getUnitId: () => unitId }) },
    { docStateChangeParams$: input },
  ) as Manager;
  const subscription = manager.docStateChange$.subscribe((state) => {
    if (!state) return;
    timers.elapse(costs.collaboration ?? 0);
    observe('collaboration');
    changes.push(structuredClone(state));
  });
  return {
    manager,
    input,
    timers,
    history,
    changes,
    publication,
    beforeCommand(id: string) {
      for (const listener of commands) listener({ id });
    },
    close() {
      subscription.unsubscribe();
      manager.dispose();
      input.complete();
      assert.equal(commands.size, 0);
      assert.equal(timers.count(), 0);
    },
  };
}

function apply(snapshot: IDocumentData, actions: JSONXActions) {
  const model = new core.DocumentDataModel(structuredClone(snapshot));
  try {
    model.apply(structuredClone(actions));
    return structuredClone(model.getSnapshot());
  } finally {
    model.dispose();
  }
}

function seed(text = 'alpha\rbravo\r\n') {
  const snapshot = core.getDocsEmptySnapshot(
    unitId,
    core.LocaleType.EN_US,
    'Composition',
    core.DocumentFlavor.MODERN,
  );
  snapshot.body = {
    dataStream: text,
    textRuns:
      text.length > 2
        ? [{ st: 0, ed: text.length - 2, ts: { bl: 1, cl: { rgb: '#123456' } } }]
        : [],
    paragraphs: [...text].flatMap((character, index) =>
      character === '\r'
        ? [
            {
              startIndex: index,
              // Native split replay preserves only IDs with the para_ prefix.
              paragraphId: `para_seed_${index}`,
              paragraphStyle: { outlineLevel: 1 },
            },
          ]
        : [],
    ),
    sectionBreaks: [{ startIndex: text.length - 1, sectionId: 'section_seed' }],
    customRanges:
      text.length > 6
        ? [
            {
              rangeId: 'link',
              rangeType: core.CustomRangeType.HYPERLINK,
              startIndex: 1,
              endIndex: 3,
              properties: { url: 'https://example.test/old' },
            },
          ]
        : [],
    customDecorations: [],
  };
  return apply(snapshot, null);
}

function sequence(requests: Request[], initial = seed()) {
  const snapshots = [initial];
  const states = requests.map((request, index): State => {
    const before = snapshots.at(-1)!;
    const actions = request(structuredClone(before));
    // This is the native mutation's inverse/apply order. Inversion realizes
    // inserted paragraph identities before the same actions are applied.
    const inverse = core.JSONX.invertWithDoc(actions, before);
    snapshots.push(apply(before, actions));
    return {
      commandId: 'doc.mutation.rich-text-editing',
      unitId,
      trigger: 'doc.command.insert-text',
      segmentId: '',
      noHistory: false,
      debounce: true,
      redoState: {
        actions,
        textRanges: [{ startOffset: index + 1, endOffset: index + 1, collapsed: true }],
        options: { restoreSelection: index % 2 === 0 },
        isEditing: index % 2 !== 0,
        layoutState: { step: index + 1, nested: ['redo', index] },
      },
      undoState: {
        actions: inverse,
        textRanges: [{ startOffset: index, endOffset: index, collapsed: true }],
        options: { restoreSelection: index % 2 !== 0 },
        isEditing: index % 2 === 0,
        layoutState: { step: index, nested: ['undo', index] },
      },
    };
  });
  // A native inverse need not recreate the seed's original representation:
  // deleting an insertion retains split style runs and initializes empty block
  // metadata. Derive the reverse oracle by applying the captured inverses one
  // at a time, with no composition and no metadata normalization in the test.
  const undoSnapshots: IDocumentData[] = [];
  undoSnapshots[states.length] = snapshots.at(-1)!;
  for (let index = states.length - 1; index >= 0; index--)
    undoSnapshots[index] = apply(undoSnapshots[index + 1], states[index].undoState.actions);
  return { states, snapshots, undoSnapshots };
}

const edit = (text: core.TextX) => core.JSONX.getInstance().editOp(text.serialize());
// Public DocInputController's collapsed input, after sync capture marks inserts
// before native apply. Captured browser caches in SPN-132 exposed this field.
function keyboardBody(index = 0): core.IDocumentBody {
  const body: core.IDocumentBody & { __textXPreserveParagraphIds: true } = {
    __textXPreserveParagraphIds: true,
    dataStream: 'x',
    textRuns: [{ st: 0, ed: 1, ts: { bl: index % 2 === 0 ? 1 : 0, cl: { rgb: '#123456' } } }],
    customRanges: [],
    customDecorations: [],
  };
  return body;
}
const insertAt =
  (offset: number, body = keyboardBody()): Request =>
  () =>
    edit(new core.TextX().retain(offset).insert(body.dataStream.length, body));

const mixed: Request[] = [
  () =>
    edit(
      new core.TextX()
        .retain(2)
        .insert(2, { dataStream: 'XY', textRuns: [{ st: 0, ed: 2, ts: { it: 1 } }] }),
    ),
  () => edit(new core.TextX().retain(3).delete(1)),
  () =>
    edit(
      new core.TextX()
        .retain(8)
        .delete(2)
        .insert(1, { dataStream: 'Z', textRuns: [{ st: 0, ed: 1, ts: { bl: 0 } }] }),
    ),
  () =>
    edit(
      new core.TextX().retain(
        4,
        { dataStream: '', textRuns: [{ st: 0, ed: 4, ts: { bl: 1, it: 1 } }] },
        core.UpdateDocsAttributeType.COVER,
      ),
    ),
  () =>
    edit(
      new core.TextX().retain(
        4,
        { dataStream: '', textRuns: [{ st: 0, ed: 4, ts: { bl: 0 } }] },
        core.UpdateDocsAttributeType.REPLACE,
      ),
    ),
  (snapshot) =>
    edit(
      new core.TextX().retain(snapshot.body!.paragraphs![0].startIndex).retain(
        1,
        {
          dataStream: '',
          paragraphs: [
            {
              startIndex: 0,
              paragraphId: snapshot.body!.paragraphs![0].paragraphId,
              paragraphStyle: {},
            },
          ],
        },
        core.UpdateDocsAttributeType.REPLACE,
      ),
    ),
  (snapshot) => {
    const text = core.BuildTextUtils.customRange.add({
      ranges: [{ startOffset: 0, endOffset: 5, collapsed: false }],
      rangeId: 'replacement-link',
      rangeType: core.CustomRangeType.HYPERLINK,
      properties: { url: 'https://example.test/new' },
      body: snapshot.body!,
    });
    assert.ok(text);
    return edit(text);
  },
  (snapshot) => core.JSONX.getInstance().replaceOp(['title'], snapshot.title, 'Updated title'),
  (snapshot) =>
    edit(
      new core.TextX().retain(snapshot.body!.dataStream.length - 2).insert(1, {
        dataStream: '\r',
        paragraphs: [{ startIndex: 0, paragraphId: 'para_inserted' }],
      }),
    ),
  () => null,
  (snapshot) => edit(new core.TextX().retain(snapshot.body!.paragraphs![0].startIndex).delete(1)),
];

function flush(source: string, history: State[], collaboration = history, raw = false) {
  const fixture = managerFixture(source);
  try {
    // Native caches are distinct arrays even when their state objects coincide.
    const inputCache = { history: [...history], collaboration: [...collaboration] };
    const cache = raw ? inputCache : structuredClone(inputCache);
    const retainedStates = [...cache.history, ...cache.collaboration];
    const before = structuredClone(retainedStates);
    fixture.manager.setStateCache(unitId, cache);
    fixture.manager.flushPendingChanges(unitId);
    assert.deepEqual(
      raw ? structuredClone(retainedStates) : retainedStates,
      before,
      'Composition must not mutate native state objects.',
    );
    assert.deepEqual(structuredClone(fixture.manager.getStateCache(unitId)), {
      history: [],
      collaboration: [],
    });
    return { history: fixture.history, changes: fixture.changes, publication: fixture.publication };
  } finally {
    fixture.close();
  }
}

function appliedSnapshots(
  output: ReturnType<typeof flush>,
  { snapshots }: ReturnType<typeof sequence>,
  historyStart = 0,
) {
  const after = snapshots.at(-1)!;
  const [entry] = output.history;
  const [change] = output.changes;
  return {
    history: entry && {
      redo: apply(snapshots[historyStart], entry.redoMutations[0].params.actions),
      undo: apply(after, entry.undoMutations[0].params.actions),
    },
    collaboration: change && {
      redo: apply(snapshots[0], change.redoState.actions),
      undo: apply(after, change.undoState.actions),
    },
  };
}

// The unmodified SDK can partition identical styles differently after aggregate
// versus individual inverse replay. This view is ONLY for that independent
// sequential oracle. Candidate publications and snapshots always compare raw.
function sequentialStyleView(snapshot: IDocumentData, context: string) {
  const otherFields = structuredClone(snapshot);
  const body = otherFields.body!;
  const ownsTextRuns = Object.hasOwn(body, 'textRuns');
  const runs = body.textRuns;
  delete body.textRuns;
  if (runs == null) return { otherFields, ownsTextRuns, runs };
  assert.ok(Array.isArray(runs), `${context}: textRuns must be an array.`);
  const covered: (Record<PropertyKey, unknown> | null)[] = Array.from(
    { length: body.dataStream.length },
    () => null,
  );
  const zeroLength: { at: number; attributes: Record<PropertyKey, unknown> }[] = [];
  let previousEnd = 0;
  for (const run of runs) {
    const { st, ed } = run;
    assert.ok(
      Number.isSafeInteger(st) &&
        Number.isSafeInteger(ed) &&
        st >= previousEnd &&
        ed >= st &&
        ed <= covered.length,
      `${context}: textRuns must be ordered, bounded and nonoverlapping.`,
    );
    const attributes = Object.fromEntries(
      Reflect.ownKeys(run)
        .filter((key) => key !== 'st' && key !== 'ed')
        .map((key) => [key, Reflect.get(run, key)]),
    );
    if (st === ed) zeroLength.push({ at: st, attributes });
    else for (let offset = st; offset < ed; offset++) covered[offset] = attributes;
    previousEnd = ed;
  }
  return { otherFields, ownsTextRuns, runs: { covered, zeroLength } };
}

function assertNativePreservation(
  control: ReturnType<typeof flush>,
  candidate: ReturnType<typeof flush>,
  scenario: ReturnType<typeof sequence>,
  context: string,
  historyStart = 0,
) {
  const label = `${context}, historyStart=${historyStart}`;
  assert.deepEqual(
    candidate,
    control,
    `${label}: complete native publications, including own undefined fields.`,
  );
  const originalSnapshots = appliedSnapshots(control, scenario, historyStart);
  const candidateSnapshots = appliedSnapshots(candidate, scenario, historyStart);
  assert.deepEqual(
    candidateSnapshots,
    originalSnapshots,
    `${label}: all complete applied snapshots.`,
  );
  for (const side of ['history', 'collaboration'] as const) {
    const snapshots = originalSnapshots[side];
    if (!snapshots) continue;
    assert.deepEqual(
      snapshots.redo,
      scenario.snapshots.at(-1),
      `${label}, ${side}/redo: sequential forward oracle.`,
    );
    const reverse = scenario.undoSnapshots[side === 'history' ? historyStart : 0];
    assert.deepEqual(
      sequentialStyleView(snapshots.undo, `${label}, ${side}/undo native`),
      sequentialStyleView(reverse, `${label}, ${side}/undo sequential`),
      `${label}, ${side}/undo: independent sequential authored styles and every other field.`,
    );
  }
}

function measuredFlush(source: string, states: State[], collaboration = states, raw = false) {
  const counts = { textCompose: 0, iteratorNext: 0, bodySlices: 0, cloneVisits: 0, allocations: 0 };
  const compose = core.TextX.compose;
  const next = core.ActionIterator.prototype.next;
  const clone = core.Tools.deepClone;
  core.TextX.compose = function (this: typeof core.TextX, ...args: Parameters<typeof compose>) {
    counts.textCompose++;
    return Reflect.apply(compose, this, args);
  };
  core.ActionIterator.prototype.next = function (
    this: core.ActionIterator,
    ...args: Parameters<typeof next>
  ) {
    counts.iteratorNext++;
    const action = Reflect.apply(next, this, args) as ReturnType<typeof next>;
    if (
      action.t === core.TextXActionType.INSERT ||
      (action.t === core.TextXActionType.RETAIN && action.body != null)
    )
      counts.bodySlices++;
    return action;
  };
  core.Tools.deepClone = function <T>(this: typeof core.Tools, value: T): T {
    counts.cloneVisits++;
    if (
      this.isDefine(value) &&
      (this.isRegExp(value) ||
        Reflect.apply(this.isDate, this, [value]) ||
        this.isArray(value) ||
        this.isObject(value))
    )
      counts.allocations++;
    return Reflect.apply(clone, this, [value]) as T;
  };
  try {
    return { output: flush(source, states, collaboration, raw), counts };
  } finally {
    core.TextX.compose = compose;
    core.ActionIterator.prototype.next = next;
    core.Tools.deepClone = clone;
  }
}


const root = '/Users/mxbaylee/projects/spinel-spn-142';
const hash = (v: string | Buffer) => createHash('sha256').update(v).digest('hex');
let listPhase: 'initialization' | 'flush' = 'initialization';
let listCounts = { initialization: 0, flush: 0 };
let getterReads: string[] = [];
function countList<T>(value: T): T { listCounts[listPhase]++; return value; }
const lists = [
  '["0", "1", "length"]', '["et", "e"]', '["t", "len"]',
  '["t", "len", "body", "valueRangeId"]',
  '["dataStream", "textRuns", "paragraphs", "customRanges", "customDecorations", "customBlocks", "sectionBreaks", "__textXPreserveParagraphIds"]',
  '["paragraphs", "customRanges", "customDecorations", "customBlocks", "sectionBreaks"]',
  '["length"]', '["0", "length"]', '["st", "ed", "ts", "sId"]',
];
const idleRaw = gunzipSync(await readFile(root + '/docs/implementation/evidence/SPN-135/corrected-3g/plain-2/spn135-native-caches.json.gz'));
const idle = JSON.parse(idleRaw.toString()).native.filter((v: any) => v.count === 6 && v.cache);
assert.equal(idle.length, 2);
const idleCache = {
 history: decodeCapture(idle.find((v: any) => v.phase === 'history').cache) as State[],
 collaboration: decodeCapture(idle.find((v: any) => v.phase === 'collaboration').cache) as State[],
};
const capacityRaw = gunzipSync(await readFile(root + '/docs/implementation/evidence/SPN-142/native-caches.json.gz'));
assert.equal(hash(capacityRaw), '714376723b3ef6a048796f7a1903a58181098960960cecb111e22e0594a2e7c8');
const caches = JSON.parse(capacityRaw.toString()).captures.map(decodeCapture);
assert.equal(caches.length, 8);
const chronological = { history: caches.flatMap((v: any) => v.history), collaboration: caches.flatMap((v: any) => v.collaboration) };
const cases = [
 {name: 'idle-six', make: () => structuredClone(idleCache)},
 ...caches.map((v: any, index: number) => ({name: `capacity-${index}`, make: () => structuredClone(v)})),
 ...Array.from({length: 32}, (_, position) => ({name: `paragraph-${position}`, make: () => structuredClone({history: chronological.history.slice(129-position, 161-position), collaboration: chronological.collaboration.slice(129-position, 161-position)})})),
];
const mutations = [
      (edits: any[]) => {
        edits[0].len += 2;
      },
      (edits: any[]) => {
        edits.at(-1).valueRangeId = 'range';
      },
      (edits: any[]) => {
        edits.at(-1).unknown = undefined;
      },
      (edits: any[]) => {
        edits.at(-1).len = 2;
      },
      (edits: any[]) => {
        edits.at(-1).body.dataStream = '\r';
      },
      (edits: any[]) => {
        edits.at(-1).body.customRanges = [{ rangeId: 'range' }];
      },
      (edits: any[]) => {
        edits.at(-1).body.__textXPreserveParagraphIds = false;
      },
      (edits: any[]) => {
        Object.setPrototypeOf(edits.at(-1), { extra: true });
      },
      (edits: any[]) => {
        Object.defineProperty(edits.at(-1), 'body', {
          get: () => { getterReads.push('body'); return keyboardBody(); },
          enumerable: true,
          configurable: true,
        });
      },
      (edits: any[]) => {
        Object.defineProperty(edits.at(-1), 'valueRangeId', {
          value: undefined,
          enumerable: false,
        });
      },
    ];
mutations.push((edits: any[]) => { edits.at(-1)[Symbol.for('spn142-unsupported')] = undefined; });
assert.equal(mutations.length, 11);
for (const [mutation, change] of mutations.entries()) for (let position = 0; position < 6; position++) cases.push({
 name: `malformed-${mutation}-position-${position}`,
 make: () => { const states = structuredClone(idleCache.history); change((states[position].undoState.actions as any)[1].e); return {history: states, collaboration: states}; },
});
assert.equal(cases.length, 107);
const results: any[] = [];
const builds: any[] = [];
for (const format of ['es', 'cjs'] as const) {
 const installed = await readBuild(format);
 const source = prepareDocsPatch(installed, format).patched;
 const start = source.indexOf('const DEBOUNCE_DELAY = 300;');
 const end = source.indexOf('const IDocStateChangeInterceptorService =', start);
 assert.ok(start > 0 && end > start);
 const helper = source.slice(start, end);
 let experiment = helper;
 for (const [index, literal] of lists.entries()) {
  assert.ok(experiment.includes(literal), `Missing list ${index}`);
  experiment = experiment.replaceAll(literal, `spn142FixedList${index}`);
 }
 experiment = experiment.replace('const DEBOUNCE_DELAY = 300;', 'const DEBOUNCE_DELAY = 300;\n' + lists.map((literal,index) => `const spn142FixedList${index} = ${literal};`).join('\n'));
 const instrument = (text: string) => lists.reduce((text, literal) => text.replaceAll(literal, `__spn142List(${literal})`), text);
 const controlSource = source.replace(helper, instrument(helper));
 const experimentSource = source.replace(helper, instrument(experiment));
 await writeFile(`/tmp/spn142-guard-probe/experiment-${format}.txt`, experiment);
 builds.push({format, installedSha256: hash(installed), patchedSha256: hash(source), helperSha256: hash(helper), experimentSha256: hash(experiment), controlInstrumentedSha256: hash(controlSource), experimentInstrumentedSha256: hash(experimentSource)});
 for (const scenario of cases) {
  const measures = [];
  for (const build of [controlSource, experimentSource]) {
   listCounts = {initialization: 0, flush: 0}; getterReads = [];
   const cache = scenario.make();
   const result = measuredFlush(build, cache.history, cache.collaboration, true);
   measures.push({...result, lists: {...listCounts}, getterReads: [...getterReads]});
  }
  const [before, after] = measures;
  assert.deepEqual(after.output, before.output, `${format}/${scenario.name}: raw publications`);
  assert.deepEqual(after.counts, before.counts, `${format}/${scenario.name}: unchanged native primitive work`);
  assert.deepEqual(after.getterReads, before.getterReads, `${format}/${scenario.name}: getter read order`);
  assert.equal(before.lists.initialization, 0);
  assert.equal(after.lists.initialization, 9);
  assert.equal(after.lists.flush, 0);
  assert.ok(before.lists.flush > 0);
  results.push({format, name: scenario.name, parity: true, primitiveCounts: after.counts, before: before.lists, after: after.lists, getterReads: after.getterReads});
 }
}
assert.equal(results.length, 214);
const report = {diagnosticOnly: true, source: '2b173b29b3c0894a45b8d48d92073c3645110673', fixtureSha256: hash(await readFile(root + '/scripts/dependencies/patch-univer-docs.test.ts')), patchSha256: hash(await readFile(root + '/scripts/dependencies/patch-univer-docs.ts')), probeSha256: hash(await readFile('/tmp/spn142-guard-probe/probe.ts')), idleCaptureSha256: hash(idleRaw), capacityCaptureSha256: hash(capacityRaw), builds, cases: 214, managerFlushes: 428, scopesAndDirectionsPerFlush: 4, limitation: 'Counts are executed array-literal evaluations, not V8 heap allocations, GC savings, latency or proof of the historical failure cause. Module initialization measured once per VM region load.', results};
await writeFile('/tmp/spn142-guard-probe/results.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({...report, results: results.filter(v => v.name === 'idle-six' || v.name === 'capacity-4')}, null, 2));
