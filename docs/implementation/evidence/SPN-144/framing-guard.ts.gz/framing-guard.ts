import { createHash } from 'node:crypto';

/** Validate the Trace wrapper, not the opaque TracePacket schema or semantics. */
export async function checkTraceEnvelope(chunks: AsyncIterable<Uint8Array>, maximumBytes: number) {
  if (!Number.isSafeInteger(maximumBytes) || maximumBytes < 1) throw Error('Invalid input bound.');
  let state: 'tag' | 'length' | 'payload' = 'tag';
  let length = 0, lengthBytes = 0, remaining = 0, bytes = 0, packets = 0, emptyPackets = 0;
  const hash = createHash('sha256');
  for await (const chunk of chunks) {
    bytes += chunk.length;
    if (bytes > maximumBytes) throw Error('Trace envelope exceeds input bound.');
    hash.update(chunk);
    let at = 0;
    while (at < chunk.length) {
      if (state === 'payload') {
        const consume = Math.min(remaining, chunk.length - at);
        at += consume; remaining -= consume;
        if (remaining === 0) { packets++; state = 'tag'; }
        continue;
      }
      const byte = chunk[at++]!;
      if (state === 'tag') {
        // perfetto.protos.Trace contains only repeated length-delimited packet=1.
        if (byte !== 0x0a) throw Error('Unexpected Trace envelope field or wire type.');
        state = 'length'; length = 0; lengthBytes = 0;
        continue;
      }
      if (lengthBytes === 4 && byte > 0x0f) throw Error('Trace packet length overflows uint32.');
      length += (byte & 0x7f) * 2 ** (7 * lengthBytes++);
      if (byte & 0x80) continue;
      if (length > maximumBytes) throw Error('Trace packet exceeds input bound.');
      remaining = length;
      if (remaining === 0) { packets++; emptyPackets++; state = 'tag'; }
      else state = 'payload';
    }
  }
  if (state !== 'tag') throw Error('Truncated Trace envelope at EOF.');
  if (packets === 0) throw Error('Empty Trace envelope.');
  return { bytes, packets, emptyPackets, sha256: hash.digest('hex') };
}
