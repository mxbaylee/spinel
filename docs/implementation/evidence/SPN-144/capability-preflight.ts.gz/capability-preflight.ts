import { readFileSync, statSync, chmodSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
const root='/tmp/spn144-capability',binary=root+'/trace_processor_shell';
assert.equal(statSync(binary).size,13597976);
assert.equal(createHash('sha256').update(readFileSync(binary)).digest('hex'),'d29864d1ba3b36855527bb1b0ca3aa7f703cdce338b9680bb922c5c151b358fa');
chmodSync(binary,0o700);
for(const [name,args] of [['version',['--version']],['convert-help',['help','convert']],['query-help',['help','query']]] as const){
 const output=execFileSync(binary,args,{encoding:'utf8',timeout:10000,maxBuffer:128*1024});writeFileSync(root+'/'+name+'.txt',output,{flag:'wx'});console.log(name,output.slice(0,150));
}
console.log('Verified official mac-arm64 v58.2 binary and metadata commands.');
