import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {gzipSync,gunzipSync} from 'node:zlib';
import {convertDocCallbackTrace} from '/Users/mxbaylee/projects/spinel-spn-144/e2e/doc-responsiveness-callback-converter.ts';
import {readDocCallbackTrace} from '/Users/mxbaylee/projects/spinel-spn-144/e2e/doc-responsiveness-callback-trace.ts';
const root='/tmp/spn144-integrated-capability-repair', prior='/tmp/spn144-integrated-capability',binary='/tmp/spn144-v59-capability/trace_processor_shell';
await mkdir(root);
const hash=(v:Uint8Array)=>createHash('sha256').update(v).digest('hex'),controller=new AbortController(),started=performance.now();
const timer=setTimeout(()=>controller.abort(Error('30-second capability deadline')),30000),report:any={passed:false,converterCommands:0,negative:[]};
try{
 const aBytes=await readFile('/tmp/spn144-v59-capability/corrected-identity/proto-converted.json'),stored=await readFile(prior+'/derived.json.gz'),bBytes=gunzipSync(stored);
 assert.equal(hash(aBytes),'fe4d2275402c56ae5eaefa0c2f13f333c5dfb2459a723a53200726b61cd6fabe');assert.equal(hash(bBytes),'9d5b97b8f9246779bb671a099e31e8fa6c45c5ce7db3a9410d5caade41f1daea');
 const receipt=JSON.parse(await readFile(prior+'/conversion.json','utf8'));assert.equal(receipt.output.sha256,hash(stored));assert.equal(receipt.output.decoded.sha256,hash(bBytes));assert.equal(receipt.passed,true);assert.equal(receipt.temporaryRemoved,true);
 for(const command of [receipt.conversion,receipt.statistics]){assert.equal(command.childClosed,true);assert.equal(command.code,0);assert.equal(command.signal,null);}
 const a=JSON.parse(aBytes.toString()),b=JSON.parse(bBytes.toString());report.converterDurations={};
 assert.equal(a.traceEvents.length,1249);assert.deepEqual(a.traceEvents,b.traceEvents);
 for(const key of ['guess_trace_type_duration_ns','parse_trace_duration_ns']){const x=a.metadata.trace_processor_stats[key],y=b.metadata.trace_processor_stats[key];assert.ok(Number.isFinite(x)&&x>=0&&Number.isFinite(y)&&y>=0);report.converterDurations[key]={previous:x,implemented:y};delete a.metadata.trace_processor_stats[key];delete b.metadata.trace_processor_stats[key];}
 assert.deepEqual(a,b);report.identicalEvents=1249;
 const parsed=await readDocCallbackTrace(prior+'/derived.json.gz',{compression:'gzip',signal:controller.signal});assert.equal(parsed.summary.uncompressedSha256,hash(bBytes));assert.equal(parsed.summary.callbackEvents,13);report.read=parsed.summary;
 const original=gunzipSync(await readFile(prior+'/original.pftrace.gz'));assert.equal(hash(original),'50a46a4f2151840f1252cab658cdc84b8e3896835790eb75a018266cb6489c8d');
 const bad=await readFile('/tmp/spn144-capability/malformed.pftrace');assert.equal(hash(bad),'d7976b4606ab7b9c3231f06747a1f5e5f7634c46dff8232226b52a321fa2d994');await writeFile(root+'/malformed.gz',gzipSync(bad),{flag:'wx'});
 for(const [name,input,identity] of [['malformed',root+'/malformed.gz',{bytes:bad.length,sha256:hash(bad)}],['wrong-identity',prior+'/original.pftrace.gz',{bytes:original.length,sha256:'0'.repeat(64)}]] as const){
 const receipt=root+'/'+name+'-receipt.json';await assert.rejects(convertDocCallbackTrace({binary,input,identity,output:root+'/'+name+'-output.gz',receipt,signal:controller.signal,phase:()=>{}}),name==='malformed'?/exceeds captured input/:/captured hash/);
 const record=JSON.parse(await readFile(receipt,'utf8'));assert.equal(record.passed,false);assert.equal(record.temporaryRemoved,true);assert.equal(record.conversion,undefined);report.negative.push({name,record});
 }
 const files=await readdir(root);assert.ok(!files.some(name=>name.startsWith('.spn144-converter-')));assert.ok(!files.some(name=>name.endsWith('-output.gz')));report.passed=true;
}catch(error){report.firstFailure=String(error);process.exitCode=1;}finally{clearTimeout(timer);report.elapsedMs=performance.now()-started;await writeFile(root+'/result.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({passed:report.passed,firstFailure:report.firstFailure,elapsedMs:report.elapsedMs,identicalEvents:report.identicalEvents,negative:report.negative.map((x:any)=>x.name),converterCommands:report.converterCommands}));}
