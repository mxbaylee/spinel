import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile,writeFile,mkdir,readdir } from 'node:fs/promises';
import { gzipSync,gunzipSync } from 'node:zlib';
import { convertDocCallbackTrace } from '/Users/mxbaylee/projects/spinel-spn-144/e2e/doc-responsiveness-callback-converter.ts';
import { readDocCallbackTrace } from '/Users/mxbaylee/projects/spinel-spn-144/e2e/doc-responsiveness-callback-trace.ts';
const root='/tmp/spn144-integrated-capability', binary='/tmp/spn144-v59-capability/trace_processor_shell';
await mkdir(root);
const hash=(v:Uint8Array)=>createHash('sha256').update(v).digest('hex');
const started=performance.now(),controller=new AbortController(),timer=setTimeout(()=>controller.abort(Error('30-second capability deadline')),30000);
const report:any={passed:false,kind:'implemented-wrapper retained-data capability only',commands:[],negative:[]};
try{
 const raw=await readFile('/tmp/spn144-capability/proto-raw.pftrace');
 assert.equal(raw.length,136693);assert.equal(hash(raw),'50a46a4f2151840f1252cab658cdc84b8e3896835790eb75a018266cb6489c8d');
 const input=root+'/original.pftrace.gz';await writeFile(input,gzipSync(raw,{level:1}),{flag:'wx'});
 const options={binary,input,identity:{bytes:raw.length,sha256:hash(raw)},output:root+'/derived.json.gz',receipt:root+'/conversion.json',signal:controller.signal,phase:(phase:string)=>report.commands.push({phase,at:performance.now()-started})};
 const converted=await convertDocCallbackTrace(options);report.converted=converted;
 assert.equal(converted.output.decoded.sha256,'fe4d2275402c56ae5eaefa0c2f13f333c5dfb2459a723a53200726b61cd6fabe');assert.equal(converted.output.decoded.bytes,357343);
 const parsed=await readDocCallbackTrace(options.output,{compression:'gzip',signal:controller.signal});
 assert.equal(parsed.summary.uncompressedSha256,converted.output.decoded.sha256);assert.equal(parsed.summary.sourceEvents,1249);assert.equal(parsed.summary.callbackEvents,13);report.read=parsed.summary;
 assert.equal(converted.record.temporaryRemoved,true);
 const bad=await readFile('/tmp/spn144-capability/malformed.pftrace');assert.equal(hash(bad),'d7976b4606ab7b9c3231f06747a1f5e5f7634c46dff8232226b52a321fa2d994');
 await writeFile(root+'/malformed.gz',gzipSync(bad),{flag:'wx'});
 for(const [name,path,identity] of [['malformed',root+'/malformed.gz',{bytes:bad.length,sha256:hash(bad)}],['wrong-identity',input,{bytes:raw.length,sha256:'0'.repeat(64)}]] as const){
  const receipt=root+'/'+name+'-receipt.json';await assert.rejects(convertDocCallbackTrace({...options,input:path,identity,output:root+'/'+name+'-output.gz',receipt}),name==='malformed'?/exceeds captured input/:/captured hash/);
  const r=JSON.parse(await readFile(receipt,'utf8'));assert.equal(r.passed,false);assert.equal(r.temporaryRemoved,true);assert.equal(r.conversion,undefined);report.negative.push({name,receipt:r});
 }
 const files=await readdir(root);assert.ok(!files.some(name=>name.startsWith('.spn144-converter-')));assert.ok(!files.some(name=>name.endsWith('-output.gz')));
 assert.equal(hash(gunzipSync(await readFile(input))),hash(raw));
 report.passed=true;
}catch(error){report.firstFailure=String(error);process.exitCode=1;}finally{clearTimeout(timer);report.elapsedMs=performance.now()-started;await writeFile(root+'/result.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({passed:report.passed,firstFailure:report.firstFailure,elapsedMs:report.elapsedMs,phases:report.commands,negative:report.negative.map((x:any)=>x.name)}));}
