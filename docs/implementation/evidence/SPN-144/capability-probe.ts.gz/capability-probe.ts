import { chromium } from '/Users/mxbaylee/projects/spinel/node_modules/@playwright/test/index.mjs';
import { DOC_CALLBACK_TRACE_SETTINGS, readDocCallbackTrace } from '/Users/mxbaylee/projects/spinel-spn-144/e2e/doc-responsiveness-callback-trace.ts';
import { createServer } from 'node:http';
import { readFile, writeFile, open, rm, stat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import assert from 'node:assert/strict';
const root='/tmp/spn144-capability',binary=root+'/trace_processor_shell';
const sha=(b:Uint8Array|string)=>createHash('sha256').update(b).digest('hex');
const source=`window.runProbe = async function runProbe() {
  performance.mark('spn144-start');
  const cancelled = setTimeout(function shouldNeverFire() { throw Error('cancelled fired'); }, 5000);
  clearTimeout(cancelled);
  let ticks = 0, repeated;
  await new Promise(resolve => { repeated = setInterval(function repeatedCallback() { ticks++; if (ticks === 3) { clearInterval(repeated); resolve(); } }, 20); });
  let final;
  await new Promise(resolve => { final = setTimeout(function finalCallback() { resolve(); }, 10); });
  performance.mark('spn144-end');
  return {cancelled, repeated, final, ticks};
};
`;
await writeFile(root+'/signal.js.txt',source,{flag:'wx'});
const report:any={kind:'capability-only',started:new Date().toISOString(),sourceSha256:sha(source),settings:DOC_CALLBACK_TRACE_SETTINGS,attempt:1,captures:[],cleanup:{},passed:false};
const started=performance.now(),overall=new AbortController();
let browser:any;
const deadline=setTimeout(()=>{overall.abort(Error('120-second capability deadline.'));void browser?.close().catch(()=>{});server.closeAllConnections();},120000);
const server=createServer((req,res)=>{if(req.url==='/signal.js'){res.setHeader('Content-Type','application/javascript');res.end(source);}else{res.setHeader('Content-Type','text/html');res.end('<!doctype html><input id="entry"><script src="/signal.js"></script>');}});
const persist=()=>writeFile(root+'/result.json',JSON.stringify(report,null,2)+'\n');
async function child(name:string,args:string[],timeout:number,expectedFailure=false,output?:string){
 overall.signal.throwIfAborted();const t=performance.now();
 const result:any=await new Promise(resolve=>{
  const c=execFile(binary,args,{timeout,killSignal:'SIGKILL',maxBuffer:128*1024,signal:overall.signal},(error,stdout,stderr)=>{clearInterval(watch);resolve({code:error?(error as any).code:0,signal:error?(error as any).signal:null,error:error?.message,stdout,stderr,pid:c.pid,elapsedMs:performance.now()-t});});
  const watch=setInterval(()=>{if(output)void stat(output).then(s=>{if(s.size>256*1024*1024)c.kill('SIGKILL');}).catch(()=>{});},50);
 });
 await writeFile(root+'/'+name+'-command.json',JSON.stringify({args,...result},null,2)+'\n',{flag:'wx'});
 assert.ok(!result.signal,`${name}: signal ${result.signal}`);
 if(expectedFailure)assert.ok(typeof result.code==='number'&&result.code!==0,`${name}: malformed input accepted`);
 else assert.equal(result.code,0,`${name}: ${result.error}`);
 overall.signal.throwIfAborted();return result;
}
async function capture(format:'json'|'proto',url:string){
 const t=performance.now();const c=await browser.newContext({viewport:{width:390,height:844}});const page=await c.newPage();
 const cdp=await c.newCDPSession(page),abort=new AbortController();let stream:string|undefined,closeRequested=false,complete=false,handle:any;
 const record:any={format,phase:'setup',sourceSha256:sha(source),cleanup:{},passed:false};report.captures.push(record);
 const abortParent=()=>abort.abort(overall.signal.reason);overall.signal.addEventListener('abort',abortParent,{once:true});
 const timer=setTimeout(()=>abort.abort(Error('30-second capture/collection bound.')),30000);
 const interrupted=new Promise<never>((_,reject)=>abort.signal.addEventListener('abort',()=>{void cdp.detach().catch(()=>{});reject(abort.signal.reason);},{once:true}));
 const race=<T>(p:Promise<T>)=>Promise.race([p,interrupted]);
 const parsed:any[]=[];const onParsed=(s:any)=>parsed.push(s);cdp.on('Debugger.scriptParsed',onParsed);
 let finish:(e:any)=>void=()=>{};const completion=new Promise<any>(resolve=>{finish=resolve;});cdp.on('Tracing.tracingComplete',finish);
 const path=root+'/'+format+'-raw.'+(format==='json'?'json':'pftrace');
 try{
  await race(cdp.send('Debugger.enable'));await race(page.goto(url));await race(cdp.send('Emulation.setCPUThrottlingRate',{rate:4}));
  const script=parsed.find(s=>s.url===url+'signal.js');assert.ok(script,'fixture source script');record.scriptId=script.scriptId;record.sourceUrl=script.url;
  const response=await race<any>(cdp.send('Debugger.getScriptSource',{scriptId:script.scriptId}));assert.equal(sha(response.scriptSource),sha(source));
  record.phase='capture';await race(cdp.send('Tracing.start',{...DOC_CALLBACK_TRACE_SETTINGS,streamFormat:format}));
  record.fixture=await race(page.evaluate(()=> (window as any).runProbe()));assert.equal(record.fixture.ticks,3);
  await race(page.locator('#entry').focus());await race(page.keyboard.type('spn144'));assert.equal(await race(page.locator('#entry').inputValue()),'spn144');
  record.behaviorMs=performance.now()-t;record.phase='completion';await race(cdp.send('Tracing.end'));record.endResponseMs=performance.now()-t;
  const event=await race(completion);record.completion=event;stream=event.stream;
  assert.equal(event.dataLossOccurred,false);assert.equal(event.traceFormat,format);assert.equal(event.streamCompression,'none');assert.ok(stream);
  record.streamOpenMs=performance.now()-t;record.phase='stream';handle=await open(path,'wx');let bytes=0;const hash=createHash('sha256');
  for(;;){const r:any=await race(cdp.send('IO.read',{handle:stream,size:65536}));const chunk=Buffer.from(r.data,r.base64Encoded?'base64':'utf8');bytes+=chunk.length;assert.ok(bytes<=64*1024*1024,'raw capture size');hash.update(chunk);await handle.writeFile(chunk);if(r.eof)break;}
  await handle.close();handle=undefined;closeRequested=true;await race(cdp.send('IO.close',{handle:stream}));record.cleanup.streamClosed=true;record.raw={path,bytes,sha256:hash.digest('hex')};complete=true;record.passed=true;
 }catch(error){record.failure=String(error);throw error;}finally{
  clearTimeout(timer);overall.signal.removeEventListener('abort',abortParent);cdp.off('Debugger.scriptParsed',onParsed);cdp.off('Tracing.tracingComplete',finish);
  if(handle)await handle.close();if(stream&&!closeRequested){closeRequested=true;await cdp.send('IO.close',{handle:stream}).catch(()=>{});}
  await cdp.detach().then(()=>record.cleanup.sessionDetached=true).catch(()=>{record.cleanup.sessionDetachedAfterAbort=abort.signal.aborted;});
  await c.close();record.cleanup.contextClosed=true;record.elapsedMs=performance.now()-t;if(!complete)await rm(path,{force:true});await persist();
 }
 return record;
}
async function inspect(path:string,record:any){
 const parsed=await readDocCallbackTrace(path,{signal:overall.signal});const raw=await readFile(path);assert.ok(raw.length<=256*1024*1024);const data=JSON.parse(raw.toString('utf8'));assert.equal(data.traceEvents.length,parsed.summary.sourceEvents);
 const events=data.traceEvents;const ids=record.fixture;const timers=events.filter((e:any)=>['TimerInstall','TimerRemove','TimerFire'].includes(e.name)&&[ids.cancelled,ids.repeated,ids.final].includes(e.args?.data?.timerId));
 const installs=timers.filter((e:any)=>e.name==='TimerInstall'&&e.args?.data?.stackTrace?.some((s:any)=>s.url===record.sourceUrl));assert.equal(installs.length,3,'all known source installs');
 const context=installs[0];const owned=timers.filter((e:any)=>e.pid===context.pid&&e.tid===context.tid);
 for(const [key,count] of [['cancelled',0],['repeated',3],['final',1]] as const){assert.equal(owned.filter((e:any)=>e.name==='TimerFire'&&e.args.data.timerId===ids[key]).length,count,key+' fire count');}
 for(const key of ['cancelled','repeated'])assert.ok(owned.some((e:any)=>e.name==='TimerRemove'&&e.args.data.timerId===ids[key]),key+' removal');
 for(const e of installs){const s=e.args.data.stackTrace.find((s:any)=>s.url===record.sourceUrl);assert.equal(String(s.scriptId),String(record.scriptId));assert.ok(Number.isFinite(s.lineNumber)&&Number.isFinite(s.columnNumber));assert.ok(Number.isFinite(e.ts));}
 const calls=events.filter((e:any)=>e.name==='FunctionCall'&&e.args?.data?.url===record.sourceUrl&&['repeatedCallback','finalCallback'].includes(e.args?.data?.functionName));
 assert.ok(calls.some((e:any)=>e.args.data.functionName==='repeatedCallback'));assert.ok(calls.some((e:any)=>e.args.data.functionName==='finalCallback'));
 for(const e of calls){assert.ok(Number.isFinite(e.ts)&&Number.isFinite(e.dur));assert.equal(String(e.args.data.scriptId),String(record.scriptId));assert.ok(Number.isFinite(e.args.data.lineNumber)&&Number.isFinite(e.args.data.columnNumber));}
 for(const name of ['spn144-start','spn144-end'])assert.ok(events.some((e:any)=>e.name===name),'marker '+name);
 const result={summary:parsed.summary,rawSha256:sha(raw),installCount:installs.length,fireCounts:{cancelled:0,repeated:3,final:1},removed:['cancelled','repeated'],functionNames:[...new Set(calls.map((e:any)=>e.args.data.functionName))].sort(),installs,calls};
 await writeFile(root+'/'+record.format+'-semantics.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});return result;
}
try{
 await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));const address=server.address();assert.ok(address&&typeof address==='object');const url=`http://127.0.0.1:${address.port}/`;
 browser=await chromium.launch({headless:true});assert.equal(browser.version(),'156.0.8078.4');report.browser=browser.version();
 const json=await capture('json',url);const proto=await capture('proto',url);
 await browser.close();browser=undefined;report.cleanup.browserClosed=true;
 const output=root+'/proto-converted.json';await child('convert',['convert','json',proto.raw.path,output],20000,false,output);
 const stats=await child('statistics',['query',proto.raw.path,"SELECT name, severity, value FROM stats WHERE value != 0 AND severity IN ('error', 'data_loss') ORDER BY name"],20000);
 assert.equal(stats.stdout.trim(),'"name","severity","value"','converter statistics must have no errors/data loss');
 const a=await inspect(json.raw.path,json),b=await inspect(output,proto);assert.deepEqual([a.installCount,a.fireCounts,a.removed,a.functionNames],[b.installCount,b.fireCounts,b.removed,b.functionNames]);
 const invalid=root+'/malformed.pftrace',invalidOutput=root+'/malformed-output.json';await writeFile(invalid,Buffer.from([0x0a,0xff,0xff,0xff,0x7f,0x01]),{flag:'wx'});
 try{await child('malformed-conversion',['convert','json',invalid,invalidOutput],5000,true,invalidOutput);}finally{await rm(invalidOutput,{force:true});}
 report.converted={bytes:(await stat(output)).size,sha256:sha(await readFile(output))};overall.signal.throwIfAborted();assert.ok(performance.now()-started<120000);report.passed=true;
}catch(error){report.firstFailure=String(error);process.exitCode=1;}finally{
 clearTimeout(deadline);if(browser)await browser.close().then(()=>report.cleanup.browserClosed=true).catch(e=>report.cleanup.browserError=String(e));
 await new Promise<void>(resolve=>server.close(()=>resolve()));report.cleanup.serverClosed=true;report.elapsedMs=performance.now()-started;await persist();console.log(JSON.stringify(report));
}
