import { readFileSync, statSync, chmodSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
const root='/tmp/spn144-v59-capability',binary=root+'/trace_processor_shell';
assert.equal(statSync(binary).size,14376168);
assert.equal(createHash('sha256').update(readFileSync(binary)).digest('hex'),'8488edbefadfc4be152cda1d42d9bfcede8b47638295eb85eb3bad8cd148fdf4');
chmodSync(binary,0o700);
for(const [name,args] of [['version',['--version']],['convert-help',['help','convert']],['query-help',['help','query']]] as const){
 const output=execFileSync(binary,args,{encoding:'utf8',timeout:10000,maxBuffer:128*1024});writeFileSync(root+'/'+name+'.txt',output,{flag:'wx'});console.log(name,output.slice(0,150));
}
console.log('Verified official mac-arm64 v59.1 binary and metadata commands.');
