import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { readFile, writeFile, stat } from 'node:fs/promises';
import { validateDocCallbackProto } from '/Users/mxbaylee/projects/spinel-spn-144/e2e/doc-responsiveness-callback-proto.ts';
import { readDocCallbackTrace } from '/Users/mxbaylee/projects/spinel-spn-144/e2e/doc-responsiveness-callback-trace.ts';
const root='/tmp/spn144-v59-capability/bounded-lifecycle', original='/tmp/spn144-capability', binary='/tmp/spn144-v59-capability/trace_processor_shell';
const sha=(v:Uint8Array)=>createHash('sha256').update(v).digest('hex');
const started=performance.now(), controller=new AbortController();
const timer=setTimeout(()=>controller.abort(Error('30-second retained-data deadline')),30000);
const report:any={kind:'retained-data-capability-only',attempt:1,passed:false,commands:[],invalidAdmitted:0};
const save=(name:string,value:unknown)=>writeFile(root+'/'+name+'.json',JSON.stringify(value,null,2)+'\n',{flag:'wx'});
function bracket(event:any,start:number,end:number){return Number.isFinite(event.ts)&&event.ts>=start&&event.ts<=end&&(event.name!=='FunctionCall'||Number.isFinite(event.dur)&&event.dur>=0&&event.ts+event.dur<=end);}
for(const name of ['TimerInstall','TimerFire','TimerRemove'])assert.equal(bracket({name,ts:101},0,100),false);
assert.equal(bracket({name:'TimerInstall',ts:-1},0,100),false);
assert.equal(bracket({name:'FunctionCall',ts:99,dur:2},0,100),false);
assert.equal(bracket({name:'TimerFire',ts:99,dur:20},0,100),true);
async function inspect(path:string,record:any){
 const raw=await readFile(path);assert.ok(raw.length<=16*1024*1024);
 const parsed=await readDocCallbackTrace(path,{signal:controller.signal});
 const events=JSON.parse(raw.toString('utf8')).traceEvents;assert.equal(events.length,parsed.summary.sourceEvents);
 const ids=record.fixture, url=record.sourceUrl;
 const installs=events.filter((e:any)=>e.name==='TimerInstall'&&e.args?.data?.stackTrace?.[0]?.url===url);
 assert.equal(installs.length,3);
 const context=installs[0], frame=context.args.data.frame;
 assert.ok(Number.isSafeInteger(context.pid)&&Number.isSafeInteger(context.tid));assert.ok(typeof frame==='string'&&frame.length>0);
 const same=(e:any)=>e.pid===context.pid&&e.tid===context.tid;
 const expected:any={cancelled:{count:0,timeout:5000,singleShot:true,line:3,column:21,remove:1},repeated:{count:3,timeout:20,singleShot:false,line:6,column:45,remove:1,fn:'repeatedCallback',callColumn:82},final:{count:1,timeout:10,singleShot:true,line:8,column:42,remove:0,fn:'finalCallback',callColumn:75}};
 const selected:any[]=[];let lastInstall=-Infinity;
 for(const key of ['cancelled','repeated','final']){
  const want=expected[key], matching=installs.filter((e:any)=>e.args.data.timerId===ids[key]);assert.equal(matching.length,1,key+' unique install');
  const install=matching[0], data=install.args.data, source=data.stackTrace[0];
  assert.ok(same(install));assert.equal(data.frame,frame);assert.equal(data.timeout,want.timeout);assert.equal(data.singleShot,want.singleShot);assert.equal(String(source.scriptId),String(record.scriptId));assert.equal(source.lineNumber,want.line);assert.equal(source.columnNumber,want.column);
  assert.ok(Number.isFinite(install.ts)&&install.ts>=lastInstall);lastInstall=install.ts;
  const owned=events.filter((e:any)=>same(e)&&e.args?.data?.timerId===ids[key]);
  const fires=owned.filter((e:any)=>e.name==='TimerFire').sort((a:any,b:any)=>a.ts-b.ts), removes=owned.filter((e:any)=>e.name==='TimerRemove');
  assert.equal(fires.length,want.count,key+' fires');assert.equal(removes.length,want.remove,key+' removes');
  let previous=install.ts;
  for(const fire of fires){assert.equal(fire.args.data.frame,frame);assert.ok(Number.isFinite(fire.ts)&&Number.isFinite(fire.dur)&&fire.dur>=0&&fire.ts>=previous);previous=fire.ts;}
  for(const remove of removes){assert.equal(remove.args.data.frame,frame);assert.ok(Number.isFinite(remove.ts)&&remove.ts>=previous);}
  const calls=events.filter((e:any)=>e.name==='FunctionCall'&&e.args?.data?.url===url&&e.args.data.functionName===want.fn).sort((a:any,b:any)=>a.ts-b.ts);
  if(want.fn){assert.equal(calls.length,want.count,key+' function count');for(let i=0;i<calls.length;i++){const call=calls[i], fire=fires[i], d=call.args.data;assert.ok(same(call));assert.equal(d.frame,frame);assert.equal(String(d.scriptId),String(record.scriptId));assert.equal(d.lineNumber,want.line);assert.equal(d.columnNumber,want.callColumn);assert.ok(Number.isFinite(call.dur)&&call.dur>=0&&call.ts>=fire.ts&&call.ts+call.dur<=fire.ts+fire.dur,'call nested in owning timer');}}
  selected.push({key,install,fires,removes,calls:want.fn?calls:[]});
 }
 const markers=['spn144-start','spn144-end'].map(name=>events.filter((e:any)=>same(e)&&e.name===name));
 for(const matches of markers)assert.equal(matches.length,1,'unique fixture marker');
 const start=markers[0][0].ts,end=markers[1][0].ts;assert.ok(Number.isFinite(start)&&Number.isFinite(end)&&start<end);
 for(const entry of selected)for(const event of [entry.install,...entry.fires,...entry.removes,...entry.calls])assert.ok(bracket(event,start,end),'marker bracket');
 return {file:path,bytes:raw.length,sha256:sha(raw),summary:parsed.summary,selected,markers,contract:'known fixture timer/source/lifecycle semantics, not arbitrary conversion fidelity'};
}
try{
 const bin=await readFile(binary);assert.equal(bin.length,14376168);assert.equal(sha(bin),'8488edbefadfc4be152cda1d42d9bfcede8b47638295eb85eb3bad8cd148fdf4');
 const capture=JSON.parse(await readFile(original+'/result.json','utf8')),proto=capture.captures.find((x:any)=>x.format==='proto'),json=capture.captures.find((x:any)=>x.format==='json');
 assert.equal(proto.raw.bytes,136693);assert.equal(proto.raw.sha256,'50a46a4f2151840f1252cab658cdc84b8e3896835790eb75a018266cb6489c8d');
 report.input=await validateDocCallbackProto(createReadStream(proto.raw.path),proto.raw,controller.signal);
 const bad=await readFile(original+'/malformed.pftrace');assert.equal(sha(bad),'d7976b4606ab7b9c3231f06747a1f5e5f7634c46dff8232226b52a321fa2d994');
 await assert.rejects(async()=>{await validateDocCallbackProto(createReadStream(original+'/malformed.pftrace'),{bytes:bad.length,sha256:sha(bad)},controller.signal);report.invalidAdmitted++;},/exceeds captured input/);assert.equal(report.invalidAdmitted,0);
 const output='/tmp/spn144-v59-capability/corrected-identity/proto-converted.json';
 assert.equal(sha(await readFile(output)),'fe4d2275402c56ae5eaefa0c2f13f333c5dfb2459a723a53200726b61cd6fabe');
 for(const [name,hash] of [['convert','01b8ee6f94d319616f07eca5ea021195b1a8de4b18007666bebd7affa7072686'],['statistics','bf47f476e00ceefba8a6c7474a1f086b853d496ea5b616e230bf770bbb3ccdbb']]){const raw=await readFile('/tmp/spn144-v59-capability/corrected-identity/'+name+'-command.json');assert.equal(sha(raw),hash);const receipt=JSON.parse(raw.toString());assert.equal(receipt.code,0);assert.equal(receipt.signal,null);if(name==='statistics')assert.equal(receipt.stdout.trim(),'"name","severity","value"');}
 const jsonRaw=await readFile(json.raw.path);assert.equal(sha(jsonRaw),json.raw.sha256);assert.equal(jsonRaw.length,json.raw.bytes);
 report.json=await inspect(json.raw.path,json);await save('json-semantics',report.json);
 report.proto=await inspect(output,proto);await save('proto-semantics',report.proto);
 report.passed=true;
}catch(error){report.firstFailure=String(error);process.exitCode=1;}finally{clearTimeout(timer);report.elapsedMs=performance.now()-started;await save('result',report);console.log(JSON.stringify({passed:report.passed,firstFailure:report.firstFailure,elapsedMs:report.elapsedMs,commands:report.commands.map((x:any)=>({name:x.name,code:x.code,elapsedMs:x.elapsedMs})),input:report.input}));}
