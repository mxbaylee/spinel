# 🔎 SPN-144 first capability probe — independent review A

## Disposition

**The first probe failed its declared acceptance condition.** Preserve that result; neither successful conversion of the real fixture nor clean statistics converts it into a pass. A new, prospectively bounded **offline retained-data framing investigation** is justified by a specific observed defect. This is permission to investigate a narrow guard, not production admission, a source grade, native acceptance, or authorization to repeat the browser captures.

I reviewed the prospective SPN-144 checkpoint, probe/preflight source and retained result, command, semantics and watchdog records, the six-byte malformed input, and the pinned public `Trace` schema. I did not execute Chromium, the converter, a benchmark, or an event-trace analysis. I independently checked the small probe/source/malformed file identities. This review is outside the probe root; original evidence remains unchanged.

## 🧾 Observed evidence

Probe SHA-256 is `7df58b43219ff3d15430457b04c9d6e8583fded4f2c36a0fee52e924d947db93`; saved fixture source is `1ef477cadeb01ded818568fae2a4c5dfb567020d89516cf9be3be87116861f1e`. The preflight source checks the official mac-arm64 binary's exact 13,597,976-byte size and SHA-256 `d29864d1ba3b36855527bb1b0ca3aa7f703cdce338b9680bb922c5c151b358fa` before enabling execution. Its retained receipt reports v58.2-add693d8b. I inspected that receipt, rather than rerunning the binary. This release is not asserted to be the exact Chromium-linked Perfetto build.

The single JSON and single proto captures used Chromium 156.0.8078.4, the same configured categories/buffer/CPU throttle, separate fresh contexts, and the declared fixture. Both completion records say no data loss, their streams reached EOF, and recorded stream/session/context cleanup succeeded; browser/server cleanup also succeeded. These are two different captures, not two encodings of the same event sequence.

JSON raw: 411,781 bytes, SHA-256 `accef97b28f622c3998e3403d16973422fd37030504ea23354ee8f46fb468713`. Proto raw: 136,693 bytes, SHA-256 `50a46a4f2151840f1252cab658cdc84b8e3896835790eb75a018266cb6489c8d`. Converted JSON's strict-reader summary records 357,203 bytes, SHA-256 `85baefecafa797fe7574e564ef4e01a4e6106f4609245ddb9ceceffc7458c5b7`. The `rawSha256` in `proto-semantics.json` refers to that converted JSON, not the proto input; preserve the distinct meanings in any later manifest. The final result's `converted` field is absent because execution failed before assigning it; the retained semantic record supplies its identity.

Both retained semantic records contain three source-attributed installs, cancelled/repeating timer removals, fire counts 0/3/1, source/script/line/column records and callback durations. Actual retained call arrays contain three repeated callbacks and one final callback. The existing strict reader accepted all 1,487 JSON and 1,249 converted events. Those differing event totals are expected for separate captures and are not an equivalence measurement.

Conversion completed in 135.367 ms. Statistics query returned only its header for nonzero `error`/`data_loss` entries. Both conversion and query stderr nevertheless report unsupported arm64 syscall traces. Thus that statistics predicate is not an exhaustive fidelity detector. It does not invalidate the specific observed timer records, but must not be described as universally clean or lossless conversion.

Malformed input is `0a ff ff ff 7f 01` (SHA-256 `d7976b4606ab7b9c3231f06747a1f5e5f7634c46dff8232226b52a321fa2d994`). The field-1 length-delimited envelope advertises 268,435,455 payload bytes with only one remaining. Converter returned exit 0 in 69.541 ms. The preserved first failure is correctly `malformed input accepted`; the overall watchdog reports command failure after 4,285 ms, peak 558,864 KiB, normal pressure. Successful cleanup is not successful capability acceptance.

## 🧪 What the next bounded investigation must establish

The supplied public schema defines only repeated field 1 `TracePacket` in the saved-file `Trace` wrapper. A streaming guard that requires complete allowed outer envelopes, bounded/overflow-safe varints and lengths, exact byte consumption and explicit EOF is a coherent way to reject this observed structural defect before conversion. Keep packet contents opaque; a new general protobuf decoder would add unjustified complexity.

Before executing that investigation, declare its finite input set, resource/output bounds, success conditions and failure disposition. Use the retained proto and deterministic byte fixtures; no new browser capture is needed. Meaningful controls include:

- The actual retained proto, multiple valid packet envelopes and boundaries split at every tag/length/payload transition, including one-byte input chunks.
- This exact six-byte failure; incomplete tags/lengths/payloads; trailing garbage; forbidden field/wire tags; overlong, overflowing and unterminated varints; declared lengths beyond configured limits. Specify whether noncanonical encodings, empty files and zero-length packets are deliberately rejected by this pinned contract rather than declaring them universally invalid protobuf.
- Validly framed but semantically invalid packet contents, and a valid packet-prefix with an entire final packet removed, as explicit **limits**: framing alone cannot prove inner validity or whole-capture completeness. Do not build a control that pretends these must be detectable from outer bytes alone.
- Exact capture byte count/hash binding through immutable raw input, guard, converter and converted-output reader, with deterministic rejection of wrong expected identity. Bind binary/version, schema authority/hash, commands and output identities. A hash generated only after accidental truncation does not prove original capture completeness.
- Preservation of converter errors, signals/timeouts, output failures, statistics and stderr. A known unsupported-architecture warning requires a narrow documented interpretation; never drop arbitrary warnings or silently treat absent parser statistics as no loss.

The current semantic assertions are deliberately small. They check three installs in aggregate, fire counts in one selected pid/tid, presence of removals/functions/marks and finite source/time fields. They do not comprehensively assert per-ID install uniqueness, exact callback function counts/context matching, lifecycle ordering, mark ordering or full source attribution behavior. The retained arrays are useful positive evidence, but these assertion limits remain. Full callback ownership/attribution, actual application source/maps, complete workload and all original caps/disposal requirements remain separate acceptance obligations before a transport change can land.

## ⏱️ Scope and remaining uncertainty

No result here diagnoses the historical 357-second pre-export workload or the ensuing deadline failure. Millisecond synthetic captures/conversion neither measure full-trace export behavior nor establish usable headroom, Linux resource behavior or a reliable finish inside the unchanged 420-second deadline. Preserve the complete XL outcome, baseline/category/content requirements and both desktop/mobile first-attempt obligations. SPN-141's storage changes remain blocked by their failed callback pair.

This next question is within SPN-144's trace-evidence/deadline investigation and needs no separate storage repair. Across all four personas, preserving complete trustworthy evidence and bounded resource ownership takes precedence over obtaining a green partial trace. A narrowly bounded outer guard is proportionate; treating it as semantic validation or adding a custom full trace interpreter is not. **No blocker to declaring the narrow offline investigation with the controls and limits above; no production or native-acceptance approval.**
