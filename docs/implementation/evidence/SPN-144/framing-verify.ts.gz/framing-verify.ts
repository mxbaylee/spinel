import { createReadStream } from 'node:fs';
import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { checkTraceEnvelope } from './guard.ts';
const root='/tmp/spn144-framing-probe',prior='/tmp/spn144-capability';
async function* chunks(bytes:Uint8Array,size:number){for(let i=0;i<bytes.length;i+=size)yield bytes.subarray(i,i+size);}
const original=JSON.parse(await readFile(prior+'/result.json','utf8'));
assert.equal(original.passed,false);assert.match(original.firstFailure,/malformed input accepted/);
const raw=original.captures.find((x:any)=>x.format==='proto').raw;
const valid=[];
for(const size of [1,2,7,65536]){const proof=await checkTraceEnvelope(createReadStream(raw.path,{highWaterMark:size}),64*1024*1024);assert.equal(proof.bytes,raw.bytes);assert.equal(proof.sha256,raw.sha256);valid.push({chunkSize:size,...proof});}
const bad:Record<string,Uint8Array>={
 empty:Buffer.from([]),wrongField:Buffer.from([0x12,0]),wrongWire:Buffer.from([0x08,1]),partialTag:Buffer.from([0x80]),
 missingLength:Buffer.from([0x0a]),partialLength:Buffer.from([0x0a,0x80]),overflow:Buffer.from([0x0a,0xff,0xff,0xff,0xff,0x10]),
 continuingFifth:Buffer.from([0x0a,0x80,0x80,0x80,0x80,0x80]),partialPayload:Buffer.from([0x0a,2,1]),
 trailingTag:Buffer.from([0x0a,1,1,0x0a]),trailingGarbage:Buffer.from([0x0a,1,1,0]),originalMalformed:await readFile(prior+'/malformed.pftrace'),
};
const negatives=[];let admittedInvalidConversions=0;
for(const [name,bytes] of Object.entries(bad))for(const size of [1,7]){
 let error='';try{await checkTraceEnvelope(chunks(bytes,size),64*1024*1024);admittedInvalidConversions++;}catch(e){error=String(e);}
 assert.ok(error,`accepted ${name}/${size}`);negatives.push({name,size,error});
}
const actual=await readFile(raw.path);await assert.rejects(checkTraceEnvelope(chunks(actual.subarray(0,actual.length-1),7),64*1024*1024),/Truncated/);
await assert.rejects(checkTraceEnvelope(chunks(actual,65536),actual.length-1),/bound/);
const emptyPacket=await checkTraceEnvelope(chunks(Buffer.from([0x0a,0]),1),64);assert.equal(emptyPacket.emptyPackets,1);
const opaque=await checkTraceEnvelope(chunks(Buffer.from([0x0a,1,0xff]),1),64);assert.equal(opaque.packets,1);
assert.equal(admittedInvalidConversions,0);
const result={passed:true,scope:'Strict wrapper framing only; no browser or converter rerun, no nested schema or complete-packet loss guarantee',valid,negatives,truncatedRetainedPayloadRejected:true,inputBoundRejected:true,emptyPacket,opaquePayloadAccepted:opaque,admittedInvalidConversions,priorProbeRemainsFailed:true};
await writeFile(root+'/result.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
