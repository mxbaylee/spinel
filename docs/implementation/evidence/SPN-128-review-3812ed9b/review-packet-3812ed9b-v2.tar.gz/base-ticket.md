---
id: SPN-128
emoji: 🌷
effort: L
impact_operator: M
impact_owner: M
impact_collaborator: M
score: 22
depends_on: []
decisions: []
---

# 🌷 SPN-128 Reinstall the preserved original after an interrupted restore

## Story

As the [Owner](../product/personas.md#owner), I want a restore interrupted during its trial to reopen on the workspace's own preserved content, so that a power loss or timeout does not cost work saved after the last backup.

## Scenarios

### The host stops during the candidate's trial

Given a confirmed restore that preserved the original and activated the candidate, then lost power or ran past its confirmation window before committing,
When the supervisor restarts and the Operator follows the unresolved-restore runbook,
Then a supported supervisor command verifies the preserved original against its frozen fingerprint and reinstalls it as a new generation,
And the restore records **Original content was recovered**, with the recovered banner and the same access reconciliation as an in-flight rollback,
And ambiguous or missing evidence still keeps the workspace closed.

## Rules

- Follow [sustainable testing](../testing.md); keep the Verify plan and progress evidence current. [Policy](../implementation/SPN-115.md#guidance-for-every-open-ticket-and-progress-checkpoint), owner 2026-11-01.

- Split by SPN-112's merge review, 2026-10-30: [disposition](../implementation/SPN-112.md#merge-review-dispositions). SPN-112 fails and reopens a restore that stopped before activation, stays fail-closed from activation onward, and documents fresh-host recovery from the last backup in `docs/maintenance.md`, which loses work after that backup.
- The command is supervisor-owned and journaled with its own crash cuts, needs fresh Operator authority, and never copies raw files over a live or newly acknowledged generation. Reuse `reconcileRestoreRollback` and the original-recovery permit rather than a second rollback path.
- Pre-launch: the launch drill (SPN-038) exercises restore on the target host, where an interruption today means lost work.
- Persona weighing: the Owner and Collaborators keep their latest work; the Operator gets a supported exit instead of fresh-host recovery; Link guests are revoked either way.

## Out of scope

- Lifting the five-minute window (SPN-124); evidence pruning (SPN-125).

## Verify

- Reuse restore crash, rich-content and original-recovery fixtures with isolated roots and actual owned subprocesses; observe each durable journal phase before SIGKILL instead of sleeping. Real-process coverage owns restart/custody safety; focused cases own ambiguous/missing evidence and stale-authority refusal.
- Track supervisor, rollback/reconciliation, journal/fingerprint, auth and shared fixture dependencies in routing. Retain every crash cut's frozen/live fingerprint, generation, authority and first-failure/process evidence; bounded cleanup must preserve the initial cause and never touch another workload.

- Real-process SIGKILL tests at trial-opening, activation, original-activation and original-commit, each followed by restart, the new command, and a check that the live fingerprint equals the frozen original's.
- Runbook step in `docs/maintenance.md` replaced by the supported command.
