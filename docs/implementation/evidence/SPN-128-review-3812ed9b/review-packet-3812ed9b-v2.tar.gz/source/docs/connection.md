# Connection status

SPN-042 implements the network control approved in SPN-047, beside the gem in
the account shell and the identity-free guest header. It is one connection
indicator, separate from the editor's save confirmation. Owner direction,
2026-10-19 and 2026-10-21; [design decision #126](implementation/SPN-047.md#legacy-decision-126-approved-redesign-and-its-limits)
and [runtime decision #132](implementation/SPN-042.md#legacy-decision-132-verified-connection-proof-and-stable-presentation).

## What each state proves

| State        | Meaning                                                                                                                                                                                                |
| ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Online       | The current account screen has received a valid server health response, or the live editor has an active collaboration unit and its document room is joined. It does not prove an edit is saved.       |
| Offline      | The browser reports no connection, a bounded reachability check fails, or the editor reports its connection unavailable. Pending work stays subject to the separate save warning and navigation guard. |
| Reconnecting | The browser has returned or the connection is being established, but the relevant server/room proof has not completed.                                                                                 |

The browser's `online` event invalidates the old room proof. A good HTTP response
or an ordinary synchronization callback cannot turn a reconnecting editor Online;
the public per-document room stream must report its new subscription. Pending
edits normalize to an active collaboration unit and can coexist with Online.
Browser recovery explicitly closes the public socket before requesting reconnect,
because a browser's offline switch can leave the old WebSocket alive. Ordinary
save Retry does not invalidate a continuously joined room: the SDK may correctly
leave a healthy socket alone, without emitting another joined event.
No connection transition clears the pending-edit guard or bypasses the existing
recovery-cache flush that precedes a completed save.

Account screens without a live editor reuse authenticated `/api/health` with
`no-store`, a three-second poll and a two-second deadline including the body.
Probes do not overlap; old responses after browser loss, replacement or disposal
are ignored. A confirmed 401 locks the prepared-account pointer and signs in
again. Live editors stop this shell probe and use their own public room/sync
streams, plus the existing document-access round trip with a bounded timeout.
An HTTP-only failure temporarily vetoes Online. Recovery removes that veto;
the existing room and synchronization states still decide readiness. It neither
manufactures a room acknowledgement nor discards a continuously joined room.
Actual browser/room loss still requires the new subscription. This is connection status for
people using Spinel, not the Operator health dashboard from SPN-032.

Guest views use only guest-scoped metadata and collaboration endpoints. They
show no account identity, account navigation or account health/session request.
Transient network errors preserve the mounted editor and unfinished changes;
authoritative 401/403/404 link denial removes document content and title.
The generic service-worker offline launch remains unchanged and never caches a
private guest document.

## Presentation and local catalogs

`ConnectionStatus` reserves a 44 by 44 px button beside the gem. Distinct icons,
an accessible state name and the same hover, keyboard-focus and touch detail
communicate the state without relying on colour. A separate polite live region
announces transitions. The detail opens outside document flow, so it cannot
move the editor, and Escape/outside touch dismiss it.

The detail uses Base UI `Popover` with hover opening and keyboard-focus support,
not its visual-only Tooltip. The named **Connection details** dialog and native
trigger relationship expose the timestamp/read-only explanation to assistive
technology as well as touch users. Opening detail does not steal focus from an
unfinished editor input. This follows the library's
[infotip guidance](https://base-ui.com/react/components/tooltip#infotips) and
[public Popover API](https://base-ui.com/react/components/popover).

When a catalog is local, offline or a refresh failed, the detail includes
**Files as of**. SPN-042 removes `OfflineBanner`; it does not add another status
row. A local catalog keeps that timestamp after connectivity returns. Downloaded
editors retain their saved viewer/editor permissions and revalidate the current
account, grant, generation and live revision before replaying pending work.
The dashboard never claims **Saved on this device**. See [offline behavior](offline.md).

The fixed title-adjacent save slot keeps a persistent short label while its
popover holds full pending-edit warnings and Retry (SPN-043). A background shared-file-list
refresh error remains an announced alert with its Retry action, after the open
editor so the delayed polling failure cannot push the document down. In the
file list it retains its existing placement above the list. The compact editor
header composes that slot and this connection control without replacing either
controller, including its slim theatre strip (SPN-049).
SPN-053 adds local/pending-sync durability states, without treating an
open connection as persistence evidence.

The native sync checkpoint must commit to IndexedDB before **Saved on this
device** appears. **Synced** also requires every durable server acknowledgement
and committed local cleanup. **Needs attention** retains work after changed
access/generation/revision or refused edits; an uncaptured visible edit keeps the
explicit keep-this-tab-open warning. Viewers remain **View only**. A second save
row is not added, and local persistence failure has a retry action that works
while offline. See [SPN-053](implementation/SPN-053.md).

## Verification and decision record

- `src/ui/connectionState.test.ts` covers browser/room/sync mapping, stale room
  proof, ordinary pending edits, health errors/timeouts, stale responses, session
  denial and disposal.
- `e2e/connection-status.spec.ts` exercises the real dashboard, Sheets and Docs
  at desktop and touch-phone widths. It holds real writes while Online, interrupts
  actual sockets and separately exercises the browser offline switch alone. It
  withholds a real successful JOIN response while HTTP health is
  already good, then releases it. It compares the complete editor bounds through
  Offline, Reconnecting and Online, including the delayed shared-list poll failure.
- Existing guest and offline end-to-end tests preserve revocation/privacy,
  unfinished guest input, local viewer restrictions and the catalog timestamp.
- `Current production/Shell/ConnectionStatus` stories cover all three states,
  keyboard/touch detail, stale/local catalogs and Online with an unsaved warning.
  The Storybook review captures them in light, dark and phone variants.

These are verification contracts; the PR records the actual executed commands,
results, resource limits, independent review and independent theme/persona screenshot review on the PR under the
[standing policy](implementation/grooming-2026-10-26.md#agent-decisions-and-visual-review).
The all-persona tradeoff and S-to-M effort reassessment are in decision [#132](implementation/SPN-042.md#legacy-decision-132-verified-connection-proof-and-stable-presentation).
The [SPN-042 screenshot review index](design/review/spn-042/README.md) links the
production browser artifacts and preserves their exact capture provenance.
