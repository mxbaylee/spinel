import config from '/Users/mxbaylee/projects/spinel-spn-156/playwright.config.ts';
export default {
  ...config,
  testDir: '/Users/mxbaylee/projects/spinel-spn-156/e2e',
  testMatch: 'offline-locks.spec.ts',
  webServer: [],
  outputDir: '/tmp/spn156-locks-platform-results',
  reporter: [['line'], ['json', { outputFile: '/tmp/spinel-dependabot-2026-11-11/spn156-locks-chromium-report.json' }]],
  projects: config.projects?.filter((project) => project.name === 'production').map((project) => ({ ...project, testMatch: 'offline-locks.spec.ts', testIgnore: [] })),
};
