import { locks } from 'node:worker_threads';
const held = Promise.withResolvers<void>();
const started = Promise.withResolvers<void>();
const owner = locks.request('spn156-abort-probe', { mode: 'shared' }, async () => { started.resolve(); await held.promise; });
await started.promise;
const c = new AbortController();
let called = false;
const queued = locks.request('spn156-abort-probe', { signal: c.signal }, () => { called = true; });
const rejected = queued.catch(e => e.name);
c.abort();
console.log('rejected', await rejected, 'immediate', await locks.query());
await new Promise<void>(resolve => setImmediate(resolve));
console.log('next task', await locks.query(), 'called', called);
held.resolve(); await owner;
console.log('owner released', await locks.query(), 'called', called);
let acquired = false;
const progressController = new AbortController();
const deadline = setTimeout(() => progressController.abort(), 1000);
try {
  await locks.request('spn156-abort-probe', { signal: progressController.signal }, () => { acquired = true; });
  console.log('subsequent valid exclusive', acquired, 'aborted callback', called, 'final', await locks.query());
} catch (error) { console.log('subsequent valid exclusive failed', String(error), 'acquired', acquired); process.exitCode = 1; }
finally { clearTimeout(deadline); }
