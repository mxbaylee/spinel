import assert from 'node:assert/strict';
import { locks } from 'node:worker_threads';
import { withOfflineItemWriter, reserveOfflineReplay, withOfflineEditorAdmission } from '/Users/mxbaylee/projects/spinel-spn-156/web/offline/offlineStore.ts';
const values = new Map<string, string>();
let denied = true;
const target = Object.assign(new EventTarget(), { localStorage: {
 getItem(key: string) { if (denied) throw new DOMException('Storage denied', 'SecurityError'); return values.get(key) ?? null; },
 setItem(key: string, value: string) { values.set(key, value); },
 removeItem(key: string) { values.delete(key); },
}});
Object.defineProperty(globalThis, 'window', { configurable: true, value: target });
Object.defineProperty(globalThis, 'navigator', { configurable: true, value: { locks } });
let ran = false;
const outcome = await withOfflineItemWriter('review-b-account', 'review-b-item', async () => { ran = true; }).then(() => 'unexpected success', (e: Error) => e.message);
assert.match(outcome, /Offline downloads need browser storage/);
assert.equal(ran, false);
denied = false;
const reservation = reserveOfflineReplay('review-b-account', 'review-b-item', async () => {});
reservation?.();
let entered = false;
const opening = withOfflineEditorAdmission('review-b-account', 'review-b-item', () => {}, async () => { entered = true; });
void opening.catch(() => {});
await new Promise<void>((resolve) => setImmediate(resolve));
console.log(JSON.stringify({ initialRefusal: outcome, workRan: ran, subsequentReplayReserved: typeof reservation === 'function', subsequentEditorEntered: entered, locks: await locks.query() }));
assert.equal(typeof reservation, 'function', 'Rejected fence capture must release temporary writer reservation');
assert.equal(entered, true, 'Subsequent editor admission must not await the failed writer forever');
await opening;
