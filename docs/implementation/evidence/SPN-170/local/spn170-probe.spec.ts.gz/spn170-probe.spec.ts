import { expect, test } from '@playwright/test';
import { readEditingSelection, withEditingDoc } from './doc-editing.ts';

if (process.env.SPINEL_DOC_EDITING_MOBILE === '1') {
  for (const mobile of [false, true]) {
    for (const scenario of ['backspace', 'paragraph', 'beforeinput'] as const) {
      test(`SPN-170 bounded ${mobile ? 'phone' : 'desktop'} ${scenario} @doc-editing-mobile`, async ({ browser, baseURL }, info) => {
        test.setTimeout(60_000);
        await withEditingDoc(browser, baseURL!, info, mobile, async (f) => {
          await f.focus();
          await expect.poll(async () => (await readEditingSelection(f.page))?.start).toBe(0);
          await f.page.keyboard.type('abc');
          await expect.poll(async () => (await f.read()).body!.dataStream).toBe('abc' + f.initial.body!.dataStream);
          await expect.poll(async () => (await readEditingSelection(f.page))?.start).toBe(3);
          if (scenario === 'paragraph') {
            await f.page.keyboard.press('Enter');
            await expect.poll(async () => (await f.read()).body!.dataStream).toBe('abc\r' + f.initial.body!.dataStream);
          }
          if (scenario === 'beforeinput') {
            await f.page.locator('[contenteditable="true"][data-u-comp="editor"]').evaluate((node) => {
              const before = new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'deleteContentBackward', data: null });
              if (node.dispatchEvent(before)) node.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward', data: null }));
            });
          } else await f.page.keyboard.press('Backspace');
          const expected = (scenario === 'paragraph' ? 'abc' : 'ab') + f.initial.body!.dataStream;
          await expect.poll(async () => (await readEditingSelection(f.page))?.text).toBe(expected);
          await expect.poll(async () => (await f.read()).body!.dataStream).toBe(expected);
        });
      });
    }
  }
}
