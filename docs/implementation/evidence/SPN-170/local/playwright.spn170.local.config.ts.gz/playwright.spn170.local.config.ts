import base from './playwright.config.ts';
import { defineConfig } from '@playwright/test';
export default defineConfig({
  ...base,
  testMatch: '**/spn170-probe.spec.ts',
  retries: 0,
  maxFailures: 0,
  reporter: [['line'], ['json', { outputFile: '../spn170-evidence/probe-first.json' }]],
  projects: [{ name: 'development', testMatch: '**/spn170-probe.spec.ts', use: {
    baseURL: 'http://localhost:3100', launchOptions: { executablePath: '/usr/bin/chromium' },
  } }],
  webServer: [{ command: 'node --max-old-space-size=512 --max-semi-space-size=8 --no-turbo-fast-api-calls server/index.ts --dev --no-open',
    url: 'http://localhost:3100/sign-in', reuseExistingServer: false,
    env: { PORT: '3100', HOST: '127.0.0.1', DATABASE_PATH: 'test-results/development/app.sqlite', VITE_SYNC_EVIDENCE: '0', VITE_DOC_SELECTION_EVIDENCE: '1', VITE_DOC_RESPONSIVENESS_EVIDENCE: '0' },
  }],
});
