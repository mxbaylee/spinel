# Doc PDF visual review receipt

**Result: PASS for this fixture set. No unexpected visual defect found. Agent-only visual review; no human sign-off or numeric score.**

## Identity and scope

- Reviewer: `/root/remaining_compatibility`.
- Original render HEAD: `be82b4c30c358db6558ecb7ddc44351ff2cbaac9`.
- Remote-prepared HEAD: `0770dbefaec0c1500230f8403779b2800129d5b1`.
- Independently verified both commits have identical tree `2a84ee73c0b643879b87b1377fd93e29d6daaf32`.
- Source folder: `/workspace/scratch/173c10859a4a/spinel/output/pdf/spn-102`.
- Freshness cutoff: `2026-11-07T04:24:49Z`.
- Inventory: **43 PDFs, 115 PDF pages, 115 corresponding PNGs, and 2 supporting JSON files**. Every artifact is newer than the cutoff; no missing, stale, or orphan page PNGs.
- PDF mtimes: `2026-11-07T04:24:52.663760Z` through `2026-11-07T04:25:36.273679Z`.
- PNG mtimes: `2026-11-07T04:24:52.799754Z` through `2026-11-07T04:25:36.293678Z`.
- The parent reports 34 focused native print tests passed. This review did not rerun tests, edit repository source, modify PDF/PNG outputs, or change checks/guards/budgets.

## Method and findings

Read the PDF skill and the complete `lib/print/README.md` rendering/visual-review contract. Reconciled PDF page counts using `pdfinfo`, inspected all 115 existing page PNGs at native resolution in 20 labeled contact sheets, and rendered six selected pages with Poppler at 144 dpi for independent detail inspection. The detail pages cover rich faces/glyphs, the first Formula table seam (pages 1 and 2), the final merged row, long-text tail, and zero margins. Contact sheets retain original pixels without downsampling.

All pages were checked for late content, page boundaries, table seams, image bands, readable glyphs, faces, colors, margins and watermark. No unexpected clipping, overlap, missing glyph, discontinuous color order, unexplained blank page or watermark was observed. At 144 dpi the thin Formula table bottom borders are visible and intact. Native font slashed-zero shapes are intentional, not stray marks.

- Long modern text remains sequential through `PARA-069` on page 18; the explicit break before `PARA-035` is respected.
- Formula output retains rows 01–30, wrapped words, final result sentinels, explicit page break, and kept two-row group. The null array cell is intentionally empty.
- Tall native rows retain `WORD000`–`WORD119`, following row and table tail. Merged content retains `MERGED000`–`MERGED099`, neighboring cells, final row and tail.
- Image continuations preserve visible red/green/blue order and width through physical pages. Multiple-image output shows caption between images and the final sentinel. Full-column Square and narrow Square fixtures preserve their expected distinct wrapping; narrow Square intentionally places the tail beside the image on page 1.
- Header, LINE-offset, compensated-offset, small-image and exact-spacing variants retain visible source order and separation. Crop/opacity output shows the expected pale blue crop without red. Heading, regular/bold/italic/bold-italic, accent/combining text, star fallback and nested list indentation are readable.
- Stored/fractional frames and zero margins match fixture intent. White paper and the 36-point normal margins are visually preserved; zero margins intentionally place text at the upper-left edge.

## Expected sparse/blank output

Source expectations were checked in `lib/print/doc-native.test.ts`, `lib/print/pdf-geometry.test.ts` and `lib/print/doc-native-test-support.ts`, with the retained `negative-tall-native-geometry.json` diagnostic.

- `tall-negative-native-image`: page 2 is intentionally white; page 3 begins with only a thin red band near the lower body edge. The independent native layout places the image at y=951.1510416666666 native pixels, preserving a gap of more than two page bodies. Pages 4–6 complete the bands and following sentinel.
- `fractional-frame` and `heterogeneous-frames`: sparse red/blue squares are the authored geometry probes.
- `vertical-tall-merge` page 5 contains only the table-end sentinel; `after-resource-failures` page 4 contains only paragraphs 78 and 79. These are intentional remaining tail content.
- One-line recovery/geometry pages, explicit-break prefix page, and thin final image-band tails are intentional synthetic fixtures.

## Complete page coverage

All pages in each range below were visually inspected and passed within the stated scope. Exact per-file mtimes, dimensions and SHA-256 values are in `doc-pdf-inventory.json`; `doc-contact-manifest.json` maps every PNG to its reviewed contact sheet.

| PDF | Pages inspected | Result |
| --- | ---: | --- |
| `after-resource-failures.pdf` | 1–4 | Pass |
| `after-unsupported-content.pdf` | 1 | Pass |
| `anchor-exact-reference.pdf` | 1 | Pass |
| `anchor-exact-spacing.pdf` | 1 | Pass |
| `anchor-normal-strut.pdf` | 1 | Pass |
| `anchor-relative-spacing.pdf` | 1 | Pass |
| `anchor-small-image.pdf` | 1 | Pass |
| `anchor-small-reference.pdf` | 1 | Pass |
| `cropped-translucent-image.pdf` | 1 | Pass |
| `fallback.pdf` | 1 | Pass |
| `formula-array.pdf` | 1 | Pass |
| `formula-explicit-break.pdf` | 1–2 | Pass |
| `formula-keep-lines.pdf` | 1–2 | Pass |
| `formula-scalar.pdf` | 1 | Pass |
| `formula-thirty-rows.pdf` | 1–7 | Pass |
| `formula-unavailable.pdf` | 1 | Pass |
| `fractional-frame.pdf` | 1 | Pass |
| `fractional.pdf` | 1 | Pass |
| `heterogeneous-frames.pdf` | 1–2 | Pass |
| `horizontal-merge.pdf` | 1 | Pass |
| `line-compensated-physical-header.pdf` | 1 | Pass |
| `line-offset-physical-header.pdf` | 1 | Pass |
| `line-zero-physical-header.pdf` | 1 | Pass |
| `modern-complete-paragraphs.pdf` | 1–18 | Pass |
| `modern-spacing.pdf` | 1 | Pass |
| `native-tall-row.pdf` | 1–5 | Pass |
| `nonleading-image-physical-header.pdf` | 1 | Pass |
| `rich-fonts-headings-lists.pdf` | 1 | Pass |
| `shared-native-lock.pdf` | 1 | Pass |
| `stored.pdf` | 1 | Pass |
| `tall-floating-image.pdf` | 1–4 | Pass |
| `tall-full-column-square.pdf` | 1–4 | Pass |
| `tall-image-only-top-bottom.pdf` | 1–4 | Pass |
| `tall-inline-image.pdf` | 1–4 | Pass |
| `tall-interleaved-multiple-images.pdf` | 1–7 | Pass |
| `tall-line-relative-caption.pdf` | 1–4 | Pass |
| `tall-line-relative-image-only.pdf` | 1–4 | Pass |
| `tall-negative-native-image.pdf` | 1–6 | Pass |
| `tall-nonleading-top-bottom.pdf` | 1–4 | Pass |
| `tall-square-image.pdf` | 1–4 | Pass |
| `traditional-spacing.pdf` | 1 | Pass |
| `vertical-tall-merge.pdf` | 1–5 | Pass |
| `zero-margins.pdf` | 1 | Pass |

## Representative current PNGs for maintained PR evidence

- `/workspace/scratch/173c10859a4a/spinel/output/pdf/spn-102/rich-fonts-headings-lists-1.png`
  - SHA-256: `44bb126667c2b9dc228b9b0c5bb7b94aa98561330ba7af23315af889485c5ec5`.
- `/workspace/scratch/173c10859a4a/spinel/output/pdf/spn-102/modern-complete-paragraphs-18.png`
  - SHA-256: `0178896ee44a5f4dbbcbd388c6678354cdf814a7aec48ff1dac7c2372a4c78fa`.
- `/workspace/scratch/173c10859a4a/spinel/output/pdf/spn-102/tall-full-column-square-3.png`
  - SHA-256: `2a7b6a46ab58e4dd7eaa11161c34ca7966acd89e0aa0f2a34cf55c78511ea02a`.

## Evidence and limits

- `doc-output-sha256.txt`: SHA-256 manifest for all 160 original outputs, paths relative to the repository root. Verify from that root with `sha256sum -c /workspace/scratch/173c10859a4a/followup-evidence/doc-output-sha256.txt`.
- `doc-output-metadata.json`: all-output paths, byte sizes, current mtimes, hashes, review identity and verified commit/tree association.
- `doc-pdf-inventory.json`: 43 PDF records, 115 page/PNG mappings, dimensions, freshness and hashes.
- `doc-contact-01.png` through `doc-contact-20.png`, plus `doc-contact-manifest.json`: exact visual inspection coverage.
- `doc-detail/`: six independently reopened Poppler detail pages at 144 dpi.

All original output hashes still matched the initial inventory at receipt creation. This is visual evidence for the fresh focused Doc fixtures only; it does not certify ungenerated Doc fixtures, Sheets, production resource capacity, every script/font, browser download behavior or the eventual hosted CI candidate. The supplied fixture fonts and synthetic content bound the observations. No unsupported-source failure was converted to a pass.
