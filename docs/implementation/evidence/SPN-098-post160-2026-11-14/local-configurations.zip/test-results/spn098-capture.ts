import { spawnSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
const ids: string[] = JSON.parse(readFileSync('/tmp/spn098-resume-2026-11-13/story-ids.json', 'utf8'));
const result = spawnSync(process.execPath, ['scripts/screenshots.ts', ...ids], {
  stdio: 'inherit', env: { ...process.env, SPINEL_SCREENSHOT_DIR: 'test-results/spn098-post160-visual' },
});
process.exitCode = result.status ?? 1;
