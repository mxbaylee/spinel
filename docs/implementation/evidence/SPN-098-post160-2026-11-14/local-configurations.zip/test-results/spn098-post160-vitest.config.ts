import config from '../vitest.config.ts';
export default { ...config, cacheDir: '/tmp/spn098-post160-20261114/cache/vitest' };
