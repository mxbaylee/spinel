import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, realpathSync, rmSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = fileURLToPath(new URL('.', import.meta.url));
const provenance = JSON.parse(readFileSync(join(root, 'source-and-dependencies.json'), 'utf8'));
const results: Array<Record<string, unknown>> = [];
const receipt: Record<string, unknown> = {
  purpose: 'Effective PRAGMA synchronous on each actual DiagnosticsStore-owned connection; no timing or Linux acceptance claim',
  pid: process.pid,
  node: process.version,
  platform: process.platform,
  arch: process.arch,
  results,
};
writeFileSync(join(root, 'owned-pid.txt'), `${process.pid}\n`);
assert.equal(process.version, 'v26.13.0');
assert.equal(process.env.LIBSQL_JS_DEV, undefined, 'Native development override invalidates dependency identity');
const resolved: Record<string, string> = {};
for (const label of ['base', 'candidate'] as const) {
  const source = provenance.sources[label];
  const directory = join(root, `${label}-owned-data`);
  mkdirSync(directory, { mode: 0o700 });
  const path = join(directory, 'diagnostics.sqlite');
  const applicationPath = join(directory, 'workspace.sqlite');
  writeFileSync(applicationPath, '', { mode: 0o600 });
  const result: Record<string, unknown> = { label, source: source.commit, stage: 'module-import', databaseRemoved: false };
  results.push(result);
  let store: { path: string; status(): { available: boolean }; close(): Promise<void> } | undefined;
  let connection: { isOpen: boolean } | undefined;
  try {
    const require = createRequire(join(source.snapshot, 'server/database.ts'));
    const modules = Object.fromEntries(['libsql', '@libsql/darwin-arm64', '@spinel/diagnostics'].map((name) => {
      const modulePath = realpathSync(require.resolve(name));
      if (resolved[name]) assert.equal(modulePath, resolved[name]);
      else resolved[name] = modulePath;
      return [name, { path: modulePath, sha256: createHash('sha256').update(readFileSync(modulePath)).digest('hex') }];
    }));
    result.resolvedModules = modules;
    const { DiagnosticsStore } = await import(pathToFileURL(join(source.snapshot, 'src/server/diagnostics/store.ts')).href);
    const { DatabaseSync } = await import(pathToFileURL(join(source.snapshot, 'server/database.ts')).href);
    result.stage = 'construction';
    store = new DiagnosticsStore({ path, applicationPath, build: 'spn157-configuration-control' });
    assert.equal(store.status().available, true, 'DiagnosticsStore construction did not retain an available database');
    // Test-only observation of the existing TS-private own field. No adapter,
    // constructor, SQL or production API is replaced, and no second connection opens.
    const descriptor = Object.getOwnPropertyDescriptor(store, 'database');
    assert.ok(descriptor && 'value' in descriptor);
    const actual = descriptor.value;
    assert.ok(actual instanceof DatabaseSync);
    assert.equal(actual.path, path);
    assert.equal(actual.isOpen, true);
    connection = actual;
    result.stage = 'actual-connection-query';
    result.synchronous = actual.prepare('PRAGMA synchronous').get()?.synchronous;
    result.journalMode = actual.prepare('PRAGMA journal_mode').get()?.journal_mode;
    result.busyTimeout = actual.prepare('PRAGMA busy_timeout').get()?.timeout;
    assert.ok(Number.isInteger(result.synchronous));
    result.constructorAvailable = true;
    result.sameStoreConnection = true;
    result.stage = 'measured';
  } catch (error) {
    result.error = error instanceof Error ? error.message : String(error);
    process.exitCode = 1;
  } finally {
    try {
      await store?.close();
      result.connectionClosed = connection ? !connection.isOpen : null;
      if (connection) assert.equal(connection.isOpen, false);
    } catch (error) {
      result.cleanupError = error instanceof Error ? error.message : String(error);
      process.exitCode = 1;
    } finally {
      rmSync(directory, { recursive: true, force: true });
      result.databaseRemoved = !existsSync(directory);
      writeFileSync(join(root, 'result.json'), `${JSON.stringify(receipt, null, 2)}\n`);
    }
  }
}
console.log(JSON.stringify(receipt, null, 2));
