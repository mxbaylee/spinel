/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Modified for Spinel: execute the pinned public Doc state manager region
 * against real JSONX/TextX operations and controlled service endpoints/timers.
 * Original bundle bytes are semantic and primitive-work negative controls.
 * Source: packages/docs/src/services/doc-state-change-manager.service.ts,
 * dream-num/univer v1.1.0. No Pro package is read or modified.
 */
// Scratch-only bounded SPN-123 proof. PREPARED FOR REVIEW; DO NOT AUTO-RUN.
// Primitive instrumentation and manager setup come from the existing counted
// test. The flush wrapper retains observations before assertions. The fixture
// unit ID is doc. This file never writes installed SDK sources.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { serialize } from 'node:v8';
import { runInNewContext } from 'node:vm';
import * as core from '@univerjs/core';
import type { IDocumentData, JSONXActions } from '@univerjs/core';
import {
  DocSelectionManagerService,
  DocStateChangeManagerService,
  DocStateEmitService,
} from '@univerjs/docs';
import type { IDocStateChangeInfo, IDocStateChangeParams } from '@univerjs/docs';
import { NORMAL_TEXT_SELECTION_PLUGIN_STYLE } from '@univerjs/engine-render';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { test, vi } from 'vitest';
import { NativeReplica } from '../index.ts';
import { nativeSession } from './native-session.ts';
import { prepareDocsPatch } from '../../../scripts/dependencies/patch-univer-docs.ts';

type State = IDocStateChangeParams;
type Side = State['redoState'] & { unitId: string; segmentId?: string; trigger?: string };
type Entry = {
  unitID: string;
  undoMutations: { id: string; params: Side }[];
  redoMutations: { id: string; params: Side }[];
};
type Manager = Pick<DocStateChangeManagerService,
  'getStateCache' | 'setStateCache' | 'clearHistory' | 'flushPendingChanges' | 'docStateChange$' | 'dispose'>;
const unitId = 'doc';
const repoRoot = resolve(import.meta.dirname, '../../..');
const outputRoot = '/tmp/spn123-marker-proof';
const marker = '__textXPreserveParagraphIds';
const sha256 = (value: string | Uint8Array) => createHash('sha256').update(value).digest('hex');
const saveJson = (name: string, value: unknown) =>
  writeFileSync(resolve(outputRoot, name), JSON.stringify(value, null, 2) + '\n');
function saveFull(name: string, value: unknown) {
  const bytes = serialize(value);
  const path = resolve(outputRoot, name);
  writeFileSync(path, bytes);
  return { path, bytes: bytes.byteLength, sha256: sha256(bytes), encoding: 'node:v8 serialize; own undefined retained' };
}

function clock() {
  let now = 0;
  let nextId = 1;
  const pending = new Map<number, { at: number; callback: () => void }>();
  return {
    count: () => pending.size,
    setTimeout(callback: () => void, delay: number) {
      const id = nextId++;
      pending.set(id, { at: now + delay, callback });
      return id;
    },
    clearTimeout(id: number) {
      pending.delete(id);
    },
    tick(milliseconds: number) {
      now += milliseconds;
      for (const [id, task] of pending) {
        if (task.at > now) continue;
        pending.delete(id);
        task.callback();
      }
    },
  };
}

function managerFixture(source: string) {
  const marker = '//#region src/services/doc-state-change-manager.service.ts\n';
  const start = source.indexOf(marker);
  const end = source.indexOf('//#endregion', start);
  assert.ok(start >= 0 && end > start, 'Execute the actual hash-verified manager region.');
  const timers = clock();
  const contextCore = { ...core, Inject: () => () => {}, Optional: () => () => {} };
  const ManagerClass = runInNewContext(
    `${source.slice(start + marker.length, end)}\nDocStateChangeManagerService;`,
    {
      ...contextCore,
      ...timers,
      BehaviorSubject,
      takeUntil,
      _univerjs_core: contextCore,
      rxjs: { BehaviorSubject, takeUntil },
      DocStateEmitService: {},
      _defineProperty: (object: Record<string, unknown>, key: string, value: unknown) => {
        object[key] = value;
        return object;
      },
      __decorate: (_decorators: unknown, constructor: unknown) => constructor,
      __decorateParam: () => () => {},
    },
    { filename: 'docs.installed-state-manager.js', timeout: 1000 },
  );
  const input = new Subject<IDocStateChangeInfo>();
  const history: Entry[] = [];
  const changes: State[] = [];
  const publication: { kind: string; history: number; collaboration: number }[] = [];
  const commands = new Set<(command: { id: string }) => void>();
  let manager: Manager;
  const observe = (kind: string) => {
    const cache = manager.getStateCache(unitId);
    publication.push({
      kind,
      history: cache.history.length,
      collaboration: cache.collaboration.length,
    });
  };
  manager = new ManagerClass(
    {
      pushUndoRedo(entry: Entry) {
        observe('history');
        history.push(structuredClone(entry));
      },
    },
    {
      beforeCommandExecuted(listener: (command: { id: string }) => void) {
        commands.add(listener);
        return { dispose: () => commands.delete(listener) };
      },
    },
    { getCurrentUnitOfType: () => ({ getUnitId: () => unitId }) },
    { docStateChangeParams$: input },
  ) as Manager;
  const subscription = manager.docStateChange$.subscribe((state) => {
    if (!state) return;
    observe('collaboration');
    changes.push(structuredClone(state));
  });
  return {
    manager,
    input,
    timers,
    history,
    changes,
    publication,
    beforeCommand(id: string) {
      for (const listener of commands) listener({ id });
    },
    close() {
      subscription.unsubscribe();
      manager.dispose();
      input.complete();
      assert.equal(commands.size, 0);
      assert.equal(timers.count(), 0);
    },
  };
}

function apply(snapshot: IDocumentData, actions: JSONXActions) {
  const model = new core.DocumentDataModel(structuredClone(snapshot));
  try {
    model.apply(structuredClone(actions));
    return structuredClone(model.getSnapshot());
  } finally {
    model.dispose();
  }
}

function errorRecord(error: unknown) {
  return error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : { message: String(error) };
}
let activeMeasurementName = 'not-started';
function flush(source: string, history: State[], collaboration = history) {
  const fixture = managerFixture(source);
  // Cache arrays are injected through the public API. For 20/32 cases, history
  // is a slice of captured native states, not a naturally cleared live cache.
  const cache = structuredClone({ history: [...history], collaboration: [...collaboration] });
  const retainedStates = [...cache.history, ...cache.collaboration];
  const before = structuredClone(retainedStates);
  let failure: ReturnType<typeof errorRecord> | null = null;
  try {
    fixture.manager.setStateCache(unitId, cache);
    fixture.manager.flushPendingChanges(unitId);
  } catch (error) {
    failure = errorRecord(error);
  }
  // Observe before cleanup. No preservation/empty-cache assertion runs here:
  // caller persists these fields and counts first, then rejects any mismatch.
  const output = {
    history: structuredClone(fixture.history),
    changes: structuredClone(fixture.changes),
    publication: structuredClone(fixture.publication),
    observations: {
      pending: structuredClone(fixture.manager.getStateCache(unitId)),
      retainedStates: structuredClone(retainedStates),
      before,
      failure,
      cleanupFailure: null as ReturnType<typeof errorRecord> | null,
    },
  };
  try {
    fixture.close();
  } catch (error) {
    output.observations.cleanupFailure = errorRecord(error);
  }
  return output;
}

function measuredFlush(source: string, states: State[], collaboration = states) {
  const counts = { textCompose: 0, iteratorNext: 0, bodySlices: 0, cloneVisits: 0, allocations: 0 };
  const compose = core.TextX.compose;
  const next = core.ActionIterator.prototype.next;
  const clone = core.Tools.deepClone;
  core.TextX.compose = function (this: typeof core.TextX, ...args: Parameters<typeof compose>) {
    counts.textCompose++;
    return Reflect.apply(compose, this, args);
  };
  core.ActionIterator.prototype.next = function (
    this: core.ActionIterator,
    ...args: Parameters<typeof next>
  ) {
    counts.iteratorNext++;
    const action = Reflect.apply(next, this, args) as ReturnType<typeof next>;
    if (
      action.t === core.TextXActionType.INSERT ||
      (action.t === core.TextXActionType.RETAIN && action.body != null)
    )
      counts.bodySlices++;
    return action;
  };
  core.Tools.deepClone = function <T>(this: typeof core.Tools, value: T): T {
    counts.cloneVisits++;
    if (
      this.isDefine(value) &&
      (this.isRegExp(value) ||
        Reflect.apply(this.isDate, this, [value]) ||
        this.isArray(value) ||
        this.isObject(value))
    )
      counts.allocations++;
    return Reflect.apply(clone, this, [value]) as T;
  };
  try {
    return { output: flush(source, states, collaboration), counts };
  } catch (error) {
    saveFull(`results/${activeMeasurementName}.measurement-exception.v8`, {
      states, collaboration, sourceSha256: sha256(source), counts, error: errorRecord(error),
    });
    throw error;
  } finally {
    core.TextX.compose = compose;
    core.ActionIterator.prototype.next = next;
    core.Tools.deepClone = clone;
  }
}


type Capture = {
  history: State[];
  collaboration: State[];
  snapshots: IDocumentData[];
  emitted: IDocStateChangeInfo[];
  beforeMutations: unknown[];
  authoredCommands: unknown[];
};
function insertBody(state: State) {
  const actions = state.redoState.actions as any[];
  assert.equal(actions[0], 'body');
  assert.equal(actions[1].et, 'text-x');
  const inserts = actions[1].e.filter((action: any) => action.t === 'i');
  assert.equal(inserts.length, 1);
  return inserts[0].body as Record<string, any>;
}
function point(at: number) {
  return { startOffset: at, endOffset: at, collapsed: true, segmentId: '' };
}
async function captureActualNativeCommands(enterAt: number | null): Promise<Capture> {
  const emitted: IDocStateChangeInfo[] = [];
  const beforeMutations: unknown[] = [];
  const authoredCommands: unknown[] = [];
  const snapshots: IDocumentData[] = [];
  let session: ReturnType<typeof nativeSession> | undefined;
  let manager: DocStateChangeManagerService | undefined;
  let before: { dispose(): void } | undefined;
  let observe: { unsubscribe(): void } | undefined;
  // Install a consistent clock before session/client setup can create timers.
  // Dispose all native owners while that same fake clock is still installed.
  vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] });
  try {
    const initial = core.getDocsEmptySnapshot(unitId, core.LocaleType.EN_US, 'Marker proof', core.DocumentFlavor.MODERN);
    initial.body = {
      dataStream: '\r\n',
      paragraphs: [{ startIndex: 0, paragraphId: 'para_marker_seed' }],
      sectionBreaks: [{ startIndex: 1, sectionId: 'section_marker_seed' }],
    };
    // nativeSession creates NativeReplica and createNativeSyncClient; that real
    // client installs captureNative before our observation hook is registered.
    session = nativeSession(initial, 'doc');
    const writer = session.client('owner');
    assert.ok(writer.live instanceof NativeReplica);
    const injector = writer.live.univer.__getInjector();
    manager = injector.get(DocStateChangeManagerService);
    const selections = injector.get(DocSelectionManagerService);
    observe = injector.get(DocStateEmitService).docStateChangeParams$.subscribe((state) => {
      if (state) emitted.push(structuredClone(state));
    });
    before = writer.commands.beforeCommandExecuted((command) => {
      if (command.id === 'doc.mutation.rich-text-editing')
        beforeMutations.push(structuredClone(command.params));
    });
    selections.replaceSelectionInfoWithoutRefresh({
      textRanges: [{ ...point(0), isActive: true }], rectRanges: [], segmentId: '',
      segmentPage: 0, isEditing: true, style: NORMAL_TEXT_SELECTION_PLUGIN_STYLE,
    }, { unitId, subUnitId: unitId });
    snapshots.push(structuredClone(writer.live.snapshot() as IDocumentData));
    for (let index = 0; index < 32; index++) {
      const body = index === enterAt
        ? { dataStream: '\r', paragraphs: [{ startIndex: 0 }] }
        : {
            dataStream: String.fromCharCode(97 + index % 26),
            textRuns: [{ st: 0, ed: 1, ts: { bl: index % 2 === 0 ? 1 : 0, cl: { rgb: '#123456' } } }],
            customRanges: [], customDecorations: [],
          };
      const command = {
        unitId, segmentId: '', range: point(index), body,
        textRanges: [point(index + 1)], debounce: true,
      };
      authoredCommands.push(structuredClone(command));
      assert.equal(await writer.commands.executeCommand('doc.command.insert-text', command), true);
      snapshots.push(structuredClone(writer.live.snapshot() as IDocumentData));
    }
    const cache = structuredClone(manager.getStateCache(unitId));
    assert.equal(cache.history.length, 32);
    assert.equal(cache.collaboration.length, 32);
    assert.equal(emitted.length, 32);
    assert.equal(beforeMutations.length, 32);
    assert.deepEqual(writer.failures, []);
    for (const state of [...cache.history, ...cache.collaboration]) {
      const body = insertBody(state);
      assert.equal(Object.hasOwn(body, marker), true, 'Actual captured insert owns the synchronization marker.');
      assert.equal(body[marker], true);
    }
    for (const params of beforeMutations as any[])
      for (const action of params.actions[1].e.filter((entry: any) => entry.t === 'i')) {
        assert.equal(Object.hasOwn(action.body, marker), true);
        assert.equal(action.body[marker], true);
      }
    return { ...cache, snapshots, emitted, beforeMutations, authoredCommands };
  } catch (error) {
    saveFull(`results/native-capture-${enterAt === null ? 'plain' : 'enter'}-failure.v8`, {
      snapshots, emitted, beforeMutations, authoredCommands,
      cache: manager ? structuredClone(manager.getStateCache(unitId)) : null,
      error: errorRecord(error),
    });
    throw error;
  } finally {
    const failures: ReturnType<typeof errorRecord>[] = [];
    for (const cleanup of [() => before?.dispose(), () => observe?.unsubscribe(), () => session?.close()]) {
      try { cleanup(); } catch (error) { failures.push(errorRecord(error)); }
    }
    vi.useRealTimers();
    if (failures.length) {
      saveFull(`results/native-capture-${enterAt === null ? 'plain' : 'enter'}-cleanup-failure.v8`, failures);
      throw new Error('Native capture cleanup failed; exact failures retained.');
    }
  }
}

type Mode = 'marked' | 'absent' | 'mixed' | 'undefined-metadata' | 'invalid-marker' | 'enter' | 'unknown-key';
type Row = {
  id: string; mode: Mode; length: number; historyStart: number;
  currentEligible: boolean; proposedEligible: boolean; expectation: 'newly-eligible' | 'already-eligible' | 'fallback';
  invalid?: unknown;
};
// Frozen before execution. No randomized inputs, alternative candidates, retry,
// larger workload, or automatic adjustment after a failure.
const matrix: readonly Row[] = Object.freeze([
  { id: 'actual-marked-32-mirrored', mode: 'marked', length: 32, historyStart: 0, currentEligible: false, proposedEligible: true, expectation: 'newly-eligible' },
  { id: 'actual-marked-32-injected20of32', mode: 'marked', length: 32, historyStart: 12, currentEligible: false, proposedEligible: true, expectation: 'newly-eligible' },
  { id: 'actual-marked-31-odd', mode: 'marked', length: 31, historyStart: 0, currentEligible: false, proposedEligible: true, expectation: 'newly-eligible' },
  { id: 'marker-absent-32', mode: 'absent', length: 32, historyStart: 0, currentEligible: true, proposedEligible: true, expectation: 'already-eligible' },
  { id: 'mixed-marker-32', mode: 'mixed', length: 32, historyStart: 0, currentEligible: false, proposedEligible: true, expectation: 'newly-eligible' },
  { id: 'mixed-marker-32-injected20of32', mode: 'mixed', length: 32, historyStart: 12, currentEligible: false, proposedEligible: true, expectation: 'newly-eligible' },
  { id: 'mixed-marker-7-odd', mode: 'mixed', length: 7, historyStart: 0, currentEligible: false, proposedEligible: true, expectation: 'newly-eligible' },
  { id: 'known-own-undefined-metadata', mode: 'undefined-metadata', length: 32, historyStart: 0, currentEligible: false, proposedEligible: true, expectation: 'newly-eligible' },
  { id: 'own-marker-undefined', mode: 'invalid-marker', invalid: undefined, length: 32, historyStart: 0, currentEligible: false, proposedEligible: false, expectation: 'fallback' },
  { id: 'own-marker-false', mode: 'invalid-marker', invalid: false, length: 32, historyStart: 0, currentEligible: false, proposedEligible: false, expectation: 'fallback' },
  { id: 'own-marker-zero', mode: 'invalid-marker', invalid: 0, length: 32, historyStart: 0, currentEligible: false, proposedEligible: false, expectation: 'fallback' },
  { id: 'own-marker-one', mode: 'invalid-marker', invalid: 1, length: 32, historyStart: 0, currentEligible: false, proposedEligible: false, expectation: 'fallback' },
  { id: 'own-marker-null', mode: 'invalid-marker', invalid: null, length: 32, historyStart: 0, currentEligible: false, proposedEligible: false, expectation: 'fallback' },
  { id: 'own-marker-string', mode: 'invalid-marker', invalid: 'true', length: 32, historyStart: 0, currentEligible: false, proposedEligible: false, expectation: 'fallback' },
  { id: 'unknown-body-key', mode: 'unknown-key', length: 32, historyStart: 0, currentEligible: false, proposedEligible: false, expectation: 'fallback' },
  { id: 'actual-enter-fallback', mode: 'enter', length: 32, historyStart: 0, currentEligible: false, proposedEligible: false, expectation: 'fallback' },
].map((row) => Object.freeze(row as Row)));

function scenario(capture: Capture, row: Row) {
  // These explicitly labeled input variants test marker absence/mixing/invalid
  // own values. Inputs are fixed before any manager runs. No output is stripped
  // or normalized, and actual marked native cases are never modified.
  const data = structuredClone(capture);
  for (const states of [data.history, data.collaboration]) {
    for (const [index, state] of states.entries()) {
      const body = insertBody(state);
      if (row.mode === 'absent' || (row.mode === 'mixed' && index % 2 === 1)) delete body[marker];
      if (row.mode === 'invalid-marker' && index === 13) body[marker] = row.invalid;
      if (row.mode === 'unknown-key' && index === 13) body.unrecognizedMarkerProofField = true;
      if (row.mode === 'undefined-metadata') {
        body.paragraphs = undefined;
        body.customBlocks = [];
        body.sectionBreaks = undefined;
        body.textRuns[0].sId = undefined;
      }
    }
  }
  return {
    history: data.history.slice(row.historyStart, row.length),
    collaboration: data.collaboration.slice(0, row.length),
    snapshots: data.snapshots.slice(0, row.length + 1),
    historyStart: row.historyStart,
    cacheConstruction: row.historyStart === 0
      ? 'Captured native states injected via public setStateCache.'
      : 'History slice [12,32) of captured native states and collaboration [0,32) injected via public setStateCache; no natural clearHistory event is claimed.',
  };
}
function eligibility(source: string) {
  const start = source.indexOf('function hasOnlyDocInsertKeys(');
  const end = source.indexOf('function composeDocStateActions(', start);
  assert.ok(start > 0 && end > start);
  return runInNewContext(`${source.slice(start, end)}\ncanBalanceDocInserts;`, {}, { timeout: 1000 }) as
    (states: State[], key: 'redoState' | 'undoState') => boolean;
}
function appliedPublications(output: ReturnType<typeof flush>, input: ReturnType<typeof scenario>) {
  const final = input.snapshots.at(-1)!;
  assert.equal(output.history.length, 1);
  assert.equal(output.changes.length, 1);
  const history = output.history[0], change = output.changes[0];
  assert.equal(history.redoMutations.length, 1);
  assert.equal(history.undoMutations.length, 1);
  return {
    history: {
      redo: apply(input.snapshots[input.historyStart], history.redoMutations[0].params.actions),
      undo: apply(final, history.undoMutations[0].params.actions),
    },
    collaboration: {
      redo: apply(input.snapshots[0], change.redoState.actions),
      undo: apply(final, change.undoState.actions),
    },
  };
}

const primitiveKeys = ['iteratorNext', 'bodySlices', 'cloneVisits', 'allocations'] as const;
const sourceFiles = [
  'scripts/dependencies/patch-univer-docs.ts', 'scripts/dependencies/patch-univer-docs.test.ts',
  'lib/sync-client/src/capture.ts', 'lib/sync-client/src/native.ts',
  'lib/sync-client/tests/native-session.ts', 'lib/sync-client/tests/fixture.ts',
  'src/ui/docHistorySync.test.ts', 'src/ui/boundedDocHistory.ts',
];

test('one frozen exact native-marker qualification proof in ES and CJS', async () => {
  mkdirSync(resolve(outputRoot, 'results'), { recursive: true });
  assert.equal(core.PRESERVE_INSERTED_PARAGRAPH_IDS, marker);
  const replacement = JSON.parse(readFileSync(resolve(outputRoot, 'candidate-replacement.json'), 'utf8'));
  const sourceHashes = Object.fromEntries(sourceFiles.map((path) => [path, sha256(readFileSync(resolve(repoRoot, path)))]));
  const results: unknown[] = [];
  let currentCase = 'capture actual native groups';
  saveJson('execution-start.json', { at: new Date().toISOString(), runtime: process.version, sourceHashes, matrix, executed: true });
  try {
    const native = await captureActualNativeCommands(null);
    const enter = await captureActualNativeCommands(15);
    saveJson('capture-files.json', {
      native: saveFull('results/native-32-input.v8', native),
      enter: saveFull('results/native-enter-32-input.v8', enter),
    });
    // Execute both manager source regions against the same imported core.
    // This is not two fully booted independent ES/CJS native runtimes.
    for (const format of ['es', 'cjs'] as const) {
      const installed = readFileSync(resolve(repoRoot, `node_modules/@univerjs/docs/lib/${format}/index.js`), 'utf8');
      const prepared = prepareDocsPatch(installed, format); // pure hash-verified source preparation
      const current = prepared.patched;
      assert.equal(installed, current, 'The installed SDK must remain the exact reviewed current patch.');
      assert.equal(current.split(replacement.before).length, 2);
      const proposed = current.replace(replacement.before, replacement.after);
      const sources = { original: prepared.original, current, proposed };
      for (const [kind, source] of Object.entries(sources)) {
        assert.equal(source, readFileSync(resolve(outputRoot, `prepared-sources/${format}.${kind}.ts`), 'utf8'));
        assert.equal(sha256(source), replacement.sourceHashes[`${format}.${kind}`]);
      }
      const currentEligible = eligibility(current), proposedEligible = eligibility(proposed);
      // This shadow is ONLY a discriminator. It is never sent to any compared
      // manager, never substitutes for a marked input, and never alters outputs.
      const shadow = structuredClone(native.history);
      for (const state of shadow) delete insertBody(state)[marker];
      assert.equal(currentEligible(native.history, 'redoState'), false);
      assert.equal(currentEligible(shadow, 'redoState'), true);
      assert.equal(proposedEligible(native.history, 'redoState'), true);
      saveFull(`results/${format}.marker-only-discriminator.v8`, { marked: native.history, shadow, currentMarked: false, currentShadow: true, proposedMarked: true });
      // Keep the real owned true marker in every C0/DEL/rich/style probe, so
      // proposed eligibility must reject the combined marked unsupported shape.
      // All C0/DEL controls and unsupported metadata stay ineligible. These
      // deliberately incomplete control bodies are guard probes only; no claim
      // is made that an unpaired structural token is a valid whole document.
      const guardCases: { id: string; states: State[] }[] = [];
      for (const code of [...Array.from({ length: 32 }, (_, index) => index), 127]) {
        const states = structuredClone(native.history);
        insertBody(states[13]).dataStream = String.fromCharCode(code);
        guardCases.push({ id: `control-${code}`, states });
      }
      for (const field of ['paragraphs', 'customRanges', 'customDecorations', 'customBlocks', 'sectionBreaks']) {
        const states = structuredClone(native.history);
        insertBody(states[13])[field] = [{}];
        guardCases.push({ id: `nonempty-${field}`, states });
      }
      const sid = structuredClone(native.history);
      insertBody(sid[13]).textRuns[0].sId = 'defined-style-id';
      guardCases.push({ id: 'defined-style-id', states: sid });
      saveFull(`results/${format}.guard-inputs.v8`, guardCases);
      for (const probe of guardCases) {
        currentCase = `${format}/${probe.id}`;
        for (const state of probe.states) {
          assert.equal(Object.hasOwn(insertBody(state), marker), true, currentCase);
          assert.equal(insertBody(state)[marker], true, currentCase);
        }
        assert.equal(currentEligible(probe.states, 'redoState'), false, currentCase);
        assert.equal(proposedEligible(probe.states, 'redoState'), false, currentCase);
      }
      for (const row of matrix) {
        currentCase = `${format}/${row.id}`;
        const input = scenario(row.mode === 'enter' ? enter : native, row);
        const before = structuredClone(input);
        const allInputsFile = saveFull(`results/${format}.${row.id}.input.v8`, input);
        for (const states of [input.history, input.collaboration]) {
          assert.equal(currentEligible(states, 'redoState'), row.currentEligible, currentCase);
          assert.equal(proposedEligible(states, 'redoState'), row.proposedEligible, currentCase);
        }
        const measured: Record<string, ReturnType<typeof measuredFlush>> = {};
        const applied: Record<string, ReturnType<typeof appliedPublications>> = {};
        for (const [kind, source] of Object.entries(sources)) {
          activeMeasurementName = `${format}.${row.id}.${kind}`;
          measured[kind] = measuredFlush(source, input.history, input.collaboration);
          // Persist available publications/pending state/retained inputs/counts
          // BEFORE assertions or application. Failure cannot erase observations.
          const outputFile = saveFull(`results/${activeMeasurementName}.output.v8`, { input, measured: measured[kind] });
          saveJson(`results/${activeMeasurementName}.counts.json`, { counts: measured[kind].counts, outputFile });
          const observations = measured[kind].output.observations;
          assert.equal(observations.failure, null, `${currentCase}/${kind}: native flush threw.`);
          assert.equal(observations.cleanupFailure, null, `${currentCase}/${kind}: native cleanup failed.`);
          assert.deepEqual(observations.retainedStates, observations.before, `${currentCase}/${kind}: native state objects changed.`);
          assert.deepEqual(observations.pending, { history: [], collaboration: [] }, `${currentCase}/${kind}: caches not empty.`);
          applied[kind] = appliedPublications(measured[kind].output, input);
          saveFull(`results/${format}.${row.id}.${kind}.applied.v8`, { input, applied: applied[kind] });
          assert.deepEqual(input, before, `${currentCase}/${kind}: source inputs changed.`);
        }
        saveJson(`results/${format}.${row.id}.counts.json`, {
          row, inputs: allInputsFile,
          sourceHashes: Object.fromEntries(Object.entries(sources).map(([key, value]) => [key, sha256(value)])),
          counts: Object.fromEntries(Object.entries(measured).map(([key, value]) => [key, value.counts])),
        });
        for (const kind of ['current', 'proposed']) {
          assert.deepEqual(measured[kind].output, measured.original.output, `${currentCase}/${kind}: complete publications differ.`);
          assert.deepEqual(applied[kind], applied.original, `${currentCase}/${kind}: complete applied snapshots differ.`);
        }
        if (row.mode === 'marked' || row.mode === 'enter') {
          assert.deepEqual(applied.original.history.redo, input.snapshots.at(-1), `${currentCase}: actual native history forward result.`);
          assert.deepEqual(applied.original.collaboration.redo, input.snapshots.at(-1), `${currentCase}: actual native collaboration forward result.`);
        }
        const expectedCalls = 2 * (input.history.length + input.collaboration.length - 2);
        for (const kind of ['original', 'current', 'proposed'])
          assert.equal(measured[kind].counts.textCompose, expectedCalls, `${currentCase}/${kind}: actual TextX compose calls.`);
        if (row.expectation === 'fallback') {
          assert.deepEqual(measured.current.counts, measured.original.counts, `${currentCase}: current fallback work.`);
          assert.deepEqual(measured.proposed.counts, measured.original.counts, `${currentCase}: candidate fallback work.`);
        } else {
          const comparison = row.expectation === 'already-eligible' ? measured.original : measured.current;
          for (const key of primitiveKeys)
            assert.ok(measured.proposed.counts[key] < comparison.counts[key], `${currentCase}: ${key} did not decrease.`);
          if (row.expectation === 'newly-eligible') assert.deepEqual(measured.current.counts, measured.original.counts);
          else assert.deepEqual(measured.proposed.counts, measured.current.counts);
        }
        const record = {
          case: currentCase, passed: true, counts: Object.fromEntries(Object.entries(measured).map(([key, value]) => [key, value.counts])),
          inputs: allInputsFile, cacheConstruction: input.cacheConstruction, exactPublications: true, exactAppliedSnapshots: true, inputsUnchanged: true,
        };
        results.push(record);
        console.log(JSON.stringify(record));
      }
      assert.equal(readFileSync(resolve(repoRoot, `node_modules/@univerjs/docs/lib/${format}/index.js`), 'utf8'), installed);
    }
    saveJson('result.json', { status: 'passed', cases: results.length, results, sourceHashes, at: new Date().toISOString(), limitations: ['20/32 caches use an injected suffix of actual captured states; no natural clearHistory divergence is claimed.', 'Both manager source regions execute against the same imported core; these are not independent fully booted ES/CJS runtimes.', 'No browser latency claim or causal attribution.', 'No production source or installed SDK mutation.', '70-input owner/peer receipt/reopen/full-undo integration remains a separate permanent regression.'] });
  } catch (error) {
    saveJson('result.json', { status: 'failed', currentCase, completedCases: results.length, results, sourceHashes, error: error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : String(error), at: new Date().toISOString(), disposition: 'Stop. Retain this attempt. No alternate candidate, rerun, normalization, budget relaxation, or expanded workload.' });
    throw error;
  } finally {
    vi.useRealTimers(); vi.restoreAllMocks();
  }
}, 165_000);
