const DEBOUNCE_DELAY = 300;
// Modified for Spinel: only plain single-character insert groups have the
// qualified native action shape. Mixed composition can change own undefined
// body fields, so an ineligible state keeps the entire original cache fold.
function hasOnlyDocInsertKeys(value, keys) {
	return value != null && typeof value === "object" && Reflect.ownKeys(value).every((key) => keys.includes(key));
}
function canBalanceDocInserts(states, key) {
	if (states.length < 2) return false;
	let previousOffset;
	let append = true;
	let prepend = true;
	for (const state of states) {
		const actions = state[key].actions;
		if (!Array.isArray(actions) || actions.length !== 2 || !hasOnlyDocInsertKeys(actions, ["0", "1", "length"]) || actions[0] !== "body") return false;
		const component = actions[1];
		if (!hasOnlyDocInsertKeys(component, ["et", "e"]) || !Object.hasOwn(component, "et") || !Object.hasOwn(component, "e") || component.et !== "text-x") return false;
		const edits = component.e;
		if (!Array.isArray(edits) || edits.length < 1 || edits.length > 2 || !hasOnlyDocInsertKeys(edits, ["0", "1", "length"])) return false;
		let offset = 0;
		if (edits.length === 2) {
			const retain = edits[0];
			if (!hasOnlyDocInsertKeys(retain, ["t", "len"]) || !Object.hasOwn(retain, "t") || !Object.hasOwn(retain, "len") || retain.t !== "r" || !Number.isSafeInteger(retain.len) || retain.len <= 0) return false;
			offset = retain.len;
		}
		const insert = edits[edits.length - 1];
		if (!hasOnlyDocInsertKeys(insert, ["t", "len", "body", "valueRangeId"]) || !Object.hasOwn(insert, "t") || !Object.hasOwn(insert, "len") || !Object.hasOwn(insert, "body") || insert.t !== "i" || insert.len !== 1 || insert.valueRangeId !== void 0) return false;
		const body = insert.body;
		if (!hasOnlyDocInsertKeys(body, ["dataStream", "textRuns", "paragraphs", "customRanges", "customDecorations", "customBlocks", "sectionBreaks", "__textXPreserveParagraphIds"]) || !Object.hasOwn(body, "dataStream") || typeof body.dataStream !== "string" || body.dataStream.length !== 1) return false;
		if (Object.hasOwn(body, "__textXPreserveParagraphIds") && body["__textXPreserveParagraphIds"] !== true) return false;
		// The SDK's structural tokens are C0 controls. Keep all C0/DEL on the native path.
		const code = body.dataStream.charCodeAt(0);
		if (code < 32 || code === 127) return false;
		for (const field of ["paragraphs", "customRanges", "customDecorations", "customBlocks", "sectionBreaks"]) {
			const value = body[field];
			if (value !== void 0 && (!Array.isArray(value) || value.length !== 0 || !hasOnlyDocInsertKeys(value, ["length"]))) return false;
		}
		const runs = body.textRuns;
		if (runs !== void 0) {
			if (!Array.isArray(runs) || runs.length > 1 || !hasOnlyDocInsertKeys(runs, ["0", "length"])) return false;
			if (runs.length === 1) {
				const run = runs[0];
				if (!hasOnlyDocInsertKeys(run, ["st", "ed", "ts", "sId"]) || !Object.hasOwn(run, "st") || !Object.hasOwn(run, "ed") || run.st !== 0 || run.ed !== 1 || run.sId !== void 0 || (run.ts !== void 0 && (run.ts === null || typeof run.ts !== "object" || Array.isArray(run.ts)))) return false;
			}
		}
		if (previousOffset !== void 0) {
			append = append && offset === previousOffset + 1;
			prepend = prepend && offset === previousOffset;
			if (!append && !prepend) return false;
		}
		previousOffset = offset;
	}
	return true;
}
function composeDocStateActions(states, key) {
	if (!canBalanceDocInserts(states, key)) return states.reduce((acc, state) => _univerjs_core.JSONX.compose(acc, state[key].actions), null);
	function composeRange(start, end) {
		const length = end - start;
		if (length === 1) return states[start][key].actions;
		const middle = start + Math.floor(length / 2);
		return _univerjs_core.JSONX.compose(composeRange(start, middle), composeRange(middle, end));
	}
	return composeRange(0, states.length);
}