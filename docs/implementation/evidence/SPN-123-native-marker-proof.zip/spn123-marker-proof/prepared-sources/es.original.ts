import { AlignTypeH, BooleanNumber, BuildTextUtils, ColumnSeparatorType, CommandType, CustomCommandExecutionError, CustomRangeType, DEFAULT_STYLES, DOCS_FORMULA_BAR_EDITOR_UNIT_ID_KEY, DOCS_NORMAL_EDITOR_UNIT_ID_KEY, DataStreamTreeTokenType, DeleteDirection, DependentOn, Disposable, DisposableCollection, DocumentDataModel, DocumentFlavor, DocxBreakType, DrawingTypeEnum, ErrorService, ICommandService, IConfigService, ILogService, IPermissionService, IResourceManagerService, IUndoRedoService, IUniverInstanceService, Inject, Injector, JSON1, JSONX, LocaleService, MODERN_DOCUMENT_DEFAULT_MARGIN, MODERN_DOCUMENT_WIDTH, MemoryCursor, ModernDocumentWidthMode, ObjectPermissionRuleModel, ObjectPermissionService, ObjectRelativeFromH, ObjectRelativeFromV, Optional, PAGE_SIZE, PageOrientType, PaperType, PermissionStatus, Plugin, PositionedObjectLayoutType, RESTORE_INSERTED_PARAGRAPH_IDS, RedoCommandId, RxDisposable, SHEET_TEXT_LINE_GAP, SectionType, TRADITIONAL_DOCUMENT_DEFAULT_MARGIN, TextX, TextXActionType, Tools, UndoCommandId, UniverInstanceType, UpdateDocsAttributeType, composeInterceptors, containsInteriorInsertionOffset, createIdentifier, createInterceptorKey, createParagraphId, createSectionId, generateRandomId, getBlockRangeInterval, getColumnGroupRangeInterval, getParagraphContentStartOffset, getParagraphContentStartOffsets, getRichTextEditPath, getSdtBindingKey, getSdtBindingValue, getSectionHeaderFooterReferenceKey, getTableRangeInterval, isInternalEditorID, merge, remove, requestImmediateMacroTask, resolveSectionHeaderFooterReference, toDisposable, validateDocBodyStructure, validateDocumentStructure } from "@univerjs/core";
import { DocumentLayoutSession, DocumentSkeleton, DocumentViewModel, FontCache, IRenderManagerService, NORMAL_TEXT_SELECTION_PLUGIN_STYLE, getDocsCustomBlockRenderViewport, getDocumentLayoutPresentation, getFontStyleString, setDocsCustomBlockRenderViewportProvider } from "@univerjs/engine-render";
import { BehaviorSubject, Observable, Subject, shareReplay, takeUntil } from "rxjs";
import { UnitAction, UnitObject } from "@univerjs/protocol";
import { ChannelService, fromModule, toModule } from "@univerjs/rpc";

//#region src/commands/operations/text-selection.operation.ts
const SetTextSelectionsOperation = {
	id: "doc.operation.set-selections",
	type: CommandType.OPERATION,
	handler: () => {
		return true;
	}
};

//#endregion
//#region \0@oxc-project+runtime@0.153.0/helpers/esm/typeof.js
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof(o);
}

//#endregion
//#region \0@oxc-project+runtime@0.153.0/helpers/esm/toPrimitive.js
function toPrimitive(t, r) {
	if ("object" != _typeof(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}

//#endregion
//#region \0@oxc-project+runtime@0.153.0/helpers/esm/toPropertyKey.js
function toPropertyKey(t) {
	var i = toPrimitive(t, "string");
	return "symbol" == _typeof(i) ? i : i + "";
}

//#endregion
//#region \0@oxc-project+runtime@0.153.0/helpers/esm/defineProperty.js
function _defineProperty(e, r, t) {
	return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}

//#endregion
//#region \0@oxc-project+runtime@0.153.0/helpers/esm/decorateParam.js
function __decorateParam(paramIndex, decorator) {
	return function(target, key) {
		decorator(target, key, paramIndex);
	};
}

//#endregion
//#region \0@oxc-project+runtime@0.153.0/helpers/esm/decorate.js
function __decorate(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
}

//#endregion
//#region src/services/doc-selection-manager.service.ts
/**
* Keeps a programmatically restored collapsed caret from being promoted back
* into a neighboring whole-entity selection by feature-specific UI.
*/
const DOC_SELECTION_OPTION_PRESERVE_CARET = "preserveCaret";
let DocSelectionManagerService = class DocSelectionManagerService extends RxDisposable {
	constructor(_commandService, _univerInstanceService) {
		super();
		this._commandService = _commandService;
		this._univerInstanceService = _univerInstanceService;
		_defineProperty(this, "_currentSelection", null);
		_defineProperty(this, "_textSelectionInfo", /* @__PURE__ */ new Map());
		_defineProperty(this, "_textSelection$", new Subject());
		_defineProperty(this, "textSelection$", this._textSelection$.asObservable());
		_defineProperty(this, "_refreshSelection$", new BehaviorSubject(null));
		_defineProperty(this, "refreshSelection$", this._refreshSelection$.asObservable());
		this._listenCurrentUnit();
	}
	_listenCurrentUnit() {
		this._univerInstanceService.getCurrentTypeOfUnit$(UniverInstanceType.UNIVER_DOC).pipe(takeUntil(this.dispose$)).subscribe((documentModel) => {
			if (documentModel == null) return;
			const unitId = documentModel.getUnitId();
			this._setCurrentSelectionNotRefresh({
				unitId,
				subUnitId: unitId
			});
		});
	}
	__getCurrentSelection() {
		return this._currentSelection;
	}
	getSelectionInfo(params = this._currentSelection) {
		return this._getTextRanges(params);
	}
	refreshSelection(params = this._currentSelection, isEditing = false) {
		if (params == null) return;
		this._refresh(params, isEditing);
	}
	__TEST_ONLY_setCurrentSelection(param) {
		this._currentSelection = param;
		this._refresh(param);
	}
	getTextRanges(params = this._currentSelection) {
		var _this$_getTextRanges;
		return (_this$_getTextRanges = this._getTextRanges(params)) === null || _this$_getTextRanges === void 0 ? void 0 : _this$_getTextRanges.textRanges;
	}
	getRectRanges(params = this._currentSelection) {
		var _this$_getTextRanges2;
		return (_this$_getTextRanges2 = this._getTextRanges(params)) === null || _this$_getTextRanges2 === void 0 ? void 0 : _this$_getTextRanges2.rectRanges;
	}
	getDocRanges(params = this._currentSelection) {
		const textRanges = this.getTextRanges(params) ?? [];
		const rectRanges = this.getRectRanges(params) ?? [];
		return [...textRanges, ...rectRanges].filter((range) => range.startOffset != null && range.endOffset != null).sort((a, b) => {
			if (a.startOffset > b.startOffset) return 1;
			else if (a.startOffset < b.startOffset) return -1;
			else return 0;
		});
	}
	getActiveTextRange() {
		const selectionInfo = this._getTextRanges(this._currentSelection);
		if (selectionInfo == null) return;
		const { textRanges } = selectionInfo;
		return textRanges.find((textRange) => textRange.isActive);
	}
	__TEST_ONLY_add(textRanges, isEditing = true) {
		if (this._currentSelection == null) return;
		this._addByParam({
			...this._currentSelection,
			textRanges,
			rectRanges: [],
			segmentId: "",
			segmentPage: -1,
			isEditing,
			style: NORMAL_TEXT_SELECTION_PLUGIN_STYLE
		});
	}
	replaceDocRanges(docRanges, params = this._currentSelection, isEditing = true, options) {
		if (params == null) return;
		const { unitId, subUnitId } = params;
		this._refreshSelection$.next({
			unitId,
			subUnitId,
			docRanges,
			isEditing,
			options: {
				...options,
				preserveInputStyle: false
			}
		});
	}
	/**
	* Replaces logical selection state without rebuilding render ranges. Atomic
	* external mutations use this before applying document actions so layout can
	* follow transformed offsets, then refresh after new geometry is available.
	*/
	replaceSelectionInfoWithoutRefresh(selectionInfo, params = this._currentSelection) {
		if (params == null) return;
		this._replaceByParam({
			...selectionInfo,
			...params
		});
	}
	__replaceTextRangesWithNoRefresh(textSelectionInfo, search) {
		const params = {
			...textSelectionInfo,
			...search
		};
		this._replaceByParam({
			...params,
			options: {
				...params.options,
				preserveInputStyle: true
			}
		});
		this._textSelection$.next(params);
		const { unitId, subUnitId, segmentId, style, textRanges, rectRanges, isEditing } = params;
		const ranges = [...textRanges, ...rectRanges].filter((range) => range.startOffset != null && range.endOffset != null).sort((a, b) => {
			if (a.startOffset > b.startOffset) return 1;
			else if (a.startOffset < b.startOffset) return -1;
			else return 0;
		});
		this._commandService.executeCommand(SetTextSelectionsOperation.id, {
			unitId,
			subUnitId,
			segmentId,
			style,
			isEditing,
			ranges
		});
	}
	dispose() {
		this._textSelection$.complete();
		this._refreshSelection$.complete();
	}
	_setCurrentSelectionNotRefresh(param) {
		this._currentSelection = param;
	}
	_getTextRanges(param) {
		var _this$_textSelectionI;
		if (param == null) return;
		const { unitId, subUnitId = "" } = param;
		return (_this$_textSelectionI = this._textSelectionInfo.get(unitId)) === null || _this$_textSelectionI === void 0 ? void 0 : _this$_textSelectionI.get(subUnitId);
	}
	_refresh(param, isEditing = false) {
		const allTextSelectionInfo = this._getTextRanges(param);
		if (allTextSelectionInfo == null) return;
		const { textRanges, rectRanges, options } = allTextSelectionInfo;
		const docRanges = [...textRanges, ...rectRanges];
		const { unitId, subUnitId } = param;
		this._refreshSelection$.next({
			unitId,
			subUnitId,
			docRanges,
			isEditing,
			options: {
				...options,
				forceFocus: false,
				preserveInputStyle: (options === null || options === void 0 ? void 0 : options.preserveInputStyle) ?? true
			}
		});
	}
	_replaceByParam(insertParam) {
		const { unitId, subUnitId, ...selectionInsertParam } = insertParam;
		if (!this._textSelectionInfo.has(unitId)) this._textSelectionInfo.set(unitId, /* @__PURE__ */ new Map());
		this._textSelectionInfo.get(unitId).set(subUnitId, { ...selectionInsertParam });
	}
	_addByParam(insertParam) {
		const { unitId, subUnitId, ...selectionInsertParam } = insertParam;
		if (!this._textSelectionInfo.has(unitId)) this._textSelectionInfo.set(unitId, /* @__PURE__ */ new Map());
		const unitTextRange = this._textSelectionInfo.get(unitId);
		if (!unitTextRange.has(subUnitId)) unitTextRange.set(subUnitId, { ...selectionInsertParam });
		else unitTextRange.get(subUnitId).textRanges.push(...insertParam.textRanges);
	}
};
DocSelectionManagerService = __decorate([__decorateParam(0, ICommandService), __decorateParam(1, IUniverInstanceService)], DocSelectionManagerService);

//#endregion
//#region src/commands/mutations/core-editing.mutation-id.ts
/**
* Copyright 2023-present DreamNum Co., Ltd.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
const RICH_TEXT_EDITING_MUTATION_ID = "doc.mutation.rich-text-editing";

//#endregion
//#region src/services/document-layout-snapshot.ts
function projectCustomBlock(block) {
	const { docxRawXml: _docxRawXml, docxExportTs: _docxExportTs, ...layoutBlock } = block;
	return layoutBlock;
}
function projectDocumentBody(body) {
	const { docxRawCustomBlocks: _docxRawCustomBlocks, docxRawBlocks: _docxRawBlocks, docxExportExcludedRanges: _docxExportExcludedRanges, payloads: _payloads, customBlocks, ...layoutBody } = body;
	return {
		...layoutBody,
		...customBlocks == null ? {} : { customBlocks: customBlocks.map(projectCustomBlock) }
	};
}
function projectHeader(header) {
	return {
		...header,
		body: projectDocumentBody(header.body)
	};
}
function projectFooter(footer) {
	return {
		...footer,
		body: projectDocumentBody(footer.body)
	};
}
/**
* Builds the model snapshot owned by the layout Worker. Exchange-only payloads
* remain in the authoritative Main model and are deliberately excluded from
* the structured-clone boundary because they do not affect document geometry.
*/
function createDocumentLayoutSnapshot(snapshot) {
	const { resources: _resources, body, headers, footers, footnotes, endnotes, ...layoutSnapshot } = snapshot;
	return {
		...layoutSnapshot,
		...footnotes == null ? {} : { footnotes: Object.fromEntries(Object.entries(footnotes).map(([id, note]) => [id, {
			...note,
			body: projectDocumentBody(note.body)
		}])) },
		...endnotes == null ? {} : { endnotes: Object.fromEntries(Object.entries(endnotes).map(([id, note]) => [id, {
			...note,
			body: projectDocumentBody(note.body)
		}])) },
		...body == null ? {} : { body: projectDocumentBody(body) },
		...headers == null ? {} : { headers: Object.fromEntries(Object.entries(headers).map(([headerId, header]) => [headerId, projectHeader(header)])) },
		...footers == null ? {} : { footers: Object.fromEntries(Object.entries(footers).map(([footerId, footer]) => [footerId, projectFooter(footer)])) }
	};
}

//#endregion
//#region src/services/doc-layout-executor.service.ts
var _DocLayoutExecutorService;
let DocLayoutExecutorType = /* @__PURE__ */ function(DocLayoutExecutorType) {
	DocLayoutExecutorType["MAIN_THREAD"] = "main-thread";
	DocLayoutExecutorType["WORKER"] = "worker";
	return DocLayoutExecutorType;
}({});
let DocLayoutSessionStatus = /* @__PURE__ */ function(DocLayoutSessionStatus) {
	DocLayoutSessionStatus["ACCEPTED"] = "accepted";
	DocLayoutSessionStatus["NOT_FOUND"] = "not-found";
	DocLayoutSessionStatus["RESNAPSHOT_REQUIRED"] = "resnapshot-required";
	DocLayoutSessionStatus["SUPERSEDED"] = "superseded";
	return DocLayoutSessionStatus;
}({});
let DocLayoutExecutorState = /* @__PURE__ */ function(DocLayoutExecutorState) {
	DocLayoutExecutorState["UNREGISTERED"] = "unregistered";
	DocLayoutExecutorState["INITIALIZING"] = "initializing";
	DocLayoutExecutorState["ACTIVE"] = "active";
	DocLayoutExecutorState["RECOVERING"] = "recovering";
	DocLayoutExecutorState["FAILED"] = "failed";
	return DocLayoutExecutorState;
}({});
function areShallowRecordsEqual(left, right) {
	const leftRecord = left;
	const rightRecord = right;
	const leftKeys = Object.keys(leftRecord);
	const rightKeys = Object.keys(rightRecord);
	return leftKeys.length === rightKeys.length && leftKeys.every((key) => leftRecord[key] === rightRecord[key]);
}
function createRecordPatch(previous, current) {
	const upserts = {};
	const removals = [];
	for (const [key, value] of Object.entries(current)) if (previous[key] == null || !areShallowRecordsEqual(previous[key], value)) upserts[key] = value;
	for (const key of Object.keys(previous)) if (current[key] == null) removals.push(key);
	return {
		removals,
		upserts
	};
}
function getCustomRangePresentationKey$1(entry) {
	return JSON.stringify([entry.segmentId, entry.rangeId]);
}
function toCustomRangePresentationMap(entries) {
	return new Map(entries.map((entry) => [getCustomRangePresentationKey$1(entry), entry]));
}
function createCustomRangePresentationPatch(previous, current) {
	const upserts = [];
	const removals = [];
	for (const [key, entry] of current) {
		const previousEntry = previous.get(key);
		if (previousEntry == null || !areShallowRecordsEqual(previousEntry.presentation, entry.presentation)) upserts.push(entry);
	}
	for (const [key, entry] of previous) if (!current.has(key)) removals.push({
		segmentId: entry.segmentId,
		rangeId: entry.rangeId
	});
	return {
		removals,
		upserts
	};
}
function isRichTextEditingMutationParams(value) {
	return typeof value === "object" && value != null && "unitId" in value && typeof value.unitId === "string" && "actions" in value;
}
function collectCustomBlockViewports(dataModel, options) {
	var _documentStyle$pageSi, _documentStyle$pageSi2;
	const snapshot = dataModel.getSnapshot();
	const documentStyle = snapshot.documentStyle;
	const isModern = documentStyle.documentFlavor === DocumentFlavor.MODERN;
	const modernMargin = options.modernHorizontalMargin ?? MODERN_DOCUMENT_DEFAULT_MARGIN;
	const pageMarginLeft = isModern ? modernMargin : documentStyle.marginLeft;
	const pageMarginRight = isModern ? modernMargin : documentStyle.marginRight;
	const pageWidth = isModern ? options.modernPageWidth ?? ((_documentStyle$pageSi = documentStyle.pageSize) === null || _documentStyle$pageSi === void 0 ? void 0 : _documentStyle$pageSi.width) ?? MODERN_DOCUMENT_WIDTH[ModernDocumentWidthMode.MEDIUM] : (_documentStyle$pageSi2 = documentStyle.pageSize) === null || _documentStyle$pageSi2 === void 0 ? void 0 : _documentStyle$pageSi2.width;
	const viewports = {};
	const bodies = [
		snapshot.body,
		...Object.values(snapshot.headers ?? {}).map((header) => header.body),
		...Object.values(snapshot.footers ?? {}).map((footer) => footer.body)
	];
	for (const customBlock of bodies.flatMap((body) => (body === null || body === void 0 ? void 0 : body.customBlocks) ?? [])) {
		var _snapshot$drawings;
		const drawing = (_snapshot$drawings = snapshot.drawings) === null || _snapshot$drawings === void 0 ? void 0 : _snapshot$drawings[customBlock.blockId];
		if (drawing == null) continue;
		const viewport = getDocsCustomBlockRenderViewport(dataModel.getUnitId(), customBlock.blockId, {
			fallbackHeight: drawing.docTransform.size.height ?? 0,
			fallbackWidth: drawing.docTransform.size.width ?? 0,
			pageMarginLeft,
			pageMarginRight,
			pageWidth
		});
		if (viewport != null) viewports[customBlock.blockId] = { ...viewport };
	}
	return viewports;
}
let DocLayoutExecutorService = _DocLayoutExecutorService = class DocLayoutExecutorService extends Disposable {
	constructor(_univerInstanceService, _commandService, _localeService, _logService) {
		super();
		this._univerInstanceService = _univerInstanceService;
		this._commandService = _commandService;
		this._localeService = _localeService;
		this._logService = _logService;
		_defineProperty(this, "_executor", null);
		_defineProperty(this, "_executorReady", null);
		_defineProperty(this, "_recoveryFailure", null);
		_defineProperty(this, "_sessionEpoch", 0);
		_defineProperty(this, "_sessions", /* @__PURE__ */ new Map());
		_defineProperty(this, "_hydrationSamples", /* @__PURE__ */ new Map());
		_defineProperty(this, "_customRangePresentationProviders", /* @__PURE__ */ new Set());
		_defineProperty(this, "_executorStatus$", new BehaviorSubject({
			state: "unregistered",
			executor: null,
			diagnostic: null,
			recoveryUnitId: null
		}));
		_defineProperty(this, "executorStatus$", this._executorStatus$.asObservable());
		this.disposeWithMe(this._univerInstanceService.getTypeOfUnitAdded$(UniverInstanceType.UNIVER_DOC).subscribe(({ unit }) => this._createSessionIfEligible(unit)));
		this.disposeWithMe(this._univerInstanceService.getTypeOfUnitDisposed$(UniverInstanceType.UNIVER_DOC).subscribe((unit) => this._disposeSession(unit.getUnitId())));
		this.disposeWithMe(this._commandService.onCommandExecuted((command) => {
			if (command.id !== "doc.mutation.rich-text-editing") return;
			const params = command.params;
			if (!isRichTextEditingMutationParams(params)) {
				this._logService.warn("[DocLayoutExecutorService]: ignored malformed document mutation parameters.");
				return;
			}
			this._enqueueCommittedMutation(params);
		}));
		this.disposeWithMe(this._localeService.localeChanged$.subscribe(() => {
			for (const unitId of this._sessions.keys()) {
				const dataModel = this._getEligibleModel(unitId);
				if (dataModel != null) this._replaceSession(dataModel).catch((error) => {
					this._logService.error("[DocLayoutExecutorService]: failed to refresh Worker locale.", error);
				});
			}
		}));
	}
	register(executor) {
		if (this._executor != null) throw new Error("A document layout executor is already registered.");
		this._executor = executor;
		this._recoveryFailure = null;
		this._executorStatus$.next({
			state: "initializing",
			executor: executor.type,
			diagnostic: null,
			recoveryUnitId: null
		});
		const executorReady = executor.initialize();
		this._executorReady = executorReady;
		executorReady.then(() => {
			if (this._executor === executor) this._executorStatus$.next({
				state: "active",
				executor: executor.type,
				diagnostic: null,
				recoveryUnitId: null
			});
		}).catch((error) => {
			if (this._executor !== executor) return;
			this._executor = null;
			this._executorReady = null;
			this._disposeManagedSessions();
			this._sessions.clear();
			const diagnostic = error instanceof Error ? error.message : String(error);
			this._executorStatus$.next({
				state: "failed",
				executor: executor.type,
				diagnostic,
				recoveryUnitId: null
			});
			this._logService.error("[DocLayoutExecutorService]: document layout executor initialization failed.", error);
		});
		for (const unit of this._univerInstanceService.getAllUnitsForType(UniverInstanceType.UNIVER_DOC)) this._createSessionIfEligible(unit);
		return toDisposable(() => {
			if (this._executor === executor) {
				this._executor = null;
				this._executorReady = null;
				this._disposeManagedSessions();
				this._sessions.clear();
				this._executorStatus$.next({
					state: "unregistered",
					executor: null,
					diagnostic: null,
					recoveryUnitId: null
				});
			}
		});
	}
	getExecutor() {
		return this._executor;
	}
	getExecutorStatus() {
		return this._executorStatus$.value;
	}
	registerCustomRangePresentationProvider(provider) {
		this._customRangePresentationProviders.add(provider);
		return toDisposable(() => this._customRangePresentationProviders.delete(provider));
	}
	async getPerformanceMetrics(unitId) {
		var _this$_executor;
		const executorMetrics = await ((_this$_executor = this._executor) === null || _this$_executor === void 0 ? void 0 : _this$_executor.getPerformanceMetrics(unitId));
		return {
			hydrationMs: [...this._hydrationSamples.get(unitId) ?? []],
			mutationTransferMs: [...(executorMetrics === null || executorMetrics === void 0 ? void 0 : executorMetrics.mutationTransferMs) ?? []],
			patchTransferMs: [...(executorMetrics === null || executorMetrics === void 0 ? void 0 : executorMetrics.patchTransferMs) ?? []],
			snapshotTransferMs: [...(executorMetrics === null || executorMetrics === void 0 ? void 0 : executorMetrics.snapshotTransferMs) ?? []]
		};
	}
	async resetPerformanceMetrics(unitId) {
		var _this$_executor2;
		this._hydrationSamples.delete(unitId);
		await ((_this$_executor2 = this._executor) === null || _this$_executor2 === void 0 ? void 0 : _this$_executor2.resetPerformanceMetrics(unitId));
	}
	recordHydrationDuration(unitId, durationMs) {
		this._appendPerformanceSample(this._hydrationSamples, unitId, durationMs);
	}
	async recoverExecutor(unitId, diagnostic) {
		const executor = this._requireExecutor();
		this._executorStatus$.next({
			state: "recovering",
			executor: executor.type,
			diagnostic,
			recoveryUnitId: unitId
		});
		for (const session of this._sessions.values()) this._markSessionDisposed(session);
		this._sessions.clear();
		this._hydrationSamples.clear();
		try {
			const executorReady = executor.recover();
			this._executorReady = executorReady;
			await executorReady;
		} catch (error) {
			if (this._executor === executor) {
				const recoveryDiagnostic = error instanceof Error ? error.message : String(error);
				this._executor = null;
				this._executorReady = null;
				this._recoveryFailure = {
					diagnostic: recoveryDiagnostic,
					unitId
				};
				this._executorStatus$.next({
					state: "recovering",
					executor: executor.type,
					diagnostic: recoveryDiagnostic,
					recoveryUnitId: unitId
				});
			}
			throw error;
		}
	}
	completeRecovery(unitId) {
		var _this$_recoveryFailur;
		const status = this._executorStatus$.value;
		if (status.state !== "recovering" || status.recoveryUnitId !== unitId) return;
		const recoveryFailure = ((_this$_recoveryFailur = this._recoveryFailure) === null || _this$_recoveryFailur === void 0 ? void 0 : _this$_recoveryFailur.unitId) === unitId ? this._recoveryFailure : null;
		this._recoveryFailure = null;
		this._executorStatus$.next({
			state: recoveryFailure == null ? "active" : "failed",
			executor: status.executor,
			diagnostic: (recoveryFailure === null || recoveryFailure === void 0 ? void 0 : recoveryFailure.diagnostic) ?? null,
			recoveryUnitId: null
		});
	}
	async startLayout(identity, options, budgetMs) {
		const { unitId } = identity;
		const executor = this._executor;
		const dataModel = this._getEligibleModel(unitId);
		if (executor == null || dataModel == null) return null;
		let session = this._sessions.get(unitId);
		if (session != null && session.sourceMutationRevision !== dataModel.getMutationRevision()) session.needsResnapshot = true;
		if (session == null || session.needsResnapshot) session = await this._replaceSession(dataModel);
		if (session.disposed || this._executor !== executor || this._getEligibleModel(unitId) !== dataModel) return null;
		let result = await this._startSynchronizedLayout(executor, session, identity, options, budgetMs);
		if (session.disposed || this._executor !== executor || this._getEligibleModel(unitId) !== dataModel) return null;
		if (result.status === "not-found" || result.status === "resnapshot-required") {
			session = await this._replaceSession(dataModel);
			result = await this._startSynchronizedLayout(executor, session, identity, options, budgetMs);
		}
		return result;
	}
	stepLayout(request) {
		return this._requireExecutor().stepLayout(request);
	}
	publishBacklog(request) {
		return this._requireExecutor().publishBacklog(request);
	}
	getLayoutPage(request) {
		return this._requireExecutor().getLayoutPage(request);
	}
	cancelLayout(request) {
		const executor = this._executor;
		return executor == null ? Promise.resolve() : executor.cancelLayout(request);
	}
	disposeLayoutMount(request) {
		const executor = this._executor;
		const session = this._sessions.get(request.unitId);
		const latestStart = session === null || session === void 0 ? void 0 : session.latestStarts.get(request.mountId);
		if ((latestStart === null || latestStart === void 0 ? void 0 : latestStart.mountEpoch) === request.mountEpoch && latestStart.viewportEpoch === request.viewportEpoch) {
			session === null || session === void 0 || session.latestStarts.delete(request.mountId);
			session === null || session === void 0 || session.customBlockViewportsByMount.delete(request.mountId);
		}
		return executor == null ? Promise.resolve() : executor.disposeLayoutMount(request);
	}
	dispose() {
		const executor = this._executor;
		if (executor != null) for (const [unitId, session] of this._sessions) {
			this._markSessionDisposed(session);
			executor.disposeSession({
				unitId,
				sessionEpoch: session.sessionEpoch
			}).catch((error) => {
				if (this._executor === executor) this._logService.error("[DocLayoutExecutorService]: failed to dispose a Worker session.", error);
			});
		}
		this._sessions.clear();
		this._executor = null;
		this._executorReady = null;
		this._recoveryFailure = null;
		this._executorStatus$.complete();
		this._customRangePresentationProviders.clear();
		super.dispose();
	}
	_createSessionIfEligible(dataModel) {
		if (this._executor == null || !this._isEligible(dataModel) || this._sessions.has(dataModel.getUnitId())) return;
		this._replaceSession(dataModel).catch((error) => {
			this._logService.error("[DocLayoutExecutorService]: failed to create a Worker session.", error);
		});
	}
	_enqueueCommittedMutation(params) {
		const executor = this._executor;
		const dataModel = this._getEligibleModel(params.unitId);
		if (executor == null || dataModel == null) return;
		const session = this._sessions.get(params.unitId);
		if (session == null) {
			this._replaceSession(dataModel).catch((error) => {
				this._logService.error("[DocLayoutExecutorService]: failed to snapshot a document mutation.", error);
			});
			return;
		}
		if (JSONX.isNoop(params.actions)) return;
		const sourceMutationRevision = dataModel.getMutationRevision();
		if (sourceMutationRevision !== session.sourceMutationRevision + 1) {
			session.needsResnapshot = true;
			return;
		}
		const baseRevision = session.modelRevision;
		const modelRevision = baseRevision + 1;
		session.modelRevision = modelRevision;
		session.sourceMutationRevision = sourceMutationRevision;
		session.pendingMutations.push({
			baseRevision,
			modelRevision,
			actions: params.actions
		});
	}
	async _startSynchronizedLayout(executor, session, identity, options, budgetMs) {
		var _session$latestStarts;
		const { unitId, mountId } = identity;
		const startId = (((_session$latestStarts = session.latestStarts.get(mountId)) === null || _session$latestStarts === void 0 ? void 0 : _session$latestStarts.startId) ?? 0) + 1;
		const startIdentity = {
			startId,
			mountEpoch: identity.mountEpoch,
			viewportEpoch: identity.viewportEpoch
		};
		session.latestStarts.set(mountId, startIdentity);
		const startTask = session.queue.then(async () => {
			if (session.disposed || this._executor !== executor) return { status: "not-found" };
			const currentModel = this._getEligibleModel(unitId);
			if (currentModel == null || currentModel.getMutationRevision() !== session.sourceMutationRevision) {
				session.needsResnapshot = true;
				return {
					status: "resnapshot-required",
					modelRevision: session.workerRevision
				};
			}
			if (session.latestStarts.get(mountId) !== startIdentity) return { status: "superseded" };
			const mutations = session.pendingMutations.slice();
			const projections = this._createLayoutProjectionPayload(session, identity, this._getRequiredModel(unitId), options);
			const request = {
				...identity,
				metricsRevision: startId,
				baseRevision: session.workerRevision,
				modelRevision: session.modelRevision,
				mutations,
				...projections.request,
				budgetMs,
				...options
			};
			const result = await executor.startLayout(request);
			if (result.status === "accepted") {
				session.workerRevision = request.modelRevision;
				session.pendingMutations.splice(0, mutations.length);
				session.customBlockViewportsByMount.set(mountId, {
					mountEpoch: identity.mountEpoch,
					value: projections.customBlockViewports
				});
				session.customRangePresentations = projections.customRangePresentations;
			} else session.needsResnapshot = true;
			return result;
		});
		session.queue = startTask.then(() => void 0, (error) => {
			if (session.disposed || this._executor !== executor) return;
			session.needsResnapshot = true;
			this._logService.error("[DocLayoutExecutorService]: synchronized layout start failed.", error);
		});
		return startTask;
	}
	_createLayoutProjectionPayload(session, identity, dataModel, options) {
		const customBlockViewports = collectCustomBlockViewports(dataModel, options);
		const previousCustomBlockViewports = session.customBlockViewportsByMount.get(identity.mountId);
		const customRangePresentations = this._collectCustomRangePresentations(dataModel);
		const customRangePresentationMap = toCustomRangePresentationMap(customRangePresentations);
		const request = {};
		if (previousCustomBlockViewports == null || previousCustomBlockViewports.mountEpoch !== identity.mountEpoch) request.customBlockViewports = customBlockViewports;
		else {
			const patch = createRecordPatch(previousCustomBlockViewports.value, customBlockViewports);
			if (patch.removals.length > 0 || Object.keys(patch.upserts).length > 0) request.customBlockViewportPatch = patch;
		}
		if (session.customRangePresentations == null) request.customRangePresentations = customRangePresentations;
		else {
			const patch = createCustomRangePresentationPatch(session.customRangePresentations, customRangePresentationMap);
			if (patch.removals.length > 0 || patch.upserts.length > 0) request.customRangePresentationPatch = patch;
		}
		return {
			request,
			customBlockViewports,
			customRangePresentations: customRangePresentationMap
		};
	}
	async _replaceSession(dataModel) {
		const executor = this._requireExecutor();
		const unitId = dataModel.getUnitId();
		const previous = this._sessions.get(unitId);
		if (previous != null) this._markSessionDisposed(previous);
		const modelRevision = (previous === null || previous === void 0 ? void 0 : previous.modelRevision) ?? 0;
		const session = {
			sessionEpoch: ++this._sessionEpoch,
			modelRevision,
			sourceMutationRevision: dataModel.getMutationRevision(),
			workerRevision: modelRevision,
			pendingMutations: [],
			latestStarts: /* @__PURE__ */ new Map(),
			customBlockViewportsByMount: /* @__PURE__ */ new Map(),
			customRangePresentations: null,
			queue: Promise.resolve(),
			needsResnapshot: false,
			disposed: false,
			cancelPendingCreateTask: null
		};
		const createTask = this._createSessionOnNextMacroTask(executor, session, dataModel);
		session.queue = createTask;
		this._sessions.set(unitId, session);
		try {
			await createTask;
		} catch (error) {
			if (!session.disposed && this._executor === executor) {
				session.needsResnapshot = true;
				throw error;
			}
		}
		return session;
	}
	_disposeSession(unitId) {
		const session = this._sessions.get(unitId);
		if (session == null) return;
		this._markSessionDisposed(session);
		this._sessions.delete(unitId);
		this._hydrationSamples.delete(unitId);
		const executor = this._executor;
		executor === null || executor === void 0 || executor.disposeSession({
			unitId,
			sessionEpoch: session.sessionEpoch
		}).catch((error) => {
			if (this._executor === executor) this._logService.error("[DocLayoutExecutorService]: failed to dispose a Worker session.", error);
		});
	}
	_getEligibleModel(unitId) {
		const dataModel = this._univerInstanceService.getUnit(unitId, UniverInstanceType.UNIVER_DOC);
		return dataModel != null && this._isEligible(dataModel) ? dataModel : null;
	}
	_getRequiredModel(unitId) {
		const dataModel = this._getEligibleModel(unitId);
		if (dataModel == null) throw new Error(`Eligible document model not found for Worker layout: "${unitId}".`);
		return dataModel;
	}
	_collectCustomRangePresentations(dataModel) {
		const presentations = [];
		const providers = Array.from(this._customRangePresentationProviders).reverse();
		if (providers.length === 0) return presentations;
		const collectSegment = (segmentId, body) => {
			if (body == null) return;
			const seenRangeIds = /* @__PURE__ */ new Set();
			for (const range of body.customRanges ?? []) {
				if (seenRangeIds.has(range.rangeId)) continue;
				seenRangeIds.add(range.rangeId);
				for (const provider of providers) {
					const presentation = provider(dataModel.getUnitId(), range, {
						segmentId,
						body
					});
					if (presentation != null) {
						presentations.push({
							segmentId,
							rangeId: range.rangeId,
							presentation: { ...presentation }
						});
						break;
					}
				}
			}
		};
		collectSegment("", dataModel.getBody());
		for (const [segmentId, headerModel] of dataModel.headerModelMap) collectSegment(segmentId, headerModel.getBody());
		for (const [segmentId, footerModel] of dataModel.footerModelMap) collectSegment(segmentId, footerModel.getBody());
		return presentations;
	}
	_isEligible(dataModel) {
		if (isInternalEditorID(dataModel.getUnitId())) return false;
		const flavor = dataModel.getSnapshot().documentStyle.documentFlavor;
		return flavor === DocumentFlavor.TRADITIONAL || flavor === DocumentFlavor.MODERN;
	}
	_requireExecutor() {
		if (this._executor == null) throw new Error("No document layout executor is registered.");
		return this._executor;
	}
	_appendPerformanceSample(target, unitId, durationMs) {
		const samples = target.get(unitId) ?? [];
		samples.push(durationMs);
		if (samples.length > _DocLayoutExecutorService._performanceSampleLimit) samples.splice(0, samples.length - _DocLayoutExecutorService._performanceSampleLimit);
		target.set(unitId, samples);
	}
	_createSessionOnNextMacroTask(executor, session, dataModel) {
		return new Promise((resolve, reject) => {
			const cancelTask = requestImmediateMacroTask(() => {
				session.cancelPendingCreateTask = null;
				const unitId = dataModel.getUnitId();
				if (session.disposed || this._executor !== executor || this._sessions.get(unitId) !== session) {
					resolve();
					return;
				}
				const executorReady = this._executorReady;
				if (executorReady == null) {
					resolve();
					return;
				}
				executorReady.then(() => {
					if (session.disposed || this._executor !== executor || this._sessions.get(unitId) !== session || this._getEligibleModel(unitId) !== dataModel) {
						resolve();
						return;
					}
					session.sourceMutationRevision = dataModel.getMutationRevision();
					session.workerRevision = session.modelRevision;
					session.pendingMutations.length = 0;
					const request = {
						unitId,
						sessionEpoch: session.sessionEpoch,
						snapshot: createDocumentLayoutSnapshot(dataModel.getSnapshot()),
						modelRevision: session.modelRevision,
						locale: this._localeService.getCurrentLocale(),
						localeData: this._localeService.getLocales(),
						direction: this._localeService.getDirection()
					};
					executor.createSession(request).then(resolve, reject);
				}, reject);
			});
			session.cancelPendingCreateTask = () => {
				cancelTask();
				session.cancelPendingCreateTask = null;
				resolve();
			};
		});
	}
	_markSessionDisposed(session) {
		var _session$cancelPendin;
		session.disposed = true;
		(_session$cancelPendin = session.cancelPendingCreateTask) === null || _session$cancelPendin === void 0 || _session$cancelPendin.call(session);
		session.cancelPendingCreateTask = null;
	}
	_disposeManagedSessions() {
		for (const session of this._sessions.values()) this._markSessionDisposed(session);
	}
};
_defineProperty(DocLayoutExecutorService, "_performanceSampleLimit", 2048);
DocLayoutExecutorService = _DocLayoutExecutorService = __decorate([
	__decorateParam(0, IUniverInstanceService),
	__decorateParam(1, ICommandService),
	__decorateParam(2, Inject(LocaleService)),
	__decorateParam(3, ILogService)
], DocLayoutExecutorService);

//#endregion
//#region src/services/doc-skeleton-manager.service.ts
let DocSkeletonManagerService = class DocSkeletonManagerService extends RxDisposable {
	constructor(_context, _localeService, _univerInstanceService, _docLayoutExecutorService, _configService) {
		super();
		this._context = _context;
		this._localeService = _localeService;
		this._univerInstanceService = _univerInstanceService;
		this._docLayoutExecutorService = _docLayoutExecutorService;
		this._configService = _configService;
		_defineProperty(this, "_skeleton", void 0);
		_defineProperty(this, "_docViewModel", void 0);
		_defineProperty(this, "_currentSkeleton$", new BehaviorSubject(null));
		_defineProperty(this, "currentSkeleton$", this._currentSkeleton$.asObservable());
		_defineProperty(this, "_currentSkeletonBefore$", new BehaviorSubject(null));
		_defineProperty(this, "currentSkeletonBefore$", this._currentSkeletonBefore$.asObservable());
		_defineProperty(this, "_currentViewModel$", new BehaviorSubject(null));
		_defineProperty(this, "currentViewModel$", this._currentViewModel$.asObservable());
		this._init();
		this._univerInstanceService.getCurrentTypeOfUnit$(UniverInstanceType.UNIVER_DOC).pipe(takeUntil(this.dispose$)).subscribe((documentModel) => {
			if (documentModel && documentModel.getUnitId() === this._context.unitId) this._update(documentModel);
		});
	}
	dispose() {
		super.dispose();
		this._currentSkeletonBefore$.complete();
		this._currentSkeleton$.complete();
	}
	getSkeleton() {
		return this._skeleton;
	}
	getViewModel() {
		return this._docViewModel;
	}
	getLayoutPerformanceMetrics() {
		return this._docLayoutExecutorService.getPerformanceMetrics(this._context.unitId);
	}
	supportsIncrementalLayout() {
		var _this$_context$unit$g;
		const documentFlavor = (_this$_context$unit$g = this._context.unit.getSnapshot().documentStyle) === null || _this$_context$unit$g === void 0 ? void 0 : _this$_context$unit$g.documentFlavor;
		return this._docLayoutExecutorService.getExecutor() != null && !isInternalEditorID(this._context.unitId) && !getDocumentLayoutPresentation(this._context.unit) && (documentFlavor === DocumentFlavor.TRADITIONAL || documentFlavor === DocumentFlavor.MODERN);
	}
	recalculate() {
		const skeleton = this._skeleton;
		skeleton.calculate();
		this._publishSkeleton(skeleton);
		return skeleton;
	}
	_publishSkeleton(skeleton) {
		this._currentSkeletonBefore$.next(skeleton);
		this._currentSkeleton$.next(skeleton);
	}
	_init() {
		const documentDataModel = this._context.unit;
		this._update(documentDataModel);
	}
	_update(documentDataModel) {
		const unitId = this._context.unitId;
		if (documentDataModel.getBody() == null) return;
		if (this._docViewModel && isInternalEditorID(unitId)) {
			this._docViewModel.reset(documentDataModel);
			this._context.unit = documentDataModel;
		} else if (!this._docViewModel) this._docViewModel = this._buildDocViewModel(documentDataModel);
		if (!this._skeleton) this._skeleton = this._buildSkeleton(this._docViewModel);
		if (this.supportsIncrementalLayout()) this._publishSkeleton(this._skeleton);
		else this.recalculate();
		this._currentViewModel$.next(this._docViewModel);
	}
	_buildSkeleton(documentViewModel) {
		const isSheetEditor = this._context.unitId === DOCS_NORMAL_EDITOR_UNIT_ID_KEY || this._context.unitId === DOCS_FORMULA_BAR_EDITOR_UNIT_ID_KEY;
		return DocumentSkeleton.create(documentViewModel, this._localeService, { lineGap: isSheetEditor ? this._configService.getConfig(SHEET_TEXT_LINE_GAP) : void 0 });
	}
	_buildDocViewModel(documentDataModel) {
		return new DocumentViewModel(documentDataModel);
	}
};
DocSkeletonManagerService = __decorate([
	__decorateParam(1, Inject(LocaleService)),
	__decorateParam(2, IUniverInstanceService),
	__decorateParam(3, Inject(DocLayoutExecutorService)),
	__decorateParam(4, IConfigService)
], DocSkeletonManagerService);

//#endregion
//#region src/services/doc-state-emit.service.ts
var DocStateEmitService = class extends RxDisposable {
	constructor() {
		super();
		_defineProperty(this, "_docStateChangeParams$", new BehaviorSubject(null));
		_defineProperty(this, "docStateChangeParams$", this._docStateChangeParams$.asObservable());
	}
	emitStateChangeInfo(params) {
		this._docStateChangeParams$.next(params);
	}
	dispose() {
		super.dispose();
		this._docStateChangeParams$.complete();
	}
};

//#endregion
//#region src/commands/mutations/doc-structure-mutation-validation.ts
const STRUCTURAL_BODY_FIELDS = [
	"paragraphs",
	"sectionBreaks",
	"customBlocks",
	"docxRawCustomBlocks",
	"docxRawBlocks",
	"docxExportExcludedRanges",
	"tables",
	"columnGroups",
	"blockRanges"
];
const STRUCTURAL_DATA_STREAM_TOKENS = /* @__PURE__ */ new Set([
	DataStreamTreeTokenType.PARAGRAPH,
	DataStreamTreeTokenType.SECTION_BREAK,
	DataStreamTreeTokenType.TABLE_START,
	DataStreamTreeTokenType.TABLE_ROW_START,
	DataStreamTreeTokenType.TABLE_CELL_START,
	DataStreamTreeTokenType.TABLE_CELL_END,
	DataStreamTreeTokenType.TABLE_ROW_END,
	DataStreamTreeTokenType.TABLE_END,
	DataStreamTreeTokenType.COLUMN_GROUP_START,
	DataStreamTreeTokenType.COLUMN_START,
	DataStreamTreeTokenType.COLUMN_END,
	DataStreamTreeTokenType.COLUMN_GROUP_END,
	DataStreamTreeTokenType.BLOCK_START,
	DataStreamTreeTokenType.BLOCK_END,
	DataStreamTreeTokenType.CUSTOM_BLOCK
]);
const NON_STRUCTURAL_ROOT_FIELDS = /* @__PURE__ */ new Set([
	"disabled",
	"documentStyle",
	"drawings",
	"drawingsOrder",
	"lists",
	"locale",
	"resources",
	"rev",
	"settings",
	"styles",
	"tableSource",
	"title"
]);
function isRecord$3(value) {
	return typeof value === "object" && value != null && !Array.isArray(value);
}
function containsStructuralToken(dataStream) {
	for (let index = 0; index < dataStream.length; index++) if (STRUCTURAL_DATA_STREAM_TOKENS.has(dataStream[index])) return true;
	return false;
}
function isStructurePreservingBody(value) {
	if (!isRecord$3(value)) return false;
	const dataStream = value.dataStream;
	if (dataStream != null && (typeof dataStream !== "string" || containsStructuralToken(dataStream))) return false;
	return STRUCTURAL_BODY_FIELDS.every((field) => {
		const metadata = value[field];
		return metadata == null || Array.isArray(metadata) && metadata.length === 0;
	});
}
function isStructurePreservingTextXEdit(value) {
	if (!Array.isArray(value)) return false;
	return value.every((action) => {
		if (!isRecord$3(action) || typeof action.len !== "number" || !Number.isFinite(action.len)) return false;
		if (action.t === TextXActionType.DELETE) return true;
		if (action.t === TextXActionType.INSERT) return isStructurePreservingBody(action.body);
		return action.t === TextXActionType.RETAIN && (action.body == null || isStructurePreservingBody(action.body));
	});
}
function pathsEqual(left, right) {
	return left.length === right.length && left.every((item, index) => item === right[index]);
}
function isStructurePreservingJSONXEdit(actions, expectedPath) {
	const cursor = JSON1.type.readCursor(actions);
	let hasComponent = false;
	let isStructurePreserving = true;
	cursor.traverse(null, (component) => {
		if (!isStructurePreserving) return;
		const path = cursor.getPath();
		hasComponent = true;
		if (NON_STRUCTURAL_ROOT_FIELDS.has(String(path[0]))) return;
		const componentKeys = Object.keys(component);
		if (component.et !== TextX.id || componentKeys.some((key) => key !== "et" && key !== "e") || !pathsEqual(path, expectedPath)) {
			isStructurePreserving = false;
			return;
		}
		const edit = component.e;
		isStructurePreserving = isStructurePreservingTextXEdit(edit);
	});
	return hasComponent && isStructurePreserving;
}
function getSegmentType(documentDataModel, segmentId) {
	var _documentDataModel$ge;
	if (!segmentId) return "body";
	const { headers, footers } = documentDataModel.getSnapshot();
	if (headers === null || headers === void 0 ? void 0 : headers[segmentId]) return "header";
	if (footers === null || footers === void 0 ? void 0 : footers[segmentId]) return "footer";
	if ((_documentDataModel$ge = documentDataModel.getSnapshot().notes) === null || _documentDataModel$ge === void 0 ? void 0 : _documentDataModel$ge[segmentId]) return "note";
	return "body";
}
function getSnapshotBody(snapshot, segmentId) {
	var _snapshot$headers, _snapshot$footers, _snapshot$notes;
	if (!segmentId) return snapshot.body;
	return ((_snapshot$headers = snapshot.headers) === null || _snapshot$headers === void 0 || (_snapshot$headers = _snapshot$headers[segmentId]) === null || _snapshot$headers === void 0 ? void 0 : _snapshot$headers.body) ?? ((_snapshot$footers = snapshot.footers) === null || _snapshot$footers === void 0 || (_snapshot$footers = _snapshot$footers[segmentId]) === null || _snapshot$footers === void 0 ? void 0 : _snapshot$footers.body) ?? ((_snapshot$notes = snapshot.notes) === null || _snapshot$notes === void 0 || (_snapshot$notes = _snapshot$notes[segmentId]) === null || _snapshot$notes === void 0 ? void 0 : _snapshot$notes.body);
}
function containsTextXEdit(actions) {
	const cursor = JSON1.type.readCursor(actions);
	let found = false;
	cursor.traverse(null, (component) => {
		if (component.et === TextX.id) found = true;
	});
	return found;
}
function subtractBaselineIssues(issues, baseline) {
	const counts = /* @__PURE__ */ new Map();
	baseline.forEach((issue) => counts.set(issue.code, (counts.get(issue.code) ?? 0) + 1));
	return issues.filter((issue) => {
		const count = counts.get(issue.code) ?? 0;
		if (count === 0) return true;
		counts.set(issue.code, count - 1);
		return false;
	});
}
function assertValidDocBodyStructure(documentDataModel, segmentId, undoActions) {
	var _documentDataModel$ge2;
	const segmentModel = documentDataModel.getSelfOrHeaderFooterModel(segmentId);
	const body = segmentModel === null || segmentModel === void 0 ? void 0 : segmentModel.getBody();
	if (!body) return;
	const segmentType = getSegmentType(documentDataModel, segmentId);
	const context = {
		segmentType,
		segmentId: segmentId || void 0
	};
	const note = (_documentDataModel$ge2 = documentDataModel.getSnapshot().notes) === null || _documentDataModel$ge2 === void 0 ? void 0 : _documentDataModel$ge2[segmentId];
	const issues = note ? validateDocumentStructure({ notes: { [segmentId]: note } }) : validateDocBodyStructure(body, {
		segmentType,
		segmentId: segmentId || void 0
	});
	if (!issues.length) return;
	const snapshot = Tools.deepClone(documentDataModel.getSnapshot());
	const baselineBody = getSnapshotBody(JSONX.apply(snapshot, undoActions), segmentId);
	const newIssues = baselineBody ? subtractBaselineIssues(issues, validateDocBodyStructure(baselineBody, context)) : issues;
	if (!newIssues.length) return;
	const detail = newIssues.map((issue) => `${issue.code}${issue.index == null ? "" : `@${issue.index}`}`).join(", ");
	const segmentLabel = segmentId ? `${segmentType} ${segmentId}` : segmentType;
	throw new Error(`[DocStructure] ${segmentLabel}: ${detail}`);
}
function getLockedSdtContent(body, range) {
	var _range$properties;
	if (((_range$properties = range.properties) === null || _range$properties === void 0 ? void 0 : _range$properties.kind) !== "group") return body.dataStream.slice(range.startIndex, range.endIndex + 1);
	const children = (body.customRanges ?? []).filter((child) => child.rangeType === CustomRangeType.SDT && child.rangeId !== range.rangeId && child.startIndex >= range.startIndex && child.endIndex <= range.endIndex).sort((left, right) => {
		const position = left.startIndex - right.startIndex || right.endIndex - left.endIndex;
		if (position || left.rangeId === right.rangeId) return position;
		return left.rangeId < right.rangeId ? -1 : 1;
	});
	const protectedContent = [];
	let offset = range.startIndex;
	for (const child of children) {
		if (child.startIndex < offset) continue;
		protectedContent.push(body.dataStream.slice(offset, child.startIndex), child.rangeId);
		offset = child.endIndex + 1;
	}
	protectedContent.push(body.dataStream.slice(offset, range.endIndex + 1));
	return JSON.stringify(protectedContent);
}
function getRepeatingItemIds(body, section) {
	const ranges = body.customRanges ?? [];
	const sectionIndex = ranges.indexOf(section);
	const nestedSections = ranges.filter((range, index) => {
		var _range$properties2;
		return range.rangeType === CustomRangeType.SDT && ((_range$properties2 = range.properties) === null || _range$properties2 === void 0 ? void 0 : _range$properties2.kind) === "repeatingSection" && range.rangeId !== section.rangeId && range.startIndex >= section.startIndex && range.endIndex <= section.endIndex && (range.startIndex > section.startIndex || range.endIndex < section.endIndex || index < sectionIndex);
	});
	return ranges.filter((range, index) => {
		var _range$properties3;
		return range.rangeType === CustomRangeType.SDT && ((_range$properties3 = range.properties) === null || _range$properties3 === void 0 ? void 0 : _range$properties3.kind) === "repeatingSectionItem" && range.startIndex >= section.startIndex && range.endIndex <= section.endIndex && !nestedSections.some((nested) => nested.startIndex <= range.startIndex && range.endIndex <= nested.endIndex && (nested.startIndex < range.startIndex || range.endIndex < nested.endIndex || index < ranges.indexOf(nested)));
	}).map((range) => range.rangeId).sort();
}
function isDocSdtMutationAllowed(documentDataModel, segmentId, actions) {
	var _previousBody$customR;
	if (!containsTextXEdit(actions) && isStructurePreservingJSONXEdit(actions, getRichTextEditPath(documentDataModel, segmentId))) return true;
	const snapshot = documentDataModel.getSnapshot();
	const previousBody = getSnapshotBody(snapshot, segmentId);
	const lockedRanges = previousBody === null || previousBody === void 0 || (_previousBody$customR = previousBody.customRanges) === null || _previousBody$customR === void 0 ? void 0 : _previousBody$customR.filter((range) => {
		var _range$properties4, _range$properties5, _range$properties$rep;
		return range.rangeType === CustomRangeType.SDT && (((_range$properties4 = range.properties) === null || _range$properties4 === void 0 ? void 0 : _range$properties4.lock) && range.properties.lock !== "unlocked" || ((_range$properties5 = range.properties) === null || _range$properties5 === void 0 ? void 0 : _range$properties5.kind) === "repeatingSection" && ((_range$properties$rep = range.properties.repeatingSection) === null || _range$properties$rep === void 0 ? void 0 : _range$properties$rep.doNotAllowInsertDelete));
	});
	if (!previousBody || !(lockedRanges === null || lockedRanges === void 0 ? void 0 : lockedRanges.length)) return true;
	const candidate = JSONX.apply(Tools.deepClone(snapshot), actions);
	const currentBody = getSnapshotBody(candidate, segmentId);
	for (const previous of lockedRanges) {
		var _previous$properties, _currentBody$customRa, _previous$properties2, _previous$properties$;
		const lock = (_previous$properties = previous.properties) === null || _previous$properties === void 0 ? void 0 : _previous$properties.lock;
		const current = currentBody === null || currentBody === void 0 || (_currentBody$customRa = currentBody.customRanges) === null || _currentBody$customRa === void 0 ? void 0 : _currentBody$customRa.find((range) => range.rangeId === previous.rangeId && range.rangeType === CustomRangeType.SDT);
		const wrapperLocked = lock === "sdtLocked" || lock === "sdtContentLocked";
		const contentLocked = lock === "contentLocked" || lock === "sdtContentLocked";
		if (wrapperLocked && !current) return false;
		if (((_previous$properties2 = previous.properties) === null || _previous$properties2 === void 0 ? void 0 : _previous$properties2.kind) === "repeatingSection" && ((_previous$properties$ = previous.properties.repeatingSection) === null || _previous$properties$ === void 0 ? void 0 : _previous$properties$.doNotAllowInsertDelete) && current && currentBody) {
			const before = getRepeatingItemIds(previousBody, previous);
			const after = getRepeatingItemIds(currentBody, current);
			if (before.length !== after.length || before.some((id, index) => id !== after[index])) return false;
		}
		if (contentLocked && current && currentBody) {
			if (getLockedSdtContent(previousBody, previous) !== getLockedSdtContent(currentBody, current) && !isBoundSdtValueUpdate(snapshot, candidate, previous, current, currentBody)) return false;
		}
	}
	return true;
}
function isBoundSdtValueUpdate(before, after, previous, current, currentBody) {
	const key = getSdtBindingKey(previous);
	const value = getSdtBindingValue(currentBody, current);
	if (!key || key !== getSdtBindingKey(current) || value === void 0) return false;
	return [
		"",
		...Object.keys(before.headers ?? {}),
		...Object.keys(before.footers ?? {}),
		...Object.keys(before.notes ?? {})
	].some((segmentId) => {
		var _previousBody$customR2;
		const previousBody = getSnapshotBody(before, segmentId);
		const nextBody = getSnapshotBody(after, segmentId);
		if (!previousBody || !nextBody) return false;
		return ((_previousBody$customR2 = previousBody.customRanges) === null || _previousBody$customR2 === void 0 ? void 0 : _previousBody$customR2.some((range) => {
			var _range$properties6, _range$properties7, _nextBody$customRange;
			if (range.rangeType !== CustomRangeType.SDT || ((_range$properties6 = range.properties) === null || _range$properties6 === void 0 ? void 0 : _range$properties6.lock) === "contentLocked" || ((_range$properties7 = range.properties) === null || _range$properties7 === void 0 ? void 0 : _range$properties7.lock) === "sdtContentLocked" || getSdtBindingKey(range) !== key) return false;
			const next = (_nextBody$customRange = nextBody.customRanges) === null || _nextBody$customRange === void 0 ? void 0 : _nextBody$customRange.find((item) => item.rangeType === CustomRangeType.SDT && item.rangeId === range.rangeId);
			return next != null && getSdtBindingKey(next) === key && getSdtBindingValue(previousBody, range) !== value && getSdtBindingValue(nextBody, next) === value;
		})) ?? false;
	});
}
function validateDocStructureMutation(documentDataModel, segmentId, actions, undoActions, isHistoryReplay = false) {
	const editPath = getRichTextEditPath(documentDataModel, segmentId);
	const preservesStructure = isStructurePreservingJSONXEdit(actions, editPath) && isStructurePreservingJSONXEdit(undoActions, editPath);
	let changesFootnoteStructure = false;
	const cursor = JSON1.type.readCursor(actions);
	cursor.traverse(null, (component) => {
		const path = cursor.getPath();
		if (path[0] === "notes" && (path.length <= 2 || path[2] !== "body") || path.includes("customRanges")) changesFootnoteStructure = true;
		if (component.et === TextX.id && Array.isArray(component.e)) for (const action of component.e) {
			if (isRecord$3(action) && Array.isArray(action.rangeUpdates) && action.rangeUpdates.some((update) => isRecord$3(update) && isRecord$3(update.range) && (update.range.rangeType === CustomRangeType.FOOTNOTE || update.range.rangeType === CustomRangeType.ENDNOTE))) changesFootnoteStructure = true;
			const ranges = isRecord$3(action) && isRecord$3(action.body) ? action.body.customRanges : void 0;
			if (Array.isArray(ranges) && ranges.some((range) => isRecord$3(range) && (range.rangeType === CustomRangeType.FOOTNOTE || range.rangeType === CustomRangeType.ENDNOTE))) changesFootnoteStructure = true;
		}
	});
	if (changesFootnoteStructure) {
		const issues = validateDocumentStructure(documentDataModel.getSnapshot());
		if (issues.length > 0) throw new Error(`[DocStructure] ${issues.map((issue) => `${issue.code}@${issue.index ?? issue.segmentId ?? ""}`).join(", ")}`);
	} else if (!preservesStructure && !isHistoryReplay) assertValidDocBodyStructure(documentDataModel, segmentId, undoActions);
	return preservesStructure && !changesFootnoteStructure;
}

//#endregion
//#region src/commands/mutations/core-editing.mutation.ts
let DocHistoryAction = /* @__PURE__ */ function(DocHistoryAction) {
	DocHistoryAction["DeleteChart"] = "delete-chart";
	DocHistoryAction["DeleteDivider"] = "delete-divider";
	DocHistoryAction["DeleteImage"] = "delete-image";
	DocHistoryAction["DeleteShape"] = "delete-shape";
	DocHistoryAction["EditTableCell"] = "edit-table-cell";
	DocHistoryAction["FormatParagraph"] = "format-paragraph";
	DocHistoryAction["InsertCustomRange"] = "insert-custom-range";
	DocHistoryAction["UpdateImage"] = "update-image";
	DocHistoryAction["UpdatePageLayout"] = "update-page-layout";
	return DocHistoryAction;
}({});
function extractDocumentBodyActions(actions, segmentId) {
	if (!Array.isArray(actions)) return;
	const bodyActions = actions.indexOf("body") > -1 ? actions : actions.find((action) => Array.isArray(action) && action.indexOf("body") > -1);
	if (!Array.isArray(bodyActions)) return;
	const bodyIndex = bodyActions.indexOf("body");
	if (bodyIndex === -1) return;
	return (bodyIndex === 0 ? "" : bodyActions[bodyIndex - 1]) === segmentId ? bodyActions.slice(bodyIndex) : void 0;
}
/**
* Transforms document selections through the same JSONX actions applied by a rich-text mutation.
* Collaboration and rendering use this shared offset rule so the Main interaction window follows
* the transformed local caret before an authoritative background layout is published.
*/
function transformDocumentTextRanges(actions, textRanges, priority = "right") {
	if (textRanges.length === 0) return [];
	const bodyActions = extractDocumentBodyActions(actions, textRanges[0].segmentId ?? "");
	if (bodyActions == null) return textRanges;
	return textRanges.map((textRange) => {
		const startOffset = JSONX.transformPosition(bodyActions, textRange.startOffset, priority);
		const endOffset = JSONX.transformPosition(bodyActions, textRange.endOffset, priority);
		return {
			...textRange,
			startOffset,
			endOffset,
			collapsed: startOffset === endOffset
		};
	});
}
function canRemoveFootnoteReference(actions, references) {
	let canRemove = false;
	const cursor = JSON1.type.readCursor(actions);
	cursor.traverse(null, (component) => {
		const path = cursor.getPath();
		if (path.length === 0) canRemove = true;
		if (canRemove || path[0] !== "body") return;
		if (path.length === 1 && component.et === TextX.id && Array.isArray(component.e)) {
			let offset = 0;
			for (const action of component.e) {
				var _action$body, _action$rangeUpdates;
				if (action.t === TextXActionType.DELETE && references.some((reference) => offset <= reference.endIndex && offset + action.len > reference.startIndex)) {
					canRemove = true;
					return;
				}
				if (action.t === TextXActionType.RETAIN && (((_action$body = action.body) === null || _action$body === void 0 ? void 0 : _action$body.customRanges) != null || ((_action$rangeUpdates = action.rangeUpdates) === null || _action$rangeUpdates === void 0 ? void 0 : _action$rangeUpdates.some((update) => references.some((reference) => reference.rangeId === update.rangeId))))) {
					canRemove = true;
					return;
				}
				if (action.t !== TextXActionType.INSERT) offset += action.len;
			}
		} else if (path.length === 1 || path[1] === "customRanges" || path[1] === "dataStream") canRemove = true;
	});
	return canRemove;
}
function includeFootnoteCleanup(before, actions) {
	var _before$body, _after$body;
	if (!before.notes) return actions;
	const references = ((_before$body = before.body) === null || _before$body === void 0 || (_before$body = _before$body.customRanges) === null || _before$body === void 0 ? void 0 : _before$body.filter((range) => range.rangeType === CustomRangeType.FOOTNOTE || range.rangeType === CustomRangeType.ENDNOTE)) ?? [];
	if (references.length === 0 || !canRemoveFootnoteReference(actions, references)) return actions;
	const after = JSONX.apply(Tools.deepClone(before), actions);
	const remaining = new Set((_after$body = after.body) === null || _after$body === void 0 || (_after$body = _after$body.customRanges) === null || _after$body === void 0 ? void 0 : _after$body.filter((range) => range.rangeType === CustomRangeType.FOOTNOTE || range.rangeType === CustomRangeType.ENDNOTE).map((range) => {
		var _range$properties;
		return (_range$properties = range.properties) === null || _range$properties === void 0 ? void 0 : _range$properties.noteId;
	}));
	let cleanup = null;
	const previousIds = new Set(references.map((reference) => {
		var _reference$properties;
		return (_reference$properties = reference.properties) === null || _reference$properties === void 0 ? void 0 : _reference$properties.noteId;
	}));
	for (const id of previousIds) {
		var _after$notes;
		if (typeof id === "string" && !remaining.has(id) && ((_after$notes = after.notes) === null || _after$notes === void 0 ? void 0 : _after$notes[id])) cleanup = JSONX.compose(cleanup, JSONX.getInstance().removeOp(["notes", id], after.notes[id]));
	}
	return JSONX.isNoop(cleanup) ? actions : JSONX.compose(actions, cleanup);
}
function applyValidatedDocumentActions(documentDataModel, segmentId, actions, isHistoryReplay = false) {
	const before = documentDataModel.getSnapshot();
	const appliedActions = includeFootnoteCleanup(before, actions);
	const undoActions = JSONX.invertWithDoc(appliedActions, before);
	documentDataModel.apply(appliedActions);
	try {
		return {
			actions: appliedActions,
			undoActions,
			preservesStructure: validateDocStructureMutation(documentDataModel, segmentId, appliedActions, undoActions, isHistoryReplay)
		};
	} catch (error) {
		documentDataModel.apply(undoActions);
		throw error;
	}
}
function resetDocumentViewModel(documentViewModel, documentDataModel, segmentId, actions, preservesStructure) {
	var _documentViewModel$re, _documentViewModel$re2;
	if (documentViewModel == null) return;
	if (!(segmentId === "" && preservesStructure && (((_documentViewModel$re = documentViewModel.resetByValidatedTextMutation) === null || _documentViewModel$re === void 0 ? void 0 : _documentViewModel$re.call(documentViewModel, documentDataModel, actions)) || ((_documentViewModel$re2 = documentViewModel.resetByValidatedMetadataMutation) === null || _documentViewModel$re2 === void 0 ? void 0 : _documentViewModel$re2.call(documentViewModel, documentDataModel, actions))))) documentViewModel.reset(documentDataModel);
}
function scheduleDocumentSelectionUpdate(selectionManager, params, isSync) {
	const { unitId, textRanges, trigger, noNeedSetTextRange, isEditing = true } = params;
	if (noNeedSetTextRange || textRanges == null || textRanges.length === 0 || trigger == null || isSync) return;
	const selectionTarget = {
		unitId,
		subUnitId: unitId
	};
	const currentSelection = selectionManager.getSelectionInfo(selectionTarget);
	const logicalTextRanges = textRanges.map((textRange, index) => ({
		...textRange,
		segmentId: textRange.segmentId ?? params.segmentId ?? "",
		collapsed: textRange.startOffset === textRange.endOffset,
		isActive: index === textRanges.length - 1
	}));
	if (currentSelection != null) selectionManager.replaceSelectionInfoWithoutRefresh({
		...currentSelection,
		segmentId: logicalTextRanges[logicalTextRanges.length - 1].segmentId,
		textRanges: logicalTextRanges,
		rectRanges: [],
		isEditing,
		options: {
			...params.options,
			preserveInputStyle: false
		}
	}, selectionTarget);
	const updatedSelection = selectionManager.getSelectionInfo(selectionTarget);
	queueMicrotask(() => {
		if (selectionManager.getSelectionInfo(selectionTarget) !== updatedSelection) return;
		selectionManager.replaceDocRanges(logicalTextRanges, selectionTarget, isEditing, params.options);
	});
}
/**
* The core mutator to change rich text actions. The execution result would be undo mutation params. Could be directly
* send to undo redo service (will be used by the triggering command).
*/
const RichTextEditingMutation = {
	id: RICH_TEXT_EDITING_MUTATION_ID,
	type: CommandType.MUTATION,
	handler: (accessor, params, options) => {
		var _renderManagerService;
		const { unitId, segmentId = "", actions, textRanges, prevTextRanges, trigger, noHistory, isCompositionEnd, debounce, isEditing = true, isSync: paramsIsSync, syncer } = params;
		const isSync = Boolean(paramsIsSync || (options === null || options === void 0 ? void 0 : options.fromCollab) || (options === null || options === void 0 ? void 0 : options.fromChangeset));
		const univerInstanceService = accessor.get(IUniverInstanceService);
		const renderManagerService = accessor.get(IRenderManagerService);
		const docStateEmitService = accessor.get(DocStateEmitService);
		const documentDataModel = univerInstanceService.getUnit(unitId, UniverInstanceType.UNIVER_DOC);
		const documentViewModel = (_renderManagerService = renderManagerService.getRenderUnitById(unitId)) === null || _renderManagerService === void 0 ? void 0 : _renderManagerService.with(DocSkeletonManagerService).getViewModel();
		if (documentDataModel == null) throw new Error(`DocumentDataModel not found for unitId: ${unitId}`);
		const docSelectionManagerService = accessor.get(DocSelectionManagerService);
		const docRanges = docSelectionManagerService.getDocRanges() ?? [];
		const selectionInfo = docSelectionManagerService.getSelectionInfo();
		const disabled = !!documentDataModel.getSnapshot().disabled;
		if (JSONX.isNoop(actions) || actions && actions.length === 0 || disabled) return {
			unitId,
			actions: [],
			textRanges: docRanges
		};
		const isHistoryReplay = trigger === UndoCommandId || trigger === RedoCommandId;
		if (!isHistoryReplay && !isDocSdtMutationAllowed(documentDataModel, segmentId, actions)) {
			params.actions = [];
			return {
				unitId,
				actions: [],
				textRanges: docRanges
			};
		}
		const presentation = getDocumentLayoutPresentation(documentDataModel);
		const previousLayoutState = presentation === null || presentation === void 0 ? void 0 : presentation.captureState();
		const { actions: appliedActions, undoActions, preservesStructure } = applyValidatedDocumentActions(documentDataModel, segmentId, actions, isHistoryReplay);
		if (presentation) try {
			if (params.layoutState !== void 0) presentation.restoreState(params.layoutState);
			else presentation.applyActions(appliedActions, documentDataModel.getSnapshot());
			params.layoutState = presentation.captureState();
		} catch (error) {
			documentDataModel.apply(undoActions);
			presentation.restoreState(previousLayoutState);
			throw error;
		}
		params.actions = appliedActions;
		resetDocumentViewModel(documentViewModel, documentDataModel, segmentId, appliedActions, preservesStructure);
		scheduleDocumentSelectionUpdate(docSelectionManagerService, params, isSync);
		const changeState = {
			commandId: RICH_TEXT_EDITING_MUTATION_ID,
			unitId,
			segmentId,
			trigger,
			noHistory,
			debounce,
			redoState: {
				...presentation ? { layoutState: params.layoutState } : {},
				actions: appliedActions,
				textRanges,
				options: params.options,
				isEditing
			},
			undoState: {
				...presentation ? { layoutState: previousLayoutState } : {},
				actions: undoActions,
				textRanges: prevTextRanges ?? docRanges,
				options: selectionInfo === null || selectionInfo === void 0 ? void 0 : selectionInfo.options,
				isEditing: selectionInfo === null || selectionInfo === void 0 ? void 0 : selectionInfo.isEditing
			},
			isCompositionEnd,
			isSync,
			syncer
		};
		docStateEmitService.emitStateChangeInfo(changeState);
		return {
			unitId,
			actions: undoActions,
			...presentation ? { layoutState: previousLayoutState } : {},
			textRanges: docRanges
		};
	}
};

//#endregion
//#region src/commands/commands/core-editing.command.ts
/**
* The command to insert text. The changed range could be non-collapsed, mainly use in line break and normal input.
*/
const InsertTextCommand = {
	id: "doc.command.insert-text",
	type: CommandType.COMMAND,
	handler: (accessor, params) => {
		var _docDataModel$getSelf;
		const commandService = accessor.get(ICommandService);
		const { range, segmentId, body, unitId, cursorOffset, debounce = true, textRanges, noNeedSetTextRange, isEditing } = params;
		const docSelectionManagerService = accessor.get(DocSelectionManagerService);
		const docDataModel = accessor.get(IUniverInstanceService).getUnit(unitId, UniverInstanceType.UNIVER_DOC);
		if (docDataModel == null) return false;
		const activeRange = docSelectionManagerService.getActiveTextRange();
		const rangeSegmentId = "segmentId" in range && typeof range.segmentId === "string" ? range.segmentId : void 0;
		const targetSegmentId = segmentId ?? rangeSegmentId ?? (activeRange === null || activeRange === void 0 ? void 0 : activeRange.segmentId) ?? "";
		const originBody = (_docDataModel$getSelf = docDataModel.getSelfOrHeaderFooterModel(targetSegmentId)) === null || _docDataModel$getSelf === void 0 ? void 0 : _docDataModel$getSelf.getBody();
		if (originBody == null) return false;
		const { startOffset, collapsed } = range;
		const cursorMove = cursorOffset ?? body.dataStream.length;
		const mutationTextRanges = textRanges ?? [{
			startOffset: startOffset + cursorMove,
			endOffset: startOffset + cursorMove,
			collapsed
		}];
		const doMutation = {
			id: RichTextEditingMutation.id,
			params: {
				unitId,
				segmentId: targetSegmentId,
				actions: [],
				textRanges: mutationTextRanges,
				debounce,
				noNeedSetTextRange,
				isEditing
			}
		};
		doMutation.params.actions = buildInsertTextActions(docDataModel, originBody, range, body, targetSegmentId);
		const result = commandService.syncExecuteCommand(doMutation.id, doMutation.params);
		return Boolean(result);
	}
};
function buildInsertTextActions(documentDataModel, originBody, range, insertBody, segmentId) {
	const { startOffset, endOffset, collapsed } = range;
	const textX = new TextX();
	if (collapsed) {
		if (startOffset > 0) textX.push({
			t: TextXActionType.RETAIN,
			len: startOffset
		});
		textX.push({
			t: TextXActionType.INSERT,
			body: insertBody,
			len: insertBody.dataStream.length
		});
	} else textX.push(...BuildTextUtils.selection.delete([range], originBody, 0, insertBody));
	const textActions = JSONX.getInstance().editOp(textX.serialize(), getRichTextEditPath(documentDataModel, segmentId));
	return collapsed ? textActions : appendRemovedDrawingActions(textActions, documentDataModel, originBody, startOffset, endOffset, segmentId);
}
function appendRemovedDrawingActions(textActions, documentDataModel, body, startOffset, endOffset, segmentId) {
	return [textActions, ...BuildTextUtils.drawing.remove(documentDataModel.getSnapshot(), [{
		startOffset,
		endOffset,
		collapsed: false
	}], body, segmentId)].reduce((accumulator, action) => JSONX.compose(accumulator, action));
}
/**
* The command to delete text, mainly used in BACKSPACE and DELETE when collapsed is true. ONLY handle collapsed range!!!
*/
const DeleteTextCommand = {
	id: "doc.command.delete-text",
	type: CommandType.COMMAND,
	handler: (accessor, params) => {
		var _docDataModel$getSelf2, _body$customRanges;
		const commandService = accessor.get(ICommandService);
		const univerInstanceService = accessor.get(IUniverInstanceService);
		const { range, segmentId, unitId, direction, len = 1 } = params;
		const docDataModel = univerInstanceService.getUnit(unitId, UniverInstanceType.UNIVER_DOC);
		const body = docDataModel === null || docDataModel === void 0 || (_docDataModel$getSelf2 = docDataModel.getSelfOrHeaderFooterModel(segmentId)) === null || _docDataModel$getSelf2 === void 0 ? void 0 : _docDataModel$getSelf2.getBody();
		if (docDataModel == null || body == null) return false;
		const { startOffset } = range;
		let start = direction === DeleteDirection.LEFT ? startOffset - len : startOffset;
		let end = direction === DeleteDirection.LEFT ? startOffset - 1 : startOffset + len - 1;
		const customRange = (_body$customRanges = body.customRanges) === null || _body$customRanges === void 0 ? void 0 : _body$customRanges.find((customRange) => customRange.startIndex <= start && customRange.endIndex >= end);
		if (customRange === null || customRange === void 0 ? void 0 : customRange.wholeEntity) {
			start = customRange.startIndex;
			end = Math.max(end, customRange.endIndex);
		}
		const doMutation = {
			id: RichTextEditingMutation.id,
			params: {
				unitId,
				segmentId,
				actions: [],
				textRanges: [{
					startOffset: start,
					endOffset: start,
					collapsed: true
				}],
				debounce: true
			}
		};
		const textX = new TextX();
		const jsonX = JSONX.getInstance();
		textX.push(...BuildTextUtils.selection.delete([{
			...range,
			startOffset: start,
			endOffset: end + 1,
			collapsed: false
		}], body, 0, null, true, docDataModel.getDocumentStyle().documentFlavor));
		const path = getRichTextEditPath(docDataModel, segmentId);
		doMutation.params.actions = appendRemovedDrawingActions(jsonX.editOp(textX.serialize(), path), docDataModel, body, start, end + 1, segmentId);
		const result = commandService.syncExecuteCommand(doMutation.id, doMutation.params);
		return Boolean(result);
	}
};
/**
* The command to update text properties, mainly used in BACKSPACE.
*/
const UpdateTextCommand = {
	id: "doc.command.update-text",
	type: CommandType.COMMAND,
	handler: (accessor, params) => {
		const { range, segmentId, updateBody, coverType, unitId, textRanges } = params;
		const commandService = accessor.get(ICommandService);
		const docDataModel = accessor.get(IUniverInstanceService).getCurrentUnitOfType(UniverInstanceType.UNIVER_DOC);
		if (docDataModel == null) return false;
		const doMutation = {
			id: RichTextEditingMutation.id,
			params: {
				unitId,
				actions: [],
				textRanges
			}
		};
		const textX = new TextX();
		const jsonX = JSONX.getInstance();
		const { startOffset, endOffset } = range;
		textX.push({
			t: TextXActionType.RETAIN,
			len: startOffset
		});
		textX.push({
			t: TextXActionType.RETAIN,
			body: updateBody,
			len: endOffset - startOffset,
			coverType
		});
		const path = getRichTextEditPath(docDataModel, segmentId);
		doMutation.params.actions = jsonX.editOp(textX.serialize(), path);
		const result = commandService.syncExecuteCommand(doMutation.id, doMutation.params);
		return Boolean(result);
	}
};

//#endregion
//#region src/commands/commands/create-header-footer.command.ts
let HeaderFooterType = /* @__PURE__ */ function(HeaderFooterType) {
	HeaderFooterType[HeaderFooterType["FIRST_PAGE_HEADER"] = 0] = "FIRST_PAGE_HEADER";
	HeaderFooterType[HeaderFooterType["FIRST_PAGE_FOOTER"] = 1] = "FIRST_PAGE_FOOTER";
	HeaderFooterType[HeaderFooterType["DEFAULT_HEADER"] = 2] = "DEFAULT_HEADER";
	HeaderFooterType[HeaderFooterType["DEFAULT_FOOTER"] = 3] = "DEFAULT_FOOTER";
	HeaderFooterType[HeaderFooterType["EVEN_PAGE_HEADER"] = 4] = "EVEN_PAGE_HEADER";
	HeaderFooterType[HeaderFooterType["EVEN_PAGE_FOOTER"] = 5] = "EVEN_PAGE_FOOTER";
	return HeaderFooterType;
}({});
function getEmptyHeaderFooterBody() {
	return {
		dataStream: "\r\n",
		textRuns: [{
			st: 0,
			ed: 0,
			ts: { fs: 9 }
		}],
		customBlocks: [],
		paragraphs: [{
			startIndex: 0,
			paragraphId: createParagraphId(/* @__PURE__ */ new Set()),
			paragraphStyle: {
				spaceAbove: { v: 0 },
				lineSpacing: 1.5,
				spaceBelow: { v: 0 }
			}
		}],
		sectionBreaks: [{
			sectionId: createSectionId(/* @__PURE__ */ new Set()),
			startIndex: 1
		}]
	};
}
function createHeaderFooterAction(segmentId, createType, headerFooterConfig, actions, createMode = "single", configPath = ["documentStyle"]) {
	const jsonX = JSONX.getInstance();
	const ID_LEN = 6;
	const firstSegmentId = segmentId ?? generateRandomId(ID_LEN);
	const isHeader = createType === 2 || createType === 0 || createType === 4;
	const insertAction = jsonX.insertOp([isHeader ? "headers" : "footers", firstSegmentId], {
		[isHeader ? "headerId" : "footerId"]: firstSegmentId,
		body: getEmptyHeaderFooterBody()
	});
	actions.push(insertAction);
	let key = "defaultHeaderId";
	let pairKey = "defaultFooterId";
	switch (createType) {
		case 2:
			key = "defaultHeaderId";
			pairKey = "defaultFooterId";
			break;
		case 3:
			key = "defaultFooterId";
			pairKey = "defaultHeaderId";
			break;
		case 0:
			key = "firstPageHeaderId";
			pairKey = "firstPageFooterId";
			break;
		case 1:
			key = "firstPageFooterId";
			pairKey = "firstPageHeaderId";
			break;
		case 4:
			key = "evenPageHeaderId";
			pairKey = "evenPageFooterId";
			break;
		case 5:
			key = "evenPageFooterId";
			pairKey = "evenPageHeaderId";
			break;
		default: throw new Error(`Unknown header footer type: ${createType}`);
	}
	const linkedSegmentIds = [[key, firstSegmentId]];
	if (createMode === "pair" && pairKey != null) {
		const secondSegmentId = generateRandomId(ID_LEN);
		const insertPairAction = jsonX.insertOp([isHeader ? "footers" : "headers", secondSegmentId], {
			[isHeader ? "footerId" : "headerId"]: secondSegmentId,
			body: getEmptyHeaderFooterBody()
		});
		actions.push(insertPairAction);
		linkedSegmentIds.push([pairKey, secondSegmentId]);
	}
	for (const [k, id] of linkedSegmentIds) if (headerFooterConfig[k] != null) {
		const replaceAction = jsonX.replaceOp([...configPath, k], headerFooterConfig[k], id);
		actions.push(replaceAction);
	} else {
		const insertAction = jsonX.insertOp([...configPath, k], id);
		actions.push(insertAction);
	}
	return actions;
}
const CreateHeaderFooterCommand = {
	id: "doc.command.create-header-footer",
	type: CommandType.COMMAND,
	handler: (accessor, params) => {
		var _body$sectionBreaks, _body$sectionBreaks2;
		const commandService = accessor.get(ICommandService);
		const univerInstanceService = accessor.get(IUniverInstanceService);
		const { unitId, segmentId, createType, headerFooterProps, createMode = "single", sectionId } = params;
		const docDataModel = univerInstanceService.getUnit(unitId, UniverInstanceType.UNIVER_DOC);
		if (docDataModel == null) return false;
		const { documentStyle, body } = docDataModel.getSnapshot();
		if (documentStyle.documentFlavor === DocumentFlavor.MODERN) return false;
		const rawActions = [];
		const jsonX = JSONX.getInstance();
		const sectionIndex = sectionId == null ? -1 : (body === null || body === void 0 || (_body$sectionBreaks = body.sectionBreaks) === null || _body$sectionBreaks === void 0 ? void 0 : _body$sectionBreaks.findIndex((section) => section.sectionId === sectionId)) ?? -1;
		const sectionBreak = sectionIndex < 0 ? void 0 : body === null || body === void 0 || (_body$sectionBreaks2 = body.sectionBreaks) === null || _body$sectionBreaks2 === void 0 ? void 0 : _body$sectionBreaks2[sectionIndex];
		if (sectionId != null && !sectionBreak) return false;
		const headerFooterConfig = sectionBreak ?? documentStyle;
		const configPath = sectionId == null ? ["documentStyle"] : [
			"body",
			"sectionBreaks",
			sectionIndex
		];
		if (createType != null) createHeaderFooterAction(segmentId, createType, headerFooterConfig, rawActions, createMode, configPath);
		if (headerFooterProps != null) Object.keys(headerFooterProps).forEach((key) => {
			const value = headerFooterProps[key];
			const oldValue = headerFooterConfig[key];
			if (value === oldValue) return;
			const action = oldValue === void 0 ? jsonX.insertOp([...configPath, key], value) : jsonX.replaceOp([...configPath, key], oldValue, value);
			rawActions.push(action);
		});
		if (rawActions.length === 0) return false;
		const doMutation = {
			id: RichTextEditingMutation.id,
			params: {
				unitId,
				actions: rawActions.reduce((acc, cur) => JSONX.compose(acc, cur), null),
				textRanges: [{
					startOffset: 0,
					endOffset: 0,
					collapsed: true
				}],
				debounce: true
			}
		};
		if ((headerFooterProps === null || headerFooterProps === void 0 ? void 0 : headerFooterProps.marginFooter) != null || (headerFooterProps === null || headerFooterProps === void 0 ? void 0 : headerFooterProps.marginHeader) != null) doMutation.params.noNeedSetTextRange = true;
		const result = commandService.syncExecuteCommand(doMutation.id, doMutation.params);
		return Boolean(result);
	}
};

//#endregion
//#region src/commands/commands/set-document-default-paragraph-style.command.ts
const SetDocumentDefaultParagraphStyleCommand = {
	id: "doc.command.set-default-paragraph-style",
	type: CommandType.COMMAND,
	handler: (accessor, params) => {
		if (params == null) return false;
		const commandService = accessor.get(ICommandService);
		const documentDataModel = accessor.get(IUniverInstanceService).getUnit(params.unitId, UniverInstanceType.UNIVER_DOC);
		if (documentDataModel == null) return false;
		const oldStyle = documentDataModel.getSnapshot().documentStyle.defaultParagraphStyle;
		const jsonX = JSONX.getInstance();
		const path = ["documentStyle", "defaultParagraphStyle"];
		const rawActions = [];
		if (params.defaultParagraphStyle == null) {
			if (oldStyle != null) rawActions.push(jsonX.removeOp(path, oldStyle));
		} else if (oldStyle == null) {
			const newStyle = Object.fromEntries(Object.entries(params.defaultParagraphStyle).filter(([, value]) => value != null).map(([key, value]) => [key, Tools.deepClone(value)]));
			if (Object.keys(newStyle).length > 0) rawActions.push(jsonX.insertOp(path, newStyle));
		} else Object.entries(params.defaultParagraphStyle).forEach(([key, value]) => {
			const oldValue = oldStyle[key];
			const propertyPath = [...path, key];
			if (value == null) {
				if (oldValue != null) rawActions.push(jsonX.removeOp(propertyPath, oldValue));
			} else if (oldValue == null) rawActions.push(jsonX.insertOp(propertyPath, Tools.deepClone(value)));
			else rawActions.push(jsonX.replaceOp(propertyPath, oldValue, Tools.deepClone(value)));
		});
		const actions = rawActions.reduce((acc, action) => JSONX.compose(acc, action), null);
		if (rawActions.length === 0 || JSONX.isNoop(actions)) return false;
		const mutation = {
			id: RichTextEditingMutation.id,
			params: {
				unitId: params.unitId,
				actions,
				textRanges: null,
				noNeedSetTextRange: true,
				debounce: true,
				isEditing: false
			}
		};
		return Boolean(commandService.syncExecuteCommand(mutation.id, mutation.params));
	}
};

//#endregion
//#region src/commands/mutations/docs-rename.mutation.ts
const DocsRenameMutation = {
	id: "doc.mutation.rename-doc",
	type: CommandType.MUTATION,
	handler: (accessor, params) => {
		const doc = accessor.get(IUniverInstanceService).getUnit(params.unitId, UniverInstanceType.UNIVER_DOC);
		if (!doc) return false;
		doc.setName(params.name);
		return true;
	}
};

//#endregion
//#region src/commands/commands/set-document-name.command.ts
const SetDocumentNameCommand = {
	id: "doc.command.set-name",
	type: CommandType.COMMAND,
	handler: (accessor, params) => {
		if (!params) return false;
		const document = accessor.get(IUniverInstanceService).getUnit(params.unitId, UniverInstanceType.UNIVER_DOC);
		if (!document) return false;
		const commandService = accessor.get(ICommandService);
		const redoParams = {
			unitId: params.unitId,
			name: params.name
		};
		const undoParams = {
			unitId: params.unitId,
			name: document.getTitle() || ""
		};
		if (!commandService.syncExecuteCommand(DocsRenameMutation.id, redoParams)) return false;
		accessor.get(IUndoRedoService).pushUndoRedo({
			unitID: params.unitId,
			redoMutations: [{
				id: DocsRenameMutation.id,
				params: redoParams
			}],
			undoMutations: [{
				id: DocsRenameMutation.id,
				params: undoParams
			}]
		});
		return true;
	}
};

//#endregion
//#region src/services/permission/permission-point/document/comment.ts
var DocumentCommentPermission = class {
	constructor(unitId) {
		this.unitId = unitId;
		_defineProperty(this, "type", UnitObject.Document);
		_defineProperty(this, "subType", UnitAction.Comment);
		_defineProperty(this, "status", PermissionStatus.INIT);
		_defineProperty(this, "id", void 0);
		_defineProperty(this, "value", true);
		this.id = `${this.type}.${this.subType}_${unitId}`;
	}
};

//#endregion
//#region src/services/permission/permission-point/document/copy.ts
var DocumentCopyPermission = class {
	constructor(unitId) {
		this.unitId = unitId;
		_defineProperty(this, "type", UnitObject.Document);
		_defineProperty(this, "subType", UnitAction.Copy);
		_defineProperty(this, "status", PermissionStatus.INIT);
		_defineProperty(this, "id", void 0);
		_defineProperty(this, "value", true);
		this.id = `${this.type}.${this.subType}_${unitId}`;
	}
};

//#endregion
//#region src/services/permission/permission-point/document/editable.ts
var DocumentEditablePermission = class {
	constructor(unitId) {
		this.unitId = unitId;
		_defineProperty(this, "type", UnitObject.Document);
		_defineProperty(this, "subType", UnitAction.Edit);
		_defineProperty(this, "status", PermissionStatus.INIT);
		_defineProperty(this, "id", void 0);
		_defineProperty(this, "value", true);
		this.id = `${this.type}.${this.subType}_${unitId}`;
	}
};

//#endregion
//#region src/services/permission/permission-point/document/export.ts
var DocumentExportPermission = class {
	constructor(unitId) {
		this.unitId = unitId;
		_defineProperty(this, "type", UnitObject.Document);
		_defineProperty(this, "subType", UnitAction.Export);
		_defineProperty(this, "status", PermissionStatus.INIT);
		_defineProperty(this, "id", void 0);
		_defineProperty(this, "value", true);
		this.id = `${this.type}.${this.subType}_${unitId}`;
	}
};

//#endregion
//#region src/services/permission/permission-point/document/print.ts
var DocumentPrintPermission = class {
	constructor(unitId) {
		this.unitId = unitId;
		_defineProperty(this, "type", UnitObject.Document);
		_defineProperty(this, "subType", UnitAction.Print);
		_defineProperty(this, "status", PermissionStatus.INIT);
		_defineProperty(this, "id", void 0);
		_defineProperty(this, "value", true);
		this.id = `${this.type}.${this.subType}_${unitId}`;
	}
};

//#endregion
//#region src/services/permission/permission-point/entity/edit.ts
var DocumentEntityEditPermission = class {
	constructor(unitId, objectId) {
		this.unitId = unitId;
		this.objectId = objectId;
		_defineProperty(this, "type", UnitObject.DocumentEntity);
		_defineProperty(this, "subType", UnitAction.Edit);
		_defineProperty(this, "status", PermissionStatus.INIT);
		_defineProperty(this, "id", void 0);
		_defineProperty(this, "value", true);
		this.id = `${this.type}.${this.subType}_${unitId}_${objectId}`;
	}
};

//#endregion
//#region src/services/permission/permission-point/paragraph/edit.ts
var DocumentParagraphEditPermission = class {
	constructor(unitId, objectId) {
		this.unitId = unitId;
		this.objectId = objectId;
		_defineProperty(this, "type", UnitObject.DocumentParagraph);
		_defineProperty(this, "subType", UnitAction.Edit);
		_defineProperty(this, "status", PermissionStatus.INIT);
		_defineProperty(this, "id", void 0);
		_defineProperty(this, "value", true);
		this.id = `${this.type}.${this.subType}_${unitId}_${objectId}`;
	}
};

//#endregion
//#region src/services/permission/permission-point/section/edit.ts
var DocumentSectionEditPermission = class {
	constructor(unitId, objectId) {
		this.unitId = unitId;
		this.objectId = objectId;
		_defineProperty(this, "type", UnitObject.DocumentSection);
		_defineProperty(this, "subType", UnitAction.Edit);
		_defineProperty(this, "status", PermissionStatus.INIT);
		_defineProperty(this, "id", void 0);
		_defineProperty(this, "value", true);
		this.id = `${this.type}.${this.subType}_${unitId}_${objectId}`;
	}
};

//#endregion
//#region src/services/permission/document-permission.ts
const DOCUMENT_UNIT_PERMISSION_ACTIONS = [
	UnitAction.Edit,
	UnitAction.Copy,
	UnitAction.Print,
	UnitAction.Export,
	UnitAction.Comment
];
const DOCUMENT_PERMISSION_OBJECT_TYPES = /* @__PURE__ */ new Set([
	UnitObject.Document,
	UnitObject.DocumentSection,
	UnitObject.DocumentParagraph,
	UnitObject.DocumentEntity
]);
const DOCUMENT_SECTION_PERMISSION_OBJECT_PREFIX = "section/";
const DOCUMENT_PARAGRAPH_PERMISSION_OBJECT_PREFIX = "paragraph/";
const DOCUMENT_ENTITY_PERMISSION_OBJECT_PREFIX = "entity/";
function getDocumentSectionPermissionObjectId(segmentId, sectionId) {
	return `${DOCUMENT_SECTION_PERMISSION_OBJECT_PREFIX}${encodeURIComponent(segmentId)}/${encodeURIComponent(sectionId)}`;
}
function getDocumentParagraphPermissionObjectId(segmentId, paragraphId) {
	return `${DOCUMENT_PARAGRAPH_PERMISSION_OBJECT_PREFIX}${encodeURIComponent(segmentId)}/${encodeURIComponent(paragraphId)}`;
}
function getDocumentEntityPermissionObjectId(segmentId, entityType, entityId) {
	return `${DOCUMENT_ENTITY_PERMISSION_OBJECT_PREFIX}${encodeURIComponent(segmentId)}/${encodeURIComponent(entityType)}/${encodeURIComponent(entityId)}`;
}
function createDocumentPermissionPoint(unitId, objectId, action) {
	if (objectId === unitId) switch (action) {
		case UnitAction.Edit: return new DocumentEditablePermission(unitId);
		case UnitAction.Copy: return new DocumentCopyPermission(unitId);
		case UnitAction.Print: return new DocumentPrintPermission(unitId);
		case UnitAction.Export: return new DocumentExportPermission(unitId);
		case UnitAction.Comment: return new DocumentCommentPermission(unitId);
		default: throw new Error(`Unsupported Document permission action: ${action}`);
	}
	if (action !== UnitAction.Edit) throw new Error(`Document object permissions only support Edit: ${objectId}`);
	if (objectId.startsWith(DOCUMENT_SECTION_PERMISSION_OBJECT_PREFIX)) return new DocumentSectionEditPermission(unitId, objectId);
	if (objectId.startsWith(DOCUMENT_PARAGRAPH_PERMISSION_OBJECT_PREFIX)) return new DocumentParagraphEditPermission(unitId, objectId);
	if (objectId.startsWith(DOCUMENT_ENTITY_PERMISSION_OBJECT_PREFIX)) return new DocumentEntityEditPermission(unitId, objectId);
	throw new Error(`Unsupported Document permission object: ${objectId}`);
}
function getDocumentPermissionValue(permissionService, unitId, objectId, action) {
	var _permissionService$ge;
	return ((_permissionService$ge = permissionService.getPermissionPoint(createDocumentPermissionPoint(unitId, objectId, action).id)) === null || _permissionService$ge === void 0 ? void 0 : _permissionService$ge.value) ?? true;
}
function setDocumentPermissionValue(permissionService, unitId, objectId, action, value) {
	const point = createDocumentPermissionPoint(unitId, objectId, action);
	if (!permissionService.getPermissionPoint(point.id)) permissionService.addPermissionPoint(point);
	permissionService.updatePermissionPoint(point.id, value);
}
function clearDocumentPermissionValuesForUnit(permissionService, unitId) {
	permissionService.getAllPermissionPoint().forEach((point$, id) => {
		point$.subscribe((point) => {
			if (DOCUMENT_PERMISSION_OBJECT_TYPES.has(point.type) && "unitId" in point && point.unitId === unitId) permissionService.deletePermissionPoint(id);
		}).unsubscribe();
	});
}
function canEditDocumentTargets(permissionService, unitId, objectIds) {
	if (!getDocumentPermissionValue(permissionService, unitId, unitId, UnitAction.Edit)) return false;
	for (const objectId of objectIds) if (!getDocumentPermissionValue(permissionService, unitId, objectId, UnitAction.Edit)) return false;
	return true;
}

//#endregion
//#region src/commands/commands/set-document-permission.command.ts
const SetDocumentPermissionCommand = {
	type: CommandType.COMMAND,
	id: "doc.command.set-permission",
	async handler(accessor, params) {
		if (!params || !DOCUMENT_UNIT_PERMISSION_ACTIONS.includes(params.action)) return false;
		if (params.objectId !== params.unitId && params.action !== UnitAction.Edit) return false;
		if (params.policy && (![
			"all",
			"owner",
			"members"
		].includes(params.policy.edit) || params.policy.strategies.some((strategy) => !DOCUMENT_UNIT_PERMISSION_ACTIONS.includes(strategy.action) || params.objectId !== params.unitId && strategy.action !== UnitAction.Edit))) return false;
		const point = createDocumentPermissionPoint(params.unitId, params.objectId, params.action);
		const target = {
			unitId: params.unitId,
			objectId: params.objectId,
			objectType: point.type
		};
		const service = accessor.get(ObjectPermissionService);
		if (params.remove) await service.remove(target);
		else if (params.policy) await service.save(target, params.policy);
		else await service.setPoint(target, point, params.value);
		return true;
	}
};

//#endregion
//#region src/commands/commands/set-document-permissions.command.ts
const SetDocumentPermissionsCommand = {
	type: CommandType.COMMAND,
	id: "doc.command.set-permissions",
	async handler(accessor, params) {
		if (!(params === null || params === void 0 ? void 0 : params.unitId) || !Array.isArray(params.changes) || !params.changes.length || params.changes.some((change) => !(change === null || change === void 0 ? void 0 : change.objectId) || change.objectId === params.unitId || change.policy !== null && (!change.policy || ![
			"all",
			"owner",
			"members"
		].includes(change.policy.edit) || !Array.isArray(change.policy.collaborators) || !Array.isArray(change.policy.strategies) || change.policy.strategies.some((strategy) => strategy.action !== UnitAction.Edit)))) throw new Error("Invalid object permission batch.");
		return accessor.get(ObjectPermissionService).saveMany(params.changes.map((change) => {
			const point = createDocumentPermissionPoint(params.unitId, change.objectId, UnitAction.Edit);
			return {
				unitId: params.unitId,
				objectId: change.objectId,
				objectType: point.type,
				policy: change.policy
			};
		}));
	}
};

//#endregion
//#region src/utils/sections.ts
/** Returns document-level section breaks, excluding table-cell and modern-column sentinels. */
function getTopLevelSectionBreaks(body) {
	const sectionBreakByIndex = new Map((body.sectionBreaks ?? []).map((sectionBreak) => [sectionBreak.startIndex, sectionBreak]));
	const result = [];
	let tableCellDepth = 0;
	let columnDepth = 0;
	for (let index = 0; index < body.dataStream.length; index++) {
		const token = body.dataStream[index];
		if (token === DataStreamTreeTokenType.TABLE_CELL_START) tableCellDepth++;
		else if (token === DataStreamTreeTokenType.TABLE_CELL_END) tableCellDepth = Math.max(0, tableCellDepth - 1);
		else if (token === DataStreamTreeTokenType.COLUMN_START) columnDepth++;
		else if (token === DataStreamTreeTokenType.COLUMN_END) columnDepth = Math.max(0, columnDepth - 1);
		else if (token === DataStreamTreeTokenType.SECTION_BREAK && tableCellDepth === 0 && columnDepth === 0) {
			const sectionBreak = sectionBreakByIndex.get(index);
			if (sectionBreak) result.push(sectionBreak);
		}
	}
	return result;
}

//#endregion
//#region src/commands/commands/set-section-header-footer-link.command.ts
const SetSectionHeaderFooterLinkCommand = {
	id: "doc.command.set-section-header-footer-link",
	type: CommandType.COMMAND,
	handler: (accessor, params) => {
		var _snapshot$body$sectio;
		if (!params) return false;
		const instanceService = accessor.get(IUniverInstanceService);
		const commandService = accessor.get(ICommandService);
		const documentDataModel = instanceService.getUnit(params.unitId, UniverInstanceType.UNIVER_DOC);
		const snapshot = documentDataModel === null || documentDataModel === void 0 ? void 0 : documentDataModel.getSnapshot();
		if (!documentDataModel || !(snapshot === null || snapshot === void 0 ? void 0 : snapshot.body) || snapshot.documentStyle.documentFlavor !== DocumentFlavor.TRADITIONAL) return false;
		const sections = getTopLevelSectionBreaks(snapshot.body);
		const sectionIndex = sections.findIndex((section) => section.sectionId === params.sectionId);
		if (sectionIndex <= 0) return false;
		const storageIndex = ((_snapshot$body$sectio = snapshot.body.sectionBreaks) === null || _snapshot$body$sectio === void 0 ? void 0 : _snapshot$body$sectio.findIndex((item) => item.sectionId === params.sectionId)) ?? -1;
		if (storageIndex < 0) return false;
		const context = {
			snapshot,
			sections,
			sectionIndex,
			storageIndex,
			key: getSectionHeaderFooterReferenceKey(params.kind, params.variant)
		};
		const rawActions = params.linkedToPrevious ? buildLinkActions(context, params.kind) : buildUnlinkActions(context, params.kind, params.segmentId);
		if (!rawActions) return false;
		const mutation = {
			id: RichTextEditingMutation.id,
			params: {
				unitId: params.unitId,
				actions: rawActions.reduce((actions, action) => JSONX.compose(actions, action), null),
				textRanges: null,
				noNeedSetTextRange: true,
				debounce: true,
				isEditing: false,
				trigger: SetSectionHeaderFooterLinkCommand.id
			}
		};
		return Boolean(commandService.syncExecuteCommand(mutation.id, mutation.params));
	}
};
function buildLinkActions(context, kind) {
	const { snapshot, sections, sectionIndex, storageIndex, key } = context;
	const section = sections[sectionIndex];
	const explicitSegmentId = section[key];
	if (typeof explicitSegmentId !== "string" || !explicitSegmentId) return null;
	const jsonX = JSONX.getInstance();
	const actions = [jsonX.removeOp([
		"body",
		"sectionBreaks",
		storageIndex,
		key
	], explicitSegmentId)];
	const referenceKeys = kind === "header" ? [
		"defaultHeaderId",
		"firstPageHeaderId",
		"evenPageHeaderId"
	] : [
		"defaultFooterId",
		"firstPageFooterId",
		"evenPageFooterId"
	];
	const referencedByDocument = referenceKeys.some((referenceKey) => snapshot.documentStyle[referenceKey] === explicitSegmentId);
	const referencedBySection = sections.some((item) => referenceKeys.some((referenceKey) => !(item.sectionId === section.sectionId && referenceKey === key) && item[referenceKey] === explicitSegmentId));
	const resources = kind === "header" ? snapshot.headers : snapshot.footers;
	if (!referencedByDocument && !referencedBySection && (resources === null || resources === void 0 ? void 0 : resources[explicitSegmentId])) actions.push(jsonX.removeOp([kind === "header" ? "headers" : "footers", explicitSegmentId], resources[explicitSegmentId]));
	return actions;
}
function buildUnlinkActions(context, kind, requestedSegmentId) {
	const { snapshot, sections, sectionIndex, storageIndex, key } = context;
	const explicitSegmentId = sections[sectionIndex][key];
	if (typeof explicitSegmentId === "string" && explicitSegmentId) return null;
	const sourceSegmentId = resolveSectionHeaderFooterReference(snapshot.documentStyle, sections, sectionIndex - 1, key).segmentId;
	const segmentId = requestedSegmentId ?? generateRandomId(6);
	const resources = kind === "header" ? snapshot.headers : snapshot.footers;
	if (resources === null || resources === void 0 ? void 0 : resources[segmentId]) return null;
	const source = sourceSegmentId ? resources === null || resources === void 0 ? void 0 : resources[sourceSegmentId] : void 0;
	const idKey = kind === "header" ? "headerId" : "footerId";
	const resource = source ? {
		...Tools.deepClone(source),
		[idKey]: segmentId
	} : {
		[idKey]: segmentId,
		body: getEmptyHeaderFooterBody()
	};
	const jsonX = JSONX.getInstance();
	return [jsonX.insertOp([kind === "header" ? "headers" : "footers", segmentId], resource), jsonX.insertOp([
		"body",
		"sectionBreaks",
		storageIndex,
		key
	], segmentId)];
}

//#endregion
//#region src/commands/commands/update-document-paragraph-style.command.ts
function isValidParams(params) {
	return Boolean((params === null || params === void 0 ? void 0 : params.unitId) && params.paragraphId && Number.isInteger(params.startOffset) && Number.isInteger(params.endOffset) && params.startOffset >= 0 && params.endOffset >= params.startOffset && params.style && Object.keys(params.style).length > 0);
}
function getCurrentParagraph(body, params) {
	const matches = (body.paragraphs ?? []).filter((paragraph) => paragraph.paragraphId === params.paragraphId);
	if (matches.length !== 1) return null;
	const paragraph = matches[0];
	return getParagraphContentStartOffset(body, paragraph) === params.startOffset && paragraph.startIndex === params.endOffset && body.dataStream[params.endOffset] === "\r" ? paragraph : null;
}
function createParagraphStyleTextX(body, paragraph, params) {
	const textX = new TextX();
	const initializesTextRuns = Boolean(params.style.textStyle && params.startOffset < params.endOffset && body.textRuns == null);
	if (params.startOffset > 0) textX.push({
		t: TextXActionType.RETAIN,
		len: params.startOffset
	});
	if (params.style.textStyle && params.startOffset < params.endOffset && !initializesTextRuns) textX.push({
		t: TextXActionType.RETAIN,
		len: params.endOffset - params.startOffset,
		coverType: UpdateDocsAttributeType.COVER,
		body: {
			dataStream: "",
			textRuns: [{
				st: 0,
				ed: params.endOffset - params.startOffset,
				ts: Tools.deepClone(params.style.textStyle)
			}]
		}
	});
	else if (params.startOffset < params.endOffset) textX.push({
		t: TextXActionType.RETAIN,
		len: params.endOffset - params.startOffset
	});
	const paragraphBody = {
		dataStream: "",
		paragraphs: [{
			...Tools.deepClone(paragraph),
			startIndex: 0,
			paragraphStyle: {
				...Tools.deepClone(paragraph.paragraphStyle ?? {}),
				...Tools.deepClone(params.style)
			}
		}]
	};
	Object.defineProperty(paragraphBody, RESTORE_INSERTED_PARAGRAPH_IDS, {
		value: true,
		enumerable: true
	});
	textX.push({
		t: TextXActionType.RETAIN,
		len: 1,
		coverType: UpdateDocsAttributeType.REPLACE,
		body: paragraphBody
	});
	return {
		textX,
		initializesTextRuns
	};
}
const UpdateDocumentParagraphStyleCommand = {
	id: "doc.command.update-paragraph-style",
	type: CommandType.COMMAND,
	handler: (accessor, params) => {
		var _documentDataModel$ge;
		if (!isValidParams(params)) return false;
		const instanceService = accessor.get(IUniverInstanceService);
		const commandService = accessor.get(ICommandService);
		const documentDataModel = instanceService.getUnit(params.unitId, UniverInstanceType.UNIVER_DOC);
		const segmentId = params.segmentId ?? "";
		const body = documentDataModel === null || documentDataModel === void 0 || (_documentDataModel$ge = documentDataModel.getSelfOrHeaderFooterModel(segmentId)) === null || _documentDataModel$ge === void 0 ? void 0 : _documentDataModel$ge.getBody();
		if (!documentDataModel || !body) return false;
		const paragraph = getCurrentParagraph(body, params);
		if (!paragraph) return false;
		const { textX, initializesTextRuns } = createParagraphStyleTextX(body, paragraph, params);
		const jsonX = JSONX.getInstance();
		const path = getRichTextEditPath(documentDataModel, segmentId);
		let actions = jsonX.editOp(textX.serialize(), path);
		if (initializesTextRuns) {
			const initializeTextRunsActions = jsonX.replaceOp([...path, "textRuns"], void 0, [{
				st: params.startOffset,
				ed: params.endOffset,
				ts: Tools.deepClone(params.style.textStyle)
			}]);
			actions = JSONX.compose(initializeTextRunsActions, actions);
		}
		return Boolean(commandService.syncExecuteCommand(RichTextEditingMutation.id, {
			unitId: params.unitId,
			segmentId,
			actions,
			textRanges: null,
			noNeedSetTextRange: true,
			isEditing: false,
			trigger: UpdateDocumentParagraphStyleCommand.id
		}));
	}
};

//#endregion
//#region src/utils/section-columns.ts
function resolveSectionValue(sectionValue, documentValue, fallback) {
	return sectionValue ?? documentValue ?? fallback;
}
function getEffectivePageSize(documentStyle, section) {
	var _section$pageSize, _documentStyle$pageSi, _section$pageSize2, _documentStyle$pageSi2;
	const fallback = PAGE_SIZE[PaperType.A4];
	return {
		width: resolveSectionValue(section === null || section === void 0 || (_section$pageSize = section.pageSize) === null || _section$pageSize === void 0 ? void 0 : _section$pageSize.width, documentStyle === null || documentStyle === void 0 || (_documentStyle$pageSi = documentStyle.pageSize) === null || _documentStyle$pageSi === void 0 ? void 0 : _documentStyle$pageSi.width, fallback.width),
		height: resolveSectionValue(section === null || section === void 0 || (_section$pageSize2 = section.pageSize) === null || _section$pageSize2 === void 0 ? void 0 : _section$pageSize2.height, documentStyle === null || documentStyle === void 0 || (_documentStyle$pageSi2 = documentStyle.pageSize) === null || _documentStyle$pageSi2 === void 0 ? void 0 : _documentStyle$pageSi2.height, fallback.height)
	};
}
function getEffectiveMargins(documentStyle, section) {
	return {
		top: resolveSectionValue(section === null || section === void 0 ? void 0 : section.marginTop, documentStyle === null || documentStyle === void 0 ? void 0 : documentStyle.marginTop, TRADITIONAL_DOCUMENT_DEFAULT_MARGIN),
		bottom: resolveSectionValue(section === null || section === void 0 ? void 0 : section.marginBottom, documentStyle === null || documentStyle === void 0 ? void 0 : documentStyle.marginBottom, TRADITIONAL_DOCUMENT_DEFAULT_MARGIN),
		left: resolveSectionValue(section === null || section === void 0 ? void 0 : section.marginLeft, documentStyle === null || documentStyle === void 0 ? void 0 : documentStyle.marginLeft, TRADITIONAL_DOCUMENT_DEFAULT_MARGIN),
		right: resolveSectionValue(section === null || section === void 0 ? void 0 : section.marginRight, documentStyle === null || documentStyle === void 0 ? void 0 : documentStyle.marginRight, TRADITIONAL_DOCUMENT_DEFAULT_MARGIN)
	};
}
function assertPositivePageSetup(pageSize, contentSize) {
	if (![
		pageSize.width,
		pageSize.height,
		contentSize.width,
		contentSize.height
	].every((value) => Number.isFinite(value) && value > 0)) throw new RangeError("Effective section page setup must leave a positive content area and use finite positive page dimensions.");
}
/** Resolves nominal traditional page geometry without requiring a renderer. */
function getEffectiveSectionPageSetup(documentStyle, section) {
	const pageSize = getEffectivePageSize(documentStyle, section);
	const margins = getEffectiveMargins(documentStyle, section);
	const contentSize = {
		width: getSectionContentWidth(documentStyle, section),
		height: pageSize.height - margins.top - margins.bottom
	};
	assertPositivePageSetup(pageSize, contentSize);
	const pageNumberStart = (section === null || section === void 0 ? void 0 : section.pageNumberStart) ?? (documentStyle === null || documentStyle === void 0 ? void 0 : documentStyle.pageNumberStart);
	return {
		pageSize,
		pageOrient: resolveSectionValue(section === null || section === void 0 ? void 0 : section.pageOrient, documentStyle === null || documentStyle === void 0 ? void 0 : documentStyle.pageOrient, PageOrientType.PORTRAIT),
		margins,
		contentSize,
		...pageNumberStart == null ? {} : { pageNumberStart }
	};
}
/** Returns the usable horizontal layout width for a traditional section. */
function getSectionContentWidth(documentStyle, section) {
	var _section$pageSize3, _documentStyle$pageSi3;
	const pageWidth = resolveSectionValue(section === null || section === void 0 || (_section$pageSize3 = section.pageSize) === null || _section$pageSize3 === void 0 ? void 0 : _section$pageSize3.width, documentStyle === null || documentStyle === void 0 || (_documentStyle$pageSi3 = documentStyle.pageSize) === null || _documentStyle$pageSi3 === void 0 ? void 0 : _documentStyle$pageSi3.width, PAGE_SIZE[PaperType.A4].width);
	return Math.max(0, pageWidth - resolveSectionValue(section === null || section === void 0 ? void 0 : section.marginLeft, documentStyle === null || documentStyle === void 0 ? void 0 : documentStyle.marginLeft, TRADITIONAL_DOCUMENT_DEFAULT_MARGIN) - resolveSectionValue(section === null || section === void 0 ? void 0 : section.marginRight, documentStyle === null || documentStyle === void 0 ? void 0 : documentStyle.marginRight, TRADITIONAL_DOCUMENT_DEFAULT_MARGIN));
}
/** Creates explicit OOXML section columns from a count, gap, and optional widths. */
function createSectionColumnProperties(documentStyle, section, columnCount, gap, widths) {
	if (columnCount <= 1) return [];
	const safeGap = Math.max(0, gap);
	const contentWidth = getSectionContentWidth(documentStyle, section);
	const availableWidth = Math.max(0, contentWidth - safeGap * (columnCount - 1));
	if (widths) {
		if (widths.some((width) => !Number.isFinite(width) || width < 0)) throw new RangeError("Section column widths must be finite and non-negative.");
		if (widths.reduce((sum, width) => sum + width, 0) > availableWidth) throw new RangeError("Section columns exceed the available page content width.");
	}
	return (widths ?? Array.from({ length: columnCount }, () => availableWidth / columnCount)).map((width, index) => ({
		width: Math.max(0, width),
		paddingEnd: index === columnCount - 1 ? 0 : safeGap
	}));
}

//#endregion
//#region src/commands/commands/update-document-section.command.ts
const UpdateDocumentSectionCommand = {
	id: "doc.command.update-section",
	type: CommandType.COMMAND,
	handler: (accessor, params) => {
		if (!(params === null || params === void 0 ? void 0 : params.updates.length) || params.updates.some(({ sectionId, config }) => !sectionId || Object.keys(config).length === 0)) return false;
		const instanceService = accessor.get(IUniverInstanceService);
		const commandService = accessor.get(ICommandService);
		const documentDataModel = instanceService.getUnit(params.unitId, UniverInstanceType.UNIVER_DOC);
		if (!documentDataModel || documentDataModel.getDocumentStyle().documentFlavor !== DocumentFlavor.TRADITIONAL) return false;
		const body = documentDataModel.getBody();
		if (!body) return false;
		const updates = new Map(params.updates.map(({ sectionId, config }) => [sectionId, config]));
		if (updates.size !== params.updates.length) return false;
		const selectedIds = new Set(updates.keys());
		const sections = getTopLevelSectionBreaks(body).filter((section) => selectedIds.has(section.sectionId)).sort((left, right) => left.startIndex - right.startIndex);
		if (sections.length !== selectedIds.size) return false;
		const documentStyle = documentDataModel.getDocumentStyle();
		if (sections.some((section) => !isValidSectionConfig({
			...section,
			...updates.get(section.sectionId)
		}, documentStyle))) return false;
		const cursor = new MemoryCursor();
		const textX = new TextX();
		for (const section of sections) {
			textX.push({
				t: TextXActionType.RETAIN,
				len: section.startIndex - cursor.cursor
			});
			textX.push({
				t: TextXActionType.RETAIN,
				len: 1,
				coverType: UpdateDocsAttributeType.REPLACE,
				body: {
					dataStream: "",
					sectionBreaks: [{
						...Tools.deepClone(section),
						...Tools.deepClone(updates.get(section.sectionId)),
						sectionId: section.sectionId,
						startIndex: 0
					}]
				}
			});
			cursor.moveCursorTo(section.startIndex + 1);
		}
		const jsonX = JSONX.getInstance();
		const mutation = {
			id: RichTextEditingMutation.id,
			params: {
				unitId: params.unitId,
				actions: jsonX.editOp(textX.serialize(), getRichTextEditPath(documentDataModel)),
				textRanges: null,
				noNeedSetTextRange: true,
				debounce: true,
				isEditing: false,
				trigger: UpdateDocumentSectionCommand.id
			}
		};
		return Boolean(commandService.syncExecuteCommand(mutation.id, mutation.params));
	}
};
const InsertDocumentSectionBreakCommand = {
	id: "doc.command.insert-section-break",
	type: CommandType.COMMAND,
	handler: (accessor, params) => {
		var _body$sectionBreaks;
		if (!params) return false;
		const context = getTraditionalDocumentContext(accessor, params.unitId);
		if (!context || !params.sectionId || !Number.isInteger(params.offset) || params.nextSectionType != null && !isValidEnumValue(SectionType, params.nextSectionType)) return false;
		const { body, documentDataModel, commandService } = context;
		const insertedSection = {
			...Tools.deepClone(params.config ?? {}),
			sectionId: params.sectionId,
			startIndex: params.offset
		};
		if (!isValidTopLevelInsertionOffset(body, params.offset) || ((_body$sectionBreaks = body.sectionBreaks) === null || _body$sectionBreaks === void 0 ? void 0 : _body$sectionBreaks.some((section) => section.sectionId === params.sectionId)) || !isValidSectionConfig(insertedSection, documentDataModel.getDocumentStyle())) return false;
		const nextSection = params.nextSectionType == null ? void 0 : getTopLevelSectionBreaks(body).find((section) => section.startIndex >= params.offset);
		if (params.nextSectionType != null && !nextSection) return false;
		const textX = new TextX();
		textX.retain(params.offset);
		textX.insert(1, {
			dataStream: DataStreamTreeTokenType.SECTION_BREAK,
			sectionBreaks: [{
				...insertedSection,
				startIndex: 0
			}]
		});
		if (nextSection && params.nextSectionType != null) {
			textX.retain(nextSection.startIndex - params.offset);
			textX.push({
				t: TextXActionType.RETAIN,
				len: 1,
				coverType: UpdateDocsAttributeType.REPLACE,
				body: {
					dataStream: "",
					sectionBreaks: [{
						...Tools.deepClone(nextSection),
						sectionType: params.nextSectionType,
						startIndex: 0
					}]
				}
			});
		}
		return executeSectionTextX(commandService, documentDataModel, textX, InsertDocumentSectionBreakCommand.id);
	}
};
const InsertDocumentColumnBreakCommand = {
	id: "doc.command.insert-column-break",
	type: CommandType.COMMAND,
	handler: (accessor, params) => {
		if (!params) return false;
		const context = getTraditionalDocumentContext(accessor, params.unitId);
		if (!context || !isValidTopLevelInsertionOffset(context.body, params.offset)) return false;
		const textX = new TextX();
		textX.retain(params.offset);
		textX.insert(1, {
			dataStream: DataStreamTreeTokenType.COLUMN_BREAK,
			customRanges: [{
				startIndex: 0,
				endIndex: 0,
				rangeId: `docx-break-${generateRandomId()}`,
				rangeType: CustomRangeType.CUSTOM,
				wholeEntity: true,
				properties: { breakType: DocxBreakType.COLUMN }
			}]
		});
		return executeSectionTextX(context.commandService, context.documentDataModel, textX, InsertDocumentColumnBreakCommand.id);
	}
};
const DeleteDocumentSectionBreakCommand = {
	id: "doc.command.delete-section-break",
	type: CommandType.COMMAND,
	handler: (accessor, params) => {
		if (!params) return false;
		const context = getTraditionalDocumentContext(accessor, params.unitId);
		if (!context || !params.sectionId) return false;
		const sections = getTopLevelSectionBreaks(context.body);
		if (sections.length <= 1) return false;
		const section = sections.find((item) => item.sectionId === params.sectionId);
		if (!section || section === sections[sections.length - 1]) return false;
		const textX = new TextX();
		textX.retain(section.startIndex);
		textX.delete(1);
		return executeSectionTextX(context.commandService, context.documentDataModel, textX, DeleteDocumentSectionBreakCommand.id);
	}
};
function getTraditionalDocumentContext(accessor, unitId) {
	if (!unitId) return null;
	const documentDataModel = accessor.get(IUniverInstanceService).getUnit(unitId, UniverInstanceType.UNIVER_DOC);
	const body = documentDataModel === null || documentDataModel === void 0 ? void 0 : documentDataModel.getBody();
	if (!documentDataModel || !body || documentDataModel.getDocumentStyle().documentFlavor !== DocumentFlavor.TRADITIONAL) return null;
	return {
		body,
		documentDataModel,
		commandService: accessor.get(ICommandService)
	};
}
function isValidTopLevelInsertionOffset(body, offset) {
	var _body$tables, _body$columnGroups, _body$blockRanges;
	return Number.isInteger(offset) && offset >= 0 && offset <= body.dataStream.length && !((_body$tables = body.tables) === null || _body$tables === void 0 ? void 0 : _body$tables.some((range) => containsInteriorInsertionOffset(getTableRangeInterval(range), offset))) && !((_body$columnGroups = body.columnGroups) === null || _body$columnGroups === void 0 ? void 0 : _body$columnGroups.some((range) => containsInteriorInsertionOffset(getColumnGroupRangeInterval(range), offset))) && !((_body$blockRanges = body.blockRanges) === null || _body$blockRanges === void 0 ? void 0 : _body$blockRanges.some((range) => containsInteriorInsertionOffset(getBlockRangeInterval(range), offset)));
}
function isValidSectionConfig(section, documentStyle) {
	if (section.sectionType != null && !isValidEnumValue(SectionType, section.sectionType)) return false;
	if (section.pageOrient != null && !isValidEnumValue(PageOrientType, section.pageOrient)) return false;
	if (section.columnSeparatorType != null && !isValidEnumValue(ColumnSeparatorType, section.columnSeparatorType)) return false;
	if (section.pageNumberStart != null && (!Number.isInteger(section.pageNumberStart) || section.pageNumberStart < 1)) return false;
	if (section.pageSize && (!isPositiveFinite(section.pageSize.width) || !isPositiveFinite(section.pageSize.height))) return false;
	if ([
		section.marginTop,
		section.marginBottom,
		section.marginLeft,
		section.marginRight
	].some((margin) => margin != null && (!Number.isFinite(margin) || margin < 0))) return false;
	const pageSize = section.pageSize ?? documentStyle.pageSize;
	const marginTop = section.marginTop ?? documentStyle.marginTop ?? 0;
	const marginBottom = section.marginBottom ?? documentStyle.marginBottom ?? 0;
	const marginLeft = section.marginLeft ?? documentStyle.marginLeft ?? 0;
	const marginRight = section.marginRight ?? documentStyle.marginRight ?? 0;
	if ((pageSize === null || pageSize === void 0 ? void 0 : pageSize.width) != null && marginLeft + marginRight >= pageSize.width || (pageSize === null || pageSize === void 0 ? void 0 : pageSize.height) != null && marginTop + marginBottom >= pageSize.height) return false;
	const columns = section.columnProperties ?? [];
	if (columns.some(({ width, paddingEnd }) => !Number.isFinite(width) || !Number.isFinite(paddingEnd) || width < 0 || paddingEnd < 0)) return false;
	return columns.reduce((sum, { width, paddingEnd }) => sum + width + paddingEnd, 0) <= getSectionContentWidth(documentStyle, section);
}
function isPositiveFinite(value) {
	return value != null && Number.isFinite(value) && value > 0;
}
function isValidEnumValue(enumObject, value) {
	return Object.values(enumObject).includes(value);
}
function executeSectionTextX(commandService, documentDataModel, textX, trigger) {
	const actions = JSONX.getInstance().editOp(textX.serialize(), getRichTextEditPath(documentDataModel));
	return Boolean(commandService.syncExecuteCommand(RichTextEditingMutation.id, {
		unitId: documentDataModel.getUnitId(),
		actions,
		textRanges: null,
		noNeedSetTextRange: true,
		debounce: true,
		isEditing: false,
		trigger
	}));
}

//#endregion
//#region src/services/permission/document-permission-rule.model.ts
/**
* Copyright 2023-present DreamNum Co., Ltd.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
let DocumentPermissionRuleModel = class DocumentPermissionRuleModel extends ObjectPermissionRuleModel {
	constructor(resources) {
		super(resources, "DOC_OBJECT_PERMISSION_PLUGIN", UniverInstanceType.UNIVER_DOC, [
			UnitObject.DocumentSection,
			UnitObject.DocumentParagraph,
			UnitObject.DocumentEntity
		]);
	}
};
DocumentPermissionRuleModel = __decorate([__decorateParam(0, IResourceManagerService)], DocumentPermissionRuleModel);

//#endregion
//#region src/commands/mutations/set-document-permission-rule.mutation.ts
const SetDocumentPermissionRuleMutation = {
	id: "doc.mutation.set-permission-rule",
	type: CommandType.MUTATION,
	handler: (accessor, params) => {
		if (!params || !accessor.get(IUniverInstanceService).getUnit(params.unitId, UniverInstanceType.UNIVER_DOC)) return false;
		return accessor.get(DocumentPermissionRuleModel).setRule(params.unitId, params.objectType, params.objectId, params.rule);
	}
};

//#endregion
//#region src/commands/mutations/set-document-permission-rules.mutation.ts
const SetDocumentPermissionRulesMutation = {
	id: "doc.mutation.set-permission-rules",
	type: CommandType.MUTATION,
	handler: (accessor, params) => {
		if (!params || !accessor.get(IUniverInstanceService).getUnit(params.unitId, UniverInstanceType.UNIVER_DOC)) return false;
		return accessor.get(DocumentPermissionRuleModel).setRules(params.unitId, params.rules);
	}
};

//#endregion
//#region src/embed-host-anchor.ts
const EMBED_DOCS_CUSTOM_BLOCK_DEFAULT_COMPONENT_KEY = "UniverEmbedDocsCustomBlock";
const DEFAULT_CUSTOM_BLOCK_SIZE = {
	width: 720,
	height: 360
};
const SHEET_LIKE_CUSTOM_BLOCK_SIZE = {
	width: 960,
	height: 480
};
const SLIDE_CUSTOM_BLOCK_SIZE = {
	width: 720,
	height: 405
};
function createDocsCustomBlockInsertMutation(params) {
	return createRichTextMutation(params.unitId, params.segmentId, createInsertCustomBlockActions(params));
}
function createDocsCustomBlockRemoveMutation(params) {
	return createRichTextMutation(params.unitId, params.segmentId, createRemoveCustomBlockActions(params));
}
function createInsertCustomBlockActions(params) {
	const textX = new TextX();
	if (params.startIndex > 0) textX.push({
		t: TextXActionType.RETAIN,
		len: params.startIndex
	});
	textX.push({
		t: TextXActionType.INSERT,
		body: {
			dataStream: "\b",
			customBlocks: [{
				startIndex: 0,
				blockId: params.blockId
			}]
		},
		len: 1
	});
	return composeActions([toBodyEditActions(textX, params.segmentId), createDrawingInsertActions(params)]);
}
function createRemoveCustomBlockActions(params) {
	const textX = new TextX();
	if (params.startIndex > 0) textX.push({
		t: TextXActionType.RETAIN,
		len: params.startIndex
	});
	textX.push({
		t: TextXActionType.DELETE,
		len: 1
	});
	return composeActions([toBodyEditActions(textX, params.segmentId), createDrawingRemoveActions(params)]);
}
function createDocsCustomBlockDrawing(params) {
	const size = resolveDocsCustomBlockSize(params.childType);
	const isInline = params.interactionMode === "inline";
	return {
		unitId: params.unitId,
		subUnitId: params.unitId,
		drawingId: params.blockId,
		drawingType: DrawingTypeEnum.DRAWING_DOM,
		componentKey: params.componentKey ?? "UniverEmbedDocsCustomBlock",
		data: createEmbedDocsCustomBlockData(params),
		title: params.blockId,
		description: "Univer embedded unit custom block",
		layoutType: isInline ? PositionedObjectLayoutType.INLINE : PositionedObjectLayoutType.WRAP_TOP_AND_BOTTOM,
		allowTransform: false,
		docTransform: {
			size: {
				width: size.width,
				height: size.height
			},
			positionH: {
				relativeFrom: isInline ? ObjectRelativeFromH.PAGE : ObjectRelativeFromH.COLUMN,
				...isInline ? { posOffset: 0 } : { align: AlignTypeH.LEFT }
			},
			positionV: {
				relativeFrom: isInline ? ObjectRelativeFromV.PAGE : ObjectRelativeFromV.PARAGRAPH,
				posOffset: 0
			},
			angle: 0
		},
		transform: {
			left: 0,
			top: 0,
			width: size.width,
			height: size.height
		}
	};
}
function resolveDocsCustomBlockSize(childType) {
	if (childType === UniverInstanceType.UNIVER_SHEET || childType === UniverInstanceType.UNIVER_BASE) return SHEET_LIKE_CUSTOM_BLOCK_SIZE;
	if (childType === UniverInstanceType.UNIVER_SLIDE) return SLIDE_CUSTOM_BLOCK_SIZE;
	return DEFAULT_CUSTOM_BLOCK_SIZE;
}
function isSheetLikeDocsCustomBlockChildType(childType) {
	return childType === UniverInstanceType.UNIVER_SHEET || childType === UniverInstanceType.UNIVER_BASE;
}
function createEmbedDocsCustomBlockData(params) {
	return {
		version: 1,
		embedId: params.embedId ?? params.blockId,
		hostUnitId: params.unitId,
		hostAnchorId: params.blockId,
		childUnitId: params.childUnitId,
		childType: params.childType,
		interactionMode: params.interactionMode ?? "block"
	};
}
function isEmbedDocsCustomBlockData(data) {
	if (!data || typeof data !== "object") return false;
	const candidate = data;
	return candidate.version === 1 && typeof candidate.embedId === "string" && typeof candidate.hostAnchorId === "string";
}
function shouldUseInlineTextSelectionForDocsCustomBlockDrawing(drawing) {
	const data = drawing && typeof drawing === "object" ? drawing.data : void 0;
	if (!isEmbedDocsCustomBlockData(data)) return true;
	return data.interactionMode === "inline";
}
function createRichTextMutation(unitId, segmentId, actions) {
	return {
		id: RichTextEditingMutation.id,
		params: {
			unitId,
			segmentId,
			actions,
			textRanges: [],
			isEditing: false,
			noNeedSetTextRange: true
		}
	};
}
function toBodyEditActions(textX, segmentId) {
	return JSONX.getInstance().editOp(textX.serialize(), segmentId ? [
		"headers",
		segmentId,
		"body"
	] : ["body"]) ?? [];
}
function createDrawingInsertActions(params) {
	if (params.segmentId) return [];
	const jsonX = JSONX.getInstance();
	const drawing = createDocsCustomBlockDrawing(params);
	return composeActions([jsonX.insertOp(["drawings", params.blockId], drawing) ?? [], jsonX.insertOp(["drawingsOrder", params.drawingOrderIndex ?? 0], params.blockId) ?? []]);
}
function createDrawingRemoveActions(params) {
	if (params.segmentId) return [];
	const jsonX = JSONX.getInstance();
	const drawing = createDocsCustomBlockDrawing(params);
	return composeActions([jsonX.removeOp(["drawings", params.blockId], drawing) ?? [], jsonX.removeOp(["drawingsOrder", params.drawingOrderIndex ?? 0], params.blockId) ?? []]);
}
function composeActions(actions) {
	return actions.reduce((composed, action) => {
		if (!action || JSONX.isNoop(action) || action.length === 0) return composed;
		if (!composed || JSONX.isNoop(composed) || composed.length === 0) return action;
		return JSONX.compose(composed, action) ?? [];
	}, []);
}

//#endregion
//#region package.json
var name = "@univerjs/docs";
var version = "1.1.0";

//#endregion
//#region src/config/config.ts
/**
* Copyright 2023-present DreamNum Co., Ltd.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
const DOCS_PLUGIN_CONFIG_KEY = "docs.config";
const configSymbol$1 = Symbol(DOCS_PLUGIN_CONFIG_KEY);
const defaultPluginConfig = {};

//#endregion
//#region src/controllers/custom-range.controller.ts
let DocCustomRangeController = class DocCustomRangeController extends Disposable {
	constructor(_commandService, _textSelectionManagerService, _univerInstanceService) {
		super();
		this._commandService = _commandService;
		this._textSelectionManagerService = _textSelectionManagerService;
		this._univerInstanceService = _univerInstanceService;
		this._initSelectionChange();
	}
	_transformCustomRange(doc, selection, segmentId) {
		var _doc$getSelfOrHeaderF;
		const { startOffset, endOffset, collapsed } = selection;
		const customRanges = (_doc$getSelfOrHeaderF = doc.getSelfOrHeaderFooterModel(selection.segmentId ?? segmentId)) === null || _doc$getSelfOrHeaderF === void 0 || (_doc$getSelfOrHeaderF = _doc$getSelfOrHeaderF.getBody()) === null || _doc$getSelfOrHeaderF === void 0 || (_doc$getSelfOrHeaderF = _doc$getSelfOrHeaderF.customRanges) === null || _doc$getSelfOrHeaderF === void 0 ? void 0 : _doc$getSelfOrHeaderF.filter((range) => {
			const selectsFieldResult = range.rangeType === CustomRangeType.FIELD && !collapsed && startOffset <= range.startIndex + 1 && endOffset >= range.endIndex;
			if (!range.wholeEntity && !selectsFieldResult) return false;
			if (startOffset <= range.startIndex && endOffset > range.endIndex) return false;
			if (collapsed) return range.startIndex < startOffset && range.endIndex >= endOffset;
			return BuildTextUtils.range.isIntersects(startOffset, endOffset - 1, range.startIndex, range.endIndex);
		});
		if (customRanges === null || customRanges === void 0 ? void 0 : customRanges.length) {
			let start = startOffset;
			let end = endOffset;
			customRanges.forEach((range) => {
				start = Math.min(range.startIndex, start);
				end = Math.max(range.endIndex + 1, end);
			});
			return {
				...selection,
				startOffset: start,
				endOffset: end,
				collapsed: start === end
			};
		}
		return selection;
	}
	_initSelectionChange() {
		this.disposeWithMe(this._commandService.onCommandExecuted((commandInfo) => {
			if (commandInfo.id === SetTextSelectionsOperation.id) {
				const params = commandInfo.params;
				const { unitId, ranges, isEditing } = params;
				const doc = this._univerInstanceService.getUnit(unitId);
				if (!doc) return;
				const transformedRanges = ranges.map((range) => this._transformCustomRange(doc, range, params.segmentId));
				if (transformedRanges.some((range, i) => ranges[i] !== range)) this._textSelectionManagerService.replaceDocRanges(transformedRanges, void 0, isEditing);
			}
		}));
	}
};
DocCustomRangeController = __decorate([
	__decorateParam(0, ICommandService),
	__decorateParam(1, Inject(DocSelectionManagerService)),
	__decorateParam(2, IUniverInstanceService)
], DocCustomRangeController);

//#endregion
//#region src/services/permission/document-permission-resolver.ts
const HEADER_FOOTER_REFERENCE_KEYS = [
	"defaultHeaderId",
	"defaultFooterId",
	"firstPageHeaderId",
	"firstPageFooterId",
	"evenPageHeaderId",
	"evenPageFooterId"
];
const documentPermissionResolverIndexCache = /* @__PURE__ */ new WeakMap();
function getDocumentPermissionResolverIndex(documentDataModel) {
	var _getMutationRevision, _snapshot$body;
	const mutationRevision = ((_getMutationRevision = documentDataModel.getMutationRevision) === null || _getMutationRevision === void 0 ? void 0 : _getMutationRevision.call(documentDataModel)) ?? NaN;
	const cached = documentPermissionResolverIndexCache.get(documentDataModel);
	if ((cached === null || cached === void 0 ? void 0 : cached.mutationRevision) === mutationRevision) return cached;
	const snapshot = documentDataModel.getSnapshot();
	const topLevelSections = snapshot.body ? getTopLevelSectionBreaks(snapshot.body) : [];
	const drawingSegmentIds = /* @__PURE__ */ new Map();
	const addDrawingSegments = (body, segmentId) => {
		for (const block of (body === null || body === void 0 ? void 0 : body.customBlocks) ?? []) if (!drawingSegmentIds.has(block.blockId)) drawingSegmentIds.set(block.blockId, segmentId);
	};
	addDrawingSegments(snapshot.body, "");
	Object.entries(snapshot.headers ?? {}).forEach(([segmentId, header]) => addDrawingSegments(header.body, segmentId));
	Object.entries(snapshot.footers ?? {}).forEach(([segmentId, footer]) => addDrawingSegments(footer.body, segmentId));
	Object.entries(snapshot.notes ?? {}).forEach(([segmentId, footnote]) => addDrawingSegments(footnote.body, segmentId));
	const footnoteReferenceRanges = /* @__PURE__ */ new Map();
	for (const reference of ((_snapshot$body = snapshot.body) === null || _snapshot$body === void 0 ? void 0 : _snapshot$body.customRanges) ?? []) {
		var _reference$properties;
		if ((reference.rangeType === CustomRangeType.FOOTNOTE || reference.rangeType === CustomRangeType.ENDNOTE) && typeof ((_reference$properties = reference.properties) === null || _reference$properties === void 0 ? void 0 : _reference$properties.noteId) === "string") footnoteReferenceRanges.set(reference.properties.noteId, {
			startOffset: reference.startIndex,
			endOffset: reference.endIndex + 1
		});
	}
	const index = {
		drawingSegmentIds,
		footnoteReferenceRanges,
		mutationRevision,
		segments: /* @__PURE__ */ new Map(),
		topLevelSections
	};
	documentPermissionResolverIndexCache.set(documentDataModel, index);
	return index;
}
function getDocumentPermissionSegmentIndex(documentDataModel, segmentId, resolverIndex = getDocumentPermissionResolverIndex(documentDataModel)) {
	var _documentDataModel$ge, _snapshot$notes;
	const cached = resolverIndex.segments.get(segmentId);
	if (cached) return cached;
	const body = ((_documentDataModel$ge = documentDataModel.getSelfOrHeaderFooterModel(segmentId)) === null || _documentDataModel$ge === void 0 ? void 0 : _documentDataModel$ge.getBody()) ?? null;
	const snapshot = documentDataModel.getSnapshot();
	const note = (_snapshot$notes = snapshot.notes) === null || _snapshot$notes === void 0 ? void 0 : _snapshot$notes[segmentId];
	const drawings = (note ? note.drawings : snapshot.drawings) ?? {};
	const entities = body == null ? [] : [
		...(body.tables ?? []).map((item) => ({
			type: "table",
			id: item.tableId,
			startOffset: item.startIndex,
			endOffset: item.endIndex
		})),
		...(body.customBlocks ?? []).map((item) => ({
			type: drawings[item.blockId] ? "drawing" : "custom-block",
			id: item.blockId,
			startOffset: item.startIndex,
			endOffset: item.startIndex + 1
		})),
		...(body.blockRanges ?? []).map((item) => ({
			type: "block-range",
			id: item.blockId,
			startOffset: item.startIndex,
			endOffset: item.endIndex + 1
		})),
		...(body.customRanges ?? []).map((item) => ({
			type: "custom-range",
			id: item.rangeId,
			startOffset: item.startIndex,
			endOffset: item.endIndex + 1
		})),
		...(body.columnGroups ?? []).map((item) => ({
			type: "column-group",
			id: item.columnGroupId,
			startOffset: item.startIndex,
			endOffset: item.endIndex + 1
		}))
	];
	const entityRanges = new Map(entities.map((entity) => [`${entity.type}:${entity.id}`, {
		startOffset: entity.startOffset,
		endOffset: entity.endOffset
	}]));
	for (const block of (body === null || body === void 0 ? void 0 : body.customBlocks) ?? []) {
		const range = {
			startOffset: block.startIndex,
			endOffset: block.startIndex + 1
		};
		entityRanges.set(`custom-block:${block.blockId}`, range);
		entityRanges.set(`drawing:${block.blockId}`, range);
	}
	const segmentIndex = {
		body,
		entities,
		entityRanges,
		paragraphContentStartOffsets: body == null ? /* @__PURE__ */ new Map() : getParagraphContentStartOffsets(body),
		paragraphsById: new Map(((body === null || body === void 0 ? void 0 : body.paragraphs) ?? []).filter((paragraph) => paragraph.paragraphId != null).map((paragraph) => [paragraph.paragraphId, paragraph]))
	};
	resolverIndex.segments.set(segmentId, segmentIndex);
	return segmentIndex;
}
function getDocumentDrawingSegmentId(documentDataModel, drawingId) {
	return getDocumentPermissionResolverIndex(documentDataModel).drawingSegmentIds.get(drawingId) ?? "";
}
function getDocumentEditTargetObjectIds(documentDataModel, segmentId, range) {
	const resolverIndex = getDocumentPermissionResolverIndex(documentDataModel);
	const segmentIndex = getDocumentPermissionSegmentIndex(documentDataModel, segmentId, resolverIndex);
	const { body } = segmentIndex;
	if (!body) return [];
	return [
		...getSectionPermissionObjectIds(documentDataModel, segmentId, range, resolverIndex),
		...getParagraphPermissionObjectIds(body, segmentId, range, segmentIndex),
		...getEntityPermissionObjectIds(segmentId, range, segmentIndex)
	];
}
function getDocumentEditTargetObjectIdsFromActions(documentDataModel, segmentId, actions) {
	const result = /* @__PURE__ */ new Set();
	if (actions == null) return [];
	const cursor = JSON1.type.readCursor(actions);
	cursor.traverse(null, () => {
		const path = cursor.getPath();
		const edit = cursor.getComponent();
		const scopedSegment = [
			"headers",
			"footers",
			"notes"
		].includes(String(path[0])) && typeof path[1] === "string" ? path[1] : segmentId;
		if (path[0] === "notes" && typeof path[1] === "string") getSectionPermissionObjectIds(documentDataModel, path[1], {
			startOffset: 0,
			endOffset: 0
		}).forEach((objectId) => result.add(objectId));
		if (path[0] === "noteSettings") getDocumentPermissionResolverIndex(documentDataModel).topLevelSections.forEach((section) => {
			result.add(getDocumentSectionPermissionObjectId("", section.sectionId));
		});
		if (path[0] === "body" && path[1] === "sectionBreaks" && typeof path[2] === "number" && (path[3] === "noteProperties" || path[3] === "suppressEndnotes")) {
			var _documentDataModel$ge2;
			const sectionId = (_documentDataModel$ge2 = documentDataModel.getBody()) === null || _documentDataModel$ge2 === void 0 || (_documentDataModel$ge2 = _documentDataModel$ge2.sectionBreaks) === null || _documentDataModel$ge2 === void 0 || (_documentDataModel$ge2 = _documentDataModel$ge2[path[2]]) === null || _documentDataModel$ge2 === void 0 ? void 0 : _documentDataModel$ge2.sectionId;
			if (sectionId) result.add(getDocumentSectionPermissionObjectId("", sectionId));
		}
		if (path[path.length - 1] !== "body" || (edit === null || edit === void 0 ? void 0 : edit.et) !== TextX.id || !Array.isArray(edit.e) || !edit.e.every(isTextXAction)) return;
		const textActions = edit.e;
		let offset = 0;
		const addRange = (startOffset, endOffset) => {
			getDocumentEditTargetObjectIds(documentDataModel, scopedSegment, {
				startOffset,
				endOffset
			}).forEach((objectId) => result.add(objectId));
		};
		textActions.forEach((action) => {
			if (action.t === TextXActionType.INSERT) {
				addRange(offset, offset);
				return;
			}
			if (action.t === TextXActionType.DELETE) {
				addRange(offset, offset + action.len);
				offset += action.len;
				return;
			}
			if (action.body !== void 0 || action.oldBody !== void 0 || action.coverType !== void 0) addRange(offset, offset + action.len);
			offset += action.len;
		});
	});
	getDrawingIdsFromActions(actions).forEach((drawingId) => {
		var _documentDataModel$ge3, _body$customBlocks;
		result.add(getDocumentEntityPermissionObjectId(segmentId, "drawing", drawingId));
		const body = (_documentDataModel$ge3 = documentDataModel.getSelfOrHeaderFooterModel(segmentId)) === null || _documentDataModel$ge3 === void 0 ? void 0 : _documentDataModel$ge3.getBody();
		const block = body === null || body === void 0 || (_body$customBlocks = body.customBlocks) === null || _body$customBlocks === void 0 ? void 0 : _body$customBlocks.find((item) => item.blockId === drawingId);
		if (block) getSectionPermissionObjectIds(documentDataModel, segmentId, {
			startOffset: block.startIndex,
			endOffset: block.startIndex + 1
		}).forEach((objectId) => result.add(objectId));
	});
	return [...result];
}
function getDrawingIdsFromActions(actions) {
	const result = /* @__PURE__ */ new Set();
	const visit = (value) => {
		if (Array.isArray(value)) {
			value.forEach((item, index) => {
				if (item === "drawings" && typeof value[index + 1] === "string") result.add(value[index + 1]);
				visit(item);
			});
			return;
		}
		if (!isRecord$2(value)) return;
		Object.values(value).forEach(visit);
	};
	visit(actions);
	return [...result];
}
function isTextXAction(value) {
	if (!isRecord$2(value) || typeof value.len !== "number") return false;
	if (value.t === TextXActionType.INSERT) return isRecord$2(value.body);
	return value.t === TextXActionType.RETAIN || value.t === TextXActionType.DELETE;
}
function isRecord$2(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function getDocumentEntityParentPermissionObjectIds(documentDataModel, segmentId, entityType, entityId) {
	const resolverIndex = getDocumentPermissionResolverIndex(documentDataModel);
	const range = getDocumentPermissionSegmentIndex(documentDataModel, segmentId, resolverIndex).entityRanges.get(`${entityType}:${entityId}`) ?? null;
	return range ? getSectionPermissionObjectIds(documentDataModel, segmentId, range, resolverIndex) : [];
}
function getDocumentParagraphParentPermissionObjectIds(documentDataModel, segmentId, paragraphId) {
	const resolverIndex = getDocumentPermissionResolverIndex(documentDataModel);
	const segmentIndex = getDocumentPermissionSegmentIndex(documentDataModel, segmentId, resolverIndex);
	const { body } = segmentIndex;
	const paragraph = segmentIndex.paragraphsById.get(paragraphId);
	if (!body || !paragraph) return [];
	return getSectionPermissionObjectIds(documentDataModel, segmentId, {
		startOffset: segmentIndex.paragraphContentStartOffsets.get(paragraph.startIndex) ?? getParagraphContentStartOffset(body, paragraph),
		endOffset: paragraph.startIndex + 1
	}, resolverIndex);
}
function getDocumentSectionPermissionObjectIdsByIds(sectionIds) {
	return Array.from(sectionIds, (sectionId) => getDocumentSectionPermissionObjectId("", sectionId));
}
function getDocumentSectionIdsAtOffset(body, offset) {
	return getSectionsIntersectingRange(getTopLevelSectionBreaks(body), {
		startOffset: offset,
		endOffset: offset
	}).map((section) => section.sectionId);
}
function getSectionPermissionObjectIds(documentDataModel, segmentId, range, resolverIndex = getDocumentPermissionResolverIndex(documentDataModel)) {
	if (segmentId) {
		const referenceRange = resolverIndex.footnoteReferenceRanges.get(segmentId);
		if (referenceRange) return getDocumentEditTargetObjectIds(documentDataModel, "", referenceRange);
		return getHeaderFooterOwnerSectionIds(documentDataModel, segmentId, resolverIndex.topLevelSections).map((sectionId) => getDocumentSectionPermissionObjectId("", sectionId));
	}
	return getSectionsIntersectingRange(resolverIndex.topLevelSections, range).map((section) => getDocumentSectionPermissionObjectId("", section.sectionId));
}
function getParagraphPermissionObjectIds(body, segmentId, range, segmentIndex) {
	const startOffset = Math.min(range.startOffset, range.endOffset);
	const endOffset = Math.max(range.startOffset, range.endOffset);
	return (body.paragraphs ?? []).filter((paragraph) => intersectsRange(segmentIndex.paragraphContentStartOffsets.get(paragraph.startIndex) ?? getParagraphContentStartOffset(body, paragraph), paragraph.startIndex + 1, startOffset, endOffset)).flatMap((paragraph) => paragraph.paragraphId ? [getDocumentParagraphPermissionObjectId(segmentId, paragraph.paragraphId)] : []);
}
function getEntityPermissionObjectIds(segmentId, range, segmentIndex) {
	const startOffset = Math.min(range.startOffset, range.endOffset);
	const endOffset = Math.max(range.startOffset, range.endOffset);
	return segmentIndex.entities.filter((item) => intersectsRange(item.startOffset, item.endOffset, startOffset, endOffset)).map((item) => getDocumentEntityPermissionObjectId(segmentId, item.type, item.id));
}
function getSectionsIntersectingRange(sections, range) {
	const startOffset = Math.min(range.startOffset, range.endOffset);
	const endOffset = Math.max(range.startOffset, range.endOffset);
	return sections.filter((section, index) => intersectsRange(index === 0 ? 0 : sections[index - 1].startIndex + 1, section.startIndex + 1, startOffset, endOffset));
}
function intersectsRange(targetStart, targetEnd, rangeStart, rangeEnd) {
	if (rangeStart === rangeEnd) return rangeStart >= targetStart && rangeStart < targetEnd;
	return rangeStart < targetEnd && rangeEnd > targetStart;
}
function getHeaderFooterOwnerSectionIds(documentDataModel, segmentId, sections = getDocumentPermissionResolverIndex(documentDataModel).topLevelSections) {
	const snapshot = documentDataModel.getSnapshot();
	const result = /* @__PURE__ */ new Set();
	sections.forEach((section, sectionIndex) => {
		if (HEADER_FOOTER_REFERENCE_KEYS.some((key) => resolveSectionHeaderFooterReference(snapshot.documentStyle, sections, sectionIndex, key).segmentId === segmentId)) result.add(section.sectionId);
	});
	return [...result];
}

//#endregion
//#region src/controllers/doc-permission.controller.ts
const NON_EDIT_DOCUMENT_COMMAND_IDS = /* @__PURE__ */ new Set([
	SetDocumentPermissionCommand.id,
	SetDocumentPermissionsCommand.id,
	"doc.command.open-header-footer-panel",
	"doc.command.close-header-footer",
	"doc.command.select-all",
	"doc.command.set-zoom-ratio"
]);
const DERIVED_DOCUMENT_MUTATION_IDS = /* @__PURE__ */ new Set(["docs-formula.mutation.set-last-values"]);
let DocPermissionController = class DocPermissionController extends Disposable {
	constructor(_injector, _commandService, _permissionService, _univerInstanceService) {
		super();
		this._injector = _injector;
		this._commandService = _commandService;
		this._permissionService = _permissionService;
		this._univerInstanceService = _univerInstanceService;
		this._univerInstanceService.getAllUnitsForType(UniverInstanceType.UNIVER_DOC).forEach((unit) => this._registerUnitPermissionPoints(unit.getUnitId()));
		this.disposeWithMe(this._univerInstanceService.getTypeOfUnitAdded$(UniverInstanceType.UNIVER_DOC).subscribe(({ unit }) => this._registerUnitPermissionPoints(unit.getUnitId())));
		this.disposeWithMe(this._commandService.beforeCommandExecuted((commandInfo, options) => {
			this._check(commandInfo, options);
		}));
		this.disposeWithMe(this._univerInstanceService.getTypeOfUnitDisposed$(UniverInstanceType.UNIVER_DOC).subscribe((unit) => {
			this._injector.get(ObjectPermissionService).clearUnit(unit.getUnitId());
			clearDocumentPermissionValuesForUnit(this._permissionService, unit.getUnitId());
		}));
	}
	_registerUnitPermissionPoints(unitId) {
		DOCUMENT_UNIT_PERMISSION_ACTIONS.forEach((action) => {
			const point = createDocumentPermissionPoint(unitId, unitId, action);
			if (!this._permissionService.getPermissionPoint(point.id)) this._permissionService.addPermissionPoint(point);
		});
		this._injector.get(ObjectPermissionService).initializeUnit({
			unitId,
			objectId: unitId,
			objectType: UnitObject.Document
		});
	}
	_check(commandInfo, options) {
		var _this$_univerInstance;
		if ((options === null || options === void 0 ? void 0 : options.fromCollab) || (options === null || options === void 0 ? void 0 : options.fromChangeset)) return;
		const unitAction = getDocumentUnitAction(commandInfo.id);
		const unitId = getUnitId(commandInfo, options) ?? (unitAction ? (_this$_univerInstance = this._univerInstanceService.getCurrentUnitOfType(UniverInstanceType.UNIVER_DOC)) === null || _this$_univerInstance === void 0 ? void 0 : _this$_univerInstance.getUnitId() : void 0);
		if (!unitId || this._univerInstanceService.getUnitType(unitId) !== UniverInstanceType.UNIVER_DOC) return;
		if (unitAction) {
			if (!getDocumentPermissionValue(this._permissionService, unitId, unitId, unitAction)) {
				this._injector.get(ErrorService).emitPermissionDenied(unitId);
				throw new CustomCommandExecutionError(`Document ${UnitAction[unitAction]} permission denied.`);
			}
			return;
		}
		const documentDataModel = this._univerInstanceService.getUnit(unitId, UniverInstanceType.UNIVER_DOC);
		if (!documentDataModel) return;
		const targetObjectIds = this._resolveTargetObjectIds(documentDataModel, commandInfo);
		if (targetObjectIds === null) return;
		if (!canEditDocumentTargets(this._permissionService, unitId, targetObjectIds)) {
			this._injector.get(ErrorService).emitPermissionDenied(unitId, targetObjectIds);
			throw new CustomCommandExecutionError("Document edit permission denied.");
		}
	}
	_resolveTargetObjectIds(documentDataModel, commandInfo) {
		if (commandInfo.id === RichTextEditingMutation.id) {
			const params = commandInfo.params;
			return getDocumentEditTargetObjectIdsFromActions(documentDataModel, params.segmentId ?? "", params.actions);
		}
		if (commandInfo.id === DocsRenameMutation.id) return [];
		if (isDerivedDocumentMutation(commandInfo)) return null;
		const knownTargets = resolveTextTargets(documentDataModel, commandInfo) ?? resolveSectionTargets(documentDataModel, commandInfo);
		if (knownTargets) return knownTargets;
		const entityTargets = resolveEntityTargets(documentDataModel, commandInfo);
		if (entityTargets.length) return entityTargets;
		return isDocumentEditCommand(commandInfo.id) || isDocumentDataMutation(commandInfo) ? [] : null;
	}
};
DocPermissionController = __decorate([
	__decorateParam(0, Inject(Injector)),
	__decorateParam(1, ICommandService),
	__decorateParam(2, IPermissionService),
	__decorateParam(3, IUniverInstanceService)
], DocPermissionController);
function isDocumentEditCommand(id) {
	if (NON_EDIT_DOCUMENT_COMMAND_IDS.has(id)) return false;
	return id.startsWith("doc.command.") || id.startsWith("docs.command.") || id.startsWith("doc.command-") || id.startsWith("doc.table.");
}
function isDocumentDataMutation(commandInfo) {
	const { id } = commandInfo;
	if (isDerivedDocumentMutation(commandInfo)) return false;
	return id.startsWith("doc.mutation.") || id.startsWith("docs.mutation.") || /^docs-[^.]+\.mutation\./.test(id);
}
function isDerivedDocumentMutation(commandInfo) {
	const params = isRecord$1(commandInfo.params) ? commandInfo.params : void 0;
	return DERIVED_DOCUMENT_MUTATION_IDS.has(commandInfo.id) || commandInfo.id === "doc.mutation.update-shape-data" && !!(params === null || params === void 0 ? void 0 : params.formulaLastValueGuard);
}
function resolveEntityTargets(documentDataModel, commandInfo) {
	const params = commandInfo.params;
	if (!isRecord$1(params)) return [];
	const result = /* @__PURE__ */ new Set();
	const add = (segmentId, entityType, entityId) => {
		result.add(getDocumentEntityPermissionObjectId(segmentId, entityType, entityId));
		getDocumentEntityParentPermissionObjectIds(documentDataModel, segmentId, entityType, entityId).forEach((objectId) => result.add(objectId));
	};
	collectEntityReferences(params).forEach(({ entityType, entityId }) => {
		const explicitSegmentId = params.segmentId;
		const segmentId = typeof explicitSegmentId === "string" ? explicitSegmentId : entityType === "drawing" || entityType === "custom-block" ? getDocumentDrawingSegmentId(documentDataModel, entityId) : "";
		add(segmentId, entityType, entityId);
	});
	return [...result];
}
function collectEntityReferences(value) {
	const result = /* @__PURE__ */ new Map();
	const typeByKey = {
		blockId: ["custom-block"],
		drawingId: ["drawing"],
		shapeId: ["drawing", "custom-block"],
		tableId: ["table"],
		rangeId: ["custom-range"],
		columnGroupId: ["column-group"]
	};
	const visit = (candidate, key = "") => {
		if (typeof candidate === "string") {
			var _typeByKey$key;
			(_typeByKey$key = typeByKey[key]) === null || _typeByKey$key === void 0 || _typeByKey$key.forEach((entityType) => {
				result.set(`${entityType}\u001F${candidate}`, {
					entityType,
					entityId: candidate
				});
			});
			return;
		}
		if (Array.isArray(candidate)) {
			const singularKey = key.endsWith("Ids") ? `${key.slice(0, -3)}Id` : key;
			candidate.forEach((item) => visit(item, singularKey));
			return;
		}
		if (!isRecord$1(candidate)) return;
		Object.entries(candidate).forEach(([childKey, child]) => visit(child, childKey));
	};
	visit(value);
	return [...result.values()];
}
function getUnitId(commandInfo, options) {
	const params = isRecord$1(commandInfo.params) ? commandInfo.params : void 0;
	return typeof (params === null || params === void 0 ? void 0 : params.unitId) === "string" ? params.unitId : typeof (options === null || options === void 0 ? void 0 : options.unitId) === "string" ? options.unitId : void 0;
}
function getDocumentUnitAction(commandId) {
	if (commandId === "doc.command.copy-current-paragraph" || commandId === "docs-table.command.copy-selection") return UnitAction.Copy;
	if (commandId === "docs.operation.print") return UnitAction.Print;
	if (commandId === "docs-exchange-client.operation.export-doc") return UnitAction.Export;
	if (commandId === "docs.operation.start-add-comment" || commandId === "docs.operation.add-drawing-comment" || commandId.startsWith("docs.command.") && commandId.includes("comment") || commandId.startsWith("thread-comment.command.") || commandId.startsWith("thread-comment.mutation.")) return UnitAction.Comment;
}
function resolveTextTargets(documentDataModel, commandInfo) {
	const { id } = commandInfo;
	if (id === InsertTextCommand.id || id === UpdateTextCommand.id) {
		const params = commandInfo.params;
		return getDocumentEditTargetObjectIds(documentDataModel, params.segmentId ?? "", params.range);
	}
	if (id === DeleteTextCommand.id) {
		const params = commandInfo.params;
		const isDeleteLeft = params.direction === DeleteDirection.LEFT;
		return getDocumentEditTargetObjectIds(documentDataModel, params.segmentId ?? "", {
			startOffset: isDeleteLeft ? params.range.startOffset - (params.len ?? 1) : params.range.startOffset,
			endOffset: isDeleteLeft ? params.range.startOffset : params.range.startOffset + (params.len ?? 1)
		});
	}
	if (id === UpdateDocumentParagraphStyleCommand.id) {
		const params = commandInfo.params;
		return getDocumentEditTargetObjectIds(documentDataModel, params.segmentId ?? "", params);
	}
	return null;
}
function resolveSectionTargets(documentDataModel, commandInfo) {
	const { id } = commandInfo;
	if (id === UpdateDocumentSectionCommand.id) {
		const params = commandInfo.params;
		return getDocumentSectionPermissionObjectIdsByIds(params.updates.map((update) => update.sectionId));
	}
	if (id === InsertDocumentSectionBreakCommand.id || id === InsertDocumentColumnBreakCommand.id) {
		const params = commandInfo.params;
		const body = documentDataModel.getBody();
		return body ? getDocumentSectionPermissionObjectIdsByIds(getDocumentSectionIdsAtOffset(body, params.offset)) : [];
	}
	if (id === DeleteDocumentSectionBreakCommand.id) {
		const params = commandInfo.params;
		const body = documentDataModel.getBody();
		const sections = body ? getTopLevelSectionBreaks(body) : [];
		const index = sections.findIndex((section) => section.sectionId === params.sectionId);
		return getDocumentSectionPermissionObjectIdsByIds([params.sectionId, ...index >= 0 && index + 1 < sections.length ? [sections[index + 1].sectionId] : []]);
	}
	if (id === SetSectionHeaderFooterLinkCommand.id) {
		const params = commandInfo.params;
		return [getDocumentSectionPermissionObjectId("", params.sectionId)];
	}
	if (id === CreateHeaderFooterCommand.id) {
		const params = commandInfo.params;
		return params.sectionId ? [getDocumentSectionPermissionObjectId("", params.sectionId)] : [];
	}
	return null;
}
function isRecord$1(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}

//#endregion
//#region src/services/doc-block-move-validator.service.ts
var DocBlockMoveValidatorService = class extends Disposable {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "_validators", []);
		_defineProperty(this, "_transformers", []);
	}
	registerValidator(validator) {
		this._validators.push(validator);
		return this.disposeWithMe(toDisposable(() => remove(this._validators, validator)));
	}
	registerTransformer(transformer) {
		this._transformers.push(transformer);
		return this.disposeWithMe(toDisposable(() => remove(this._transformers, transformer)));
	}
	canMoveBlock(context) {
		return this._validators.every((validator) => validator(context));
	}
	transformMoveResult(context) {
		return this._transformers.reduce((result, transformer) => transformer({
			...context,
			result
		}), context.result);
	}
};

//#endregion
//#region src/services/doc-content-insert.service.ts
/**
* Copyright 2023-present DreamNum Co., Ltd.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var DocContentInsertService = class extends Disposable {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "_range", null);
	}
	setInsertRange(range) {
		this._range = range;
	}
	consumeInsertRange(unitId) {
		if (!this._range) return null;
		if (unitId && this._range.unitId !== unitId) return null;
		const range = this._range;
		this._range = null;
		return range;
	}
	clearInsertRange() {
		this._range = null;
	}
};

//#endregion
//#region src/services/doc-state-change-manager.service.ts
const DEBOUNCE_DELAY = 300;
const IDocStateChangeInterceptorService = createIdentifier("doc.state-change-interceptor-service");
let DocStateChangeManagerService = class DocStateChangeManagerService extends RxDisposable {
	constructor(_undoRedoService, _commandService, _univerInstanceService, _docStateEmitService, _docStateChangeInterceptorService) {
		super();
		this._undoRedoService = _undoRedoService;
		this._commandService = _commandService;
		this._univerInstanceService = _univerInstanceService;
		this._docStateEmitService = _docStateEmitService;
		this._docStateChangeInterceptorService = _docStateChangeInterceptorService;
		_defineProperty(this, "_docStateChange$", new BehaviorSubject(null));
		_defineProperty(this, "docStateChange$", this._docStateChange$.asObservable());
		_defineProperty(this, "_historyStateCache", /* @__PURE__ */ new Map());
		_defineProperty(this, "_changeStateCache", /* @__PURE__ */ new Map());
		_defineProperty(this, "_historyTimer", null);
		_defineProperty(this, "_changeStateCacheTimer", null);
		this._initialize();
		this._listenDocStateChange();
	}
	dispose() {
		if (this._historyTimer != null) {
			clearTimeout(this._historyTimer);
			this._historyTimer = null;
		}
		if (this._changeStateCacheTimer != null) {
			clearTimeout(this._changeStateCacheTimer);
			this._changeStateCacheTimer = null;
		}
		this._historyStateCache.clear();
		this._changeStateCache.clear();
		this._docStateChange$.complete();
		super.dispose();
	}
	getStateCache(unitId) {
		return {
			history: this._historyStateCache.get(unitId) ?? [],
			collaboration: this._changeStateCache.get(unitId) ?? []
		};
	}
	setStateCache(unitId, cache) {
		this._historyStateCache.set(unitId, cache.history);
		this._changeStateCache.set(unitId, cache.collaboration);
	}
	clearHistory(unitId) {
		this._historyStateCache.delete(unitId);
	}
	flushPendingChanges(unitId) {
		this._pushHistory(unitId);
		this._emitChangeState(unitId);
	}
	_setChangeState(changeState) {
		this._cacheChangeState(changeState, "history");
		this._cacheChangeState(changeState, "collaboration");
	}
	_initialize() {
		this.disposeWithMe(this._commandService.beforeCommandExecuted((command) => {
			if (command.id === UndoCommandId || command.id === RedoCommandId) {
				const univerDoc = this._univerInstanceService.getCurrentUnitOfType(UniverInstanceType.UNIVER_DOC);
				if (univerDoc == null) return;
				const unitId = univerDoc.getUnitId();
				this._pushHistory(unitId);
				this._emitChangeState(unitId);
			}
		}));
	}
	_listenDocStateChange() {
		this._docStateEmitService.docStateChangeParams$.pipe(takeUntil(this.dispose$)).subscribe((changeStateInfo) => {
			var _this$_docStateChange;
			if (changeStateInfo == null) return;
			const interceptedChangeStateInfo = ((_this$_docStateChange = this._docStateChangeInterceptorService) === null || _this$_docStateChange === void 0 ? void 0 : _this$_docStateChange.transformChangeStateInfo(changeStateInfo)) ?? changeStateInfo;
			if (interceptedChangeStateInfo == null) return;
			if (interceptedChangeStateInfo.isSync) return;
			const { isCompositionEnd: _isCompositionEnd, isSync: _isSync, syncer: _syncer, ...changeState } = interceptedChangeStateInfo;
			this._setChangeState(changeState);
		});
	}
	_cacheChangeState(changeState, type = "history") {
		const { trigger, unitId, noHistory, debounce = false } = changeState;
		if (noHistory || type === "history" && trigger == null) return;
		if (type === "history" && (trigger === RedoCommandId || trigger === UndoCommandId)) return;
		const stateCache = type === "history" ? this._historyStateCache : this._changeStateCache;
		const cb = type === "history" ? this._pushHistory.bind(this) : this._emitChangeState.bind(this);
		const pendingStates = stateCache.get(unitId);
		if ((pendingStates === null || pendingStates === void 0 ? void 0 : pendingStates.length) && pendingStates[pendingStates.length - 1].segmentId !== changeState.segmentId) cb(unitId);
		if (stateCache.has(unitId)) {
			const cacheStates = stateCache.get(unitId);
			cacheStates === null || cacheStates === void 0 || cacheStates.push(changeState);
		} else stateCache.set(unitId, [changeState]);
		if (debounce) {
			if (type === "history") {
				if (this._historyTimer) clearTimeout(this._historyTimer);
				this._historyTimer = setTimeout(() => {
					cb(unitId);
				}, DEBOUNCE_DELAY);
			} else {
				if (this._changeStateCacheTimer) clearTimeout(this._changeStateCacheTimer);
				this._changeStateCacheTimer = setTimeout(() => {
					cb(unitId);
				}, DEBOUNCE_DELAY);
			}
		} else cb(unitId);
	}
	_pushHistory(unitId) {
		const undoRedoService = this._undoRedoService;
		const cacheStates = this._historyStateCache.get(unitId);
		if (undoRedoService == null || !Array.isArray(cacheStates) || cacheStates.length === 0) return;
		const len = cacheStates.length;
		const commandId = cacheStates[0].commandId;
		const firstState = cacheStates[0];
		const lastState = cacheStates[len - 1];
		const redoParams = {
			unitId,
			trigger: RedoCommandId,
			...lastState.redoState.layoutState === void 0 ? {} : { layoutState: lastState.redoState.layoutState },
			actions: cacheStates.reduce((acc, cur) => JSONX.compose(acc, cur.redoState.actions), null),
			textRanges: lastState.redoState.textRanges,
			segmentId: lastState.segmentId,
			options: lastState.redoState.options,
			isEditing: lastState.redoState.isEditing
		};
		const undoParams = {
			unitId,
			trigger: UndoCommandId,
			...firstState.undoState.layoutState === void 0 ? {} : { layoutState: firstState.undoState.layoutState },
			actions: cacheStates.reverse().reduce((acc, cur) => JSONX.compose(acc, cur.undoState.actions), null),
			textRanges: firstState.undoState.textRanges,
			segmentId: firstState.segmentId,
			options: firstState.undoState.options,
			isEditing: firstState.undoState.isEditing
		};
		undoRedoService.pushUndoRedo({
			unitID: unitId,
			undoMutations: [{
				id: commandId,
				params: undoParams
			}],
			redoMutations: [{
				id: commandId,
				params: redoParams
			}]
		});
		cacheStates.length = 0;
	}
	_emitChangeState(unitId) {
		const cacheStates = this._changeStateCache.get(unitId);
		if (!Array.isArray(cacheStates) || cacheStates.length === 0) return;
		const len = cacheStates.length;
		const { commandId, trigger, segmentId, noHistory, debounce } = cacheStates[0];
		const firstState = cacheStates[0];
		const lastState = cacheStates[len - 1];
		const changeState = {
			commandId,
			unitId,
			trigger,
			redoState: {
				unitId,
				actions: cacheStates.reduce((acc, cur) => JSONX.compose(acc, cur.redoState.actions), null),
				textRanges: lastState.redoState.textRanges,
				segmentId: lastState.segmentId,
				options: lastState.redoState.options,
				isEditing: lastState.redoState.isEditing
			},
			undoState: {
				unitId,
				actions: cacheStates.reverse().reduce((acc, cur) => JSONX.compose(acc, cur.undoState.actions), null),
				textRanges: firstState.undoState.textRanges,
				segmentId: firstState.segmentId,
				options: firstState.undoState.options,
				isEditing: firstState.undoState.isEditing
			},
			segmentId,
			noHistory,
			debounce
		};
		cacheStates.length = 0;
		this._docStateChange$.next(changeState);
	}
};
DocStateChangeManagerService = __decorate([
	__decorateParam(0, Optional(IUndoRedoService)),
	__decorateParam(1, ICommandService),
	__decorateParam(2, IUniverInstanceService),
	__decorateParam(3, Inject(DocStateEmitService)),
	__decorateParam(4, Optional(IDocStateChangeInterceptorService))
], DocStateChangeManagerService);

//#endregion
//#region src/services/doc-text-resolver.service.ts
/**
* Builds a consumer-facing text projection while retaining a mapping back to
* the native document offsets.
*
* Consumers such as find/replace can search the projected text and then use
* `characters` to focus the native object that supplied a matching character.
* Resolvers must return half-open, non-overlapping replacements.
*/
var DocTextResolverService = class extends Disposable {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "_resolvers", /* @__PURE__ */ new Set());
		_defineProperty(this, "_textChanged$", new Subject());
		_defineProperty(this, "textChanged$", this._textChanged$.asObservable());
	}
	register(resolver) {
		this._resolvers.add(resolver);
		return toDisposable(() => this._resolvers.delete(resolver));
	}
	notifyTextChanged(unitId) {
		this._textChanged$.next(unitId);
	}
	resolve(unitId, body) {
		const replacements = this._collectReplacements(unitId, body);
		const characters = [];
		let text = "";
		let sourceOffset = 0;
		for (const replacement of replacements) {
			const sourceText = body.dataStream.slice(sourceOffset, replacement.startOffset);
			text += sourceText;
			for (let index = sourceOffset; index < replacement.startOffset; index += 1) characters.push({
				startOffset: index,
				endOffset: index + 1,
				replaceable: true
			});
			text += replacement.text;
			for (let index = 0; index < replacement.text.length; index += 1) characters.push({
				startOffset: replacement.startOffset,
				endOffset: replacement.endOffset,
				replaceable: replacement.replaceable ?? false
			});
			sourceOffset = replacement.endOffset;
		}
		text += body.dataStream.slice(sourceOffset);
		for (let index = sourceOffset; index < body.dataStream.length; index += 1) characters.push({
			startOffset: index,
			endOffset: index + 1,
			replaceable: true
		});
		return {
			characters,
			text
		};
	}
	_collectReplacements(unitId, body) {
		const candidates = [...this._resolvers].flatMap((resolver) => resolver.resolve(unitId, body)).filter((replacement) => Number.isInteger(replacement.startOffset) && Number.isInteger(replacement.endOffset) && replacement.startOffset >= 0 && replacement.endOffset > replacement.startOffset && replacement.endOffset <= body.dataStream.length).sort((left, right) => left.startOffset - right.startOffset || right.endOffset - left.endOffset);
		const replacements = [];
		let previousEnd = -1;
		for (const candidate of candidates) {
			if (candidate.startOffset < previousEnd) continue;
			replacements.push(candidate);
			previousEnd = candidate.endOffset;
		}
		return replacements;
	}
	dispose() {
		this._textChanged$.complete();
		super.dispose();
	}
};

//#endregion
//#region src/plugin.ts
let UniverDocsPlugin = class UniverDocsPlugin extends Plugin {
	constructor(_config = defaultPluginConfig, _injector, _configService) {
		super();
		this._config = _config;
		this._injector = _injector;
		this._configService = _configService;
		const { ...rest } = merge({}, defaultPluginConfig, this._config);
		this._configService.setConfig(DOCS_PLUGIN_CONFIG_KEY, rest);
	}
	onStarting() {
		this._injector.add([DocumentPermissionRuleModel]);
		this.disposeWithMe(this._injector.get(ICommandService).registerCommand(SetDocumentPermissionRuleMutation));
		this.disposeWithMe(this._injector.get(ICommandService).registerCommand(SetDocumentPermissionRulesMutation));
		this.disposeWithMe(this._injector.get(ObjectPermissionService).registerRuleModel(UnitObject.Document, this._injector.get(DocumentPermissionRuleModel), SetDocumentPermissionRuleMutation.id, SetDocumentPermissionRulesMutation.id));
		this._initializeDependencies();
		this._initializeCommands();
		this._initializeWordResources();
	}
	_initializeWordResources() {
		for (const pluginName of ["DOC_WORD_STYLES_PLUGIN", "DOC_NOTE_PLUGIN"]) {
			const resources = /* @__PURE__ */ new Map();
			this.disposeWithMe({ dispose: () => resources.clear() });
			this.disposeWithMe(this._injector.get(IResourceManagerService).registerPluginResource({
				pluginName,
				businesses: [UniverInstanceType.UNIVER_DOC],
				parseJson: (data) => data,
				onLoad: (unitId, data) => {
					resources.set(unitId, data);
				},
				onUnLoad: (unitId) => {
					resources.delete(unitId);
				},
				toJson: (unitId) => resources.get(unitId) ?? ""
			}));
		}
	}
	_initializeCommands() {
		[
			InsertTextCommand,
			DeleteTextCommand,
			UpdateTextCommand,
			CreateHeaderFooterCommand,
			SetDocumentPermissionCommand,
			SetDocumentPermissionsCommand,
			SetDocumentDefaultParagraphStyleCommand,
			SetDocumentNameCommand,
			SetSectionHeaderFooterLinkCommand,
			UpdateDocumentParagraphStyleCommand,
			UpdateDocumentSectionCommand,
			InsertDocumentSectionBreakCommand,
			InsertDocumentColumnBreakCommand,
			DeleteDocumentSectionBreakCommand,
			RichTextEditingMutation,
			DocsRenameMutation,
			SetTextSelectionsOperation
		].forEach((command) => {
			this._injector.get(ICommandService).registerCommand(command);
		});
	}
	_initializeDependencies() {
		[
			[DocSelectionManagerService],
			[DocStateEmitService],
			[DocStateChangeManagerService],
			[DocBlockMoveValidatorService],
			[DocContentInsertService],
			[DocLayoutExecutorService],
			[DocTextResolverService],
			[DocCustomRangeController],
			[DocPermissionController]
		].forEach((d) => this._injector.add(d));
	}
	onReady() {
		this._injector.get(DocStateChangeManagerService);
		this._injector.get(DocCustomRangeController);
		this._injector.get(DocPermissionController);
	}
};
_defineProperty(UniverDocsPlugin, "pluginName", "DOCS_PLUGIN");
_defineProperty(UniverDocsPlugin, "packageName", name);
_defineProperty(UniverDocsPlugin, "version", version);
UniverDocsPlugin = __decorate([__decorateParam(1, Inject(Injector)), __decorateParam(2, IConfigService)], UniverDocsPlugin);

//#endregion
//#region src/layout-worker/config/config.ts
/**
* Copyright 2023-present DreamNum Co., Ltd.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
const DOCS_LAYOUT_WORKER_PLUGIN_CONFIG_KEY = "docs-layout-worker.config";
const configSymbol = Symbol(DOCS_LAYOUT_WORKER_PLUGIN_CONFIG_KEY);
const DEFAULT_DOCS_LAYOUT_WORKER_REQUEST_TIMEOUT_MS = 15e3;
const defaultPluginDocsLayoutWorkerConfig = { requestTimeoutMs: DEFAULT_DOCS_LAYOUT_WORKER_REQUEST_TIMEOUT_MS };

//#endregion
//#region src/layout-worker/document-font-metrics.ts
/**
* Copyright 2023-present DreamNum Co., Ltd.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Collect once from the snapshot, then only from mutation payloads (including JSON1 font replacements). */
function collectDocumentFontFamilies(value, families) {
	if (value == null || typeof value !== "object") return;
	if (Array.isArray(value)) {
		for (let index = 0; index < value.length; index++) {
			const item = value[index];
			if (value[index - 1] === "ff" && item != null && typeof item === "object" && typeof item.i === "string") families.add(item.i);
			collectDocumentFontFamilies(item, families);
		}
		return;
	}
	const textStyle = value;
	if (typeof textStyle.eastAsiaFontFamily === "string" && textStyle.eastAsiaFontFamily.trim()) {
		const primary = typeof textStyle.ff === "string" && textStyle.ff.trim() ? textStyle.ff : DEFAULT_STYLES.ff;
		families.add(`${primary}, ${textStyle.eastAsiaFontFamily.trim()}`);
		families.add(`${textStyle.eastAsiaFontFamily.trim()}, ${primary}, ${textStyle.eastAsiaFontFamily.trim()}`);
	}
	for (const [key, item] of Object.entries(value)) if (key === "ff" && typeof item === "string") families.add(item);
	else collectDocumentFontFamilies(item, families);
}
function measureDocumentFontFamilies(families) {
	FontCache.getNormalLineHeight(getFontStyleString());
	for (const ff of ["", ...families]) for (const bl of [BooleanNumber.FALSE, BooleanNumber.TRUE]) for (const it of [BooleanNumber.FALSE, BooleanNumber.TRUE]) FontCache.getNormalLineHeight(getFontStyleString({
		ff,
		bl,
		it
	}));
	return FontCache.getNormalLineHeightCache();
}

//#endregion
//#region src/layout-worker/font-loader.ts
/** Owns the same explicitly supplied font faces in the rendering and layout realms. */
var DocsLayoutFontLoader = class extends Disposable {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "_loading", null);
		_defineProperty(this, "_fontSet", void 0);
		_defineProperty(this, "_faces", []);
	}
	load(fonts) {
		this._loading ??= this._load(fonts);
		return this._loading;
	}
	dispose() {
		for (const face of this._faces) {
			var _this$_fontSet;
			(_this$_fontSet = this._fontSet) === null || _this$_fontSet === void 0 || _this$_fontSet.delete(face);
		}
		if (this._faces.length > 0) FontCache.invalidateMetrics(() => true);
		this._faces = [];
		this._fontSet = void 0;
		super.dispose();
	}
	async _load(fonts) {
		this.ensureNotDisposed();
		if (fonts.length === 0) return;
		const fontSet = typeof document === "undefined" ? globalThis.fonts : document.fonts;
		if (typeof FontFace === "undefined" || fontSet == null) throw new Error("Document layout requires FontFace support to load the configured fonts.");
		try {
			const faces = fonts.map(({ family, source, descriptors }) => {
				if (!family.trim() || (typeof source === "string" ? !source.trim() : source.byteLength === 0)) throw new TypeError("Document layout font family and source must not be empty.");
				return new FontFace(family, source, descriptors);
			});
			await Promise.all(faces.map((face) => face.load()));
			this.ensureNotDisposed();
			this._fontSet = fontSet;
			this._faces = faces;
			for (const face of faces) fontSet.add(face);
			FontCache.invalidateMetrics(() => true);
		} catch (error) {
			this.dispose();
			throw error;
		}
	}
};

//#endregion
//#region src/layout-worker/performance-tracker.ts
const PERFORMANCE_SAMPLE_LIMIT = 2048;
function isRecord(value) {
	return typeof value === "object" && value != null;
}
function getRequest(message) {
	if (!isRecord(message) || typeof message.method !== "string" || !Array.isArray(message.args)) return null;
	const request = message.args[0];
	return isRecord(request) ? {
		method: message.method,
		request
	} : null;
}
function getPublicationResult(message) {
	if (!isRecord(message) || !isRecord(message.data)) return null;
	const result = message.data;
	if (isRecord(result.step)) return result.step;
	return result;
}
function createTransferMetrics() {
	return {
		mutationTransferMs: [],
		patchTransferMs: [],
		snapshotTransferMs: []
	};
}
var DocsLayoutWorkerPerformanceTracker = class {
	constructor() {
		_defineProperty(this, "_metrics", /* @__PURE__ */ new Map());
	}
	recordRequest(message, durationMs) {
		const requestInfo = getRequest(message);
		const unitId = requestInfo === null || requestInfo === void 0 ? void 0 : requestInfo.request.unitId;
		if (requestInfo == null || typeof unitId !== "string") return;
		if (requestInfo.method === "createSession") {
			this._append(unitId, "snapshotTransferMs", durationMs);
			return;
		}
		if (requestInfo.method === "startLayout" && Array.isArray(requestInfo.request.mutations) && requestInfo.request.mutations.length > 0) this._append(unitId, "mutationTransferMs", durationMs);
	}
	recordResponse(message, durationMs) {
		const result = getPublicationResult(message);
		if (result == null || typeof result.unitId !== "string" || result.publication == null) return;
		this._append(result.unitId, "patchTransferMs", durationMs);
	}
	getMetrics(unitId) {
		const metrics = this._metrics.get(unitId) ?? createTransferMetrics();
		return {
			mutationTransferMs: [...metrics.mutationTransferMs],
			patchTransferMs: [...metrics.patchTransferMs],
			snapshotTransferMs: [...metrics.snapshotTransferMs]
		};
	}
	reset(unitId) {
		this._metrics.delete(unitId);
	}
	resetAll() {
		this._metrics.clear();
	}
	_append(unitId, metric, durationMs) {
		const metrics = this._metrics.get(unitId) ?? createTransferMetrics();
		const samples = metrics[metric];
		samples.push(durationMs);
		if (samples.length > PERFORMANCE_SAMPLE_LIMIT) samples.splice(0, samples.length - PERFORMANCE_SAMPLE_LIMIT);
		this._metrics.set(unitId, metrics);
	}
};

//#endregion
//#region src/layout-worker/protocol.ts
const DOCS_LAYOUT_WORKER_CHANNEL = "univer.docs-layout-worker";

//#endregion
//#region src/layout-worker/worker.ts
const FONT_PROBE_CONTENT = "Univer 文档 Worker 0123456789";
const FONT_PROBE_STYLE = "16px Arial";
const WORKER_LAYOUT_INTERRUPT_INTERVAL = 8;
function yieldForWorkerMessage() {
	return new Promise((resolve) => {
		requestImmediateMacroTask(() => resolve());
	});
}
function createDocsLayoutWorkerMessageProtocol$1(performanceTracker) {
	return {
		send(message) {
			const startedAt = Tools.now();
			postMessage(message);
			performanceTracker.recordResponse(message, Tools.now() - startedAt);
		},
		onMessage: new Observable((subscriber) => {
			const handler = (event) => subscriber.next(event.data);
			addEventListener("message", handler);
			return () => removeEventListener("message", handler);
		}).pipe(shareReplay({
			bufferSize: 1,
			refCount: true
		}))
	};
}
function getCustomRangePresentationKey(entry) {
	return JSON.stringify([entry.segmentId, entry.rangeId]);
}
function applyRecordPatch(target, patch) {
	if (patch == null) return;
	for (const key of patch.removals) delete target[key];
	Object.assign(target, patch.upserts);
}
var DocsLayoutWorkerRuntime = class {
	constructor(_performanceTracker = new DocsLayoutWorkerPerformanceTracker()) {
		this._performanceTracker = _performanceTracker;
		_defineProperty(this, "_sessions", /* @__PURE__ */ new Map());
		_defineProperty(this, "_fontLoader", new DocsLayoutFontLoader());
		_defineProperty(this, "type", "worker");
	}
	initialize(fontFaces = []) {
		return this._fontLoader.load(fontFaces);
	}
	async getCapabilities() {
		const metrics = FontCache.getMeasureText(FONT_PROBE_CONTENT, FONT_PROBE_STYLE);
		return {
			protocolVersion: 5,
			executor: "worker",
			offscreenCanvas: typeof OffscreenCanvas !== "undefined",
			structuredClone: typeof structuredClone === "function",
			fontProbe: {
				content: FONT_PROBE_CONTENT,
				font: FONT_PROBE_STYLE,
				width: metrics.width,
				actualBoundingBoxAscent: metrics.actualBoundingBoxAscent,
				actualBoundingBoxDescent: metrics.actualBoundingBoxDescent
			}
		};
	}
	async recover() {
		for (const session of this._sessions.values()) for (const mount of session.layoutSessions.values()) mount.layoutSession.dispose();
		this._sessions.clear();
	}
	async createSession(request) {
		if (typeof OffscreenCanvas === "undefined") throw new Error("Document layout Worker requires OffscreenCanvas text measurement support.");
		const currentSession = this._sessions.get(request.unitId);
		if (currentSession != null && request.sessionEpoch < currentSession.sessionEpoch) return;
		this._disposeSession(request.unitId);
		FontCache.setNormalLineHeightCache(request.normalFontLineHeights ?? {});
		const dataModel = new DocumentDataModel(request.snapshot);
		const localeService = new LocaleService();
		if (request.localeData != null) localeService.load({ [request.locale]: request.localeData });
		localeService.setLocale(request.locale);
		localeService.setDirection(request.direction);
		this._sessions.set(request.unitId, {
			sessionEpoch: request.sessionEpoch,
			dataModel,
			layoutSessions: /* @__PURE__ */ new Map(),
			localeService,
			modelRevision: request.modelRevision,
			customRangePresentations: /* @__PURE__ */ new Map()
		});
	}
	async startLayout(request) {
		const session = this._sessions.get(request.unitId);
		if (session == null) return { status: "not-found" };
		if (session.modelRevision !== request.baseRevision) return {
			status: "resnapshot-required",
			modelRevision: session.modelRevision
		};
		if (!this._applyMutations(session, request)) return {
			status: "resnapshot-required",
			modelRevision: session.modelRevision
		};
		FontCache.setNormalLineHeightCache(request.normalFontLineHeights ?? {});
		this._updateCustomRangePresentations(session, request);
		this._applyCustomRangePresentations(session.dataModel, Array.from(session.customRangePresentations.values()));
		let mount = session.layoutSessions.get(request.mountId);
		if (mount != null && (request.mountEpoch < mount.mountEpoch || request.mountEpoch === mount.mountEpoch && request.viewportEpoch < mount.viewportEpoch)) return { status: "superseded" };
		if (mount != null && request.mountEpoch > mount.mountEpoch) {
			mount.layoutSession.dispose();
			session.layoutSessions.delete(request.mountId);
			mount = void 0;
		}
		if (mount == null) {
			const customBlockViewports = { ...request.customBlockViewports };
			applyRecordPatch(customBlockViewports, request.customBlockViewportPatch);
			mount = {
				mountId: request.mountId,
				layoutSession: new DocumentLayoutSession(session.dataModel, session.localeService),
				customBlockViewports,
				metricsRevision: request.metricsRevision,
				mountEpoch: request.mountEpoch,
				viewportEpoch: request.viewportEpoch,
				activeGeneration: null,
				cancelledGeneration: null
			};
			session.layoutSessions.set(request.mountId, mount);
		} else {
			if (request.customBlockViewports != null) mount.customBlockViewports = { ...request.customBlockViewports };
			applyRecordPatch(mount.customBlockViewports, request.customBlockViewportPatch);
			mount.metricsRevision = request.metricsRevision;
			mount.viewportEpoch = request.viewportEpoch;
		}
		const generation = mount.layoutSession.start({
			waitForHyphenationPatterns: true,
			reason: request.reason,
			anchor: request.anchor,
			priorityAnchor: request.priorityAnchor,
			invalidation: request.invalidation,
			modernPageWidth: request.modernPageWidth,
			modernHorizontalMargin: request.modernHorizontalMargin
		});
		mount.activeGeneration = generation;
		mount.cancelledGeneration = null;
		return {
			status: "accepted",
			step: await this._runLayoutStep(session, mount, generation, request.budgetMs)
		};
	}
	_applyMutations(session, request) {
		for (const mutation of request.mutations) {
			if (mutation.baseRevision !== session.modelRevision || mutation.modelRevision !== mutation.baseRevision + 1) return false;
			session.dataModel.apply(mutation.actions);
			session.modelRevision = mutation.modelRevision;
		}
		if (session.modelRevision !== request.modelRevision) return false;
		if (request.mutations.length > 0) for (const mount of session.layoutSessions.values()) {
			mount.activeGeneration = null;
			mount.cancelledGeneration = null;
			mount.layoutSession.resetDataModel(session.dataModel);
		}
		return true;
	}
	_applyCustomRangePresentations(dataModel, presentations) {
		const rangeMaps = /* @__PURE__ */ new Map();
		const segmentModels = [
			["", dataModel],
			...dataModel.headerModelMap,
			...dataModel.footerModelMap
		];
		for (const [segmentId, segmentModel] of segmentModels) {
			var _segmentModel$getBody;
			const rangeMap = /* @__PURE__ */ new Map();
			for (const range of ((_segmentModel$getBody = segmentModel.getBody()) === null || _segmentModel$getBody === void 0 ? void 0 : _segmentModel$getBody.customRanges) ?? []) {
				const workerRange = range;
				delete workerRange.active;
				delete workerRange.glyphAscentEm;
				delete workerRange.glyphDescentEm;
				delete workerRange.glyphWidthEm;
				delete workerRange.show;
				if (!rangeMap.has(range.rangeId)) rangeMap.set(range.rangeId, workerRange);
			}
			rangeMaps.set(segmentId, rangeMap);
		}
		for (const { segmentId, rangeId, presentation } of presentations ?? []) {
			const rangeMap = rangeMaps.get(segmentId);
			const range = rangeMap === null || rangeMap === void 0 ? void 0 : rangeMap.get(rangeId);
			if (range != null) {
				Object.assign(range, presentation);
				rangeMap === null || rangeMap === void 0 || rangeMap.delete(rangeId);
			}
		}
	}
	_updateCustomRangePresentations(session, request) {
		var _request$customRangeP, _request$customRangeP2;
		if (request.customRangePresentations != null) {
			session.customRangePresentations.clear();
			for (const entry of request.customRangePresentations) {
				const key = getCustomRangePresentationKey(entry);
				if (!session.customRangePresentations.has(key)) session.customRangePresentations.set(key, entry);
			}
		}
		for (const removal of ((_request$customRangeP = request.customRangePresentationPatch) === null || _request$customRangeP === void 0 ? void 0 : _request$customRangeP.removals) ?? []) session.customRangePresentations.delete(getCustomRangePresentationKey(removal));
		for (const entry of ((_request$customRangeP2 = request.customRangePresentationPatch) === null || _request$customRangeP2 === void 0 ? void 0 : _request$customRangeP2.upserts) ?? []) session.customRangePresentations.set(getCustomRangePresentationKey(entry), entry);
	}
	async stepLayout(request) {
		const session = this._getSession(request.unitId);
		const mount = this._getLayoutMount(session, request);
		return await this._runLayoutStep(session, mount, request.generation, request.budgetMs);
	}
	async publishBacklog(request) {
		const session = this._getSession(request.unitId);
		const mount = this._getLayoutMount(session, request);
		return this._runWithCustomBlockViewports(session, mount, () => ({
			...mount.layoutSession.publishBacklog(request.generation),
			unitId: request.unitId,
			mountId: request.mountId,
			mountEpoch: mount.mountEpoch,
			viewportEpoch: mount.viewportEpoch,
			modelRevision: session.modelRevision,
			metricsRevision: mount.metricsRevision
		}));
	}
	async getLayoutPage(request) {
		const session = this._getSession(request.unitId);
		const mount = this._getLayoutMount(session, request);
		return {
			...request,
			modelRevision: session.modelRevision,
			metricsRevision: mount.metricsRevision,
			page: mount.layoutSession.getPage(request.pageIndex)
		};
	}
	async cancelLayout(request) {
		var _this$_sessions$get;
		const mount = (_this$_sessions$get = this._sessions.get(request.unitId)) === null || _this$_sessions$get === void 0 ? void 0 : _this$_sessions$get.layoutSessions.get(request.mountId);
		if ((mount === null || mount === void 0 ? void 0 : mount.mountEpoch) === request.mountEpoch && mount.viewportEpoch === request.viewportEpoch) {
			if (request.generation == null || request.generation === mount.activeGeneration) mount.cancelledGeneration = request.generation ?? mount.activeGeneration;
			mount.layoutSession.cancel(request.generation);
		}
	}
	async getPerformanceMetrics(unitId) {
		return this._performanceTracker.getMetrics(unitId);
	}
	async resetPerformanceMetrics(unitId) {
		this._performanceTracker.reset(unitId);
	}
	async disposeLayoutMount(request) {
		const session = this._sessions.get(request.unitId);
		const mount = session === null || session === void 0 ? void 0 : session.layoutSessions.get(request.mountId);
		if (session == null || mount == null || mount.mountEpoch !== request.mountEpoch || mount.viewportEpoch !== request.viewportEpoch) return;
		session.layoutSessions.delete(request.mountId);
		mount.activeGeneration = null;
		mount.layoutSession.dispose();
	}
	async disposeSession(request) {
		const session = this._sessions.get(request.unitId);
		if ((session === null || session === void 0 ? void 0 : session.sessionEpoch) !== request.sessionEpoch) return;
		this._disposeSession(request.unitId);
		this._performanceTracker.reset(request.unitId);
	}
	dispose() {
		this._fontLoader.dispose();
		for (const unitId of this._sessions.keys()) this._disposeSession(unitId);
		this._performanceTracker.resetAll();
	}
	_getSession(unitId) {
		const session = this._sessions.get(unitId);
		if (session == null) throw new Error(`Document layout Worker session not found for unit "${unitId}".`);
		return session;
	}
	_getLayoutMount(session, request) {
		const mount = session.layoutSessions.get(request.mountId);
		if (mount == null) throw new Error(`Document layout Worker mount not found: "${request.mountId}".`);
		if (mount.mountEpoch !== request.mountEpoch || mount.viewportEpoch !== request.viewportEpoch) throw new Error(`Document layout Worker rejected a stale mount publication: "${request.mountId}".`);
		return mount;
	}
	async _runLayoutStep(session, mount, generation, budgetMs) {
		const result = this._runWithCustomBlockViewports(session, mount, () => ({
			...mount.layoutSession.step(generation, budgetMs, WORKER_LAYOUT_INTERRUPT_INTERVAL),
			unitId: session.dataModel.getUnitId(),
			mountId: mount.mountId,
			mountEpoch: mount.mountEpoch,
			viewportEpoch: mount.viewportEpoch,
			modelRevision: session.modelRevision,
			metricsRevision: mount.metricsRevision
		}));
		await yieldForWorkerMessage();
		if (mount.activeGeneration === generation && mount.cancelledGeneration !== generation) return result;
		return this._runWithCustomBlockViewports(session, mount, () => ({
			...mount.layoutSession.step(generation, 0, 1),
			unitId: session.dataModel.getUnitId(),
			mountId: mount.mountId,
			mountEpoch: mount.mountEpoch,
			viewportEpoch: mount.viewportEpoch,
			modelRevision: session.modelRevision,
			metricsRevision: mount.metricsRevision
		}));
	}
	_runWithCustomBlockViewports(session, mount, run) {
		const unregister = setDocsCustomBlockRenderViewportProvider((unitId, blockId) => unitId === session.dataModel.getUnitId() ? mount.customBlockViewports[blockId] : null);
		try {
			return run();
		} finally {
			unregister();
		}
	}
	_disposeSession(unitId) {
		const session = this._sessions.get(unitId);
		if (session == null) return;
		this._sessions.delete(unitId);
		for (const mount of session.layoutSessions.values()) {
			mount.activeGeneration = null;
			mount.layoutSession.dispose();
		}
		session.layoutSessions.clear();
		session.dataModel.dispose();
		session.localeService.dispose();
	}
};
var DocsLayoutWorkerChannelService = class extends ChannelService {
	constructor(protocol, _runtime) {
		super(protocol);
		this._runtime = _runtime;
	}
	dispose() {
		this._runtime.dispose();
		super.dispose();
	}
};
function startDocsLayoutWorker() {
	const performanceTracker = new DocsLayoutWorkerPerformanceTracker();
	const runtime = new DocsLayoutWorkerRuntime(performanceTracker);
	const channelService = new DocsLayoutWorkerChannelService(createDocsLayoutWorkerMessageProtocol$1(performanceTracker), runtime);
	channelService.registerChannel(DOCS_LAYOUT_WORKER_CHANNEL, fromModule(runtime));
	return channelService;
}

//#endregion
//#region src/layout-worker/index.ts
const FONT_METRICS_TOLERANCE = 1;
var DocsLayoutWorkerCapabilityError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "DocsLayoutWorkerCapabilityError";
	}
};
function createDocsLayoutWorkerMessageProtocol(worker, performanceTracker) {
	return {
		send(message) {
			const startedAt = Tools.now();
			worker.postMessage(message);
			performanceTracker.recordRequest(message, Tools.now() - startedAt);
		},
		onMessage: new Observable((subscriber) => {
			const handler = (event) => subscriber.next(event.data);
			worker.addEventListener("message", handler);
			return () => worker.removeEventListener("message", handler);
		}).pipe(shareReplay({
			bufferSize: 1,
			refCount: true
		}))
	};
}
var DocsLayoutWorkerClientService = class extends Disposable {
	constructor(_workerFactory, _requestTimeoutMs = DEFAULT_DOCS_LAYOUT_WORKER_REQUEST_TIMEOUT_MS, _fontFaces = []) {
		super();
		this._workerFactory = _workerFactory;
		this._requestTimeoutMs = _requestTimeoutMs;
		this._fontFaces = _fontFaces;
		_defineProperty(this, "type", "worker");
		_defineProperty(this, "_worker", null);
		_defineProperty(this, "_channelService", null);
		_defineProperty(this, "_runtime", null);
		_defineProperty(this, "_initialization", void 0);
		_defineProperty(this, "_initialized", false);
		_defineProperty(this, "_performanceTracker", new DocsLayoutWorkerPerformanceTracker());
		_defineProperty(this, "_fontFamilies", /* @__PURE__ */ new Map());
		_defineProperty(this, "_fontLoader", new DocsLayoutFontLoader());
		this.disposeWithMe(this._fontLoader);
		this._initialization = this._replaceRuntime();
	}
	initialize() {
		return this._initialization;
	}
	get renderingFontsReady() {
		return this._fontFaces.length > 0 ? this._initialization : void 0;
	}
	async getCapabilities() {
		await this._initialization;
		return this._getRuntime().getCapabilities();
	}
	async recover() {
		this._initialization = this._replaceRuntime();
		await this._initialization;
	}
	createSession(request) {
		const families = /* @__PURE__ */ new Set();
		collectDocumentFontFamilies(request.snapshot, families);
		this._fontFamilies.set(request.unitId, families);
		const measuredRequest = {
			...request,
			normalFontLineHeights: measureDocumentFontFamilies(families)
		};
		if (this._initialized) return this._withTimeout(this._getRuntime().createSession(measuredRequest), "create session");
		const capturedRequest = Tools.deepClone(measuredRequest);
		return this._initialization.then(() => this._withTimeout(this._getRuntime().createSession(capturedRequest), "create session"));
	}
	async startLayout(request) {
		await this._initialization;
		const families = this._fontFamilies.get(request.unitId);
		if (families != null) collectDocumentFontFamilies(request.mutations, families);
		const measuredRequest = families == null ? request : {
			...request,
			normalFontLineHeights: measureDocumentFontFamilies(families)
		};
		return this._withTimeout(this._getRuntime().startLayout(measuredRequest), "start layout");
	}
	async stepLayout(request) {
		await this._initialization;
		return this._withTimeout(this._getRuntime().stepLayout(request), "step layout");
	}
	async publishBacklog(request) {
		await this._initialization;
		return this._withTimeout(this._getRuntime().publishBacklog(request), "publish layout backlog");
	}
	async getLayoutPage(request) {
		await this._initialization;
		return this._withTimeout(this._getRuntime().getLayoutPage(request), "get layout page");
	}
	async cancelLayout(request) {
		await this._initialization;
		return this._withTimeout(this._getRuntime().cancelLayout(request), "cancel layout");
	}
	async getPerformanceMetrics(unitId) {
		await this._initialization;
		const workerMetrics = await this._withTimeout(this._getRuntime().getPerformanceMetrics(unitId), "read performance metrics");
		const clientMetrics = this._performanceTracker.getMetrics(unitId);
		return {
			mutationTransferMs: clientMetrics.mutationTransferMs,
			patchTransferMs: workerMetrics.patchTransferMs,
			snapshotTransferMs: clientMetrics.snapshotTransferMs
		};
	}
	async resetPerformanceMetrics(unitId) {
		await this._initialization;
		await this._withTimeout(this._getRuntime().resetPerformanceMetrics(unitId), "reset performance metrics");
		this._performanceTracker.reset(unitId);
	}
	async disposeLayoutMount(request) {
		await this._initialization;
		return this._withTimeout(this._getRuntime().disposeLayoutMount(request), "dispose layout mount");
	}
	async disposeSession(request) {
		await this._initialization;
		await this._withTimeout(this._getRuntime().disposeSession(request), "dispose session");
		this._performanceTracker.reset(request.unitId);
		this._fontFamilies.delete(request.unitId);
	}
	dispose() {
		this._disposeRuntime();
		super.dispose();
	}
	async _replaceRuntime() {
		this._initialized = false;
		this._disposeRuntime();
		await this._withTimeout(this._fontLoader.load(this._fontFaces), "load rendering fonts");
		this.ensureNotDisposed();
		const worker = this._workerFactory();
		const channelService = new ChannelService(createDocsLayoutWorkerMessageProtocol(worker, this._performanceTracker));
		this._worker = worker;
		this._channelService = channelService;
		this._runtime = toModule(channelService.requestChannel(DOCS_LAYOUT_WORKER_CHANNEL));
		try {
			await this._withTimeout(this._runtime.initialize(this._fontFaces), "load Worker fonts");
			await this._withTimeout(this._verifyCapabilities(), "verify capabilities");
			this.ensureNotDisposed();
			this._initialized = true;
		} catch (error) {
			if (this._worker === worker) this._disposeRuntime();
			throw error;
		}
	}
	_disposeRuntime() {
		var _this$_channelService, _this$_worker;
		this._fontFamilies.clear();
		this._initialized = false;
		(_this$_channelService = this._channelService) === null || _this$_channelService === void 0 || _this$_channelService.dispose();
		this._channelService = null;
		this._runtime = null;
		(_this$_worker = this._worker) === null || _this$_worker === void 0 || _this$_worker.terminate();
		this._worker = null;
		this._performanceTracker.resetAll();
	}
	_getRuntime() {
		if (this._runtime == null) throw new Error("Document layout Worker runtime is unavailable.");
		return this._runtime;
	}
	_withTimeout(task, operation) {
		let timeoutId = null;
		const timeout = new Promise((_resolve, reject) => {
			timeoutId = setTimeout(() => {
				reject(/* @__PURE__ */ new Error(`Document layout Worker timed out while attempting to ${operation}.`));
			}, this._requestTimeoutMs);
		});
		return Promise.race([task, timeout]).finally(() => {
			if (timeoutId != null) clearTimeout(timeoutId);
		});
	}
	async _verifyCapabilities() {
		const capabilities = await this._getRuntime().getCapabilities();
		if (capabilities.protocolVersion !== 5) throw new DocsLayoutWorkerCapabilityError("Document layout Worker protocol version mismatch.");
		if (!capabilities.offscreenCanvas || !capabilities.structuredClone) throw new DocsLayoutWorkerCapabilityError("Document layout Worker requires OffscreenCanvas and structured clone support.");
		const mainMetrics = FontCache.getMeasureText(capabilities.fontProbe.content, capabilities.fontProbe.font);
		if ([
			[mainMetrics.width, capabilities.fontProbe.width],
			[mainMetrics.actualBoundingBoxAscent, capabilities.fontProbe.actualBoundingBoxAscent],
			[mainMetrics.actualBoundingBoxDescent, capabilities.fontProbe.actualBoundingBoxDescent]
		].some(([mainValue, workerValue]) => !Number.isFinite(mainValue) || !Number.isFinite(workerValue) || Math.abs(mainValue - workerValue) > FONT_METRICS_TOLERANCE)) throw new DocsLayoutWorkerCapabilityError("Document layout Worker font metrics differ from the main rendering context.");
	}
};
let UniverDocsLayoutWorkerPlugin = class UniverDocsLayoutWorkerPlugin extends Plugin {
	constructor(_config = defaultPluginDocsLayoutWorkerConfig, _injector, _layoutExecutorService, _configService) {
		super();
		this._config = _config;
		this._injector = _injector;
		this._layoutExecutorService = _layoutExecutorService;
		this._configService = _configService;
		const { ...rest } = merge({}, defaultPluginDocsLayoutWorkerConfig, this._config);
		this._configService.setConfig(DOCS_LAYOUT_WORKER_PLUGIN_CONFIG_KEY, rest);
	}
	onStarting() {
		if (typeof this._config.workerFactory !== "function") throw new TypeError("[UniverDocsLayoutWorkerPlugin]: workerFactory is required.");
		const requestTimeoutMs = this._config.requestTimeoutMs ?? 15e3;
		if (!Number.isFinite(requestTimeoutMs) || requestTimeoutMs <= 0) throw new RangeError("[UniverDocsLayoutWorkerPlugin]: requestTimeoutMs must be a positive finite number.");
		const client = new DocsLayoutWorkerClientService(this._config.workerFactory, requestTimeoutMs, this._config.fontFaces);
		this._injector.add([DocsLayoutWorkerClientService, { useValue: client }]);
		this.disposeWithMe(client);
		this.disposeWithMe(this._layoutExecutorService.register(client));
	}
};
_defineProperty(UniverDocsLayoutWorkerPlugin, "pluginName", "DOCS_LAYOUT_WORKER_PLUGIN");
_defineProperty(UniverDocsLayoutWorkerPlugin, "packageName", name);
_defineProperty(UniverDocsLayoutWorkerPlugin, "version", version);
UniverDocsLayoutWorkerPlugin = __decorate([
	DependentOn(UniverDocsPlugin),
	__decorateParam(1, Inject(Injector)),
	__decorateParam(2, Inject(DocLayoutExecutorService)),
	__decorateParam(3, IConfigService)
], UniverDocsLayoutWorkerPlugin);

//#endregion
//#region src/services/doc-interceptor/interceptor-const.ts
const CUSTOM_RANGE = createInterceptorKey("CUSTOM_RANGE");
const CUSTOM_DECORATION = createInterceptorKey("CUSTOM_DECORATION");
const DOC_INTERCEPTOR_POINT = {
	CUSTOM_RANGE,
	CUSTOM_DECORATION
};

//#endregion
//#region src/services/doc-interceptor/doc-interceptor.service.ts
let DocInterceptorService = class DocInterceptorService extends Disposable {
	constructor(_context, _docSkeletonManagerService) {
		super();
		this._context = _context;
		this._docSkeletonManagerService = _docSkeletonManagerService;
		_defineProperty(this, "_interceptorsByName", /* @__PURE__ */ new Map());
		const viewModel = this._docSkeletonManagerService.getViewModel();
		const unitId = viewModel.getDataModel().getUnitId();
		if (unitId === DOCS_NORMAL_EDITOR_UNIT_ID_KEY || unitId === DOCS_FORMULA_BAR_EDITOR_UNIT_ID_KEY) return;
		this.disposeWithMe(this.interceptDocumentViewModel(viewModel));
		this.disposeWithMe(this.intercept(DOC_INTERCEPTOR_POINT.CUSTOM_RANGE, {
			priority: -1,
			handler: (data, pos, next) => {
				return next(data);
			}
		}));
		let disposableCollection = new DisposableCollection();
		viewModel.segmentViewModels$.subscribe((segmentViewModels) => {
			disposableCollection.dispose();
			disposableCollection = new DisposableCollection();
			segmentViewModels.forEach((segmentViewModel) => {
				disposableCollection.add(this.interceptDocumentViewModel(segmentViewModel));
			});
		});
		this.disposeWithMe(disposableCollection);
	}
	intercept(name, interceptor) {
		const key = name;
		if (!this._interceptorsByName.has(key)) this._interceptorsByName.set(key, []);
		const interceptors = this._interceptorsByName.get(key);
		interceptors.push(interceptor);
		this._interceptorsByName.set(key, interceptors.sort((a, b) => (b.priority ?? 0) - (a.priority ?? 0)));
		return this.disposeWithMe(toDisposable(() => remove(this._interceptorsByName.get(key), interceptor)));
	}
	fetchThroughInterceptors(name) {
		const key = name;
		const interceptors = this._interceptorsByName.get(key);
		return composeInterceptors(interceptors || []);
	}
	interceptDocumentViewModel(viewModel) {
		const disposableCollection = new DisposableCollection();
		disposableCollection.add(viewModel.registerCustomRangeInterceptor({
			getCustomRange: (index) => {
				return this.fetchThroughInterceptors(DOC_INTERCEPTOR_POINT.CUSTOM_RANGE)(viewModel.getCustomRangeRaw(index), {
					index,
					unitId: viewModel.getDataModel().getUnitId(),
					body: viewModel.getDataModel().getBody(),
					customRanges: viewModel.getDataModel().getCustomRanges() ?? []
				});
			},
			getCustomDecoration: (index) => {
				return this.fetchThroughInterceptors(DOC_INTERCEPTOR_POINT.CUSTOM_DECORATION)(viewModel.getCustomDecorationRaw(index), {
					index,
					unitId: viewModel.getDataModel().getUnitId(),
					customDecorations: viewModel.getDataModel().getCustomDecorations() ?? []
				});
			}
		}));
		return disposableCollection;
	}
};
DocInterceptorService = __decorate([__decorateParam(1, Inject(DocSkeletonManagerService))], DocInterceptorService);

//#endregion
//#region src/utils/custom-range-factory.ts
function addCustomRangeFactory(accessor, param, body) {
	const { unitId, segmentId } = param;
	const documentDataModel = accessor.get(IUniverInstanceService).getUnit(unitId);
	if (!documentDataModel) return false;
	const doMutation = {
		id: RichTextEditingMutation.id,
		params: {
			unitId: param.unitId,
			actions: [],
			textRanges: void 0
		}
	};
	const jsonX = JSONX.getInstance();
	const textX = BuildTextUtils.customRange.add({
		...param,
		body
	});
	if (!textX) return false;
	const path = getRichTextEditPath(documentDataModel, segmentId);
	doMutation.params.actions = jsonX.editOp(textX.serialize(), path);
	return doMutation;
}
function addCustomRangeBySelectionFactory(accessor, param) {
	var _selections$, _documentDataModel$ge;
	const { rangeId, rangeType, wholeEntity, properties, unitId, selections: propSelection } = param;
	const docSelectionManagerService = accessor.get(DocSelectionManagerService);
	const univerInstanceService = accessor.get(IUniverInstanceService);
	const selections = propSelection ?? docSelectionManagerService.getTextRanges({
		unitId,
		subUnitId: unitId
	});
	const segmentId = selections === null || selections === void 0 || (_selections$ = selections[0]) === null || _selections$ === void 0 ? void 0 : _selections$.segmentId;
	if (!(selections === null || selections === void 0 ? void 0 : selections.length)) return false;
	const documentDataModel = univerInstanceService.getUnit(unitId, UniverInstanceType.UNIVER_DOC);
	if (!documentDataModel) return false;
	const body = (_documentDataModel$ge = documentDataModel.getSelfOrHeaderFooterModel(segmentId)) === null || _documentDataModel$ge === void 0 ? void 0 : _documentDataModel$ge.getBody();
	if (!body) return false;
	const textX = BuildTextUtils.customRange.add({
		ranges: selections,
		rangeId,
		rangeType,
		segmentId,
		wholeEntity,
		properties,
		body
	});
	if (!textX) return false;
	const jsonX = JSONX.getInstance();
	const doMutation = {
		id: RichTextEditingMutation.id,
		params: {
			unitId,
			actions: [],
			textRanges: textX.selections,
			segmentId
		},
		textX
	};
	const path = getRichTextEditPath(documentDataModel, segmentId);
	doMutation.params.actions = jsonX.editOp(textX.serialize(), path);
	return doMutation;
}
function deleteCustomRangeFactory(accessor, params) {
	const { unitId, segmentId, insert } = params;
	const documentDataModel = accessor.get(IUniverInstanceService).getUnit(unitId);
	if (!documentDataModel) return false;
	const doMutation = {
		id: RichTextEditingMutation.id,
		params: {
			unitId: params.unitId,
			actions: [],
			textRanges: void 0,
			segmentId
		}
	};
	const jsonX = JSONX.getInstance();
	const textX = BuildTextUtils.customRange.delete({
		documentDataModel,
		rangeId: params.rangeId,
		insert,
		segmentId
	});
	if (!textX) return false;
	const path = getRichTextEditPath(documentDataModel, segmentId);
	doMutation.params.actions = jsonX.editOp(textX.serialize(), path);
	doMutation.params.textRanges = textX.selections;
	return doMutation;
}

//#endregion
//#region src/utils/paragraphs.ts
/** Builds paragraph metadata for inserted paragraph tokens, including horizontal-rule borders. */
function generateParagraphs(dataStream, prevParagraph, borderBottom, existingParagraphIds = []) {
	const paragraphs = [];
	const existingIds = new Set(existingParagraphIds);
	for (let i = 0, len = dataStream.length; i < len; i++) {
		if (dataStream[i] !== DataStreamTreeTokenType.PARAGRAPH) continue;
		paragraphs.push({
			startIndex: i,
			paragraphId: createParagraphId(existingIds)
		});
	}
	for (const paragraph of paragraphs) {
		if (prevParagraph === null || prevParagraph === void 0 ? void 0 : prevParagraph.bullet) paragraph.bullet = Tools.deepClone(prevParagraph.bullet);
		if (prevParagraph === null || prevParagraph === void 0 ? void 0 : prevParagraph.paragraphStyle) {
			paragraph.paragraphStyle = Tools.deepClone(prevParagraph.paragraphStyle);
			delete paragraph.paragraphStyle.borderBottom;
			if (prevParagraph.paragraphStyle.headingId) paragraph.paragraphStyle.headingId = generateRandomId(6);
		}
		if (borderBottom) {
			paragraph.paragraphStyle ??= {};
			paragraph.paragraphStyle.borderBottom = Tools.deepClone(borderBottom);
			paragraph.paragraphStyle.spaceBelow = { v: 10 };
		}
	}
	return paragraphs;
}

//#endregion
//#region src/utils/replace-selection-factory.ts
function replaceSelectionFactory(accessor, params) {
	var _params$selection, _docDataModel$getSelf;
	const { unitId, body: insertBody, doc } = params;
	let docDataModel = doc;
	if (!docDataModel) docDataModel = accessor.get(IUniverInstanceService).getUnit(unitId);
	if (!docDataModel) return false;
	const segmentId = (_params$selection = params.selection) === null || _params$selection === void 0 ? void 0 : _params$selection.segmentId;
	const body = (_docDataModel$getSelf = docDataModel.getSelfOrHeaderFooterModel(segmentId)) === null || _docDataModel$getSelf === void 0 ? void 0 : _docDataModel$getSelf.getBody();
	if (!body) return false;
	const docSelectionManagerService = accessor.get(DocSelectionManagerService);
	const selection = params.selection ?? docSelectionManagerService.getActiveTextRange();
	if (!selection || !body) return false;
	const textRanges = params.textRanges ?? [{
		startOffset: selection.startOffset + insertBody.dataStream.length,
		endOffset: selection.startOffset + insertBody.dataStream.length,
		collapsed: true,
		segmentId
	}];
	const textX = BuildTextUtils.selection.replace({
		selection,
		body: insertBody,
		doc: docDataModel
	});
	if (!textX) return false;
	const doMutation = {
		id: RichTextEditingMutation.id,
		params: {
			unitId,
			actions: [],
			textRanges,
			debounce: true,
			segmentId
		},
		textX
	};
	const jsonX = JSONX.getInstance();
	doMutation.params.actions = jsonX.editOp(textX.serialize());
	return doMutation;
}

//#endregion
//#region src/utils/transform-position.ts
function buildDocTransform(width, height, position) {
	return {
		size: {
			width,
			height
		},
		positionH: {
			relativeFrom: ObjectRelativeFromH.PAGE,
			posOffset: (position === null || position === void 0 ? void 0 : position.left) ?? 0
		},
		positionV: {
			relativeFrom: ObjectRelativeFromV.PARAGRAPH,
			posOffset: (position === null || position === void 0 ? void 0 : position.top) ?? 0
		},
		angle: 0
	};
}
function docDrawingPositionToTransform(position) {
	return {
		left: position.positionH.posOffset,
		top: position.positionV.posOffset,
		width: position.size.width,
		height: position.size.height,
		flipX: position.flipX,
		flipY: position.flipY
	};
}
function transformToDocDrawingPosition(transform, marginLeft = 0, marginTop = 0) {
	return {
		size: {
			width: transform.width,
			height: transform.height
		},
		positionH: {
			relativeFrom: ObjectRelativeFromH.MARGIN,
			posOffset: (transform.left || 0) - marginLeft
		},
		positionV: {
			relativeFrom: ObjectRelativeFromV.PAGE,
			posOffset: (transform.top || 0) - marginTop
		},
		angle: transform.angle || 0,
		flipX: transform.flipX,
		flipY: transform.flipY
	};
}

//#endregion
//#region src/utils/util.ts
function consumeContentInsertRange(accessor, unitId) {
	try {
		return accessor.get(DocContentInsertService).consumeInsertRange(unitId);
	} catch {
		return null;
	}
}
function getContentInsertRange(accessor, unitId) {
	var _accessor$get$getCurr;
	const _unitId = unitId ?? ((_accessor$get$getCurr = accessor.get(IUniverInstanceService).getCurrentUnitOfType(UniverInstanceType.UNIVER_DOC)) === null || _accessor$get$getCurr === void 0 ? void 0 : _accessor$get$getCurr.getUnitId());
	if (!_unitId) return null;
	const insertRange = consumeContentInsertRange(accessor, _unitId);
	if (!insertRange) return null;
	return {
		...insertRange,
		collapsed: (insertRange === null || insertRange === void 0 ? void 0 : insertRange.startOffset) === (insertRange === null || insertRange === void 0 ? void 0 : insertRange.endOffset)
	};
}
function isHeaderFooterSelection(range) {
	return Boolean(range === null || range === void 0 ? void 0 : range.segmentId);
}
function normalizeTextRange(textRange) {
	const endOffset = textRange.endOffset ?? textRange.startOffset;
	return {
		...textRange,
		endOffset,
		collapsed: textRange.collapsed ?? textRange.startOffset === endOffset,
		segmentId: textRange.segmentId ?? ""
	};
}

//#endregion
export { CreateHeaderFooterCommand, DOCUMENT_UNIT_PERMISSION_ACTIONS, DOC_INTERCEPTOR_POINT, DOC_SELECTION_OPTION_PRESERVE_CARET, DeleteDocumentSectionBreakCommand, DeleteTextCommand, DocBlockMoveValidatorService, DocContentInsertService, DocHistoryAction, DocInterceptorService, DocLayoutExecutorService, DocLayoutExecutorState, DocLayoutExecutorType, DocLayoutSessionStatus, DocSelectionManagerService, DocSkeletonManagerService, DocStateChangeManagerService, DocStateEmitService, DocTextResolverService, DocsLayoutWorkerCapabilityError, DocsLayoutWorkerClientService, EMBED_DOCS_CUSTOM_BLOCK_DEFAULT_COMPONENT_KEY, HeaderFooterType, IDocStateChangeInterceptorService, InsertDocumentColumnBreakCommand, InsertDocumentSectionBreakCommand, InsertTextCommand, RichTextEditingMutation, SetDocumentDefaultParagraphStyleCommand, SetDocumentNameCommand, SetDocumentPermissionCommand, SetDocumentPermissionRuleMutation, SetDocumentPermissionRulesMutation, SetDocumentPermissionsCommand, SetSectionHeaderFooterLinkCommand, SetTextSelectionsOperation, UniverDocsLayoutWorkerPlugin, UniverDocsPlugin, UpdateDocumentParagraphStyleCommand, UpdateDocumentSectionCommand, UpdateTextCommand, addCustomRangeBySelectionFactory, addCustomRangeFactory, buildDocTransform, canEditDocumentTargets, consumeContentInsertRange, createDocsCustomBlockDrawing, createDocsCustomBlockInsertMutation, createDocsCustomBlockRemoveMutation, createDocumentPermissionPoint, createEmbedDocsCustomBlockData, createInsertCustomBlockActions, createRemoveCustomBlockActions, createSectionColumnProperties, deleteCustomRangeFactory, docDrawingPositionToTransform, generateParagraphs, getContentInsertRange, getDocumentDrawingSegmentId, getDocumentEditTargetObjectIds, getDocumentEntityParentPermissionObjectIds, getDocumentEntityPermissionObjectId, getDocumentParagraphParentPermissionObjectIds, getDocumentParagraphPermissionObjectId, getDocumentPermissionValue, getDocumentSectionPermissionObjectId, getEffectiveSectionPageSetup, getSectionContentWidth, getTopLevelSectionBreaks, isEmbedDocsCustomBlockData, isHeaderFooterSelection, isSheetLikeDocsCustomBlockChildType, normalizeTextRange, replaceSelectionFactory, resolveDocsCustomBlockSize, setDocumentPermissionValue, shouldUseInlineTextSelectionForDocsCustomBlockDrawing, startDocsLayoutWorker, transformDocumentTextRanges, transformToDocDrawingPosition };