# SPN-123 native marker proof evidence

## Execution and disposition

Frozen preparation revision 2 executed once at 2026-10-30T01:27:45.399Z under Node v26.12.1 and head 475f656c701f95d296c3df127e763540b0014d29.
It passed all 32 complete-publication/applied-snapshot/work comparisons (16 cases per manager source format), plus the frozen 39 marked guard probes per format.
The watchdog completed with exit 0 in 3473 ms, with 786316 KiB (767.89 MiB) peak process-tree RSS.
No resource abort occurred. The 180-second / 2-GiB limits were unchanged.

The plan is a preserved preparation document. Its historical prepared/not-executed wording is left intact; run-start.json, execution-start.json, result.json, execution.log and resource-result.json are the execution record.
pre-review-revision-1/ is superseded preparation that was never executed, not a failed run or a retry.
All original proof files are archived byte-for-byte. MANIFEST.json lists every payload except itself; the companion repository summary records the manifest and ZIP hashes.
Original absolute paths inside retained evidence identify the execution environment and are not rewritten.

## What this establishes

The actual nativeSession / NativeReplica / captureNative path produced owned __textXPreserveParagraphIds=true on the captured inserts.
The candidate admits exactly absent or owned-true markers while preserving all existing shape restrictions.
Full original/current/proposed publications and applied history/collaboration redo/undo snapshots were compared without normalization; owned undefined values survive in the V8 records.
The proof retained the same binary TextX.compose counts and measured fewer iterator, body-slice, clone-visit and clone-allocation operations for newly eligible groups.
Invalid owned marker values, unsupported metadata, structural controls and the actual Enter case retained the original fallback.

## Limits

This is bounded mechanism and exact-preservation evidence, not browser timing acceptance or causal attribution for either retained mobile failure.
The 20/32 cases inject a suffix of actual captured history states and full collaboration states through public setStateCache; they do not claim natural clearHistory divergence.
Both ES/CJS manager source regions execute against the same imported core; they are not two independently booted full runtimes.
The 70-input owner/peer receipts, reopen and full-undo integration remains separate permanent regression work.
No production or installed SDK file was changed by the proof. Required exact-head CI and independent reviews are separate gates.
The archive preserves the complete requested proof records, not a full installation of its npm dependencies; their exact source hashes and pinned source identity are retained in the plan and execution records.

## Attribution and license

Prepared original/current/proposed manager bundle sources derive from @univerjs/docs 1.1.0, dream-num/univer v1.1.0, packages/docs/src/services/doc-state-change-manager.service.ts.
Copyright 2023-present DreamNum Co., Ltd. The retained upstream code and copied manager test helpers are licensed under Apache License 2.0. The package license is included as LICENSE-UNIVER-APACHE-2.0.txt, and existing source license headers are preserved.
The counted fixture/helpers were copied from Spinel's scripts/dependencies/patch-univer-docs.test.ts at the recorded HEAD, whose SHA-256 is 109a4cee9fa447903e3ef1ca03d4a29a60647f07fd56d3717493be997c027ac5.
Modifications for this scratch proof: fixture unit ID; retention of observations before assertions; exact marker qualification; actual native captured inputs; fixed case/guard matrix; V8 evidence and resource watchdog. The exact candidate substitution is retained separately in candidate-replacement.json.
No Univer Pro package was read or modified.

## Reading the records

- result.json: all 32 results and exact primitive counts.
- prepared-sources/: full original/current/proposed ES/CJS sources and helper text.
- candidate-replacement.json: exact in-memory qualification change.
- results/*.v8: full native captures, discriminator/guard inputs, every compared input, publication and applied snapshot. Read with Node's node:v8 deserialize; do not use JSON to replace these records because it drops owned undefined properties.
- results/*.counts.json: per-case/per-source counters and output hashes.
- proof-plan.json and spn123-marker-proof.test.ts: frozen revision 2 plan and executable proof, retained for inspection.
- watchdog.ts and resource-result.json: one-shot execution guard, command, limits and resource result.
- copied-helper-source-at-head.ts: complete helper source before later permanent test changes.
- pre-review-revision-1/: clearly labeled unexecuted prior preparation.
