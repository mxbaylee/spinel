// Scratch-only one-shot SPN-123 proof launcher. Do not invoke before review.
import { execFileSync, spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createWriteStream, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const root = '/tmp/spn123-marker-proof';
const plan = JSON.parse(readFileSync(resolve(root, 'proof-plan.json'), 'utf8'));
const repo = plan.repository;
const hash = (bytes: Uint8Array) => createHash('sha256').update(bytes).digest('hex');
if (process.argv[2] !== '--reviewed-once') throw new Error('Review the frozen plan and pass --reviewed-once explicitly.');
if (process.version !== `v${plan.nodeVersion}`) throw new Error(`Use pinned Node ${plan.nodeVersion}; got ${process.version}.`);
const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim();
if (head !== plan.headCommit) throw new Error('HEAD changed after proof preparation; stop for source review.');
for (const [path, expected] of Object.entries(plan.executionInputSha256))
  if (hash(readFileSync(path)) !== expected) throw new Error(`Reviewed proof input changed: ${path}`);
const pressure = () => process.platform !== 'darwin' ||
  Number(execFileSync('sysctl', ['-n', 'kern.memorystatus_vm_pressure_level'], { encoding: 'utf8' }).trim()) === 1;
if (!pressure()) throw new Error('Deferred: elevated macOS memory pressure.');
// Exclusive creation forbids an unchanged rerun, including after a failed or
// resource-aborted attempt. No automatic cleanup or retry is provided.
writeFileSync(resolve(root, 'run-start.json'), JSON.stringify({ at: new Date().toISOString(), head, runtime: process.version, scriptSha256: hash(readFileSync(import.meta.filename)) }, null, 2) + '\n', { flag: 'wx' });
const command = [
  resolve(repo, 'node_modules/vitest/vitest.mjs'), 'run', plan.testRelativePath,
  '--maxWorkers=1', '--no-file-parallelism', '--testTimeout=165000', '--bail=1',
];
const logPath = resolve(root, 'execution.log');
const log = createWriteStream(logPath, { flags: 'wx' });
const started = Date.now();
const child = spawn(process.execPath, command, { cwd: repo, stdio: ['ignore', 'pipe', 'pipe'], detached: true });
let peakRssKiB = 0;
let abortReason: string | null = null;
let killing: ReturnType<typeof setTimeout> | undefined;
const groups = new Set<number>();
if (child.pid) groups.add(child.pid);
const note = (value: string) => { process.stderr.write(value); log.write(value); };
child.stdout.on('data', (chunk) => { process.stdout.write(chunk); log.write(chunk); });
child.stderr.on('data', (chunk) => { process.stderr.write(chunk); log.write(chunk); });
function rows() {
  return execFileSync('ps', ['-axo', 'pid=,ppid=,rss=,pgid='], { encoding: 'utf8' }).trim().split('\n').filter(Boolean).map((line) => line.trim().split(/\s+/).map(Number));
}
function stop(reason: string) {
  if (abortReason) return;
  abortReason = reason;
  note(`\nPROOF ABORT: ${reason}\n`);
  for (const group of groups) { try { process.kill(-group, 'SIGTERM'); } catch {} }
  killing = setTimeout(() => {
    for (const group of groups) { try { process.kill(-group, 'SIGKILL'); } catch {} }
  }, 500);
}
function inspect() {
  try {
    const processRows = rows();
    const owned = new Set<number>(child.pid ? [child.pid] : []);
    for (const [pid, , , group] of processRows) if (groups.has(group)) owned.add(pid);
    let changed = true;
    while (changed) {
      changed = false;
      for (const [pid, parent] of processRows)
        if (owned.has(parent) && !owned.has(pid)) { owned.add(pid); changed = true; }
    }
    let rss = 0;
    for (const [pid, , value, group] of processRows) if (owned.has(pid)) {
      rss += value;
      if (pid === group) groups.add(group);
    }
    peakRssKiB = Math.max(peakRssKiB, rss);
    if (rss > 2 * 1024 * 1024) stop(`process-tree RSS ${rss} KiB exceeded 2 GiB`);
    else if (!pressure()) stop('macOS memory pressure increased');
    else if (Date.now() - started >= 180_000) stop('180-second deadline exceeded');
  } catch (error) { stop(`watchdog inspection failed: ${String(error)}`); }
}
const timer = setInterval(inspect, 200);
const deadline = setTimeout(() => stop('180-second deadline exceeded'), 180_000);
const signalHandler = () => stop('external interrupt');
process.on('SIGINT', signalHandler); process.on('SIGTERM', signalHandler);
child.on('error', (error) => { note(`Spawn error: ${String(error)}\n`); stop('spawn failed'); });
child.on('close', async (code, signal) => {
  clearInterval(timer); clearTimeout(deadline);
  if (killing) clearTimeout(killing);
  // Terminate any task-owned group still present after the root exits. This
  // cannot address unrelated editor/browser/user process groups.
  for (const group of groups) { try { process.kill(-group, 'SIGKILL'); } catch {} }
  const elapsedMs = Date.now() - started;
  const status = abortReason ? 'aborted' : code === 0 ? 'completed' : 'failed';
  note(`\nProof watchdog: ${status}; peak RSS ${(peakRssKiB / 1024).toFixed(2)} MiB; ${elapsedMs} ms\n`);
  await new Promise<void>((done) => log.end(done));
  const bytes = readFileSync(logPath);
  writeFileSync(resolve(root, 'resource-result.json'), JSON.stringify({
    status, abortReason, code, signal, elapsedMs, peakRssKiB, limitRssKiB: 2 * 1024 * 1024,
    deadlineMs: 180_000, log: { path: logPath, bytes: bytes.length, sha256: hash(bytes) },
    command: [process.execPath, ...command], serialRunnerRequired: true,
  }, null, 2) + '\n');
  process.exitCode = abortReason ? (abortReason.includes('deadline') ? 124 : 75) : (code ?? 1);
});
