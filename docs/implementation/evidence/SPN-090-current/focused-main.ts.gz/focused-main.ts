import config from '/Users/mxbaylee/projects/spinel-spn-090-current/.storybook/main.ts';
export default {...config, stories: ['/Users/mxbaylee/projects/spinel-spn-090-current/web/StartupStage.stories.tsx', '/Users/mxbaylee/projects/spinel-spn-090-current/web/offline/OfflineAvailability.stories.tsx']};
