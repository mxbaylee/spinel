# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: admin-layout.spec.ts >> pending invitations prevent section changes, manual copying works, and leaving discards the secret
- Location: e2e/admin-layout.spec.ts:131:1

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /#invites$/
Received string:  "http://localhost:3100/admin#health"
Timeout: 5000ms

Call log:
  - Expect "toHaveURL" with timeout 5000ms
    14 × locator resolved to <html lang="en" data-theme="light">…</html>
       - unexpected value "http://localhost:3100/admin#health"

```

```yaml
- banner:
  - link "Spinel Your docs":
    - /url: /
    - img "Spinel"
    - text: Your docs
  - status "Connection status": Online
  - button "Online — connected to Spinel"
  - navigation "Workspace":
    - link "Admin":
      - /url: /admin
  - radiogroup "Appearance":
    - radio "Follow system" [checked]
    - radio "Light"
    - radio "Dark"
  - link "Your profile":
    - /url: /profile
    - text: Invite layout d247d1107d58feeba083-518f29cc69d9fac6cad2-0
- main:
  - paragraph: SERVER OPERATOR
  - heading "Administration" [level=1]
  - navigation "Administration sections":
    - link "People":
      - /url: "#people"
    - link "Invites":
      - /url: "#invites"
    - link "Connections":
      - /url: "#connections"
    - link "Backups & health":
      - /url: "#health"
  - region "Backups & health":
    - heading "Backups & health" [level=2]
    - region "Workspace maintenance controls":
      - heading "Maintenance" [level=3]
      - paragraph: Maintenance controls are unavailable for this server. Follow the recovery guide to set them up.
      - button "Refresh maintenance"
      - link "Open recovery guide":
        - /url: https://github.com/mxbaylee/spinel/blob/main/docs/maintenance.md
    - region "Backups":
      - heading "Backups" [level=3]
      - button "Refresh backup status"
      - paragraph:
        - strong: Not configured
      - paragraph: "Destination: Manual downloads only"
      - alert: Offsite backups are not configured. Follow the backup setup guide on the server.
      - paragraph: "Last successful backup: None yet"
      - paragraph: "Last backup attempt: None yet"
      - region "Backup policy":
        - heading "Backup policy" [level=4]
        - term: Automatic backups
        - definition: "Off"
        - term: Workspace downloads
        - definition: "Off"
        - paragraph: Your deployment controls these settings. Backup retention does not change document history or diagnostics expiry.
      - region "Workspace backup download":
        - heading "Encrypted workspace download" [level=4]
        - paragraph: Keep a recovery copy of the workspace. Its recovery key is kept separately and is never included in this download.
        - paragraph: Workspace downloads are turned off in the deployment configuration.
        - button "Prepare workspace backup" [disabled]
        - button "Refresh download status"
        - paragraph: A download does not confirm an offsite copy or a successful restore. Keep the file and its key somewhere you can reach if this server is lost.
      - region "Restore verification":
        - heading "Restore verification" [level=4]
        - paragraph:
          - strong: Not configured
        - paragraph: Automatic restore checks are off. Follow the backup guide to verify a downloaded recovery copy.
        - paragraph: "Last successful restore check: None yet"
        - paragraph: "Last restore check attempt: None yet"
      - link "Open backup guide":
        - /url: https://github.com/mxbaylee/spinel/blob/main/docs/backups.md
    - region "Restore workspace":
      - heading "Restore workspace" [level=3]
      - button "Refresh restore status" [disabled]
      - paragraph: Prepare an encrypted backup and review its consequences before maintenance begins. Document contents stay private.
      - status: Loading restore status…
      - button "Prepare restore" [disabled]
      - link "Open recovery guide":
        - /url: https://github.com/mxbaylee/spinel/blob/main/docs/backups.md
    - region "Server health":
      - heading "Server health" [level=3]
      - button "Refresh server health"
      - paragraph:
        - strong: Needs attention
      - alert: Host memory is above 80% of the 2 GiB budget. First observed 11/14/2026, 11:26:14 AM.
      - paragraph: Sampled 11/14/2026, 11:26:16 AM. Process started 11/14/2026, 11:26:14 AM. Refreshes every minute.
      - heading "Memory & connections" [level=4]
      - term: Host memory used
      - definition: 7.9 GiB
      - term: Host budget
      - definition: 2 GiB
      - term: Reported host capacity
      - definition: 8 GiB
      - term: App process (RSS)
      - definition: 354.6 MiB
      - term: Container memory used
      - definition: Unavailable
      - term: Container memory limit
      - definition: Unavailable
      - term: Live editor connections
      - definition: "0"
      - paragraph: Host usage uses free memory; reclaimable cache may count as used. Process and container values overlap with host usage; do not add them.
      - heading "Application & collaboration" [level=4]
      - term: Database file
      - definition: 552 KiB
      - term: Write-ahead log (WAL)
      - definition: 120.7 KiB
      - term: Combined physical size
      - definition: 672.7 KiB
      - term: Physical growth
      - definition: +40.2 KiB
      - paragraph: Growth measured since 11/14/2026, 11:26:14 AM; it can decrease after WAL cleanup.
      - paragraph: The shared application and collaboration database is counted once.
      - heading "Diagnostics storage" [level=4]
      - term: Database file
      - definition: 56 KiB
      - term: Write-ahead log (WAL)
      - definition: 60.4 KiB
      - term: Combined physical size
      - definition: 116.4 KiB
      - term: Physical growth
      - definition: +4 KiB
      - paragraph: Growth measured since 11/14/2026, 11:26:14 AM; it can decrease after WAL cleanup.
      - heading "Backup space" [level=4]
      - term: Free data-volume space
      - definition: 19.5 GiB
      - term: Backup staging requirement
      - definition: 257.1 MiB
      - term: Logical application database
      - definition: 552 KiB
      - term: Backup upload ceiling
      - definition: 5 GiB
      - paragraph: Staging allows 2.1 times the logical database plus 256 MiB. The encrypted archive size depends on compression; database size alone does not establish whether an upload will fit.
      - heading "Maintenance jobs" [level=4]
      - list:
        - listitem:
          - strong: History capture & pruning
          - paragraph: OK
          - paragraph: "Last attempt: 11/14/2026, 11:26:14 AM"
          - paragraph: "Last success: 11/14/2026, 11:26:14 AM"
        - listitem:
          - strong: Trash expiry
          - paragraph: OK
          - paragraph: "Last attempt: 11/14/2026, 11:26:14 AM"
          - paragraph: "Last success: 11/14/2026, 11:26:14 AM"
        - listitem:
          - strong: Collaboration & restored-generation cleanup
          - paragraph: OK
          - paragraph: "Last attempt: 11/14/2026, 11:26:14 AM"
          - paragraph: "Last success: 11/14/2026, 11:26:14 AM"
        - listitem:
          - strong: Space trash expiry
          - paragraph: OK
          - paragraph: "Last attempt: 11/14/2026, 11:26:14 AM"
          - paragraph: "Last success: 11/14/2026, 11:26:14 AM"
      - link "Open server guide":
        - /url: https://github.com/mxbaylee/spinel/blob/main/docs/deployment.md
    - region "Diagnostics":
      - heading "Diagnostics" [level=3]
      - button "Download diagnostics"
      - button "Diagnostics actions": ···
      - paragraph: Download a consistent SQLite snapshot for local inspection. Automatic records can include user and file IDs, but no document titles, content or credentials. Submitted feedback, when present, is included.
      - paragraph:
        - strong: Available
      - term: Stored records
      - definition: "96"
      - term: Logical record payload
      - definition: 22.3 KiB
      - group: Dropped records since server start
      - button "Refresh diagnostics status"
      - link "Open diagnostics guide":
        - /url: https://github.com/mxbaylee/spinel/blob/main/docs/diagnostics.md
```

# Test source

```ts
  117 |           expect(await page.locator('body').innerText()).not.toContain(privateItem.name);
  118 |           await page.screenshot({
  119 |             path: `test-results/theme-screenshots/admin-${info.project.name}-${width}-${theme}-${section.toLowerCase().replaceAll(/[^a-z]+/g, '-')}.png`,
  120 |             fullPage: true,
  121 |           });
  122 |         }
  123 |       }
  124 |       expect(errors).toEqual([]);
  125 |     } finally {
  126 |       db.close();
  127 |     }
  128 |   });
  129 | }
  130 | 
  131 | test('pending invitations prevent section changes, manual copying works, and leaving discards the secret', async ({
  132 |   page,
  133 |   context,
  134 |   baseURL,
  135 | }, info) => {
  136 |   const db = openDatabase(`test-results/${info.project.name}/app.sqlite`),
  137 |     auth = new AuthStore(db);
  138 |   const operator = auth.createUser(`Invite layout ${info.testId}-${info.retry}`, true);
  139 |   await context.addCookies([
  140 |     {
  141 |       name: COOKIE_NAME,
  142 |       value: auth.createSession(operator.id).token,
  143 |       url: baseURL!.replace('http:', 'https:'),
  144 |       secure: true,
  145 |       httpOnly: true,
  146 |       sameSite: 'Strict',
  147 |     },
  148 |   ]);
  149 |   let release = () => {},
  150 |     releaseReadback = () => {};
  151 |   let created = false,
  152 |     heldReadback = false;
  153 |   const readbackGate = new Promise<void>((resolve) => {
  154 |     releaseReadback = resolve;
  155 |   });
  156 |   const gate = new Promise<void>((resolve) => {
  157 |     release = resolve;
  158 |   });
  159 |   await page.route('**/api/auth/invites', async (route) => {
  160 |     if (route.request().method() === 'POST') {
  161 |       await gate;
  162 |       const response = await route.fetch();
  163 |       created = true;
  164 |       await route.fulfill({ response });
  165 |     } else if (created && !heldReadback) {
  166 |       heldReadback = true;
  167 |       await readbackGate;
  168 |       await route.fulfill({
  169 |         status: 503,
  170 |         contentType: 'application/json',
  171 |         body: JSON.stringify({ error: 'Could not refresh invitations.' }),
  172 |       });
  173 |     } else await route.continue();
  174 |   });
  175 |   try {
  176 |     await page.goto('/admin#invites');
  177 |     await page.getByRole('button', { name: 'Create invite', exact: true }).click();
  178 |     const dialog = page.getByRole('dialog', { name: 'Create invite', exact: true });
  179 |     const creationResponse = page.waitForResponse(
  180 |       (response) =>
  181 |         new URL(response.url()).pathname === '/api/auth/invites' &&
  182 |         response.request().method() === 'POST',
  183 |     );
  184 |     // Preserve the primary assertion if fixture cleanup closes this pending wait.
  185 |     // The same promise is still awaited below; an actual response error must fail.
  186 |     void creationResponse.catch(() => {});
  187 |     await dialog.getByRole('button', { name: 'Create invite', exact: true }).click();
  188 |     await expect(dialog.getByRole('button', { name: 'Creating…' })).toBeDisabled();
  189 |     await page.evaluate(() => {
  190 |       location.hash = 'people';
  191 |     });
  192 |     await expect(page).toHaveURL(/#invites$/);
  193 |     await page.keyboard.press('Escape');
  194 |     await expect(dialog).toBeVisible();
  195 |     release();
  196 |     // Releasing the route permits delivery; it does not complete the mutation.
  197 |     // Observe the real response within the unchanged overall test deadline before
  198 |     // starting the existing five-second UI publication assertion.
  199 |     const response = await creationResponse;
  200 |     expect(response.status()).toBe(201);
  201 |     expect(await response.finished()).toBeNull();
  202 |     const address = page.getByRole('textbox', { name: 'New invite link' });
  203 |     await expect(address).toBeVisible();
  204 |     await expect(address).toBeFocused();
  205 |     // The once-only address remains the focus target while a slow readback keeps Create disabled.
  206 |     await expect(page.getByRole('button', { name: 'Create invite', exact: true })).toBeDisabled();
  207 |     const healthLink = page.getByRole('link', { name: 'Backups & health', exact: true });
  208 |     await expect(healthLink).toHaveAttribute('aria-disabled', 'true');
  209 |     // Seeing the created link is not completion: the real readback still owns
  210 |     // the navigation fence. Dispatch the disabled anchor's event directly to
  211 |     // exercise its handler; Playwright correctly refuses a user click here.
  212 |     await healthLink.dispatchEvent('click');
  213 |     await expect(page).toHaveURL(/#invites$/);
  214 |     await page.evaluate(() => {
  215 |       location.hash = 'health';
  216 |     });
> 217 |     await expect(page).toHaveURL(/#invites$/);
      |                        ^ Error: expect(page).toHaveURL(expected) failed
  218 |     releaseReadback();
  219 |     await expect(healthLink).not.toHaveAttribute('aria-disabled', 'true');
  220 |     await expect(page.getByRole('button', { name: 'Refresh invites', exact: true })).toBeEnabled();
  221 |     await expect(address).toBeFocused();
  222 |     const secret = await address.inputValue();
  223 |     await page.evaluate(() => {
  224 |       Object.defineProperty(navigator, 'clipboard', {
  225 |         configurable: true,
  226 |         value: {
  227 |           writeText: async () => {
  228 |             throw new Error('Unavailable');
  229 |           },
  230 |         },
  231 |       });
  232 |     });
  233 |     await page.getByRole('button', { name: 'Copy invite link' }).click();
  234 |     await expect(
  235 |       page.getByRole('region', { name: 'Invites', exact: true }).getByRole('status'),
  236 |     ).toHaveText('Select the link below and copy it manually.');
  237 |     await expect(address).toHaveValue(secret);
  238 |     const nav = page.getByRole('navigation', { name: 'Administration sections' });
  239 |     await healthLink.click();
  240 |     await expect(
  241 |       page.getByRole('heading', { name: 'Backups & health', exact: true }),
  242 |     ).toBeVisible();
  243 |     await nav.getByRole('link', { name: 'People', exact: true }).click();
  244 |     await expect(page.getByRole('heading', { name: 'People', exact: true })).toBeVisible();
  245 |     await nav.getByRole('link', { name: 'Invites', exact: true }).click();
  246 |     await expect(page.getByRole('list', { name: 'Invites' })).toBeVisible();
  247 |     await expect(address).toHaveCount(0);
  248 |     expect(await page.content()).not.toContain(secret);
  249 |     await page.reload();
  250 |     await expect(page.getByRole('list', { name: 'Invites' })).toBeVisible();
  251 |     await expect(address).toHaveCount(0);
  252 |     expect(await (await context.request.get('/api/auth/invites')).text()).not.toContain(secret);
  253 |   } finally {
  254 |     release();
  255 |     releaseReadback();
  256 |     db.close();
  257 |   }
  258 | });
  259 | 
  260 | test('a response from an unmounted section cannot redirect a current administration view', async ({
  261 |   page,
  262 |   context,
  263 |   baseURL,
  264 | }, info) => {
  265 |   const db = openDatabase(`test-results/${info.project.name}/app.sqlite`),
  266 |     auth = new AuthStore(db);
  267 |   const operator = auth.createUser(`Stale layout ${info.testId}-${info.retry}`, true);
  268 |   await context.addCookies([
  269 |     {
  270 |       name: COOKIE_NAME,
  271 |       value: auth.createSession(operator.id).token,
  272 |       url: baseURL!.replace('http:', 'https:'),
  273 |       secure: true,
  274 |       httpOnly: true,
  275 |       sameSite: 'Strict',
  276 |     },
  277 |   ]);
  278 |   let release = () => {},
  279 |     started = () => {};
  280 |   const gate = new Promise<void>((resolve) => {
  281 |     release = resolve;
  282 |   });
  283 |   const requested = new Promise<void>((resolve) => {
  284 |     started = resolve;
  285 |   });
  286 |   await page.route('**/api/auth/admin/users', async (route) => {
  287 |     started();
  288 |     await gate;
  289 |     await route.fulfill({
  290 |       status: 401,
  291 |       contentType: 'application/json',
  292 |       body: JSON.stringify({ error: 'Expired old response' }),
  293 |     });
  294 |   });
  295 |   try {
  296 |     await page.goto('/admin');
  297 |     await requested;
  298 |     await page
  299 |       .getByRole('navigation', { name: 'Administration sections' })
  300 |       .getByRole('link', { name: 'Invites', exact: true })
  301 |       .click();
  302 |     await expect(page.getByRole('button', { name: 'Create invite', exact: true })).toBeEnabled();
  303 |     const response = page.waitForResponse('**/api/auth/admin/users');
  304 |     release();
  305 |     await response;
  306 |     // A second authorized load gives the abandoned callback time to finish without a fixed sleep.
  307 |     await page.getByRole('button', { name: 'Create invite', exact: true }).click();
  308 |     await expect(page.getByRole('dialog', { name: 'Create invite', exact: true })).toBeVisible();
  309 |     await expect(page).toHaveURL(/\/admin#invites$/);
  310 |     await expect(page.getByText('Expired old response', { exact: true })).toHaveCount(0);
  311 |   } finally {
  312 |     release();
  313 |     db.close();
  314 |   }
  315 | });
  316 | 
```