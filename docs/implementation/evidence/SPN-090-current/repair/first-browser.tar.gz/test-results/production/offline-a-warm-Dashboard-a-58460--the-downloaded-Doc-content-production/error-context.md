# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: offline.spec.ts >> a warm Dashboard and a failed first-list deep link restore the downloaded Doc content
- Location: e2e/offline.spec.ts:1034:1

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "Offline writing keeps the whole saved document."
Received string:    "Phone journal"
```

# Test source

```ts
  945  |       await expect.poll(() => page.evaluate(() => navigator.clipboard.readText())).toContain(text);
  946  |       await page.keyboard.press('ArrowRight');
  947  |     };
  948  | 
  949  |     await context.setOffline(true);
  950  |     await assertLiveOfflineCover(page);
  951  |     await page.reload();
  952  |     await expect(page).toHaveURL(baseURL! + docHref);
  953  |     await assertPreparedDoc();
  954  |     await mkdir('test-results/theme-screenshots', { recursive: true });
  955  |     for (const [theme, width, variant] of [
  956  |       ['light', 1440, 'light'],
  957  |       ['dark', 1440, 'dark'],
  958  |       ['light', 390, 'phone'],
  959  |     ] as const) {
  960  |       await page.setViewportSize({ width, height: 1100 });
  961  |       await page.emulateMedia({ colorScheme: theme });
  962  |       await expect(page.locator('html')).toHaveAttribute('data-theme', theme);
  963  |       await expect(
  964  |         page
  965  |           .getByRole('region', { name: 'Offline copy', exact: true })
  966  |           .getByRole('status', { name: 'Save status', exact: true }),
  967  |       ).toHaveText('Saved on this device — waiting to sync.');
  968  |       await expect(
  969  |         page
  970  |           .getByRole('region', { name: 'Offline copy', exact: true })
  971  |           .getByRole('button', { name: 'Bold', exact: true }),
  972  |       ).toBeEnabled();
  973  |       const screenshot = `test-results/theme-screenshots/spn-092-space-native-doc-offline-${variant}-${info.project.name}.png`;
  974  |       await page.screenshot({ path: screenshot, fullPage: true });
  975  |       await info.attach(`Native prepared Space Doc and image (${variant})`, {
  976  |         path: screenshot,
  977  |         contentType: 'image/png',
  978  |       });
  979  |     }
  980  |     await page.setViewportSize({ width: 1440, height: 1100 });
  981  | 
  982  |     const remoteReads: string[] = [];
  983  |     page.on('request', (request) => {
  984  |       const path = new URL(request.url()).pathname;
  985  |       if (/^\/(?:api\/(?:spaces|items)(?:\/|$)|space-api\/)/.test(path)) remoteReads.push(path);
  986  |     });
  987  |     await page.getByRole('button', { name: 'My files', exact: true }).click();
  988  |     await expect(page.getByRole('heading', { name: 'My files', exact: true })).toBeVisible();
  989  |     const contents = page.getByRole('list', { name: 'Folder contents', exact: true });
  990  |     const rootRow = contents.getByRole('listitem').filter({
  991  |       has: page.locator('.dashboard-file-open', { hasText: root.name }),
  992  |     });
  993  |     await expect(rootRow).toContainText('Space');
  994  |     await expect(contents.getByText(doc.name, { exact: true })).toHaveCount(0);
  995  |     await expect(contents.getByText(missing.name, { exact: true })).toHaveCount(0);
  996  |     await rootRow.getByRole('button', { name: `${root.name} Space`, exact: true }).click();
  997  |     await expect(page).toHaveURL(baseURL! + rootHref);
  998  |     await assertPreparedDoc();
  999  | 
  1000 |     const missingHref = `${rootHref}?item=${missing.id}`;
  1001 |     await page.goto(missingHref);
  1002 |     await expect(page).toHaveURL(baseURL! + missingHref);
  1003 |     await expect(
  1004 |       page.getByRole('status').filter({ hasText: 'This page needs a connection.' }),
  1005 |     ).toHaveText(
  1006 |       'This page needs a connection. It has not been prepared in this Space on this device.',
  1007 |     );
  1008 |     await expect(page.getByRole('heading', { name: root.name, exact: true })).toBeVisible();
  1009 |     await expect(page.getByRole('region', { name: 'Offline copy', exact: true })).toHaveCount(0);
  1010 |     await expect(page.locator('.univer-container')).toHaveCount(0);
  1011 |     // A prepared sibling remains a deliberate navigation choice, never a
  1012 |     // substitute for the explicit child in the address bar.
  1013 |     await expect(
  1014 |       page
  1015 |         .getByRole('navigation', { name: 'Prepared pages', exact: true })
  1016 |         .getByRole('link', { name: doc.name, exact: true }),
  1017 |     ).toHaveAttribute('href', docHref);
  1018 |     expect(remoteReads).toEqual([]);
  1019 |     expect(errors).toEqual([]);
  1020 |     // The account destination remains available from a prepared Space, including
  1021 |     // the local sign-out that locks its saved documents until online sign-in.
  1022 |     await page.getByRole('button', { name: 'Your profile', exact: true }).click();
  1023 |     await expect(page).toHaveURL(baseURL! + '/profile');
  1024 |     await expect(page.getByRole('heading', { name: 'Your profile', exact: true })).toBeVisible();
  1025 |     await page.getByRole('button', { name: 'Sign out', exact: true }).click();
  1026 |     await expect(page).toHaveURL(baseURL! + '/sign-in');
  1027 |   } finally {
  1028 |     await context.close();
  1029 |     db.close();
  1030 |   }
  1031 | });
  1032 | 
  1033 | // Warm and deep-link opens must restore real native content, not just the frame.
  1034 | test('a warm Dashboard and a failed first-list deep link restore the downloaded Doc content', async ({
  1035 |   browser,
  1036 |   baseURL,
  1037 | }, info) => {
  1038 |   test.setTimeout(180_000);
  1039 |   const f = await fixture(browser, baseURL!, info, 'doc', { flavor: DocumentFlavor.MODERN });
  1040 |   const { page, item } = f;
  1041 |   const restoredContent = async () => {
  1042 |     await usableCanvas(page);
  1043 |     const content = await copy(page, 'doc');
  1044 |     expect(content).toContain('Phone journal');
> 1045 |     expect(content).toContain('Offline writing keeps the whole saved document.');
       |                     ^ Error: expect(received).toContain(expected) // indexOf
  1046 |     await expect(page.getByText("This item isn't available")).toHaveCount(0);
  1047 |     await expect(page.getByText('Failed to fetch')).toHaveCount(0);
  1048 |   };
  1049 |   try {
  1050 |     await f.download();
  1051 |     await page.getByRole('button', { name: 'Back to files', exact: true }).click();
  1052 |     await f.network.setOffline(true);
  1053 |     await page.getByRole('button', { name: `${item.name} Doc`, exact: true }).click();
  1054 |     await restoredContent();
  1055 |     // A new Dashboard has no in-memory metadata. Its live session succeeds,
  1056 |     // but only the prepared catalog can supply the failed list/item request.
  1057 |     await f.network.setOffline(false);
  1058 |     await page.route('**/api/items{,/**}', (route) => route.abort('internetdisconnected'));
  1059 |     await page.goto(f.href);
  1060 |     await restoredContent();
  1061 |     // A real denied response remains authoritative even with the same saved copy.
  1062 |     await page.unrouteAll();
  1063 |     await page.route(`**/api/items/${item.id}`, (route) =>
  1064 |       route.fulfill({
  1065 |         status: 403,
  1066 |         contentType: 'application/json',
  1067 |         body: JSON.stringify({ error: 'Access denied.' }),
  1068 |       }),
  1069 |     );
  1070 |     await page.goto(f.href);
  1071 |     await expect(page.getByText("This item isn't available")).toBeVisible();
  1072 |     await expect(page.getByRole('region', { name: 'Offline copy', exact: true })).toHaveCount(0);
  1073 |   } finally {
  1074 |     await f.close();
  1075 |   }
  1076 | });
  1077 | 
  1078 | // A network transition is not permission to dispose a native editor's unfinished
  1079 | // input. One real Sheet draft exercises the shared Dashboard/OfflineViewer lifetime.
  1080 | test('a warm offline Sheet keeps unfinished native input through reconnect and delayed failed metadata', async ({
  1081 |   browser,
  1082 |   baseURL,
  1083 | }, info) => {
  1084 |   test.setTimeout(180_000);
  1085 |   const f = await fixture(browser, baseURL!, info, 'sheet');
  1086 |   const { page, item } = f;
  1087 |   let releaseMetadata = () => {};
  1088 |   try {
  1089 |     await f.download();
  1090 |     await page.getByRole('button', { name: 'Back to files', exact: true }).click();
  1091 |     await f.network.setOffline(true);
  1092 |     await page.getByRole('button', { name: `${item.name} Sheet`, exact: true }).click();
  1093 |     await usableCanvas(page);
  1094 |     await selectCell(page, 'D1');
  1095 |     const draft = 'Unfinished warm reconnect cell 090';
  1096 |     await page.keyboard.insertText(draft);
  1097 |     const input = page.locator(
  1098 |       `[id="__editor_${DOCS_NORMAL_EDITOR_UNIT_ID_KEY}"][contenteditable="true"][data-u-comp="editor"]`,
  1099 |     );
  1100 |     await expect(input).toBeFocused();
  1101 |     const canvas = await page.locator('.univer-container canvas').first().elementHandle();
  1102 |     const baseline = await f.read();
  1103 |     let metadataRequested = false;
  1104 |     const metadataGate = new Promise<void>((resolve) => {
  1105 |       releaseMetadata = resolve;
  1106 |     });
  1107 |     await page.route(`**/api/items/${item.id}`, async (route) => {
  1108 |       metadataRequested = true;
  1109 |       await metadataGate;
  1110 |       await route.abort('internetdisconnected');
  1111 |     });
  1112 |     await f.network.setOffline(false);
  1113 |     // The native socket is the connection authority; a background metadata read
  1114 |     // can remain pending without replacing the editor or claiming the draft saved.
  1115 |     await expect(page.getByRole('status', { name: 'Connection status', exact: true })).toHaveText(
  1116 |       'Online',
  1117 |     );
  1118 |     // The fixed Dashboard issues no replacement metadata fetch. If the old
  1119 |     // handoff returns, this route holds it pending and then rejects it; neither
  1120 |     // phase may unmount the editor. The native binding owns its separate
  1121 |     // /collaboration authority checks and socket reconnect throughout.
  1122 |     await page.evaluate(() => new Promise<void>((done) => requestAnimationFrame(() => requestAnimationFrame(() => done()))));
  1123 |     expect(metadataRequested).toBe(false);
  1124 |     const sameEditor = async () => {
  1125 |       expect(
  1126 |         await page
  1127 |           .locator('.univer-container canvas')
  1128 |           .first()
  1129 |           .evaluate((node, original) => node === original, canvas!),
  1130 |       ).toBe(true);
  1131 |       await input.focus();
  1132 |       await page.keyboard.press('Control+a');
  1133 |       await page.keyboard.press('Control+c');
  1134 |       await expect
  1135 |         .poll(async () => (await page.evaluate(() => navigator.clipboard.readText())).trim())
  1136 |         .toBe(draft);
  1137 |       expect((await f.read()).snapshot).toEqual(baseline.snapshot);
  1138 |     };
  1139 |     await sameEditor();
  1140 |     releaseMetadata();
  1141 |     await expect.poll(() => page.locator('.univer-container canvas').count()).toBeGreaterThan(0);
  1142 |     await sameEditor();
  1143 |     await page.unrouteAll();
  1144 |     await page.keyboard.press('Enter');
  1145 |     await synced(page);
```