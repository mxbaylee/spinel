# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: offline.spec.ts >> a warm Dashboard and a failed first-list deep link restore the downloaded Doc content
- Location: e2e/offline.spec.ts:1041:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByText('Failed to fetch')
Expected: 0
Received: 2
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" getByText('Failed to fetch') with timeout 5000ms
  - waiting for getByText('Failed to fetch')
    14 × locator resolved to 2 elements
       - unexpected value "2"

```

# Test source

```ts
  966  |     ] as const) {
  967  |       await page.setViewportSize({ width, height: 1100 });
  968  |       await page.emulateMedia({ colorScheme: theme });
  969  |       await expect(page.locator('html')).toHaveAttribute('data-theme', theme);
  970  |       await expect(
  971  |         page
  972  |           .getByRole('region', { name: 'Offline copy', exact: true })
  973  |           .getByRole('status', { name: 'Save status', exact: true }),
  974  |       ).toHaveText('Saved on this device — waiting to sync.');
  975  |       await expect(
  976  |         page
  977  |           .getByRole('region', { name: 'Offline copy', exact: true })
  978  |           .getByRole('button', { name: 'Bold', exact: true }),
  979  |       ).toBeEnabled();
  980  |       const screenshot = `test-results/theme-screenshots/spn-092-space-native-doc-offline-${variant}-${info.project.name}.png`;
  981  |       await page.screenshot({ path: screenshot, fullPage: true });
  982  |       await info.attach(`Native prepared Space Doc and image (${variant})`, {
  983  |         path: screenshot,
  984  |         contentType: 'image/png',
  985  |       });
  986  |     }
  987  |     await page.setViewportSize({ width: 1440, height: 1100 });
  988  | 
  989  |     const remoteReads: string[] = [];
  990  |     page.on('request', (request) => {
  991  |       const path = new URL(request.url()).pathname;
  992  |       if (/^\/(?:api\/(?:spaces|items)(?:\/|$)|space-api\/)/.test(path)) remoteReads.push(path);
  993  |     });
  994  |     await page.getByRole('button', { name: 'My files', exact: true }).click();
  995  |     await expect(page.getByRole('heading', { name: 'My files', exact: true })).toBeVisible();
  996  |     const contents = page.getByRole('list', { name: 'Folder contents', exact: true });
  997  |     const rootRow = contents.getByRole('listitem').filter({
  998  |       has: page.locator('.dashboard-file-open', { hasText: root.name }),
  999  |     });
  1000 |     await expect(rootRow).toContainText('Space');
  1001 |     await expect(contents.getByText(doc.name, { exact: true })).toHaveCount(0);
  1002 |     await expect(contents.getByText(missing.name, { exact: true })).toHaveCount(0);
  1003 |     await rootRow.getByRole('button', { name: `${root.name} Space`, exact: true }).click();
  1004 |     await expect(page).toHaveURL(baseURL! + rootHref);
  1005 |     await assertPreparedDoc();
  1006 | 
  1007 |     const missingHref = `${rootHref}?item=${missing.id}`;
  1008 |     await page.goto(missingHref);
  1009 |     await expect(page).toHaveURL(baseURL! + missingHref);
  1010 |     await expect(
  1011 |       page.getByRole('status').filter({ hasText: 'This page needs a connection.' }),
  1012 |     ).toHaveText(
  1013 |       'This page needs a connection. It has not been prepared in this Space on this device.',
  1014 |     );
  1015 |     await expect(page.getByRole('heading', { name: root.name, exact: true })).toBeVisible();
  1016 |     await expect(page.getByRole('region', { name: 'Offline copy', exact: true })).toHaveCount(0);
  1017 |     await expect(page.locator('.univer-container')).toHaveCount(0);
  1018 |     // A prepared sibling remains a deliberate navigation choice, never a
  1019 |     // substitute for the explicit child in the address bar.
  1020 |     await expect(
  1021 |       page
  1022 |         .getByRole('navigation', { name: 'Prepared pages', exact: true })
  1023 |         .getByRole('link', { name: doc.name, exact: true }),
  1024 |     ).toHaveAttribute('href', docHref);
  1025 |     expect(remoteReads).toEqual([]);
  1026 |     expect(errors).toEqual([]);
  1027 |     // The account destination remains available from a prepared Space, including
  1028 |     // the local sign-out that locks its saved documents until online sign-in.
  1029 |     await page.getByRole('button', { name: 'Your profile', exact: true }).click();
  1030 |     await expect(page).toHaveURL(baseURL! + '/profile');
  1031 |     await expect(page.getByRole('heading', { name: 'Your profile', exact: true })).toBeVisible();
  1032 |     await page.getByRole('button', { name: 'Sign out', exact: true }).click();
  1033 |     await expect(page).toHaveURL(baseURL! + '/sign-in');
  1034 |   } finally {
  1035 |     await context.close();
  1036 |     db.close();
  1037 |   }
  1038 | });
  1039 | 
  1040 | // Warm and deep-link opens must restore real native content, not just the frame.
  1041 | test('a warm Dashboard and a failed first-list deep link restore the downloaded Doc content', async ({
  1042 |   browser,
  1043 |   baseURL,
  1044 | }, info) => {
  1045 |   test.setTimeout(180_000);
  1046 |   const text = 'Downloaded Doc 090: every saved word survives a warm open and first-list failure.';
  1047 |   const seed = getDocsEmptySnapshot(
  1048 |     'warm-doc-090',
  1049 |     LocaleType.EN_US,
  1050 |     'Warm saved notes',
  1051 |     DocumentFlavor.MODERN,
  1052 |   );
  1053 |   seed.body = {
  1054 |     ...seed.body,
  1055 |     dataStream: text + '\r\n',
  1056 |     paragraphs: [{ startIndex: text.length, paragraphId: createParagraphId(new Set()) }],
  1057 |     sectionBreaks: [{ startIndex: text.length + 1, sectionId: createSectionId(new Set()) }],
  1058 |   };
  1059 |   const f = await fixture(browser, baseURL!, info, 'doc', { seed });
  1060 |   const { page, item } = f;
  1061 |   const restoredContent = async () => {
  1062 |     await usableCanvas(page);
  1063 |     const content = await copy(page, 'doc');
  1064 |     expect(content.trim()).toBe(text);
  1065 |     await expect(page.getByText("This item isn't available")).toHaveCount(0);
> 1066 |     await expect(page.getByText('Failed to fetch')).toHaveCount(0);
       |                                                     ^ Error: expect(locator).toHaveCount(expected) failed
  1067 |   };
  1068 |   try {
  1069 |     await f.download();
  1070 |     await page.getByRole('button', { name: 'Back to files', exact: true }).click();
  1071 |     await f.network.setOffline(true);
  1072 |     await page.getByRole('button', { name: `${item.name} Doc`, exact: true }).click();
  1073 |     await restoredContent();
  1074 |     // A new Dashboard has no in-memory metadata. Its live session succeeds,
  1075 |     // but only the prepared catalog can supply the failed list/item request.
  1076 |     await f.network.setOffline(false);
  1077 |     await page.route('**/api/items{,/**}', (route) => route.abort('internetdisconnected'));
  1078 |     await page.goto(f.href);
  1079 |     await restoredContent();
  1080 |     // A real denied response remains authoritative even with the same saved copy.
  1081 |     await page.unrouteAll();
  1082 |     await page.route(`**/api/items/${item.id}`, (route) =>
  1083 |       route.fulfill({
  1084 |         status: 403,
  1085 |         contentType: 'application/json',
  1086 |         body: JSON.stringify({ error: 'Access denied.' }),
  1087 |       }),
  1088 |     );
  1089 |     await page.goto(f.href);
  1090 |     await expect(page.getByText("This item isn't available")).toBeVisible();
  1091 |     await expect(page.getByRole('region', { name: 'Offline copy', exact: true })).toHaveCount(0);
  1092 |   } finally {
  1093 |     await f.close();
  1094 |   }
  1095 | });
  1096 | 
  1097 | // A network transition is not permission to dispose a native editor's unfinished
  1098 | // input. One real Sheet draft exercises the shared Dashboard/OfflineViewer lifetime.
  1099 | test('a warm offline Sheet keeps unfinished native input through reconnect and delayed failed metadata', async ({
  1100 |   browser,
  1101 |   baseURL,
  1102 | }, info) => {
  1103 |   test.setTimeout(180_000);
  1104 |   const f = await fixture(browser, baseURL!, info, 'sheet');
  1105 |   const { page, item } = f;
  1106 |   let releaseMetadata = () => {};
  1107 |   try {
  1108 |     await f.download();
  1109 |     await page.getByRole('button', { name: 'Back to files', exact: true }).click();
  1110 |     await f.network.setOffline(true);
  1111 |     await page.getByRole('button', { name: `${item.name} Sheet`, exact: true }).click();
  1112 |     await usableCanvas(page);
  1113 |     await selectCell(page, 'D1');
  1114 |     const draft = 'Unfinished warm reconnect cell 090';
  1115 |     await page.keyboard.insertText(draft);
  1116 |     const input = page.locator(
  1117 |       `[id="__editor_${DOCS_NORMAL_EDITOR_UNIT_ID_KEY}"][contenteditable="true"][data-u-comp="editor"]`,
  1118 |     );
  1119 |     await expect(input).toBeFocused();
  1120 |     const canvas = await page.locator('.univer-container canvas').first().elementHandle();
  1121 |     const baseline = await f.read();
  1122 |     let metadataRequested = false;
  1123 |     const metadataGate = new Promise<void>((resolve) => {
  1124 |       releaseMetadata = resolve;
  1125 |     });
  1126 |     await page.route(`**/api/items/${item.id}`, async (route) => {
  1127 |       metadataRequested = true;
  1128 |       await metadataGate;
  1129 |       await route.abort('internetdisconnected');
  1130 |     });
  1131 |     await f.network.setOffline(false);
  1132 |     // The native socket is the connection authority; a background metadata read
  1133 |     // can remain pending without replacing the editor or claiming the draft saved.
  1134 |     await expect(page.getByRole('status', { name: 'Connection status', exact: true })).toHaveText(
  1135 |       'Online',
  1136 |     );
  1137 |     // The fixed Dashboard issues no replacement metadata fetch. If the old
  1138 |     // handoff returns, this route holds it pending and then rejects it; neither
  1139 |     // phase may unmount the editor. The native binding owns its separate
  1140 |     // /collaboration authority checks and socket reconnect throughout.
  1141 |     await page.evaluate(
  1142 |       () =>
  1143 |         new Promise<void>((done) =>
  1144 |           requestAnimationFrame(() => requestAnimationFrame(() => done())),
  1145 |         ),
  1146 |     );
  1147 |     const sameEditor = async () => {
  1148 |       expect(
  1149 |         await page
  1150 |           .locator('.univer-container canvas')
  1151 |           .first()
  1152 |           .evaluate((node, original) => node === original, canvas!),
  1153 |       ).toBe(true);
  1154 |       await input.focus();
  1155 |       await page.keyboard.press('Control+a');
  1156 |       await page.keyboard.press('Control+c');
  1157 |       await expect
  1158 |         .poll(async () => (await page.evaluate(() => navigator.clipboard.readText())).trim())
  1159 |         .toBe(draft);
  1160 |       expect((await f.read()).snapshot).toEqual(baseline.snapshot);
  1161 |     };
  1162 |     await sameEditor();
  1163 |     expect(metadataRequested).toBe(false);
  1164 |     releaseMetadata();
  1165 |     await expect.poll(() => page.locator('.univer-container canvas').count()).toBeGreaterThan(0);
  1166 |     await sameEditor();
```