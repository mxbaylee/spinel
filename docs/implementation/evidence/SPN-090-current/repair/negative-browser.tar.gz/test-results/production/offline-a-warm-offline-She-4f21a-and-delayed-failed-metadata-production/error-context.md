# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: offline.spec.ts >> a warm offline Sheet keeps unfinished native input through reconnect and delayed failed metadata
- Location: e2e/offline.spec.ts:1099:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  1053 |   seed.body = {
  1054 |     ...seed.body,
  1055 |     dataStream: text + '\r\n',
  1056 |     paragraphs: [{ startIndex: text.length, paragraphId: createParagraphId(new Set()) }],
  1057 |     sectionBreaks: [{ startIndex: text.length + 1, sectionId: createSectionId(new Set()) }],
  1058 |   };
  1059 |   const f = await fixture(browser, baseURL!, info, 'doc', { seed });
  1060 |   const { page, item } = f;
  1061 |   const restoredContent = async () => {
  1062 |     await usableCanvas(page);
  1063 |     const content = await copy(page, 'doc');
  1064 |     expect(content.trim()).toBe(text);
  1065 |     await expect(page.getByText("This item isn't available")).toHaveCount(0);
  1066 |     await expect(page.getByText('Failed to fetch')).toHaveCount(0);
  1067 |   };
  1068 |   try {
  1069 |     await f.download();
  1070 |     await page.getByRole('button', { name: 'Back to files', exact: true }).click();
  1071 |     await f.network.setOffline(true);
  1072 |     await page.getByRole('button', { name: `${item.name} Doc`, exact: true }).click();
  1073 |     await restoredContent();
  1074 |     // A new Dashboard has no in-memory metadata. Its live session succeeds,
  1075 |     // but only the prepared catalog can supply the failed list/item request.
  1076 |     await f.network.setOffline(false);
  1077 |     await page.route('**/api/items{,/**}', (route) => route.abort('internetdisconnected'));
  1078 |     await page.goto(f.href);
  1079 |     await restoredContent();
  1080 |     // A real denied response remains authoritative even with the same saved copy.
  1081 |     await page.unrouteAll();
  1082 |     await page.route(`**/api/items/${item.id}`, (route) =>
  1083 |       route.fulfill({
  1084 |         status: 403,
  1085 |         contentType: 'application/json',
  1086 |         body: JSON.stringify({ error: 'Access denied.' }),
  1087 |       }),
  1088 |     );
  1089 |     await page.goto(f.href);
  1090 |     await expect(page.getByText("This item isn't available")).toBeVisible();
  1091 |     await expect(page.getByRole('region', { name: 'Offline copy', exact: true })).toHaveCount(0);
  1092 |   } finally {
  1093 |     await f.close();
  1094 |   }
  1095 | });
  1096 | 
  1097 | // A network transition is not permission to dispose a native editor's unfinished
  1098 | // input. One real Sheet draft exercises the shared Dashboard/OfflineViewer lifetime.
  1099 | test('a warm offline Sheet keeps unfinished native input through reconnect and delayed failed metadata', async ({
  1100 |   browser,
  1101 |   baseURL,
  1102 | }, info) => {
  1103 |   test.setTimeout(180_000);
  1104 |   const f = await fixture(browser, baseURL!, info, 'sheet');
  1105 |   const { page, item } = f;
  1106 |   let releaseMetadata = () => {};
  1107 |   try {
  1108 |     await f.download();
  1109 |     await page.getByRole('button', { name: 'Back to files', exact: true }).click();
  1110 |     await f.network.setOffline(true);
  1111 |     await page.getByRole('button', { name: `${item.name} Sheet`, exact: true }).click();
  1112 |     await usableCanvas(page);
  1113 |     await selectCell(page, 'D1');
  1114 |     const draft = 'Unfinished warm reconnect cell 090';
  1115 |     await page.keyboard.insertText(draft);
  1116 |     const input = page.locator(
  1117 |       `[id="__editor_${DOCS_NORMAL_EDITOR_UNIT_ID_KEY}"][contenteditable="true"][data-u-comp="editor"]`,
  1118 |     );
  1119 |     await expect(input).toBeFocused();
  1120 |     const canvas = await page.locator('.univer-container canvas').first().elementHandle();
  1121 |     const baseline = await f.read();
  1122 |     let metadataRequested = false;
  1123 |     const metadataGate = new Promise<void>((resolve) => {
  1124 |       releaseMetadata = resolve;
  1125 |     });
  1126 |     await page.route(`**/api/items/${item.id}`, async (route) => {
  1127 |       metadataRequested = true;
  1128 |       await metadataGate;
  1129 |       await route.abort('internetdisconnected');
  1130 |     });
  1131 |     await f.network.setOffline(false);
  1132 |     // The native socket is the connection authority; a background metadata read
  1133 |     // can remain pending without replacing the editor or claiming the draft saved.
  1134 |     await expect(page.getByRole('status', { name: 'Connection status', exact: true })).toHaveText(
  1135 |       'Online',
  1136 |     );
  1137 |     // The fixed Dashboard issues no replacement metadata fetch. If the old
  1138 |     // handoff returns, this route holds it pending and then rejects it; neither
  1139 |     // phase may unmount the editor. The native binding owns its separate
  1140 |     // /collaboration authority checks and socket reconnect throughout.
  1141 |     await page.evaluate(
  1142 |       () =>
  1143 |         new Promise<void>((done) =>
  1144 |           requestAnimationFrame(() => requestAnimationFrame(() => done())),
  1145 |         ),
  1146 |     );
  1147 |     const sameEditor = async () => {
  1148 |       expect(
  1149 |         await page
  1150 |           .locator('.univer-container canvas')
  1151 |           .first()
  1152 |           .evaluate((node, original) => node === original, canvas!),
> 1153 |       ).toBe(true);
       |         ^ Error: expect(received).toBe(expected) // Object.is equality
  1154 |       await input.focus();
  1155 |       await page.keyboard.press('Control+a');
  1156 |       await page.keyboard.press('Control+c');
  1157 |       await expect
  1158 |         .poll(async () => (await page.evaluate(() => navigator.clipboard.readText())).trim())
  1159 |         .toBe(draft);
  1160 |       expect((await f.read()).snapshot).toEqual(baseline.snapshot);
  1161 |     };
  1162 |     await sameEditor();
  1163 |     expect(metadataRequested).toBe(false);
  1164 |     releaseMetadata();
  1165 |     await expect.poll(() => page.locator('.univer-container canvas').count()).toBeGreaterThan(0);
  1166 |     await sameEditor();
  1167 |     await page.unrouteAll();
  1168 |     await page.keyboard.press('Enter');
  1169 |     await synced(page);
  1170 |     await expect
  1171 |       .poll(
  1172 |         async () =>
  1173 |           (await f.read()).snapshot.sheets[baseline.snapshot.sheetOrder[0]].cellData?.[0]?.[3]?.v,
  1174 |       )
  1175 |       .toBe(draft);
  1176 |   } finally {
  1177 |     releaseMetadata();
  1178 |     await f.close();
  1179 |   }
  1180 | });
  1181 | 
```