# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: offline.spec.ts >> a warm Dashboard and a failed first-list deep link restore the downloaded Doc content
- Location: e2e/offline.spec.ts:1041:1

# Error details

```
Error: The restored native canvas must have a visible layout height.

The restored native canvas must have a visible layout height.

expect(received).toBeGreaterThan(expected)

Expected: > 100
Received:   0

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Test source

```ts
  1   | import { randomUUID } from 'node:crypto';
  2   | import { writeFile } from 'node:fs/promises';
  3   | import { expect } from '@playwright/test';
  4   | import type {
  5   |   Browser,
  6   |   BrowserContext,
  7   |   BrowserContextOptions,
  8   |   Page,
  9   |   TestInfo,
  10  | } from '@playwright/test';
  11  | import type { IDocumentData, IWorkbookData } from '@univerjs/core';
  12  | import {
  13  |   createParagraphId,
  14  |   createSectionId,
  15  |   DocumentFlavor,
  16  |   getDocsEmptySnapshot,
  17  |   LocaleType,
  18  |   validateDocumentStructure,
  19  | } from '@univerjs/core';
  20  | import type { ClientCheckpoint, NativeSnapshot } from '@spinel/sync-client';
  21  | import {
  22  |   canonical,
  23  |   inlineSnapshotCell,
  24  |   normalizedCell,
  25  |   normalizedDocBody,
  26  | } from '@spinel/sync-transform';
  27  | import { openDatabase } from '../server/database.ts';
  28  | import { AuthStore, COOKIE_NAME } from '../src/server/auth/store.ts';
  29  | import { WorkspaceStore } from '../src/server/workspace/store.ts';
  30  | import { DocumentStore } from '../src/server/workspace/documents.ts';
  31  | import { SpaceStore } from '../src/server/workspace/spaces.ts';
  32  | import { PortableFiles } from '../src/server/workspace/portable.ts';
  33  | import type { OfflineBundle } from '../src/shared/offlineBundle.ts';
  34  | import { sheetImageFixture } from './sheet-image-fixture.ts';
  35  | import { recordNativeSnapshots } from './sync-snapshot.ts';
  36  | import { syncNetwork } from './sync-network.ts';
  37  | import type { CreationTransportPost } from './offline-creation-network.ts';
  38  | 
  39  | export type Kind = 'sheet' | 'doc';
  40  | export type Stored = {
  41  |   bundle: OfflineBundle;
  42  |   recovery?: {
  43  |     recoveryId: string;
  44  |     filename: string;
  45  |     snapshot: NativeSnapshot;
  46  |     possibleReplayCrash: boolean;
  47  |   };
  48  |   outbox?: {
  49  |     account: string;
  50  |     item: string;
  51  |     spaceId?: string;
  52  |     unitId: string;
  53  |     checkpoint: ClientCheckpoint;
  54  |   };
  55  | };
  56  | export const saveStatus = (page: Page) =>
  57  |   page.getByRole('status', { name: 'Save status', exact: true });
  58  | export const nativeInput = (page: Page) =>
  59  |   page.locator('[contenteditable="true"][data-u-comp="editor"]');
  60  | export const savedLocally = (page: Page) =>
  61  |   expect(saveStatus(page)).toHaveText('Saved on this device — waiting to sync.', {
  62  |     timeout: 30_000,
  63  |   });
  64  | export const synced = (page: Page) =>
  65  |   expect(saveStatus(page)).toHaveText(
  66  |     'Synced. All changes are saved on the server and this device.',
  67  |     { timeout: 30_000 },
  68  |   );
  69  | export const attention = (page: Page) =>
  70  |   expect(saveStatus(page)).toContainText('Needs attention.', { timeout: 30_000 });
  71  | export const pending = (checkpoint?: ClientCheckpoint) =>
  72  |   Boolean(checkpoint?.sent || checkpoint?.buffer.length || checkpoint?.failure);
  73  | 
  74  | export async function usableCanvas(page: Page) {
  75  |   await expect
  76  |     .poll(
  77  |       () =>
  78  |         page.locator('.univer-container canvas').evaluateAll((canvases) =>
  79  |           // Sheets also renders its short formula-bar input as a canvas. Check
  80  |           // the document surface, independent of those auxiliary canvas nodes.
  81  |           Math.max(0, ...canvases.map((canvas) => canvas.getBoundingClientRect().height)),
  82  |         ),
  83  |       {
  84  |         message: 'The restored native canvas must have a visible layout height.',
  85  |         timeout: 15_000,
  86  |       },
  87  |     )
> 88  |     .toBeGreaterThan(100);
      |      ^ Error: The restored native canvas must have a visible layout height.
  89  | }
  90  | 
  91  | export async function stored(page: Page, accountId: string, itemId: string) {
  92  |   return page.evaluate(
  93  |     async ({ accountId, itemId }) => {
  94  |       const name = `spinel-offline-${accountId}`;
  95  |       if (!(await indexedDB.databases()).some((database) => database.name === name)) return;
  96  |       return new Promise<Stored | undefined>((resolve, reject) => {
  97  |         const opening = indexedDB.open(`spinel-offline-${accountId}`);
  98  |         opening.onerror = () => reject(opening.error);
  99  |         opening.onupgradeneeded = () => {
  100 |           opening.transaction?.abort();
  101 |           reject(new Error('The device database was removed during observation.'));
  102 |         };
  103 |         opening.onsuccess = () => {
  104 |           const database = opening.result;
  105 |           if (!database.objectStoreNames.contains('items')) {
  106 |             database.close();
  107 |             resolve(undefined);
  108 |             return;
  109 |           }
  110 |           const read = database.transaction('items').objectStore('items').get(itemId);
  111 |           read.onerror = () => {
  112 |             database.close();
  113 |             reject(read.error);
  114 |           };
  115 |           read.onsuccess = () => {
  116 |             database.close();
  117 |             resolve(read.result);
  118 |           };
  119 |         };
  120 |       });
  121 |     },
  122 |     { accountId, itemId },
  123 |   );
  124 | }
  125 | 
  126 | export async function selectCell(page: Page, address: string) {
  127 |   const name = page
  128 |     .getByRole('region', { name: 'Sheet document', exact: true })
  129 |     .locator('[data-u-comp="defined-name"] input');
  130 |   await name.fill(address);
  131 |   await name.press('Enter');
  132 | }
  133 | 
  134 | export async function edit(page: Page, kind: Kind, text: string, address = 'D1') {
  135 |   if (kind === 'sheet') await selectCell(page, address);
  136 |   else {
  137 |     await page.locator('.univer-container').click({ position: { x: 130, y: 200 } });
  138 |     await nativeInput(page).focus();
  139 |     await page.keyboard.press('Control+Home');
  140 |   }
  141 |   // insertText goes through the real native input/composition path and commits
  142 |   // one user insertion; tests never invoke a writable editor/debug global.
  143 |   await page.keyboard.insertText(text);
  144 |   if (kind === 'sheet') await page.keyboard.press('Enter');
  145 | }
  146 | 
  147 | export async function copy(page: Page, kind: Kind, address = 'D1') {
  148 |   if (kind === 'sheet') await selectCell(page, address);
  149 |   else {
  150 |     await page.locator('.univer-container').click({ position: { x: 130, y: 200 } });
  151 |     await nativeInput(page).focus();
  152 |     await page.keyboard.press('Control+a');
  153 |   }
  154 |   const sentinel = `not-copied-${randomUUID()}`;
  155 |   await page.evaluate((text) => navigator.clipboard.writeText(text), sentinel);
  156 |   await page.keyboard.press('Control+c');
  157 |   await expect.poll(() => page.evaluate(() => navigator.clipboard.readText())).not.toBe(sentinel);
  158 |   return page.evaluate(() => navigator.clipboard.readText());
  159 | }
  160 | 
  161 | /** Same documented defaults as existing native acceptance; every field remains compared. */
  162 | export function comparable(snapshot: NativeSnapshot) {
  163 |   if (!('sheets' in snapshot))
  164 |     return JSON.parse(
  165 |       canonical({ ...snapshot, rev: undefined, body: normalizedDocBody(snapshot.body) }),
  166 |     );
  167 |   const sheets = Object.fromEntries(
  168 |     Object.entries(snapshot.sheets).map(([sheetId, sheet]) => [
  169 |       sheetId,
  170 |       {
  171 |         ...sheet,
  172 |         cellData: Object.fromEntries(
  173 |           Object.entries(sheet.cellData ?? {})
  174 |             .map(([row, columns]) => [
  175 |               row,
  176 |               Object.fromEntries(
  177 |                 Object.keys(columns ?? {}).flatMap((column) => {
  178 |                   const value = normalizedCell(
  179 |                     inlineSnapshotCell(snapshot, {
  180 |                       sheetId,
  181 |                       row: Number(row),
  182 |                       column: Number(column),
  183 |                     }),
  184 |                   );
  185 |                   return value ? [[column, value]] : [];
  186 |                 }),
  187 |               ),
  188 |             ])
```