# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: startup-lifecycle.spec.ts >> guest startup reporting ends when a ready guest mounts after slow app code
- Location: e2e/startup-lifecycle.spec.ts:81:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('status').filter({ hasText: /^Still starting:/ })
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" getByRole('status').filter({ hasText: /^Still starting:/ }) with timeout 5000ms
  - waiting for getByRole('status').filter({ hasText: /^Still starting:/ })
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e4]:
    - banner [ref=e5]:
      - generic "Spinel" [ref=e6] [cursor=pointer]:
        - img "Spinel" [ref=e7]
      - generic [ref=e32]:
        - status "Connection status" [ref=e33]: Online
        - button "Online — connected to Spinel" [ref=e34] [cursor=pointer]
      - radiogroup "Appearance" [ref=e39]:
        - radio "Follow system" [checked] [ref=e40] [cursor=pointer]
        - radio [checked] [aria-hidden] [ref=e43]
        - radio "Light" [ref=e44] [cursor=pointer]
        - radio [aria-hidden] [ref=e47]
        - radio "Dark" [ref=e48] [cursor=pointer]
        - radio [aria-hidden] [ref=e51]
    - complementary "Space contents" [ref=e52]:
      - button "Collapse navigation" [ref=e54] [cursor=pointer]
      - navigation "Pages" [ref=e57]:
        - heading "Shared timer fixture" [level=2] [ref=e58]:
          - generic [aria-hidden] [ref=e59]: 🪷
          - text: Shared timer fixture
        - region "Space pages" [ref=e60]:
          - list
          - paragraph [ref=e61]: No pages yet.
    - main [ref=e62]:
      - generic [ref=e63]:
        - generic [ref=e75]:
          - paragraph [ref=e76]: Space · Shared timer fixture
          - heading "Shared timer fixture" [level=1] [ref=e77]
        - generic [ref=e78]: View only
        - generic [ref=e79]: Guest
      - generic [ref=e80]:
        - heading "This Space is empty" [level=2] [ref=e92]
        - paragraph [ref=e93]: Pages will appear here when an editor adds them.
  - status [ref=e94]: "Still starting: styles (15 s)"
```

# Test source

```ts
  22  |     };
  23  |     browserWindow.clearInterval = (handle) => {
  24  |       if (handle === probe.reporter) probe.cleared = true;
  25  |       clear(handle);
  26  |     };
  27  |   });
  28  | });
  29  | 
  30  | async function reporterCleared(page: Page, cleared: boolean) {
  31  |   await expect
  32  |     .poll(() =>
  33  |       page.evaluate(() => {
  34  |         const probe = (
  35  |           window as unknown as {
  36  |             startupTimerProbe: { reporter: number | null; cleared: boolean };
  37  |           }
  38  |         ).startupTimerProbe;
  39  |         return { started: probe.reporter !== null, cleared: probe.cleared };
  40  |       }),
  41  |     )
  42  |     .toEqual({ started: true, cleared });
  43  | }
  44  | 
  45  | async function beyondDeadline(page: Page, elapsed = 120_000) {
  46  |   // Change wall time, then tick once. Do not exhaust unrelated HTTP deadlines
  47  |   // or replay two minutes of guest polling just to test the startup reporter.
  48  |   await page.clock.setSystemTime((await page.evaluate(() => Date.now())) + elapsed);
  49  |   await page.clock.runFor(1000);
  50  | }
  51  | 
  52  | async function readySpace(page: Page) {
  53  |   await page.route('**' + guestPath, (route) =>
  54  |     route.fulfill({
  55  |       json: { item: { id, kind: 'space', name: 'Shared timer fixture', access: 'viewer' } },
  56  |     }),
  57  |   );
  58  |   await page.route('**/api/guest-spaces/' + id, (route) =>
  59  |     route.fulfill({
  60  |       json: {
  61  |         space: {
  62  |           id,
  63  |           kind: 'space',
  64  |           name: 'Shared timer fixture',
  65  |           parentId: null,
  66  |           spaceId: null,
  67  |           position: null,
  68  |           createdAt: 0,
  69  |           updatedAt: 0,
  70  |         },
  71  |         access: 'viewer',
  72  |         items: [],
  73  |       },
  74  |     }),
  75  |   );
  76  | }
  77  | 
  78  | // This is an actual application -> GuestApp -> Space mount with deterministic
  79  | // HTTP responses. Native editing has its own owners; no SDK editor is needed
  80  | // to verify entry lifecycle, DOM removal and timer disposal.
  81  | test('guest startup reporting ends when a ready guest mounts after slow app code', async ({
  82  |   page,
  83  |   context,
  84  | }) => {
  85  |   await readySpace(page);
  86  |   let release!: () => void;
  87  |   const gate = new Promise<void>((resolve) => {
  88  |     release = resolve;
  89  |   });
  90  |   let requested!: (owner: 'service worker' | 'app code') => void;
  91  |   const applicationRequested = new Promise<'service worker' | 'app code'>((resolve) => {
  92  |     requested = resolve;
  93  |   });
  94  |   // Production precaches the imported application through its real worker;
  95  |   // page.route cannot intercept that worker-owned fetch. Keep both owners gated.
  96  |   await context.route(
  97  |     /\/(?:application\.tsx(?:\?.*)?|assets\/application-[^/]+\.js)$/,
  98  |     async (route) => {
  99  |       requested(route.request().serviceWorker() ? 'service worker' : 'app code');
  100 |       await gate;
  101 |       await route.continue();
  102 |     },
  103 |   );
  104 |   try {
  105 |     await page.goto('/share/' + id, { waitUntil: 'commit' });
  106 |     const owner = await applicationRequested;
  107 |     test.info().annotations.push({ type: 'application delivery gate', description: owner });
  108 |     await beyondDeadline(page, 9000);
  109 |     // Network ownership does not rename the bootstrap's application-import stage.
  110 |     await expect(slowLine(page)).toContainText('Still starting: app code');
  111 |     await expect(
  112 |       page.getByRole('heading', { name: 'This Space is empty', exact: true }),
  113 |     ).toHaveCount(0);
  114 |     await reporterCleared(page, false);
  115 |     release();
  116 |     await expect(
  117 |       page.getByRole('heading', { name: 'This Space is empty', exact: true }),
  118 |     ).toBeVisible();
  119 |     await expect(
  120 |       page.getByRole('heading', { name: 'Shared timer fixture', exact: true, level: 1 }),
  121 |     ).toBeVisible();
> 122 |     await expect(slowLine(page)).toHaveCount(0);
      |                                  ^ Error: expect(locator).toHaveCount(expected) failed
  123 |     await reporterCleared(page, true);
  124 |     await beyondDeadline(page);
  125 |     await expect(slowLine(page)).toHaveCount(0);
  126 |   } finally {
  127 |     release();
  128 |   }
  129 | });
  130 | 
  131 | for (const state of ['unavailable', 'revoked', 'unsupported'] as const) {
  132 |   test(`guest startup reporting ends for ${state} entry`, async ({ page }) => {
  133 |     if (state === 'unsupported')
  134 |       await page.addInitScript(() => {
  135 |         Object.defineProperty(navigator, 'locks', { value: undefined, configurable: true });
  136 |       });
  137 |     await page.route('**' + guestPath, (route) =>
  138 |       route.fulfill({ status: state === 'revoked' ? 404 : 503, json: {} }),
  139 |     );
  140 |     await page.goto('/share/' + id + (state === 'unsupported' ? '#timer-fixture' : ''));
  141 |     if (state === 'unsupported')
  142 |       await expect(page.getByRole('alert')).toHaveText(
  143 |         'Open this link in a current browser that supports Web Locks.',
  144 |       );
  145 |     else
  146 |       await expect(
  147 |         page.getByRole('heading', {
  148 |           name: state === 'revoked' ? 'This link no longer works.' : "You're offline",
  149 |           exact: true,
  150 |         }),
  151 |       ).toBeVisible();
  152 |     await reporterCleared(page, true);
  153 |     await beyondDeadline(page);
  154 |     await expect(slowLine(page)).toHaveCount(0);
  155 |   });
  156 | }
  157 | 
  158 | test('account startup reporting remains live while actual admission is pending', async ({
  159 |   page,
  160 | }) => {
  161 |   let requested!: () => void;
  162 |   const sessionRequested = new Promise<void>((resolve) => {
  163 |     requested = resolve;
  164 |   });
  165 |   await page.route('**/api/auth/session', () => {
  166 |     requested();
  167 |   });
  168 |   await page.goto('/sign-in');
  169 |   await sessionRequested;
  170 |   await beyondDeadline(page, 9000);
  171 |   await expect(slowLine(page)).toContainText('Still starting: sign-in check');
  172 |   await reporterCleared(page, false);
  173 | });
  174 | 
```