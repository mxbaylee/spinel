/** Run from the Spinel checkout with its pinned Node/Playwright installation.
 * This controlled navigation experiment does not run the product or a restore. */
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import type { ServerResponse } from 'node:http';
import { once } from 'node:events';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { writeFile } from 'node:fs/promises';

const { chromium } = await import(pathToFileURL(join(process.cwd(), 'node_modules/@playwright/test/index.mjs')).href);
const evidence: Record<string, unknown> = {
  scope: 'Bounded actual Chromium navigation control; synthetic pages, no product restore or passkey authentication',
  node: process.version,
  cases: [],
};
const cases = evidence.cases as Record<string, unknown>[];
const deferred = () => {
  let resolve!: () => void;
  const promise = new Promise<void>(done => { resolve = done; });
  return { promise, resolve };
};
const bounded = async <T>(promise: Promise<T>, milliseconds = 5000): Promise<T> => {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([promise, new Promise<T>((_resolve, reject) => {
      timer = setTimeout(() => reject(new Error('Experiment readiness deadline exceeded.')), milliseconds);
    })]);
  } finally { clearTimeout(timer); }
};
let mode = '';
let signInRequests = 0;
let health: ServerResponse | undefined;
let firstNavigation: ServerResponse | undefined;
let healthReady = deferred();
let navigationReady = deferred();
const server = createServer((request, response) => {
  response.setHeader('Cache-Control', 'no-store');
  if (request.url === '/health') {
    health = response;
    healthReady.resolve();
    return;
  }
  response.setHeader('Content-Type', 'text/html; charset=utf-8');
  if (request.url === '/admin') {
    response.end('<!doctype html><title>Operator shell control</title><script>fetch("/health").then(response => { if (response.status === 401) location.assign("/sign-in"); });</script>');
    return;
  }
  if (request.url === '/sign-in') {
    signInRequests++;
    if (mode === 'competing-navigation' && signInRequests === 1) {
      firstNavigation = response;
      navigationReady.resolve();
      return;
    }
    response.end('<!doctype html><title>Public sign-in control</title>');
    return;
  }
  response.statusCode = 404;
  response.end();
});
server.listen(0, '127.0.0.1');
await once(server, 'listening');
const address = server.address();
assert.ok(address && typeof address !== 'string');
const origin = `http://127.0.0.1:${address.port}`;
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
try {
  browser = await chromium.launch();
  evidence.browserVersion = browser.version();
  for (const current of ['competing-navigation', 'passive-navigation', 'missing-redirect', 'missing-button']) {
    mode = current;
    signInRequests = 0;
    health = undefined;
    firstNavigation = undefined;
    healthReady = deferred();
    navigationReady = deferred();
    const context = await browser.newContext();
    const page = await context.newPage();
    page.setDefaultTimeout(5000);
    const started = performance.now();
    const result: Record<string, unknown> = { name: current };
    try {
      await page.goto(`${origin}/admin`);
      await bounded(healthReady.promise);
      assert.ok(health);
      if (current === 'competing-navigation') {
        const explicit = page.goto(`${origin}/sign-in`).then(
          () => ({ status: 'resolved' }),
          (error: Error) => ({ status: 'rejected', message: error.message }),
        );
        await bounded(navigationReady.promise);
        health.writeHead(401).end();
        const settled = await bounded(explicit);
        assert.equal(settled.status, 'rejected');
        assert.match(settled.message ?? '', /ERR_ABORTED|interrupted by another navigation/);
        await page.waitForURL(`${origin}/sign-in`);
        assert.equal(signInRequests, 2);
        result.explicitNavigation = settled;
        result.status = 'expected explicit navigation rejection';
      } else if (current === 'missing-redirect') {
        await assert.rejects(page.waitForURL(`${origin}/sign-in`, { timeout: 500 }), /Timeout/);
        assert.equal(signInRequests, 0);
        result.status = 'expected bounded missing-redirect rejection';
      } else {
        const ready = page.waitForURL(`${origin}/sign-in`);
        health.writeHead(401).end();
        await ready;
        assert.equal(signInRequests, 1);
        const button = page.getByRole('button', { name: 'Sign in with a passkey', exact: true });
        if (current === 'missing-button') {
          await assert.rejects(button.click({ timeout: 500 }), /Timeout/);
          result.status = 'expected bounded missing-button rejection';
        } else {
          const click = button.click();
          await page.evaluate(() => {
            const button = document.createElement('button');
            button.textContent = 'Sign in with a passkey';
            button.addEventListener('click', () => { document.title = 'Clicked once'; }, { once: true });
            document.body.append(button);
          });
          await click;
          assert.equal(await page.title(), 'Clicked once');
          result.status = 'passive URL wait and later button action passed';
        }
      }
      result.signInRequests = signInRequests;
      result.elapsedMs = Math.round(performance.now() - started);
      cases.push(result);
    } finally {
      health?.destroy();
      firstNavigation?.destroy();
      await context.close();
    }
  }
  evidence.status = 'passed';
} catch (error) {
  evidence.status = 'failed';
  evidence.error = String(error);
  throw error;
} finally {
  await browser?.close();
  server.closeAllConnections();
  await new Promise<void>(resolve => server.close(() => resolve()));
  evidence.cleanup = { browserClosed: !browser?.isConnected(), serverClosed: !server.listening };
  await writeFile('/workspace/scratch/bcf5836a3f8b/validation/restore-navigation-control-result.json', JSON.stringify(evidence, null, 2) + '\n');
  console.log(JSON.stringify(evidence));
}
