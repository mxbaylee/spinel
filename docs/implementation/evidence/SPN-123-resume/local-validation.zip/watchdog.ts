import { spawn } from 'node:child_process';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';

const [evidencePath, command, ...args] = process.argv.slice(2);
if (!evidencePath || !command) throw new Error('Usage: watchdog.ts evidence.json command ...args');
const startedAt = new Date().toISOString();
const started = performance.now();
const child = spawn(command, args, { stdio: 'inherit' });
const ownerPid = Number(readFileSync('/proc/self/status', 'utf8').match(/^Pid:\s+(\d+)/m)![1]);
let peakKiB = 0;
let aborted: string | null = null;
function sample() {
  const rows = readdirSync('/proc').filter((name) => /^\d+$/.test(name)).flatMap((name) => {
    try {
      const status = readFileSync(`/proc/${name}/status`, 'utf8');
      return [[Number(name), Number(status.match(/^PPid:\s+(\d+)/m)![1]),
        Number(status.match(/^VmRSS:\s+(\d+)/m)?.[1] ?? 0)]];
    } catch { return []; }
  });
  const descendants = new Set<number>([ownerPid]);
  let added = true;
  while (added) {
    added = false;
    for (const [pid, ppid] of rows) if (descendants.has(ppid) && !descendants.has(pid)) {
      descendants.add(pid); added = true;
    }
  }
  const rss = rows.reduce((sum, [pid, , memory]) => sum + (descendants.has(pid) ? memory : 0), 0);
  peakKiB = Math.max(peakKiB, rss);
  if (!aborted && (rss > 2 * 1024 * 1024 || performance.now() - started > 480000)) {
    aborted = rss > 2 * 1024 * 1024 ? 'process tree exceeded 2 GiB' : 'eight minute deadline';
    child.kill('SIGTERM');
  }
}
const timer = setInterval(sample, 100);
child.on('error', (error) => { aborted = String(error); });
child.on('close', (code, signal) => {
  clearInterval(timer);
  const evidence = { startedAt, finishedAt: new Date().toISOString(), node: process.version,
    cwd: process.cwd(), command, args, elapsedMs: Math.round(performance.now() - started),
    peakKiB, code, signal, aborted };
  writeFileSync(evidencePath, JSON.stringify(evidence, null, 2) + '\n');
  console.error(JSON.stringify(evidence));
  process.exit(aborted ? 75 : code ?? 1);
});
