# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: history.spec.ts >> sheet versions can be named, renamed, unnamed and read by a viewer
- Location: e2e/history.spec.ts:8:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: 'Sheet document', exact: true }).getByRole('status', { name: 'Save status' })
Expected substring: "View only"
Timeout: 30000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('region', { name: 'Sheet document', exact: true }).getByRole('status', { name: 'Save status' }) with timeout 30000ms
  - waiting for getByRole('region', { name: 'Sheet document', exact: true }).getByRole('status', { name: 'Save status' })

```

```yaml
- banner:
  - link "Spinel Your docs":
    - /url: /
    - img "Spinel"
    - text: Your docs
  - status "Connection status": Online
  - button "Online — connected to Spinel"
  - button "Collapse navigation" [expanded]
  - navigation "File places":
    - button "My files"
    - button "Shared with me"
  - radiogroup "Appearance":
    - radio "Follow system" [checked]
    - radio "Light"
    - radio "Dark"
  - link "Your profile":
    - /url: /profile
    - text: Version viewer
  - button "Sign out"
- main:
  - region "Your files":
    - heading "My files" [level=1]
    - button "More actions for My files": ···
    - button "New"
    - region "Search your workspace":
      - text: Search files
      - searchbox "Search files"
      - button "Search options"
      - radiogroup "File view":
        - radio "List" [checked]
        - radio "Grid"
      - group: Search help
      - paragraph:
        - text: "Searching:"
        - strong: All accessible files
    - list "Folder contents":
      - listitem:
        - button "Trash Recently deleted files":
          - strong: Trash
          - text: Recently deleted files
    - paragraph: This folder is empty.
```

# Test source

```ts
  1   | import { gunzipSync } from 'node:zlib';
  2   | import { expect, test } from '@playwright/test';
  3   | import { openDatabase } from '../server/database.ts';
  4   | import { AuthStore, COOKIE_NAME } from '../src/server/auth/store.ts';
  5   | import { WorkspaceStore } from '../src/server/workspace/store.ts';
  6   | 
  7   | for (const kind of ['sheet', 'doc'] as const) {
  8   |   test(`${kind} versions can be named, renamed, unnamed and read by a viewer`, async ({
  9   |     page,
  10  |     context,
  11  |     baseURL,
  12  |   }, info) => {
  13  |     test.setTimeout(90_000);
  14  |     const db = openDatabase(`test-results/${info.project.name}/app.sqlite`);
  15  |     const auth = new AuthStore(db),
  16  |       workspace = new WorkspaceStore(auth);
  17  |     const owner = auth.createUser('Version owner'),
  18  |       viewer = auth.createUser('Version viewer');
  19  |     const item = workspace.create(owner.id, { name: 'Version test', kind, parentId: null });
  20  |     workspace.share(owner.id, item.id, viewer.id, 'viewer');
  21  |     const cookie = (user: string) => ({
  22  |       name: COOKIE_NAME,
  23  |       value: auth.createSession(user).token,
  24  |       url: baseURL!.replace('http:', 'https:'),
  25  |       secure: true,
  26  |       httpOnly: true,
  27  |       sameSite: 'Strict' as const,
  28  |     });
  29  |     await context.addCookies([cookie(owner.id)]);
  30  |     const errors: string[] = [];
  31  |     page.on('pageerror', (error) => errors.push(error.message));
  32  |     try {
  33  |       await page.goto(`/?item=${item.id}`);
  34  |       const editor = page.getByRole('region', {
  35  |         name: kind === 'sheet' ? 'Sheet document' : 'Doc document',
  36  |         exact: true,
  37  |       });
  38  |       const saved = editor.getByRole('status', { name: 'Save status' });
  39  |       await expect(saved).toHaveText('All changes saved.', { timeout: 30_000 });
  40  |       if (kind === 'sheet') {
  41  |         const box = editor.getByRole('textbox').nth(2);
  42  |         await box.fill('A1');
  43  |         await box.press('Enter');
  44  |       } else await editor.locator('.univer-container').click({ position: { x: 130, y: 200 } });
  45  |       await page.keyboard.type('Keep this content');
  46  |       if (kind === 'sheet') await page.keyboard.press('Enter');
  47  |       await expect
  48  |         .poll(async () =>
  49  |           JSON.stringify(
  50  |             (await (await context.request.get(`/api/items/${item.id}/${kind}`)).json()).snapshot,
  51  |           ),
  52  |         )
  53  |         .toContain('Keep this content');
  54  |       await expect(saved).toHaveText('All changes saved.');
  55  |       await page.getByRole('button', { name: 'Document actions', exact: true }).click();
  56  |       await page.getByRole('menuitem', { name: 'Versions', exact: true }).click();
  57  |       const panel = page.getByRole('region', { name: 'Version names' });
  58  |       await panel.getByRole('button', { name: 'Name this version', exact: true }).click();
  59  |       await panel.getByLabel('Version name', { exact: true }).fill('Q3 Final Lock');
  60  |       await panel.getByRole('button', { name: 'Save version name' }).click();
  61  |       const named = panel.getByRole('listitem').filter({ hasText: 'Q3 Final Lock' });
  62  |       await expect(named.getByText('Q3 Final Lock', { exact: true })).toBeVisible();
  63  |       const stored = db
  64  |         .prepare('SELECT id,snapshot FROM history_checkpoints WHERE item_id=? AND name=?')
  65  |         .get(item.id, 'Q3 Final Lock')!;
  66  |       expect(gunzipSync(stored.snapshot as Uint8Array).toString()).toContain('Keep this content');
  67  |       await named.getByRole('button', { name: 'Rename version' }).click();
  68  |       await panel.getByLabel('Version name', { exact: true }).fill('Final approved');
  69  |       await panel.getByRole('button', { name: 'Save version name' }).click();
  70  |       await expect(panel.getByText('Final approved', { exact: true })).toBeVisible();
  71  |       // The original collaboration baseline remains a distinct past version.
  72  |       const past = panel.getByRole('listitem').filter({ hasText: 'Unnamed version' }).last();
  73  |       await past.getByRole('button', { name: 'Name version', exact: true }).click();
  74  |       await panel.getByLabel('Version name', { exact: true }).fill('Before editing');
  75  |       await panel.getByRole('button', { name: 'Save version name' }).click();
  76  |       await expect(panel.getByText('Before editing', { exact: true })).toBeVisible();
  77  |       await page.reload();
  78  |       await expect(saved).toHaveText('All changes saved.', { timeout: 30_000 });
  79  |       await page.getByRole('button', { name: 'Document actions', exact: true }).click();
  80  |       await page.getByRole('menuitem', { name: 'Versions', exact: true }).click();
  81  |       await panel
  82  |         .getByRole('listitem')
  83  |         .filter({ hasText: 'Final approved' })
  84  |         .getByRole('button', { name: 'Remove name' })
  85  |         .click();
  86  |       await expect(panel.getByText('Final approved', { exact: true })).toHaveCount(0);
  87  |       expect(
  88  |         db.prepare('SELECT name FROM history_checkpoints WHERE id=?').get(String(stored.id))?.name,
  89  |       ).toBeNull();
  90  |       await context.clearCookies();
  91  |       await context.addCookies([cookie(viewer.id)]);
  92  |       await page.reload();
> 93  |       await expect(saved).toContainText('View only', { timeout: 30_000 });
      |                           ^ Error: expect(locator).toContainText(expected) failed
  94  |       await page.getByRole('button', { name: 'Document actions', exact: true }).click();
  95  |       await page.getByRole('menuitem', { name: 'Versions', exact: true }).click();
  96  |       await expect(panel.getByText('Before editing', { exact: true })).toBeVisible();
  97  |       await expect(
  98  |         panel.getByRole('button', {
  99  |           name: /Name this version|Rename version|Remove name|^Name version$/,
  100 |         }),
  101 |       ).toHaveCount(0);
  102 |       expect(errors).toEqual([]);
  103 |     } finally {
  104 |       db.close();
  105 |     }
  106 |   });
  107 | }
  108 | 
```