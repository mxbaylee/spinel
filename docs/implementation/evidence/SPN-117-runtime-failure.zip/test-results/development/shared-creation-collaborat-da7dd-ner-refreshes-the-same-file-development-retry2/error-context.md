# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: shared-creation.spec.ts >> collaborator creates and edits in a shared folder; owner refreshes the same file
- Location: e2e/shared-creation.spec.ts:8:1

# Error details

```
Error: page.goto: net::ERR_CONNECTION_REFUSED at http://localhost:3100/?item=a9b1e9fe-1aeb-4bdc-bbca-45a249a60226
Call log:
  - navigating to "http://localhost:3100/?item=a9b1e9fe-1aeb-4bdc-bbca-45a249a60226", waiting until "load"

```

# Test source

```ts
  1   | import { mkdir, writeFile } from 'node:fs/promises';
  2   | import { expect, test } from '@playwright/test';
  3   | import type { IWorkbookData } from '@univerjs/core';
  4   | import { openDatabase } from '../server/database.ts';
  5   | import { AuthStore, COOKIE_NAME } from '../src/server/auth/store.ts';
  6   | import { WorkspaceStore } from '../src/server/workspace/store.ts';
  7   | 
  8   | test('collaborator creates and edits in a shared folder; owner refreshes the same file', async ({
  9   |   page,
  10  |   context,
  11  |   browser,
  12  |   baseURL,
  13  | }, info) => {
  14  |   test.setTimeout(120_000);
  15  |   const db = openDatabase(`test-results/${info.project.name}/app.sqlite`);
  16  |   const auth = new AuthStore(db);
  17  |   const workspace = new WorkspaceStore(auth);
  18  |   const owner = auth.createUser('Alex Kim');
  19  |   const collaborator = auth.createUser('Sam Lee');
  20  |   const folder = workspace.create(owner.id, { name: 'Trip 2027', kind: 'folder', parentId: null });
  21  |   workspace.share(owner.id, folder.id, collaborator.id, 'editor');
  22  |   const cookie = (id: string) => ({
  23  |     name: COOKIE_NAME,
  24  |     value: auth.createSession(id).token,
  25  |     url: baseURL!.replace('http:', 'https:'),
  26  |     secure: true,
  27  |     httpOnly: true,
  28  |     sameSite: 'Strict' as const,
  29  |   });
  30  |   await context.addCookies([cookie(owner.id)]);
  31  |   const second = await browser.newContext({ baseURL, viewport: { width: 1440, height: 1000 } });
  32  |   await second.addCookies([cookie(collaborator.id)]);
  33  |   const other = await second.newPage();
  34  |   const errors: string[] = [];
  35  |   let stage = 'open-owner-and-collaborator-folder';
  36  |   for (const tab of [page, other]) tab.on('pageerror', (error) => errors.push(error.message));
  37  |   try {
> 38  |     await page.goto(`/?item=${folder.id}`);
      |                ^ Error: page.goto: net::ERR_CONNECTION_REFUSED at http://localhost:3100/?item=a9b1e9fe-1aeb-4bdc-bbca-45a249a60226
  39  |     await expect(page.getByText('This folder is empty.')).toBeVisible();
  40  |     await other.goto(`/?item=${folder.id}`);
  41  |     await expect(other.getByRole('heading', { name: folder.name, exact: true })).toBeVisible();
  42  |     stage = 'create-and-edit-shared-sheet';
  43  |     await other.getByRole('button', { name: 'New', exact: true }).click();
  44  |     await other.getByRole('menuitem', { name: 'Sheet', exact: true }).click();
  45  |     const dialog = other.getByRole('dialog', { name: 'New sheet', exact: true });
  46  |     await expect(dialog).toContainText('This item will belong to Alex Kim.');
  47  |     await dialog.getByRole('textbox', { name: 'Name', exact: true }).fill('Travel budget');
  48  |     await dialog.getByRole('button', { name: 'Create', exact: true }).click();
  49  |     const sheet = other.getByRole('region', { name: 'Sheet document', exact: true });
  50  |     await expect(sheet.getByRole('status', { name: 'Save status' })).toHaveText(
  51  |       'All changes saved.',
  52  |       {
  53  |         timeout: 20_000,
  54  |       },
  55  |     );
  56  |     const itemId = new URL(other.url()).searchParams.get('item')!;
  57  |     const nameBox = sheet.getByRole('textbox').nth(2);
  58  |     await nameBox.fill('A1');
  59  |     await nameBox.press('Enter');
  60  |     await other.keyboard.type('2027');
  61  |     await other.keyboard.press('Enter');
  62  |     const serverCell = async () => {
  63  |       const response = await context.request.get(`/api/items/${itemId}/sheet`);
  64  |       expect(response.status()).toBe(200);
  65  |       const { snapshot } = (await response.json()) as { snapshot: IWorkbookData };
  66  |       return snapshot.sheets[snapshot.sheetOrder[0]].cellData?.[0]?.[0]?.v;
  67  |     };
  68  |     await expect.poll(serverCell).toBe(2027);
  69  |     await expect(sheet.getByRole('status', { name: 'Save status' })).toHaveText(
  70  |       'All changes saved.',
  71  |     );
  72  |     expect(workspace.fileOwner(itemId)).toBe(owner.id);
  73  |     expect(workspace.get(collaborator.id, itemId)).toMatchObject({
  74  |       parentId: folder.id,
  75  |       access: 'editor',
  76  |       ownerName: owner.name,
  77  |       createdByName: collaborator.name,
  78  |     });
  79  |     await other.getByRole('button', { name: 'Back to files', exact: true }).click();
  80  |     await expect(other.getByRole('heading', { name: folder.name, exact: true })).toBeVisible();
  81  |     const row = other.getByRole('button', { name: 'Travel budget Sheet', exact: true });
  82  |     await expect(row).toContainText('Shared · Can edit');
  83  |     await expect(row).toContainText('Owner: Alex Kim');
  84  |     await expect(row).toContainText('Created by Sam Lee');
  85  |     stage = 'verify-editor-row-actions';
  86  |     await other
  87  |       .getByRole('button', { name: 'More actions for Travel budget', exact: true })
  88  |       .click();
  89  |     const actions = other.getByRole('menu');
  90  |     // Prove the menu is ready before checking absent owner-only actions or
  91  |     // dismissing it; absence alone also passes before the portal has mounted.
  92  |     await expect(actions.getByRole('menuitem', { name: 'Open', exact: true })).toBeVisible();
  93  |     for (const name of ['Rename…', 'Move…', 'Move to Trash', 'Share…'])
  94  |       await expect(actions.getByRole('menuitem', { name, exact: true })).toHaveCount(0);
  95  |     await actions.press('Escape');
  96  |     await expect(actions).toHaveCount(0);
  97  | 
  98  |     stage = 'capture-light-dark-phone';
  99  |     await mkdir('test-results/theme-screenshots', { recursive: true });
  100 |     for (const [theme, width] of [
  101 |       ['light', 1440],
  102 |       ['dark', 1440],
  103 |       ['light', 390],
  104 |     ] as const) {
  105 |       await other.emulateMedia({ colorScheme: theme });
  106 |       await other.setViewportSize({ width, height: 844 });
  107 |       await expect(other.locator('html')).toHaveAttribute('data-theme', theme);
  108 |       await expect
  109 |         .poll(() => other.evaluate(() => document.documentElement.scrollWidth <= innerWidth))
  110 |         .toBe(true);
  111 |       await other.screenshot({
  112 |         path: `test-results/theme-screenshots/spn-069-shared-folder-${theme}-${width}-${info.project.name}.png`,
  113 |         animations: 'disabled',
  114 |       });
  115 |       await other.getByRole('button', { name: 'New', exact: true }).click();
  116 |       await other.getByRole('menuitem', { name: 'Doc', exact: true }).click();
  117 |       await expect(other.getByRole('dialog', { name: 'New doc' })).toContainText(
  118 |         'This item will belong to Alex Kim.',
  119 |       );
  120 |       await other.screenshot({
  121 |         path: `test-results/theme-screenshots/spn-069-shared-new-${theme}-${width}-${info.project.name}.png`,
  122 |         animations: 'disabled',
  123 |       });
  124 |       await other.getByRole('button', { name: 'Cancel', exact: true }).click();
  125 |     }
  126 | 
  127 |     stage = 'owner-refresh-and-open';
  128 |     await page.bringToFront();
  129 |     await page.getByRole('button', { name: 'More actions for Trip 2027', exact: true }).click();
  130 |     await page.getByRole('menuitem', { name: 'Refresh folder', exact: true }).click();
  131 |     await expect(
  132 |       page.getByRole('button', { name: 'Travel budget Sheet', exact: true }),
  133 |     ).toContainText('Created by Sam Lee');
  134 |     await page.getByRole('button', { name: 'Travel budget Sheet', exact: true }).click();
  135 |     await expect(page).toHaveURL(new RegExp(`item=${itemId}$`));
  136 |     await expect(
  137 |       page
  138 |         .getByRole('region', { name: 'Sheet document' })
```