import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {existsSync,readFileSync,writeFileSync} from 'node:fs';
const old='7fd2b0a655513e628ab682174ae231e6a99b2874', previous='c1d0d6e8ded33c10cf555ed2ed05ffd9ebc3a423', base='312e5546386ece21f8e0845d696598cc4d85c731';
const git=(...a:string[])=>execFileSync('git',a,{maxBuffer:64*1024*1024});
const txt=(...a:string[])=>git(...a).toString('utf8').trim();
const hash=(b:Buffer|string)=>createHash('sha256').update(b).digest('hex');
assert.equal(txt('rev-parse',base+'^{tree}'),txt('rev-parse','a9450ed32a55c1689fe46ebd575e45ff0fb66209^{tree}'));
assert.equal(txt('rev-parse',base+'^'),previous);
const paths=(a:string,b:string)=>txt('diff','--no-renames','--name-only',a,b).split('\n');
const incoming=paths(previous,base),owned=paths(previous,old);
const overlaps=incoming.filter(p=>owned.includes(p));
assert.deepEqual(overlaps,['docs/todo/backlog.json','docs/todo/readme.md']);
const exceptions=new Set([...overlaps,'docs/implementation/SPN-123.md','e2e/diagnostics.spec.ts']);
const verified=[];
for(const [parent,entries] of [[base,incoming],[old,owned]] as const)for(const path of entries){
 if(exceptions.has(path))continue;
 if(!txt('ls-tree',parent,'--',path)){assert.ok(!existsSync(path));verified.push({parent,path,deleted:true});continue;}
 const original=git('show',`${parent}:${path}`),current=readFileSync(path);
 assert.ok(current.equals(original),path);verified.push({parent,path,sha256:hash(current),bytes:current.length});
}
const samplePath='/tmp/spinel-dependabot-2026-11-11/spn123-c1-overhead-sample.json';
const sample=JSON.parse(readFileSync(samplePath,'utf8'));
const sampleInputs=Object.entries(sample.source.sha256).map(([path,prior])=>{const current=hash(readFileSync(path));assert.equal(current,prior,path);return{path,sha256:current};});
assert.equal(sampleInputs.length,50);
const source=readFileSync('e2e/diagnostics.spec.ts','utf8');
const prior=git('show',old+':e2e/diagnostics.spec.ts').toString();
// Every existing assertion expression retains its non-whitespace bytes in order.
const assertions=(s:string)=>[...s.matchAll(/\bexpect(?:\.poll)?\([\s\S]*?;/g)].map(m=>m[0].replace(/\s+/g,''));
assert.deepEqual(assertions(source),assertions(prior));
assert.ok(source.includes('3298 : 3299'));
assert.ok(source.includes('rm, writeFile'));
assert.equal((source.match(/const f = await fixture\(/g)||[]).length,5);
assert.equal((source.match(/await withFixtureCleanup\(/g)||[]).length,5);
const output={at:new Date().toISOString(),old,previous,base,prospectiveTreeEqual:true,incomingPaths:incoming.length,ownedPaths:owned.length,overlaps,verifiedParentPaths:verified,changedFixture:{path:'e2e/diagnostics.spec.ts',beforeSha256:hash(prior),afterSha256:hash(source),existingAssertionExpressions:assertions(source).length,originalAssertionsPreserved:true,scenarios:5,change:'Partial acquisition cleanup and first-error-preserving outer cleanup; no feature assertion change.'},sample:{path:samplePath,sha256:hash(readFileSync(samplePath)),measuredSource:sample.source.baseCommit,unchangedInputs:sampleInputs,rerun:false},bookkeeping:JSON.parse(readFileSync('docs/todo/backlog.json','utf8'))};
writeFileSync('/tmp/spn123-312-integration-audit.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({verified:verified.length,incoming:incoming.length,overlaps,assertions:assertions(source).length,sampleInputs:sampleInputs.length}));
