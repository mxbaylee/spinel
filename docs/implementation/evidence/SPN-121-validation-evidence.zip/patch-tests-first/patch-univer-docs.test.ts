/**
 * Copyright 2023-present DreamNum Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Modified for Spinel: execute the pinned public Doc state manager region
 * against real JSONX/TextX operations and controlled service endpoints/timers.
 * Original bundle bytes are semantic and primitive-work negative controls.
 * Source: packages/docs/src/services/doc-state-change-manager.service.ts,
 * dream-num/univer v1.1.0. No Pro package is read or modified.
 */
import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { resolve } from 'node:path';
import { test } from 'node:test';
import { runInNewContext } from 'node:vm';
import * as core from '@univerjs/core';
import type { IDocumentData, JSONXActions } from '@univerjs/core';
import type {
  DocStateChangeManagerService,
  IDocStateChangeInfo,
  IDocStateChangeParams,
} from '@univerjs/docs';
import { BehaviorSubject, Subject, takeUntil } from 'rxjs';
import { patchInstalledDocs, prepareDocsPatch } from './patch-univer-docs.ts';

type Format = 'es' | 'cjs';
type State = IDocStateChangeParams;
type Side = State['redoState'] & { unitId: string; segmentId?: string; trigger?: string };
type Entry = {
  unitID: string;
  undoMutations: { id: string; params: Side }[];
  redoMutations: { id: string; params: Side }[];
};
type Manager = Pick<
  DocStateChangeManagerService,
  | 'getStateCache'
  | 'setStateCache'
  | 'clearHistory'
  | 'flushPendingChanges'
  | 'docStateChange$'
  | 'dispose'
>;
type Request = (snapshot: IDocumentData) => JSONXActions;
const unitId = 'composition-doc';
const readBuild = (format: Format) =>
  readFile(
    new URL(`../../node_modules/@univerjs/docs/lib/${format}/index.js`, import.meta.url),
    'utf8',
  );

function clock() {
  let now = 0;
  let nextId = 1;
  const pending = new Map<number, { at: number; callback: () => void }>();
  return {
    count: () => pending.size,
    setTimeout(callback: () => void, delay: number) {
      const id = nextId++;
      pending.set(id, { at: now + delay, callback });
      return id;
    },
    clearTimeout(id: number) {
      pending.delete(id);
    },
    tick(milliseconds: number) {
      now += milliseconds;
      for (const [id, task] of [...pending]) {
        if (task.at > now) continue;
        pending.delete(id);
        task.callback();
      }
    },
  };
}

function managerFixture(source: string) {
  const marker = '//#region src/services/doc-state-change-manager.service.ts\n';
  const start = source.indexOf(marker);
  const end = source.indexOf('//#endregion', start);
  assert.ok(start >= 0 && end > start, 'Execute the actual hash-verified manager region.');
  const timers = clock();
  const contextCore = { ...core, Inject: () => () => {}, Optional: () => () => {} };
  const ManagerClass = runInNewContext(
    `${source.slice(start + marker.length, end)}\nDocStateChangeManagerService;`,
    {
      ...contextCore,
      ...timers,
      BehaviorSubject,
      takeUntil,
      _univerjs_core: contextCore,
      rxjs: { BehaviorSubject, takeUntil },
      DocStateEmitService: {},
      _defineProperty: (object: Record<string, unknown>, key: string, value: unknown) => {
        object[key] = value;
        return object;
      },
      __decorate: (_decorators: unknown, constructor: unknown) => constructor,
      __decorateParam: () => () => {},
    },
    { filename: 'docs.installed-state-manager.js', timeout: 1000 },
  );
  const input = new Subject<IDocStateChangeInfo>();
  const history: Entry[] = [];
  const changes: State[] = [];
  const publication: { kind: string; history: number; collaboration: number }[] = [];
  const commands = new Set<(command: { id: string }) => void>();
  let manager: Manager;
  const observe = (kind: string) => {
    const cache = manager.getStateCache(unitId);
    publication.push({
      kind,
      history: cache.history.length,
      collaboration: cache.collaboration.length,
    });
  };
  manager = new ManagerClass(
    {
      pushUndoRedo(entry: Entry) {
        observe('history');
        history.push(structuredClone(entry));
      },
    },
    {
      beforeCommandExecuted(listener: (command: { id: string }) => void) {
        commands.add(listener);
        return { dispose: () => commands.delete(listener) };
      },
    },
    { getCurrentUnitOfType: () => ({ getUnitId: () => unitId }) },
    { docStateChangeParams$: input },
  ) as Manager;
  const subscription = manager.docStateChange$.subscribe((state) => {
    if (!state) return;
    observe('collaboration');
    changes.push(structuredClone(state));
  });
  return {
    manager,
    input,
    timers,
    history,
    changes,
    publication,
    beforeCommand(id: string) {
      for (const listener of commands) listener({ id });
    },
    close() {
      subscription.unsubscribe();
      manager.dispose();
      input.complete();
      assert.equal(commands.size, 0);
      assert.equal(timers.count(), 0);
    },
  };
}

function apply(snapshot: IDocumentData, actions: JSONXActions) {
  const model = new core.DocumentDataModel(structuredClone(snapshot));
  try {
    model.apply(structuredClone(actions));
    return structuredClone(model.getSnapshot());
  } finally {
    model.dispose();
  }
}

function seed(text = 'alpha\rbravo\r\n') {
  const snapshot = core.getDocsEmptySnapshot(
    unitId,
    core.LocaleType.EN_US,
    'Composition',
    core.DocumentFlavor.MODERN,
  );
  snapshot.body = {
    dataStream: text,
    textRuns:
      text.length > 2
        ? [{ st: 0, ed: text.length - 2, ts: { bl: 1, cl: { rgb: '#123456' } } }]
        : [],
    paragraphs: [...text].flatMap((character, index) =>
      character === '\r'
        ? [
            {
              startIndex: index,
              paragraphId: `paragraph-${index}`,
              paragraphStyle: { outlineLevel: 1 },
            },
          ]
        : [],
    ),
    sectionBreaks: [{ startIndex: text.length - 1, sectionId: 'section-one' }],
    customRanges:
      text.length > 6
        ? [
            {
              rangeId: 'link',
              rangeType: core.CustomRangeType.HYPERLINK,
              startIndex: 1,
              endIndex: 3,
              properties: { url: 'https://example.test/old' },
            },
          ]
        : [],
    customDecorations: [],
  };
  return apply(snapshot, null);
}

function sequence(requests: Request[], initial = seed()) {
  const snapshots = [initial];
  const states = requests.map((request, index): State => {
    const before = snapshots.at(-1)!;
    const actions = request(structuredClone(before));
    // This is the native mutation's inverse/apply order. Inversion realizes
    // inserted paragraph identities before the same actions are applied.
    const inverse = core.JSONX.invertWithDoc(actions, before);
    snapshots.push(apply(before, actions));
    return {
      commandId: 'doc.mutation.rich-text-editing',
      unitId,
      trigger: 'doc.command.insert-text',
      segmentId: '',
      noHistory: false,
      debounce: true,
      redoState: {
        actions,
        textRanges: [{ startOffset: index + 1, endOffset: index + 1, collapsed: true }],
        options: { restoreSelection: index % 2 === 0 },
        isEditing: index % 2 !== 0,
        layoutState: { step: index + 1, nested: ['redo', index] },
      },
      undoState: {
        actions: inverse,
        textRanges: [{ startOffset: index, endOffset: index, collapsed: true }],
        options: { restoreSelection: index % 2 !== 0 },
        isEditing: index % 2 === 0,
        layoutState: { step: index, nested: ['undo', index] },
      },
    };
  });
  return { states, snapshots };
}

const edit = (text: core.TextX) => core.JSONX.getInstance().editOp(text.serialize());
const mixed: Request[] = [
  () =>
    edit(
      new core.TextX()
        .retain(2)
        .insert(2, { dataStream: 'XY', textRuns: [{ st: 0, ed: 2, ts: { it: 1 } }] }),
    ),
  () => edit(new core.TextX().retain(3).delete(1)),
  () =>
    edit(
      new core.TextX()
        .retain(8)
        .delete(2)
        .insert(1, { dataStream: 'Z', textRuns: [{ st: 0, ed: 1, ts: { bl: 0 } }] }),
    ),
  () =>
    edit(
      new core.TextX().retain(
        4,
        { dataStream: '', textRuns: [{ st: 0, ed: 4, ts: { bl: 1, it: 1 } }] },
        core.UpdateDocsAttributeType.COVER,
      ),
    ),
  () =>
    edit(
      new core.TextX().retain(
        4,
        { dataStream: '', textRuns: [{ st: 0, ed: 4, ts: { bl: 0 } }] },
        core.UpdateDocsAttributeType.REPLACE,
      ),
    ),
  (snapshot) =>
    edit(
      new core.TextX()
        .retain(snapshot.body!.paragraphs![0].startIndex)
        .retain(
          1,
          {
            dataStream: '',
            paragraphs: [
              {
                startIndex: 0,
                paragraphId: snapshot.body!.paragraphs![0].paragraphId,
                paragraphStyle: {},
              },
            ],
          },
          core.UpdateDocsAttributeType.REPLACE,
        ),
    ),
  (snapshot) => {
    const text = core.BuildTextUtils.customRange.add({
      ranges: [{ startOffset: 0, endOffset: 5, collapsed: false }],
      rangeId: 'replacement-link',
      rangeType: core.CustomRangeType.HYPERLINK,
      properties: { url: 'https://example.test/new' },
      body: snapshot.body!,
    });
    assert.ok(text);
    return edit(text);
  },
  (snapshot) => core.JSONX.getInstance().replaceOp(['title'], snapshot.title, 'Updated title'),
  (snapshot) =>
    edit(
      new core.TextX()
        .retain(snapshot.body!.dataStream.length - 2)
        .insert(1, {
          dataStream: '\r',
          paragraphs: [{ startIndex: 0, paragraphId: 'inserted-paragraph' }],
        }),
    ),
  () => null,
  (snapshot) => edit(new core.TextX().retain(snapshot.body!.paragraphs![0].startIndex).delete(1)),
];

function flush(source: string, history: State[], collaboration = history) {
  const fixture = managerFixture(source);
  try {
    // Native caches are distinct arrays even when their state objects coincide.
    const cache = structuredClone({ history: [...history], collaboration: [...collaboration] });
    const retainedStates = [...cache.history, ...cache.collaboration];
    const before = structuredClone(retainedStates);
    fixture.manager.setStateCache(unitId, cache);
    fixture.manager.flushPendingChanges(unitId);
    assert.deepEqual(retainedStates, before, 'Composition must not mutate native state objects.');
    assert.deepEqual(structuredClone(fixture.manager.getStateCache(unitId)), {
      history: [],
      collaboration: [],
    });
    return { history: fixture.history, changes: fixture.changes, publication: fixture.publication };
  } finally {
    fixture.close();
  }
}

function metadata(output: ReturnType<typeof flush>) {
  const copy = structuredClone(output);
  for (const entry of copy.history)
    for (const mutation of [...entry.undoMutations, ...entry.redoMutations])
      mutation.params.actions = null;
  for (const change of copy.changes) change.redoState.actions = change.undoState.actions = null;
  return copy;
}

function assertSnapshots(
  output: ReturnType<typeof flush>,
  snapshots: IDocumentData[],
  historyStart = 0,
) {
  const after = snapshots.at(-1)!;
  const [entry] = output.history;
  assert.ok(entry);
  assert.deepEqual(apply(snapshots[historyStart], entry.redoMutations[0].params.actions), after);
  assert.deepEqual(apply(after, entry.undoMutations[0].params.actions), snapshots[historyStart]);
  const [change] = output.changes;
  assert.ok(change);
  assert.deepEqual(apply(snapshots[0], change.redoState.actions), after);
  assert.deepEqual(apply(after, change.undoState.actions), snapshots[0]);
}

function measuredFlush(source: string, states: State[]) {
  const counts = { textCompose: 0, iteratorNext: 0, bodySlices: 0, cloneVisits: 0, allocations: 0 };
  const compose = core.TextX.compose;
  const next = core.ActionIterator.prototype.next;
  const clone = core.Tools.deepClone;
  core.TextX.compose = function (this: typeof core.TextX, ...args: Parameters<typeof compose>) {
    counts.textCompose++;
    return Reflect.apply(compose, this, args);
  };
  core.ActionIterator.prototype.next = function (
    this: core.ActionIterator,
    ...args: Parameters<typeof next>
  ) {
    counts.iteratorNext++;
    const action = Reflect.apply(next, this, args) as ReturnType<typeof next>;
    if (
      action.t === core.TextXActionType.INSERT ||
      (action.t === core.TextXActionType.RETAIN && action.body != null)
    )
      counts.bodySlices++;
    return action;
  };
  core.Tools.deepClone = function <T>(this: typeof core.Tools, value: T): T {
    counts.cloneVisits++;
    if (
      this.isDefine(value) &&
      (this.isRegExp(value) ||
        Reflect.apply(this.isDate, this, [value]) ||
        this.isArray(value) ||
        this.isObject(value))
    )
      counts.allocations++;
    return Reflect.apply(clone, this, [value]) as T;
  };
  try {
    return { output: flush(source, states), counts };
  } finally {
    core.TextX.compose = compose;
    core.ActionIterator.prototype.next = next;
    core.Tools.deepClone = clone;
  }
}

for (const format of ['es', 'cjs'] as const) {
  test(`${format}: native publications preserve mixed operations, independent caches and complete metadata`, async () => {
    const { original, patched } = prepareDocsPatch(await readBuild(format), format);
    assert.deepEqual(flush(patched, []), flush(original, []));
    for (const requests of [
      [() => null],
      mixed.slice(0, 1),
      [() => null, mixed[0], () => null],
      mixed.slice(0, 5),
      mixed,
    ]) {
      const { states, snapshots } = sequence(requests);
      for (const historyStart of states.length > 5 ? [0, 4] : [0]) {
        const control = flush(original, states.slice(historyStart), states);
        const candidate = flush(patched, states.slice(historyStart), states);
        assert.deepEqual(
          metadata(candidate),
          metadata(control),
          'First/last selection, options, editing, layout and publication metadata must remain exact.',
        );
        assertSnapshots(control, snapshots, historyStart);
        assertSnapshots(candidate, snapshots, historyStart);
      }
    }
    const { states } = sequence(mixed.slice(0, 5));
    const separateCaches: [State[], State[]][] = [
      [[], states],
      [states, []],
    ];
    for (const caches of separateCaches)
      assert.deepEqual(
        flush(patched, ...caches),
        flush(original, ...caches),
        'Neither cache may substitute for its independent companion.',
      );
  });

  test(`${format}: real composition work falls for both typed inserts and deletes whose undo inserts`, async () => {
    const { original, patched } = prepareDocsPatch(await readBuild(format), format);
    for (const deleting of [false, true]) {
      const initial = seed(deleting ? `${'x'.repeat(32)}\r\n` : '\r\n');
      const requests = Array.from(
        { length: 32 },
        (): Request => (snapshot) =>
          edit(
            deleting
              ? new core.TextX().delete(1)
              : new core.TextX()
                  .retain(snapshot.body!.dataStream.length - 2)
                  .insert(1, {
                    dataStream: 'x',
                    textRuns: [{ st: 0, ed: 1, ts: { cl: { rgb: '#123456' } } }],
                  }),
          ),
      );
      const { states, snapshots } = sequence(requests, initial);
      const control = measuredFlush(original, states);
      const candidate = measuredFlush(patched, states);
      assert.deepEqual(candidate.output, control.output);
      assertSnapshots(candidate.output, snapshots);
      assert.equal(
        control.counts.textCompose,
        124,
        'The native subtype counter must observe all four nontrivial folds.',
      );
      assert.equal(candidate.counts.textCompose, control.counts.textCompose);
      for (const key of ['iteratorNext', 'bodySlices', 'cloneVisits', 'allocations'] as const)
        assert.ok(
          candidate.counts[key] < control.counts[key],
          `${deleting ? 'delete/undo-insert' : 'typing'}: actual ${key} must fall, independently of wall-clock noise.`,
        );
    }
  });

  test(`${format}: native idle, segment, remote and pre-Undo flush boundaries retain their ordering`, async () => {
    const builds = prepareDocsPatch(await readBuild(format), format);
    const { states } = sequence(mixed.slice(0, 5));
    const outputs = [];
    for (const source of [builds.original, builds.patched]) {
      const f = managerFixture(source);
      try {
        f.input.next(states[0]);
        f.timers.tick(299);
        assert.equal(f.history.length, 0);
        f.input.next(states[1]);
        f.timers.tick(299);
        assert.equal(f.history.length, 0);
        f.timers.tick(1);
        assert.equal(f.history.length, 1);
        assert.equal(f.changes.length, 1);
        f.input.next({ ...states[2], segmentId: 'header' });
        f.input.next({ ...states[3], segmentId: 'footer' });
        assert.equal(f.history.length, 2, 'Changing segments closes the previous native group.');
        f.input.next({ ...states[4], isSync: true });
        f.input.next({ ...states[4], noHistory: true });
        assert.equal(f.manager.getStateCache(unitId).history.length, 1);
        f.beforeCommand(core.UndoCommandId);
        assert.equal(f.history.length, 3);
        assert.equal(f.changes.length, 3);
        f.timers.tick(300);
        assert.equal(f.history.length, 3, 'Already-flushed idle callbacks publish nothing.');
        outputs.push(
          structuredClone({ history: f.history, changes: f.changes, publication: f.publication }),
        );
      } finally {
        f.close();
      }
    }
    assert.deepEqual(outputs[1], outputs[0]);
  });

  test(`${format}: guard accepts only the complete pinned original or complete patch`, async () => {
    const { original, patched } = prepareDocsPatch(await readBuild(format), format);
    assert.equal(prepareDocsPatch(patched, format).patched, patched);
    assert.throws(() => prepareDocsPatch(original + '\n// unknown edit', format), /Unrecognized/);
    const json = format === 'cjs' ? '_univerjs_core.JSONX' : 'JSONX';
    const partial = patched.replace(
      'composeDocStateActions(cacheStates, "redoState")',
      `cacheStates.reduce((acc, cur) => ${json}.compose(acc, cur.redoState.actions), null)`,
    );
    assert.throws(() => prepareDocsPatch(partial, format), /Partially modified/);
  });
}

test('Docs installer validates package identity and both complete builds before any write', async (t) => {
  const root = await mkdtemp(resolve(tmpdir(), 'spinel-docs-composition-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const directory = resolve(root, 'node_modules/@univerjs/docs');
  const originals = {
    es: prepareDocsPatch(await readBuild('es'), 'es').original,
    cjs: prepareDocsPatch(await readBuild('cjs'), 'cjs').original,
  };
  for (const format of ['es', 'cjs'] as const) {
    await mkdir(resolve(directory, 'lib', format), { recursive: true });
    await writeFile(resolve(directory, 'lib', format, 'index.js'), originals[format]);
  }
  const metadataPath = resolve(directory, 'package.json');
  for (const metadata of [
    { name: '@univerjs/docs', version: '1.2.0' },
    { name: 'other', version: '1.1.0' },
  ]) {
    await writeFile(metadataPath, JSON.stringify(metadata));
    await assert.rejects(patchInstalledDocs(root), /Upgrading/);
  }
  await writeFile(metadataPath, JSON.stringify({ name: '@univerjs/docs', version: '1.1.0' }));
  const cjs = resolve(directory, 'lib/cjs/index.js');
  await writeFile(cjs, originals.cjs + '\n// unknown edit');
  await assert.rejects(patchInstalledDocs(root), /Unrecognized/);
  assert.equal(await readFile(resolve(directory, 'lib/es/index.js'), 'utf8'), originals.es);
  assert.equal(await readFile(cjs, 'utf8'), originals.cjs + '\n// unknown edit');
  await writeFile(cjs, originals.cjs);
  await patchInstalledDocs(root);
  await patchInstalledDocs(root);
  for (const format of ['es', 'cjs'] as const)
    assert.equal(
      await readFile(resolve(directory, 'lib', format, 'index.js'), 'utf8'),
      prepareDocsPatch(originals[format], format).patched,
    );
});
