import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

root=Path('/workspace/scratch/5386d318a310')
label=sys.argv[1]
command=sys.argv[2:]
assert label.replace('-','').isalnum() and command
folder=root/'spn121-validation'/label
folder.mkdir(parents=True,exist_ok=False)
cgroup=Path('/sys/fs/cgroup/memory.current')
limit=int(Path('/sys/fs/cgroup/memory.max').read_text())
initial=int(cgroup.read_text())
if initial>0.8*limit: raise SystemExit('Deferred: elevated starting memory use')
env=dict(os.environ)
env['PATH']=str(root/'node-v26.12.1-linux-x64/bin')+os.pathsep+env['PATH']
env['NODE_OPTIONS']='--max-old-space-size=1024'
started=time.monotonic()
peak=0
reason=None
with (folder/'output.log').open('w') as log:
 child=subprocess.Popen(command,cwd=root/'spinel-spn121',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while child.poll() is None:
  rows=[tuple(map(int,line.split())) for line in subprocess.check_output(['ps','-eo','pid,ppid,rss','--no-headers'],text=True).splitlines()]
  owned={child.pid}
  while True:
   expanded=owned|{pid for pid,parent,_ in rows if parent in owned}
   if expanded==owned: break
   owned=expanded
  rss=sum(rss for pid,_,rss in rows if pid in owned)
  peak=max(peak,rss)
  if rss>2*1024*1024: reason='2 GiB process-tree RSS limit exceeded'
  elif int(cgroup.read_text())>0.9*limit: reason='elevated cgroup memory use'
  elif time.monotonic()-started>480: reason='480-second deadline exceeded'
  if reason:
   os.killpg(child.pid,signal.SIGKILL)
   break
  time.sleep(0.25)
 status=child.wait()
record={'command':command,'exitCode':status,'resourceAborted':reason is not None,'reason':reason,'elapsedSeconds':time.monotonic()-started,'peakProcessTreeRssKiB':peak,'initialCgroupBytes':initial,'cgroupLimitBytes':limit,'pressureAvailability':'Linux cgroup polling; PSI unavailable'}
(folder/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(124 if reason else status)
