import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import subprocess
import tempfile
import time

root = Path('/workspace/scratch/5386d318a310')
label = sys.argv[1]
command = sys.argv[2:]
assert label.replace('-', '').isalnum() and command
directory = root / 'spn121-validation' / label
directory.mkdir(parents=True, exist_ok=False)
(directory / 'watchdog.py').write_text(Path(__file__).read_text())
node = root / 'node-v26.12.1-linux-x64/bin/node'
current = Path('/sys/fs/cgroup/memory.current')
limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
initial = int(current.read_text())
environment = dict(os.environ)
environment['PATH'] = str(node.parent) + os.pathsep + environment['PATH']
environment['NODE_OPTIONS'] = '--max-old-space-size=1024'
source_paths = [root / 'spinel-spn121/scripts/dependencies' / name for name in ['patch-univer-docs.ts', 'patch-univer-docs.test.ts']]
source_hashes = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
started = time.monotonic()
peak = 0
reason = None
child = None
status = None
# Keep the live stream outside the synced workspace; publish it only after the
# command exits. Earlier close/write synchronization lost a report's final tail.
log = tempfile.TemporaryFile(mode='w+', encoding='utf8')
try:
 if initial > limit * 0.8:
  raise RuntimeError('Elevated starting cgroup memory')
 child = subprocess.Popen(command, cwd=root / 'spinel-spn121', env=environment, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
 while child.poll() is None:
  rows = [tuple(map(int, line.split())) for line in subprocess.check_output(['ps', '-eo', 'pid,ppid,rss', '--no-headers'], text=True).splitlines()]
  owned = {child.pid}
  while True:
   expanded = owned | {pid for pid, parent, _ in rows if parent in owned}
   if expanded == owned: break
   owned = expanded
  rss = sum(rss for pid, _, rss in rows if pid in owned)
  peak = max(peak, rss)
  if rss > 2 * 1024 * 1024: raise RuntimeError('2 GiB process-tree RSS limit exceeded')
  if int(current.read_text()) > limit * 0.9: raise RuntimeError('Elevated cgroup memory')
  if time.monotonic() - started > 480: raise RuntimeError('480-second deadline exceeded')
  time.sleep(0.25)
except Exception as error:
 reason = f'{type(error).__name__}: {error}'
finally:
 if child is not None:
  if reason and child.poll() is None:
   try: os.killpg(child.pid, signal.SIGKILL)
   except ProcessLookupError: pass
  status = child.wait()
 log.flush()
 log.seek(0)
 output = log.read()
 log.close()
 (directory / 'output.log').write_text(output)
result = {'command':command,'exitCode':status,'resourceOrMonitorAborted':reason is not None,'reason':reason,'elapsedSeconds':time.monotonic()-started,'peakProcessTreeRssKiB':peak,'initialCgroupBytes':initial,'cgroupLimitBytes':limit,'pressureAvailability':'Linux cgroup polling; PSI unavailable','failClosedCleanup':True,'outputBytes':len(output.encode()),'outputSha256':hashlib.sha256(output.encode()).hexdigest(),'sourceHashesBefore':source_hashes,'sourceHashesAfter':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}}
(directory/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
raise SystemExit(124 if reason else status)
