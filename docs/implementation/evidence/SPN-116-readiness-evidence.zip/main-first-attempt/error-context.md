# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: offline-creation.spec.ts >> documents created offline >> shared creation survives same-profile browser-process restarts
- Location: e2e/offline-creation.spec.ts:193:3

# Error details

```
Test timeout of 180000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - banner [ref=f2e4]:
    - generic [ref=f2e5]:
      - link [ref=f2e6] [cursor=pointer]:
        - /url: /
        - img "Spinel" [ref=f2e8]
        - generic: Your docs
      - generic [ref=f2e33]:
        - status "Connection status" [ref=f2e34]: Offline
        - button "Offline — not connected to Spinel" [ref=f2e35] [cursor=pointer]
    - navigation "Workspace" [ref=f2e38]:
      - link "Dashboard" [ref=f2e39] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f2e40]: ▦
    - generic [ref=f2e41]:
      - radiogroup "Appearance" [ref=f2e43]:
        - radio "Follow system" [checked] [ref=f2e44] [cursor=pointer]
        - radio [checked] [aria-hidden] [ref=f2e47]
        - radio "Light" [ref=f2e48] [cursor=pointer]
        - radio [aria-hidden] [ref=f2e51]
        - radio "Dark" [ref=f2e52] [cursor=pointer]
        - radio [aria-hidden] [ref=f2e55]
      - link "Your profile" [ref=f2e56] [cursor=pointer]:
        - /url: /profile
        - generic: Restart creator 42defac763e8d20480e7-04bd2b8c4663c9d4d6b7
      - button "Sign out" [ref=f2e61] [cursor=pointer]:
        - generic [aria-hidden] [ref=f2e62]: ↪
  - main [ref=f2e64]:
    - region "Your files" [ref=f2e65]:
      - alert [ref=f2e66]:
        - text: Failed to fetch
        - button "Refresh shared items" [ref=f2e67] [cursor=pointer]
      - region [ref=f2e69]:
        - alert [ref=f2e70]:
          - heading "This item isn't available" [level=1] [ref=f2e71]
        - paragraph [ref=f2e72]: It may have moved, or you may no longer have access.
        - button "Go to My files" [ref=f2e73] [cursor=pointer]
      - alert [ref=f2e74]: Failed to fetch
```