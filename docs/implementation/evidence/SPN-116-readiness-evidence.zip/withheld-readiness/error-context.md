# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: offline-creation.spec.ts >> documents created offline >> shared creation survives same-profile browser-process restarts
- Location: e2e/offline-creation.spec.ts:193:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('list', { name: 'Folder contents', exact: true }).getByRole('button', { name: 'Prepare sheet Sheet', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('list', { name: 'Folder contents', exact: true }).getByRole('button', { name: 'Prepare sheet Sheet', exact: true }) with timeout 5000ms
  - waiting for getByRole('list', { name: 'Folder contents', exact: true }).getByRole('button', { name: 'Prepare sheet Sheet', exact: true })

```

```yaml
- banner:
  - link "Spinel Your docs":
    - /url: /
    - img "Spinel"
    - text: Your docs
  - status "Connection status": Online
  - button "Online — connected to Spinel"
  - button "Collapse navigation" [expanded]
  - navigation "File places":
    - button "My files"
    - button "Shared with me"
  - radiogroup "Appearance":
    - radio "Follow system" [checked]
    - radio "Light"
    - radio "Dark"
  - link "Your profile":
    - /url: /profile
    - text: Restart creator 42defac763e8d20480e7-04bd2b8c4663c9d4d6b7
  - button "Sign out"
- main:
  - region "Your files":
    - navigation "Breadcrumb":
      - button "My files"
    - heading "Restart project" [level=1]
    - button "More actions for Restart project": ···
    - button "New"
    - region "Search your workspace":
      - text: Search files
      - searchbox "Search files"
      - button "Search options"
      - radiogroup "File view":
        - radio "List" [checked]
        - radio "Grid"
      - group: Search help
      - paragraph:
        - text: "Searching:"
        - strong: Restart project
        - button "Search all files"
    - status: Loading your files…
```

# Test source

```ts
  35  | 
  36  | /** Uses the existing production server; every restart opens the same real profile. */
  37  | export async function verifySharedCreationRestart(baseURL: string, info: TestInfo) {
  38  |   const directory = await mkdtemp(join(tmpdir(), 'spinel-shared-creation-restart-'));
  39  |   const db = openDatabase(`test-results/${info.project.name}/app.sqlite`);
  40  |   const auth = new AuthStore(db);
  41  |   const workspace = new WorkspaceStore(auth, { spacesEnabled: true });
  42  |   const owner = auth.createUser(`Restart owner ${info.testId}`);
  43  |   const actor = auth.createUser(`Restart creator ${info.testId}`);
  44  |   const folder = workspace.create(owner.id, {
  45  |     kind: 'folder',
  46  |     name: 'Restart project',
  47  |     parentId: null,
  48  |   });
  49  |   workspace.share(owner.id, folder.id, actor.id, 'editor');
  50  |   const seeds = (['sheet', 'doc'] as const).map((kind) =>
  51  |     workspace.create(owner.id, { kind, name: `Prepare ${kind}`, parentId: folder.id }),
  52  |   );
  53  |   const created: { id: string; kind: Kind; text: string; before: Creation }[] = [];
  54  |   const accepted = new Map<string, { revision: number; snapshot: NativeSnapshot }>();
  55  |   const stages: string[] = [];
  56  |   const errors: string[] = [];
  57  |   const transport = await offlineCreationNetwork(baseURL);
  58  |   let context: BrowserContext | undefined;
  59  |   let heldFolder: Route | undefined;
  60  |   const start = async (offline = false) => {
  61  |     transport.setOffline(offline);
  62  |     // Closing this context terminates its browser process. No storageState or
  63  |     // IndexedDB fixture reconstructs data, and offline precedes any navigation.
  64  |     context = await chromium.launchPersistentContext(join(directory, 'profile'), {
  65  |       headless: true,
  66  |       baseURL,
  67  |       viewport: { width: 1440, height: 1100 },
  68  |       permissions: ['clipboard-read', 'clipboard-write'],
  69  |       offline,
  70  |       proxy: transport.proxy,
  71  |     });
  72  |     await recordNativeSnapshots(context);
  73  |     const network = await syncNetwork(context);
  74  |     await network.setOffline(offline);
  75  |     const page = context.pages()[0] ?? (await context.newPage());
  76  |     expect(await page.evaluate(() => navigator.onLine)).toBe(!offline);
  77  |     page.on('pageerror', (error) => errors.push(error.message));
  78  |     return { page, network };
  79  |   };
  80  |   const serverItem = (id: string) => db.prepare('SELECT * FROM workspace_items WHERE id=?').get(id);
  81  |   const readServer = async (id: string, unitId: string) => {
  82  |     const response = await context!.request.get(
  83  |       `/sync-api/items/${id}/snapshot?unitId=${encodeURIComponent(unitId)}`,
  84  |     );
  85  |     expect(response.status(), await response.text()).toBe(200);
  86  |     return (await response.json()) as { revision: number; snapshot: NativeSnapshot };
  87  |   };
  88  |   try {
  89  |     let { page, network } = await start();
  90  |     const session = auth.createSession(actor.id);
  91  |     await context!.addCookies([
  92  |       {
  93  |         name: COOKIE_NAME,
  94  |         value: session.token,
  95  |         url: baseURL.replace('http:', 'https:'),
  96  |         secure: true,
  97  |         httpOnly: true,
  98  |         sameSite: 'Strict',
  99  |         expires: Math.floor(session.session.expires_at / 1000),
  100 |       },
  101 |     ]);
  102 |     for (const seed of seeds) {
  103 |       await page.goto(`/?item=${seed.id}`);
  104 |       await expect(saveStatus(page)).toHaveText('All changes saved.', { timeout: 30_000 });
  105 |       await expect
  106 |         .poll(() => page.evaluate(() => Boolean(navigator.serviceWorker.controller)))
  107 |         .toBe(true);
  108 |       await page.getByRole('button', { name: 'Document actions', exact: true }).click();
  109 |       await page
  110 |         .getByRole('menuitem', { name: 'Available offline on this device', exact: true })
  111 |         .click();
  112 |       const dialog = page.getByRole('dialog', { name: 'Offline availability', exact: true });
  113 |       await expect(dialog.getByRole('status')).toHaveText(
  114 |         `${seed.name} is available offline on this device.`,
  115 |         { timeout: 120_000 },
  116 |       );
  117 |       await dialog.getByRole('button', { name: 'Done', exact: true }).click();
  118 |       await synced(page);
  119 |     }
  120 |     if (process.env.SPINEL_RESTART_PROBE === 'withheld-readiness')
  121 |       await context!.route(`**/api/items/${folder.id}`, (route) => { heldFolder = route; });
  122 |     await page.goto('/');
  123 |     await page.getByRole('button', { name: 'Shared with me', exact: true }).click();
  124 |     await page.getByRole('button', { name: `${folder.name} Folder`, exact: true }).click();
  125 |     await expect(page.getByRole('heading', { name: folder.name, exact: true })).toBeVisible();
  126 |     // The heading can use the shared-list row before this folder's view loads.
  127 |     // Prepare the actual contents before deliberately cutting its request off.
  128 |     const contents = page.getByRole('list', { name: 'Folder contents', exact: true });
  129 |     for (const seed of seeds)
  130 |       await expect(
  131 |         contents.getByRole('button', {
  132 |           name: `${seed.name} ${seed.kind === 'sheet' ? 'Sheet' : 'Doc'}`,
  133 |           exact: true,
  134 |         }),
> 135 |       ).toBeVisible();
      |         ^ Error: expect(locator).toBeVisible() failed
  136 |     stages.push('shared-folder-view-ready');
  137 |     transport.setOffline(true);
  138 |     await network.setOffline(true);
  139 |     await transport.verifyDisconnected();
  140 |     for (const kind of ['sheet', 'doc'] as const) {
  141 |       await page.getByRole('button', { name: 'New', exact: true }).click();
  142 |       const menu = page.getByRole('menu');
  143 |       await expect(menu.getByRole('menuitem')).toHaveText(['Sheet', 'Doc']);
  144 |       await menu
  145 |         .getByRole('menuitem', { name: kind === 'sheet' ? 'Sheet' : 'Doc', exact: true })
  146 |         .click();
  147 |       const dialog = page.getByRole('dialog', { name: `New ${kind}`, exact: true });
  148 |       await dialog.getByRole('textbox', { name: 'Name' }).fill(`Cold restart ${kind}`);
  149 |       await dialog.getByRole('button', { name: 'Create', exact: true }).click();
  150 |       await expect(page).toHaveURL(/\?item=[a-f\d-]{36}$/);
  151 |       await usableCanvas(page);
  152 |       const id = new URL(page.url()).searchParams.get('item')!;
  153 |       const text = kind === 'sheet' ? '69851' : 'Persisted through a browser process restart 69851';
  154 |       await edit(page, kind, text);
  155 |       await savedLocally(page);
  156 |       const before = (await stored(page, actor.id, id)) as Creation;
  157 |       expect(before.creation).toMatchObject({
  158 |         request: { itemId: id, parentId: folder.id, kind },
  159 |         access: 'editor',
  160 |         ownerName: owner.name,
  161 |         createdByName: actor.name,
  162 |       });
  163 |       expect(before.bundle).toMatchObject({ accountId: actor.id, access: 'editor' });
  164 |       expect(before.outbox).toMatchObject({ account: actor.id, item: id });
  165 |       expect(pending(before.outbox?.checkpoint)).toBe(true);
  166 |       expect(serverItem(id)).toBeUndefined();
  167 |       created.push({ id, kind, text, before });
  168 |       await page.getByRole('button', { name: 'Back to files', exact: true }).click();
  169 |     }
  170 |     stages.push('both-native-drafts-persisted-offline');
  171 |     await context!.close();
  172 |     context = undefined;
  173 |     ({ page, network } = await start(true));
  174 |     for (const item of created) {
  175 |       await page.goto(`/?item=${item.id}`);
  176 |       expect(await page.evaluate(() => navigator.onLine)).toBe(false);
  177 |       await usableCanvas(page);
  178 |       await savedLocally(page);
  179 |       expect(await copy(page, item.kind)).toContain(item.text);
  180 |       const reopened = (await stored(page, actor.id, item.id)) as Creation;
  181 |       expect(reopened.creation).toEqual(item.before.creation);
  182 |       expect(reopened.outbox?.checkpoint).toEqual(item.before.outbox!.checkpoint);
  183 |       expect(reopened.bundle).toMatchObject({
  184 |         accountId: actor.id,
  185 |         access: 'editor',
  186 |         unitId: item.before.creation!.request.unitId,
  187 |       });
  188 |       expect(serverItem(item.id)).toBeUndefined();
  189 |     }
  190 |     stages.push('offline-process-restart-retained-exact-drafts');
  191 |     transport.setOffline(false);
  192 |     await network.setOffline(false);
  193 |     // The last opened Doc publishes first; opening the Sheet resumes its writer.
  194 |     for (const item of [...created].reverse()) {
  195 |       if (new URL(page.url()).searchParams.get('item') !== item.id)
  196 |         await page.goto(`/?item=${item.id}`);
  197 |       await synced(page);
  198 |       const unitId = item.before.creation!.request.unitId;
  199 |       expect(serverItem(item.id)).toMatchObject({
  200 |         id: item.id,
  201 |         owner_id: owner.id,
  202 |         parent_id: folder.id,
  203 |         kind: item.kind,
  204 |       });
  205 |       expect(
  206 |         db.prepare('SELECT * FROM workspace_item_creators WHERE item_id=?').get(item.id),
  207 |       ).toMatchObject({ created_by: actor.id, created_by_name: actor.name });
  208 |       expect(
  209 |         db.prepare('SELECT * FROM workspace_offline_creations WHERE item_id=?').get(item.id),
  210 |       ).toMatchObject({ user_id: actor.id, owner_id: owner.id, unit_id: unitId });
  211 |       expect(workspace.get(owner.id, item.id)).toMatchObject({
  212 |         access: 'owner',
  213 |         createdByName: actor.name,
  214 |       });
  215 |       const result = await readServer(item.id, unitId);
  216 |       await matchesServer(page, result);
  217 |       if (item.kind === 'sheet') {
  218 |         if (!('sheets' in result.snapshot)) throw new Error('Expected the published Sheet.');
  219 |         expect(result.snapshot.sheets[result.snapshot.sheetOrder[0]].cellData?.[0]?.[3]?.v).toBe(
  220 |           Number(item.text),
  221 |         );
  222 |       } else {
  223 |         if ('sheets' in result.snapshot) throw new Error('Expected the published Doc.');
  224 |         expect(result.snapshot.body?.dataStream.split(item.text)).toHaveLength(2);
  225 |       }
  226 |       const committed = (await stored(page, actor.id, item.id)) as Creation;
  227 |       expect(committed.creation).toBeUndefined();
  228 |       expect(pending(committed.outbox?.checkpoint)).toBe(false);
  229 |       accepted.set(item.id, result);
  230 |     }
  231 |     expect(
  232 |       db
  233 |         .prepare('SELECT item_id FROM workspace_offline_creations WHERE user_id=? ORDER BY item_id')
  234 |         .all(actor.id),
  235 |     ).toEqual(
```