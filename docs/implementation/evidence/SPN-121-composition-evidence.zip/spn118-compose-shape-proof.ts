import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import {
  ActionIterator, DocumentFlavor, getDocsEmptySnapshot, ICommandService,
  IUndoRedoService, IUniverInstanceService, JSONX, LocaleType, TextX, UniverInstanceType,
} from '/workspace/scratch/662fdaf2c600/spinel/node_modules/@univerjs/core/lib/es/index.js';
import {
  DocSelectionManagerService, DocStateChangeManagerService,
} from '/workspace/scratch/662fdaf2c600/spinel/node_modules/@univerjs/docs/lib/es/index.js';
import { NORMAL_TEXT_SELECTION_PLUGIN_STYLE } from '/workspace/scratch/662fdaf2c600/spinel/node_modules/@univerjs/engine-render/lib/es/index.js';
import { NativeReplica } from '/workspace/scratch/662fdaf2c600/spinel/lib/sync-client/src/native.ts';

const root = '/workspace/scratch/662fdaf2c600/spinel';
const output = '/tmp/spn118-compose-shape-proof.json';
const data: any = {
  purpose: 'One bounded synthetic source-mechanism proof; no performance acceptance or attribution of historical unprofiled outliers.',
  runtime: process.version,
  sourceHashes: {},
  caveats: [
    'Native public insert commands in Node, not a browser or actual key/IME events.',
    'Browser-shaped bodies reproduce the installed DocInputController fields with controlled same-color textRuns; they are not captured browser operations.',
    'Paragraph case inserts a native paragraph body at state6 using InsertTextCommand, not the UI Enter command.',
    'No product, SDK, budget, workload, retry or acceptance changes; no timing claim.',
  ],
  cases: [],
};
for (const file of ['node_modules/@univerjs/core/lib/es/index.js','node_modules/@univerjs/docs/lib/es/index.js','node_modules/@univerjs/docs-ui/lib/es/index.js','src/ui/boundedDocHistory.ts','package-lock.json'])
  data.sourceHashes[file] = createHash('sha256').update(await readFile(`${root}/${file}`)).digest('hex');
const describe = (body: any) => ({
  keys: Object.keys(body),
  undefinedKeys: Object.keys(body).filter((key) => body[key] === undefined),
  emptyArrays: Object.keys(body).filter((key) => Array.isArray(body[key]) && body[key].length === 0),
  body,
});
const components = (op: any): any[] => {
  if (Array.isArray(op)) return op.flatMap(components);
  if (op && typeof op === 'object' && op.et === 'text-x') return [op];
  return [];
};
const count = (op: any) => components(op).reduce((sum, part) => sum + part.e.length, 0);
const shape = (op: any) => components(op).flatMap((part) => part.e.map((action: any) => ({
  type: action.t, length: action.len, ...(action.body ? { body: describe(action.body) } : {}),
})));
const fold = (operations: any[]) => {
  let composed: any = null;
  const accumulatedActionCounts: number[] = [];
  let inputTextActionVisitsLowerBound = 0;
  for (const operation of operations) {
    inputTextActionVisitsLowerBound += count(composed) + count(operation);
    composed = JSONX.compose(composed, structuredClone(operation));
    accumulatedActionCounts.push(count(composed));
  }
  return { accumulatedActionCounts, inputTextActionVisitsLowerBound, finalActions: shape(composed), composed };
};

const a: any = { t: 'i', len: 1, body: { dataStream: 'a' } };
const b: any = { t: 'i', len: 1, body: { dataStream: 'b' } };
const slicedA = new ActionIterator([a]).next();
const slicedB = new ActionIterator([b]).next();
const direct = new TextX().push(a, b).serialize();
const sliced = new TextX().push(slicedA, slicedB).serialize();
data.minimalPublicApi = {
  originalBody: describe(a.body), slicedBody: describe(slicedA.body),
  directPushActions: direct, slicedPushActions: sliced,
  directPushActionCount: direct.length, slicedPushActionCount: sliced.length,
};
assert.equal(direct.length, 1);
assert.equal(sliced.length, 2);
assert.deepEqual(sliced.map((action: any) => action.body.dataStream).join(''), direct[0].body.dataStream);

for (const cap of [24, 32]) {
  for (const kind of ['minimal', 'empty-metadata', 'uniform-style', 'uniform-style-paragraph']) {
    const id = `proof-${cap}-${kind}`;
    let replica: NativeReplica | undefined;
    const result: any = { cap, kind };
    data.cases.push(result);
    try {
      replica = new NativeReplica(getDocsEmptySnapshot(id, LocaleType.EN_US, id, DocumentFlavor.MODERN), 'doc', { undoRedoHistoryLimit: 100 });
      const injector = replica.univer.__getInjector();
      injector.get(IUniverInstanceService).focusUnit(id);
      const commands = injector.get(ICommandService);
      const manager = injector.get(DocStateChangeManagerService);
      const history = injector.get(IUndoRedoService);
      const selections = injector.get(DocSelectionManagerService);
      const model: any = injector.get(IUniverInstanceService).getUnit(id, UniverInstanceType.UNIVER_DOC);
      const range = (at: number) => ({ startOffset: at, endOffset: at, collapsed: true, segmentId: '' });
      selections.replaceSelectionInfoWithoutRefresh({ textRanges: [{ ...range(0), isActive: true }], rectRanges: [], segmentId: '', segmentPage: 0, isEditing: true, style: NORMAL_TEXT_SELECTION_PLUGIN_STYLE }, { unitId: id, subUnitId: id });
      const initial = structuredClone(model.getBody());
      const characters = Array.from({length: cap}, (_, index) => kind.endsWith('paragraph') && index === 5 ? '\r' : String.fromCharCode(97 + index % 26));
      for (const character of characters) {
        const offset = model.getBody().dataStream.length - 2;
        const body: any = { dataStream: character };
        if (kind !== 'minimal') {
          body.textRuns = kind === 'empty-metadata' ? [] : [{ st: 0, ed: 1, ts: { cl: { rgb: '#1f1f1f' } } }];
          body.customRanges = [];
          body.customDecorations = [];
        }
        if (character === '\r') body.paragraphs = [{ startIndex: 0 }];
        assert.equal(commands.syncExecuteCommand('doc.command.insert-text', { unitId: id, segmentId: '', range: range(offset), body, textRanges: [range(offset + 1)], debounce: true }), true);
      }
      const pending = manager.getStateCache(id);
      result.pending = { history: pending.history.length, collaboration: pending.collaboration.length };
      assert.equal(pending.history.length, cap);
      assert.equal(pending.collaboration.length, cap);
      result.cachesMirrorByStateIdentity = pending.history.every((state: any, index: number) => state === pending.collaboration[index]);
      result.firstNativeRedoShape = shape(pending.history[0].redoState.actions);
      if (kind.endsWith('paragraph')) result.paragraphNativeRedoShape = shape(pending.history[5].redoState.actions);
      const redo = fold(pending.history.map((state: any) => state.redoState.actions));
      const undo = fold([...pending.history].reverse().map((state: any) => state.undoState.actions));
      result.redo = { accumulatedActionCounts: redo.accumulatedActionCounts, inputTextActionVisitsLowerBound: redo.inputTextActionVisitsLowerBound, finalActionCount: count(redo.composed), firstFinalActions: redo.finalActions.slice(0, 3) };
      result.undo = { accumulatedActionCounts: undo.accumulatedActionCounts, inputTextActionVisitsLowerBound: undo.inputTextActionVisitsLowerBound, finalActionCount: count(undo.composed), firstFinalActions: undo.finalActions.slice(0, 3) };
      const finalBody = structuredClone(model.getBody());
      assert.equal(finalBody.dataStream, characters.join('') + '\r\n');
      manager.flushPendingChanges(id);
      assert.deepEqual(history.getUndoRedoStatus(id), { undos: 1, redos: 0 });
      assert.equal(commands.syncExecuteCommand('univer.command.undo', { unitId: id }), true);
      assert.deepEqual(model.getBody(), initial);
      assert.equal(commands.syncExecuteCommand('univer.command.redo', { unitId: id }), true);
      assert.deepEqual(model.getBody(), finalBody);
      result.originalNativeHistoryRoundTrip = 'exact full body, including text, styles and paragraph IDs';
      result.status = 'passed';
    } catch (error) {
      result.status = 'failed';
      result.error = error instanceof Error ? {name: error.name, message: error.message, stack: error.stack} : String(error);
    } finally {
      replica?.dispose();
      await writeFile(output, JSON.stringify(data, null, 2));
      console.log(JSON.stringify({cap, kind, status: result.status, pending: result.pending, mirrored: result.cachesMirrorByStateIdentity, redoActionCount: result.redo?.finalActionCount, undoActionCount: result.undo?.finalActionCount, redoInputActions: result.redo?.inputTextActionVisitsLowerBound, undoInputActions: result.undo?.inputTextActionVisitsLowerBound, error: result.error}));
    }
  }
}
console.log(`Proof output: ${output}`);
if (data.cases.some((entry: any) => entry.status !== 'passed')) process.exitCode = 1;
