import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root='/tmp/spn090-input-safari'; const sha=(b:Buffer|string)=>createHash('sha256').update(b).digest('hex');
const p:any={complete:false,archives:[],source:'29b465b42f5616a1c3e18007cd9561b6a008e211'};
try{
const meta=JSON.parse(readFileSync(root+'/artifacts.json','utf8')).artifacts;
for(const [id,file] of [[13451217525,'outcome.zip'],[13451551897,'build.zip']] as const){
 if(!existsSync(root+'/'+file))writeFileSync(root+'/'+file,execFileSync('gh',['api',`repos/mxbaylee/spinel/actions/artifacts/${id}/zip`],{maxBuffer:12*1024*1024,timeout:30000}));
 const b=readFileSync(root+'/'+file),a=meta.find((x:any)=>x.id===id);assert.equal(b.length,a.size_in_bytes);assert.equal('sha256:'+sha(b),a.digest);assert.equal(a.workflow_run.head_sha,p.source);
 execFileSync('unzip',['-tqq',root+'/'+file]); const names=execFileSync('unzip',['-Z1',root+'/'+file],{encoding:'utf8'}).trim().split('\n');assert.equal(names.length,new Set(names).size);
 const rec:any={id,file,bytes:b.length,sha256:sha(b),members:[]};p.archives.push(rec);
 for(const n of names){assert.ok(!n.startsWith('/')&&!n.includes('..')&&!n.endsWith('/'));const d=execFileSync('unzip',['-p',root+'/'+file,n],{maxBuffer:8*1024*1024});rec.members.push({name:n,bytes:d.length,sha256:sha(d)});const dest=root+'/'+file.replace('.zip','')+'/'+n;mkdirSync(dest.slice(0,dest.lastIndexOf('/')),{recursive:true});writeFileSync(dest,d);}
}
const out=p.archives[0],build=p.archives[1];assert.equal(out.members.length,57);assert.equal(build.members.length,51);for(const m of build.members)assert.deepEqual(out.members.find((v:any)=>v.name===m.name),m);
const load=(n:string)=>JSON.parse(readFileSync(root+'/outcome/artifacts/'+n,'utf8'));
assert.equal(sha(readFileSync(root+'/capability.json')),sha(readFileSync(root+'/outcome/artifacts/browserstack-capability.json')));
p.buildIdentity=load('browserstack-build-identity.json');p.buildResult=load('browserstack-build-result.json');
const r=load('browserstack-capability.json');for(const k of ['sourceSha','testedSha','eventSha'])assert.equal(r[k],p.source);assert.equal(r.runId,'42105769919');assert.equal(r.attempt,'1');assert.equal(r.status,'failed');
const l=r.lanes.find((x:any)=>x.target.browser==='safari');assert.equal(l.failure,'capability-acceptance-authored-sheet-changed-other-content');assert.equal(l.sessionId,'8cbaa0c791c99215220d2651e9925315fe38e0a5');assert.ok(r.lanes.filter((x:any)=>x!==l).every((x:any)=>x.allocation==='not-started'));
const obs=(n:string)=>l.observations.filter((x:any)=>x.stage===n);const keys=obs('native-input-keys');assert.equal(keys.length,1);const v=keys[0].value;assert.deepEqual(v.steps.map((s:any)=>s.count),[1,2,3]);assert.equal(v.cleanup,'stopped');assert.equal(v.diagnosticFailure,false);
const events=v.steps.flatMap((s:any)=>s.trace.events);assert.equal(events.length,14);assert.deepEqual(events.map((e:any)=>e.sequence),Array.from({length:14},(_,i)=>i));assert.ok(events.every((e:any)=>e.trusted&&!e.preventedAfterDispatch&&!e.preventedAtCapture));assert.ok(v.steps.every((s:any)=>s.trace.pending===0&&s.trace.dropped===0&&s.trace.current));
p.input={counts:[1,2,3],events:14,cleanup:v.cleanup,diagnosticFailure:v.diagnosticFailure};p.difference=obs('authored-content-differences')[0].value;assert.deepEqual(p.difference,{kind:'sheet',differences:[{path:'sheets.tab.cellData.0.0.s',change:'added',actual:'object',expected:'absent'}],omitted:0});
p.cleanup=l.cleanup;assert.deepEqual(l.cleanup,{network:'restored-4g-lte-good',session:'deleted',fixture:'closed'});p.timing={failure:l.timing.failure,total:l.timing.totalElapsedMilliseconds,cleanup:l.timing.cleanupElapsedMilliseconds};
const run=JSON.parse(readFileSync(root+'/run.json','utf8'));assert.equal(run.conclusion,'failure');const job=run.jobs.find((j:any)=>j.databaseId===127520065781);p.steps=job.steps.map((s:any)=>({name:s.name,conclusion:s.conclusion}));assert.equal(job.steps.find((s:any)=>s.name==='Stop Local tunnel').conclusion,'success');
p.complete=true;
}catch(e){p.error=String(e);throw e;}finally{writeFileSync(root+'/proof-a.json',JSON.stringify(p,null,2)+'\n');}
console.log(JSON.stringify({complete:p.complete,archives:p.archives.map((x:any)=>({id:x.id,members:x.members.length})),difference:p.difference,input:p.input,cleanup:p.cleanup}));
