# 🍎 SPN-090 Safari observation outcome — independent A audit

**Run 42105769919, attempt 1, failed on exact source/tested/event `29b465b42f5616a1c3e18007cd9561b6a008e211`. The allowance is consumed and closed.** The previous dropped-third-key behavior did not recur in this sample; a later exact-content assertion failed. This is not Safari acceptance, a causal explanation of the earlier key loss, or grounds for a paid retry.

## 🔗 Original evidence and build

I verified original outcome artifact 13451217525: 7,035,601 bytes, SHA-256 `b4d2daa2c2f7628745508635fa76f7832021655096e1f97f4bbbd132055bc3c6`, all 57 members CRC/size/SHA inventoried and extracted. I fetched pre-allocation build artifact 13451551897 from GitHub (not BrowserStack): 3,652,720 bytes, SHA-256 `39a932db08a2d0ca6e686ee36abb82f16cfa2cbcfb10300411e4535b5230d2e4`. Its 51 original members are byte-identical in the terminal artifact, including the complete 48-file dist and three build receipts.

Build source/tree/run/attempt identities match reviewed source/tree `091d6bf932c08031c62c555adcff6e3a3cbfe16d`; all nine recorded source hashes match exact Git blobs. The build reports complete/settled with the 78-module renderer boundary passing. The raw job steps show npm ci, typecheck, build and pre-allocation upload succeeded before tunnel/session work. These are actual run results, not the separate local fixture build.

`audit-a.ts`, `proof-a.json`, original archives, extracted members and watchdog/log retain the independent checks. The first helper incorrectly required byte equality with the separately formatted capability.json; that file is semantically identical to the original ZIP member. Original helper/failure/proof/watchdog are preserved as `*-first.*` (4,098 ms / 257,392 KiB). The correction uses semantic equality while retaining the ZIP member as original byte authority. Corrected verification passed **1,581 ms / 237,856 KiB**, normal pressure. No phone, app, converter or scenario was rerun.

## 🧪 Actual first failure

Only Safari was allocated, session `8cbaa0c791c99215220d2651e9925315fe38e0a5`; Chrome and Firefox remain not-started. The lane reached installed authentication/downloads, native termination and offline Home Screen relaunch. The retained observations include first-restart content and all four Doc/Sheet normal/conflict image-rendering witnesses before native editing.

The first Sheet's three key ranges report cumulative insertion counts **1, 2, 3**. Fourteen retained events have contiguous sequence 0–13; all are trusted, with zero dropped or pending observations and no recorded cancellation at capture or after dispatch. The recorder was stopped successfully and diagnosticFailure is false. The first range includes an extra keydown/keyup pair; the bounded categories do not identify its key values and should not be overinterpreted. These observations establish this sample's delivered input, not the cause of an earlier absent event or guaranteed future delivery.

The failure is `capability-acceptance-authored-sheet-changed-other-content`. Its complete bounded difference report has one path and zero omissions: **`sheets.tab.cellData.0.0.s` was added as an object; expected absent.** Source `verifyAuthoredContent` first requires numeric value 731, then compares the entire comparable snapshot against the baseline with only `{v:731,t:2}` installed at A1. Thus the value check passed and the subsequent exact-content assertion failed. The source reaches this point after obtaining/validating a durable pending local checkpoint; it has not yet completed the remaining image/native/server checks for that edit or later authored cases, second restart and reconnect outcomes.

The retained report carries only the difference's type, not the added object's members/value. Do not call it an empty style, harmless normalization, lost formatting or a product defect yet. I opened the actual failure PNG: the synthetic Sheet visibly contains 731 and the colored fixture content, with offline/local status. A screenshot does not establish exact serialized style semantics.

## 🧹 Bounds and cleanup

First failure was recorded at **158,001 ms**, with 621,999 ms remaining; deadlineReached and laneAborted are false. Total lane time is **159,489 ms**, cleanup 874 ms; this was an assertion failure, not an exhausted 780-second deadline. The original 240-second prerequisite and per-key bounds were not enlarged.

The terminal lane records network restored to 4g-lte-good, session deleted and fixture closed. Raw job 127520065781 additionally confirms **Stop Local tunnel succeeded**, 20:45:17–20:45:20 UTC, followed by successful evidence upload. This is positive owned cleanup evidence, not a provider-wide process census. The selected job/run remain failed; the unselected diagnostics job is skipped. No cleanup pass converts this outcome into application acceptance.

## 🔎 Narrow completed-log question

**A prospectively bounded, one-time local read of this completed session's Appium log is useful in principle, subject to reviewing its concrete parser/bounds before GET.** The original read-only local checkpoint response necessarily supplied the snapshot to this assertion; a retained provider response may therefore reveal the synthetic A1 style object without another device command. Availability and completeness of that logged response are not yet proven. This is a new retained-evidence read, not an automatic follow-on from the consumed phone allowance.

Pin this exact completed session/run/source and target the specific first Sheet item/checkpoint response immediately preceding this mismatch. Bind the selected response by the synthetic item/unit identity and actual response envelope, not merely the nearest uncorrelated request. If ambiguous, truncated, omitted or absent, return unavailable and stop. Keep one GET, explicit time/byte caps and raw bytes in memory; retain their digest/coverage. Extract only the targeted synthetic cell's bounded style shape/value (and the minimum allowlisted identity/value fields needed to establish that selection), rejecting oversized/deep/malformed data. Do not export surrounding auth tokens, raw logs, unrelated cell/account content or arbitrary strings. Preserve first read/parser failure and secondary cleanup/finalization failures; no automatic second read.

Even a recovered style object only enables a lower-layer semantic investigation: compare with supported native typing behavior, effective fixture styles and the authored contract before proposing code or assertion changes. Do not drop `.s` globally from comparisons or waive this failed assertion. Operator gains precise private diagnostics; Owner/Collaborator retain exact authored content and formatting guarantees; guest isolation stays unchanged. No new phone allowance or merge approval follows. SPN-090 remains incomplete.
