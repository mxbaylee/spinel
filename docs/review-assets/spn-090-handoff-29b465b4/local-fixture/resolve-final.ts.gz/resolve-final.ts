import assert from 'node:assert/strict';
import {readFile,writeFile,readlink,realpath,unlink,rename,lstat} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {join} from 'node:path';
const root='/Users/mxbaylee/projects/spinel-spn-090-production',copy='/tmp/spn090-local-fixture';
const result:any={complete:false,platform:process.platform,architecture:process.arch,node:process.version,resolutions:{}};
try{
 assert.ok((await lstat(join(root,'node_modules'))).isDirectory());
 const req=createRequire(join(root,'package.json')),semver=req('semver');
 const bodyPath=req.resolve('body-parser/package.json');const body=JSON.parse(await readFile(bodyPath,'utf8')),bodyReq=createRequire(bodyPath);
 for(const [name,range] of Object.entries(body.dependencies) as [string,string][]){
  const entry=await realpath(bodyReq.resolve(name));let directory=entry.slice(0,entry.lastIndexOf('/')),path='',manifest:any;
  for(let depth=0;depth<8;depth++){try{const candidate=JSON.parse(await readFile(directory+'/package.json','utf8'));if(candidate.name===name){path=directory+'/package.json';manifest=candidate;break;}}catch{}directory=directory.slice(0,directory.lastIndexOf('/'));}
  assert.ok(path,'Resolved dependency manifest '+name);
  assert.ok(path.startsWith(join(root,'node_modules/')));assert.ok(semver.satisfies(manifest.version,range));
  result.resolutions[name]={path,version:manifest.version,required:range};
 }
 for(const name of ['vite','typescript','rolldown','@napi-rs/canvas','@univerjs/core','@univerjs/docs','@spinel/sync-server','@spinel/sync-transform']){
  const path=await realpath(req.resolve(name));assert.ok(path.startsWith(root+'/node_modules/')||path.startsWith(root+'/lib/'));result.resolutions[name]={path};
 }
 for(const name of ['vite','tsc']){const path=await realpath(join(root,'node_modules/.bin',name));assert.ok(path.startsWith(root+'/node_modules/'));result.resolutions['bin/'+name]={path};}
 result.complete=true;
}catch(error){result.failure=error instanceof Error?error.stack:String(error);process.exitCode=1;}
finally{await writeFile(join(copy,'resolve-final-result.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});}
console.log(JSON.stringify(result));
