# 🔎 SPN-090 local fixture outcome — independent review A

Reviewed 2026-11-05, read-only. This is a local feasibility checkpoint, not a new source grade, physical-device acceptance or merge approval. The executed application source was `29b465b42f5616a1c3e18007cd9561b6a008e211`, tree `091d6bf932c08031c62c555adcff6e3a3cbfe16d`. The later documentation checkpoint does not retroactively change that execution identity.

## ✅ Supported outcome

The retained scripts and receipts support a usable isolated local dependency/build/typecheck/fixture path. No BrowserStack device, tunnel or application browser was started by this checkpoint. I inspected the retained scripts, results, watchdogs and build identities; I did not repeat copying, installation, patches, build, typechecking, fixture execution or provider requests.

The APFS copy created owned dependency files. The only recorded installed metadata mismatch was body-parser 2.3.0 versus locked 2.4.0; the replacement tarball was checked against the exact lockfile URL and SHA-512 integrity. The five current public dependency patchers were invoked with the explicit owned copy root. The corrected audit checks 486 node_modules package versions and seven workspace links. The final resolver follows runtime entry ancestry, verifies body-parser dependency ranges and keeps relevant tools/packages inside the owned node_modules or current source workspaces. The directory was moved into the SPN-090 worktree to give Vite ordinary module paths; it is no longer a link to the donor. These checks support the reported donor-preserving reconciliation, not equivalence to a fresh npm ci or a cryptographic audit of every copied package byte.

The local build labels its identity explicitly LOCAL, binds the actual Git head/tree and selected source files, and retains the graph before enforcing the renderer criterion. It completed with 48 emitted files and all 78 renderer modules satisfying the recorded boundary, in 5,562 ms with a sampled watchdog peak of 1,177,728 KiB. Full `tsc -p .` completed in 5,694 ms at 1,769,328 KiB. Both watchdogs passed at normal pressure. These are successful current-source local checks, not hosted Linux or phone results.

The final fixture check created the four normal/conflict Sheet/Doc seeds, served `/sign-in` over local HTTPS and matched the exact built HTML after the expected public-origin metadata substitutions. HTTP 200 returned 4,690 bytes, SHA-256 `64d1911d5cf24bedbfb64c65af0b1577df62b020cd032016c8651be5cf178d53`. It awaited fixture closure and temporary-directory removal; the receipt records cleanup passed. The watchdog completed in 2,168 ms at 430,736 KiB, normal pressure. Provider requests and sessions allocated were zero.

## 🧾 First failures and correction

All earlier attempts remain failures in their original receipts: the preparation version audit mistakenly included workspace metadata; the first resolution check hit package.json export restrictions; the first fixture assertion compared against an unsubstituted template; the next observed the real anonymous `/` redirect (HTTP 302) rather than the intended public sign-in HTML. The final route check corrected the probe expectation. No product routing change or automatic device retry is implied.

I found that `qualify-result.json` labelled hashes for `@univerjs/drawing`, while the drawing patcher actually targets `@univerjs/sheets-drawing`. This was an evidence-target gap, not proof that the patch failed. The original receipt is preserved. The supplemental read-only `sheets-drawing-hashes.json` now records the actual patched targets: ES 83,130 bytes / SHA-256 `76e98c46fc3ba4acfd4ca5dbcd74f1e6a7a270b0127141d95becac41caf891bb`; CJS 85,624 bytes / `2211371bc8ce29013dcacaebb18e21bdd76ca230d979dee2405b6592aef092c5`. I read back that correction; no patch or build was repeated. Do not describe the original drawing hashes as patch-target hashes.

## ⚠️ Limits and next boundary

The HTTPS probe deliberately uses `rejectUnauthorized: false` with the local self-signed certificate. It proves local serving and exact response bytes, not browser/provider certificate trust. It does not render the app, execute its modules, authenticate an account, verify editor behavior, exercise Home Screen persistence, establish tunnel reachability or prove real-device input/storage behavior. Seed creation is fixture preparation, not a completed user journey.

No further investigation is needed to record this bounded feasibility result honestly. A future full local device attempt still needs its own concrete reviewed execution plan and current-source guards. In particular, the existing serial runner's eight-minute limit cannot silently contain the authored 780-second full-run budget plus cleanup; that ownership/deadline mismatch must be resolved explicitly before allocation, without bypass, renewal or splitting a live session. Current local feasibility neither grants a device allowance nor changes the failed physical acceptance history.

All four personas benefit from an isolated, reproducible local path and truthful evidence; none gains durable offline or recovery assurance from an HTML smoke check alone. SPN-090 and SPN-146 remain incomplete. This report approves the stated local feasibility claims only.
