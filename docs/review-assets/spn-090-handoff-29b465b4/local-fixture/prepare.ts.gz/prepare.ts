import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile,mkdir,rename,lstat,readlink,unlink,symlink} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {patchInstalledCore} from '/Users/mxbaylee/projects/spinel-spn-090-production/scripts/dependencies/patch-univer-core.ts';
import {patchInstalledDocs} from '/Users/mxbaylee/projects/spinel-spn-090-production/scripts/dependencies/patch-univer-docs.ts';
import {patchInstalledUi} from '/Users/mxbaylee/projects/spinel-spn-090-production/scripts/dependencies/patch-univer-ui.ts';
import {patchInstalledDrawing} from '/Users/mxbaylee/projects/spinel-spn-090-production/scripts/dependencies/patch-univer-drawing.ts';
import {patchInstalledDocsUi} from '/Users/mxbaylee/projects/spinel-spn-090-production/scripts/dependencies/patch-univer-docs-ui.ts';
const root='/Users/mxbaylee/projects/spinel-spn-090-production',copy='/tmp/spn090-local-fixture';
const sha=(b:Buffer|string)=>createHash('sha256').update(b).digest('hex');
const report:any={operation:'isolated-copy-qualification',source:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),complete:false,providerRequests:0,packageRegistryRequests:0,patches:[],links:[]};
assert.equal(report.source,'29b465b42f5616a1c3e18007cd9561b6a008e211');
try {
 const lockBytes=await readFile(join(root,'package-lock.json'));report.lockSha256=sha(lockBytes);
 const wanted=JSON.parse(lockBytes.toString()).packages,installed=JSON.parse(await readFile(join(copy,'node_modules/.package-lock.json'),'utf8')).packages;
 const mismatches=Object.entries(installed).filter(([path,row]:any)=>!row.link&&['version','resolved','integrity'].some(key=>row[key]!==wanted[path]?.[key])).map(([path])=>path);
 assert.deepEqual(mismatches,['node_modules/body-parser']);
 assert.deepEqual(Object.entries(wanted).filter(([path,row]:any)=>path.startsWith('node_modules/')&&!installed[path]&&!row.optional).map(([path])=>path),[]);
 report.initialMismatches=mismatches;
 const identity=wanted['node_modules/body-parser'];assert.equal(identity.resolved,'https://registry.npmjs.org/body-parser/-/body-parser-2.4.0.tgz');
 report.packageRegistryRequests++;
 const response=await fetch(identity.resolved,{signal:AbortSignal.timeout(15000),redirect:'error'});assert.equal(response.status,200);
 const bytes=Buffer.from(await response.arrayBuffer());assert.ok(bytes.length<1024*1024);
 assert.equal('sha512-'+createHash('sha512').update(bytes).digest('base64'),identity.integrity);
 const archive=join(copy,'body-parser-2.4.0.tgz');await writeFile(archive,bytes,{flag:'wx'});
 const members=execFileSync('tar',['-tzf',archive],{encoding:'utf8'}).trim().split('\n');
 assert.ok(members.length>0&&members.length<100);for(const path of members)assert.ok(path.startsWith('package/')&&!path.split('/').includes('..')&&!path.includes('\\'));
 await mkdir(join(copy,'body-parser-2.4.0'));
 execFileSync('tar',['-xzf',archive,'-C',join(copy,'body-parser-2.4.0'),'--strip-components','1']);
 const packageJson=JSON.parse(await readFile(join(copy,'body-parser-2.4.0/package.json'),'utf8'));assert.equal(packageJson.version,identity.version);
 await rename(join(copy,'node_modules/body-parser'),join(copy,'body-parser-2.3.0-donor'));
 await rename(join(copy,'body-parser-2.4.0'),join(copy,'node_modules/body-parser'));
 report.replacement={path:'node_modules/body-parser',version:identity.version,archiveSha256:sha(bytes),integrity:identity.integrity,members};
 for(const [path,row] of Object.entries(wanted) as [string,any][]){
  if(!path.startsWith('node_modules/')||!row.link)continue;
  assert.ok(/^lib\/[a-z0-9-]+$/.test(row.resolved));
  const target=join(root,row.resolved);await readFile(join(target,'package.json'));
  const link=join(copy,path);assert.ok((await lstat(link)).isSymbolicLink());await unlink(link);await symlink(target,link);
  report.links.push({path,target});
 }
 for(const [name,patch] of [['core',patchInstalledCore],['docs',patchInstalledDocs],['ui',patchInstalledUi],['drawing',patchInstalledDrawing],['docs-ui',patchInstalledDocsUi]] as const){
  const result=await patch(copy);report.patches.push({name,result});
 }
 let checked=0;
 for(const [path,row] of Object.entries(installed) as [string,any][]){
  if(row.link)continue;
  const actual=JSON.parse(await readFile(join(copy,path,'package.json'),'utf8'));assert.equal(actual.version,wanted[path].version,path);checked++;
 }
 report.versionChecked=checked;
 const existing=join(root,'node_modules');assert.ok((await lstat(existing)).isSymbolicLink());
 assert.equal(await readlink(existing),'/Users/mxbaylee/projects/spinel/node_modules');
 await unlink(existing);await symlink(join(copy,'node_modules'),existing);report.worktreeUsesOwnedCopy=true;
 report.complete=true;
}catch(error){report.failure=error instanceof Error?error.stack:String(error);process.exitCode=1;}
finally{await writeFile(join(copy,'prepare-result.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});}
console.log(JSON.stringify(report));
