import assert from 'node:assert/strict';
import {mkdtemp,readFile,writeFile,rm} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {request} from 'node:https';
import {createBrowserstackFixture} from '/Users/mxbaylee/projects/spinel-spn-090-production/scripts/ci/browserstack-fixture.ts';
import {escapeMarkup} from '/Users/mxbaylee/projects/spinel-spn-090-production/src/shared/markup.ts';
const report:any={kind:'local-HTTPS-production-fixture-start-close',providerRequests:0,sessionsAllocated:0,complete:false,cleanup:'pending'};
const directory=await mkdtemp('/tmp/spn090-local-fixture/fixture-');let fixture:Awaited<ReturnType<typeof createBrowserstackFixture>>|undefined;let primary:unknown;
try{
 const build=JSON.parse(await readFile('artifacts/browserstack-build-result.json','utf8'));assert.equal(build.complete,true);assert.equal(build.source,'29b465b42f5616a1c3e18007cd9561b6a008e211');
 const graph=JSON.parse(await readFile('artifacts/browserstack-build-graph.json','utf8'));assert.equal(graph.rendererBoundary.passed,true);
 fixture=await createBrowserstackFixture(directory);
 report.items=fixture.items.map(({kind,outcome})=>({kind,outcome}));report.certificate=fixture.certificate;
 const response=await new Promise<{status:number|undefined,bytes:Buffer}>((resolve,reject)=>{
  const req=request({hostname:'127.0.0.1',port:8176,path:'/sign-in',servername:'bs-local.com',rejectUnauthorized:false,method:'GET',headers:{Host:'bs-local.com:8176'}},res=>{
   let size=0;const chunks:Buffer[]=[];res.on('data',chunk=>{size+=chunk.length;if(size>1024*1024){req.destroy(new Error('response-limit'));return;}chunks.push(chunk);});res.on('end',()=>resolve({status:res.statusCode,bytes:Buffer.concat(chunks)}));res.on('error',reject);
  });req.setTimeout(10000,()=>req.destroy(new Error('local-request-timeout')));req.on('error',reject);req.end();
 });
 report.responseBeforeAssertions={status:response.status,bytes:response.bytes.length,sha256:createHash('sha256').update(response.bytes).digest('hex')};
 assert.equal(response.status,200);
 const values:Record<string,string>={TITLE:'Spinel',IMAGE:'https://bs-local.com:8176/social-preview.png',DESCRIPTION:'Your private workspace for documents and spreadsheets.',IMAGE_ALT:"Spinel's faceted pink heart. A little space for your big ideas. Documents and spreadsheets, together."};
 const expected=(await readFile('dist/index.html','utf8')).replace(/__SPINEL_(TITLE|IMAGE|DESCRIPTION|IMAGE_ALT)__/g,(_match,key)=>escapeMarkup(values[key]));
 assert.equal(response.bytes.toString('utf8'),expected);
 report.response={status:response.status,bytes:response.bytes.length,sha256:createHash('sha256').update(response.bytes).digest('hex'),matchesBuiltHTMLWithPublicOriginMetadata:true};report.complete=true;
}catch(error){primary=error;report.failure=error instanceof Error?error.name:'unknown';report.complete=false;}
finally{
 try{await fixture?.close();await rm(directory,{recursive:true,force:true});report.cleanup='passed';}catch(error){report.cleanup='failed';report.cleanupFailure=error instanceof Error?error.name:'unknown';primary??=error;report.complete=false;}
 await writeFile('/tmp/spn090-local-fixture/fixture-sign-in-result.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
}
console.log(JSON.stringify(report));if(primary)process.exitCode=1;
