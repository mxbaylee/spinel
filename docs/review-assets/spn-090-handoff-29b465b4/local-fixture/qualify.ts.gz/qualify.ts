import assert from 'node:assert/strict';
import {readFile,writeFile,lstat,readlink,unlink,symlink} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
const root='/Users/mxbaylee/projects/spinel-spn-090-production',copy='/tmp/spn090-local-fixture';
const wanted=JSON.parse(await readFile(join(root,'package-lock.json'),'utf8')).packages;
const metadata=JSON.parse(await readFile(join(copy,'node_modules/.package-lock.json'),'utf8'));
const result:any={complete:false,providerRequests:0,packageRegistryRequests:0,versions:0,workspaces:[],patchHashes:{},priorSetupFailure:'Version audit incorrectly treated workspace metadata as a copied dependency path; no patch or network step repeated'};
try{
 const prior=JSON.parse(await readFile(join(copy,'prepare-result.json'),'utf8'));assert.equal(prior.patches.length,5);assert.equal(prior.replacement.version,'2.4.0');
 for(const [path,row] of Object.entries(metadata.packages) as [string,any][]){
  if(!path.startsWith('node_modules/'))continue;
  if(row.link){assert.equal(await readlink(join(copy,path)),join(root,wanted[path].resolved));result.workspaces.push(path);continue;}
  const actual=JSON.parse(await readFile(join(copy,path,'package.json'),'utf8'));assert.equal(actual.version,wanted[path].version,path);result.versions++;
 }
 for(const name of ['core','docs','ui','drawing','docs-ui'])for(const format of ['es','cjs']){
  const path=`node_modules/@univerjs/${name}/lib/${format}/index.js`;
  result.patchHashes[`${name}/${format}`]=createHash('sha256').update(await readFile(join(copy,path))).digest('hex');
 }
 const existing=join(root,'node_modules');assert.ok((await lstat(existing)).isSymbolicLink());assert.equal(await readlink(existing),'/Users/mxbaylee/projects/spinel/node_modules');
 await unlink(existing);await symlink(join(copy,'node_modules'),existing);result.worktreeUsesOwnedCopy=true;
 await writeFile(join(copy,'donor-installed-metadata.json'),JSON.stringify(metadata,null,2)+'\n',{flag:'wx'});
 metadata.packages['node_modules/body-parser']=wanted['node_modules/body-parser'];
 await writeFile(join(copy,'node_modules/.package-lock.json'),JSON.stringify(metadata,null,2)+'\n');
 result.complete=true;
}catch(error){result.failure=error instanceof Error?error.stack:String(error);process.exitCode=1;}
finally{await writeFile(join(copy,'qualify-result.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});}
console.log(JSON.stringify(result));
