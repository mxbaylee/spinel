# 🧪 SPN-090 current native desktop outcome review A

**The three selected native desktop owners pass on exact source `29b465b42f5616a1c3e18007cd9561b6a008e211`, run `42095169654`, attempt 1.** This is independent retained-evidence acceptance for these desktop owners only. It is not physical-phone, overall CI or merge approval.

Freshly fetched terminal run/jobs metadata shows three successful jobs and no missing native owner. Retained API commit metadata independently confirms tested merge `e2ecf005b2b4c4afe261be50b5784a98389f2a51`, parents base `2f442317dd2e1c188ae4a810ac094fd1162a4a2a` and reviewed source, with equal tree `091d6bf932c08031c62c555adcff6e3a3cbfe16d`.

## 🔗 Artifact identity and bounded verification

Downloaded original archives are retained, with all 46 members CRC-tested, individually size/SHA-256 inventoried and safely extracted. Their reports carry the current source/tested/run/attempt identities:

- Chrome job `127483175144`, artifact `13446712945`: 227,669 bytes, SHA-256 `af4095e1db1f621adadff829a471337490671228df79e6e1ad0af95dd7a5304f`, 13 members, 37 stages. Chrome 157.0.8103.39, macOS 26 arm64.
- Firefox job `127483175184`, artifact `13447486704`: 496,424 bytes, `c541b8dba0d6e1551a985c9a4fe870ea37a392c28f05b599c0bd4a44c1be3380`, 15 members, 37 stages. Firefox 159.0.1, macOS 26 arm64.
- Safari job `127483174976`, artifact `13447372251`: 1,053,577 bytes, `9cd0265449b56d1cb510b765b32522c106db3c8e1230743e0d36db5211722642`, 18 members, 39 stages. Safari 27.2, macOS 15 Intel.

`native-proof-a.ts`, `native-proof-a.json`, its log/watchdog and `native-tested-commit-a.json` preserve the checks and source bindings. The successful serialized 60-second/2 GiB guarded audit took **427 ms / 186,560 KiB**, normal pressure. No browser, provider session or application scenario was rerun.

The first helper execution failed after **270 ms / 93,024 KiB** because it incorrectly inherited a previous-head assertion that the report's transport summary must have zero sockets. Current Chrome has two in that summary. The current source takes it before final browser stop and fixture close; it is not a terminal inventory. All four actual outage witnesses are zero. I preserved the original helper/report/log/watchdog as `*-first.*`, corrected only that unsupported assumption, and reran the local evidence verifier. This is not a hidden application failure or an assertion waiver.

## ✅ Actual current contract

I read the current source assertions as well as the raw reports. Each owner records **three**, not four, same-profile launches with distinct browser PIDs, correct previous-PID linkage and three witnessed browser/driver exits. Do not import SPN-141's later four-launch/all-tab handoff contract into this source.

Four complete original downloads (Doc/Sheet × normal/conflict) precede disconnection and termination. Current assertions deep-compare full original records and image records across the first restart, then full pending records after actual native edits and the second restart. Each of the four pending cases retains checkpoint hashes, three positive-size image hashes and successful pixel evidence. All six native clipboard checks yield the expected Sheet `731` or Doc `Desktop offline 731 Recovery base notes` text.

Normal reconnect asserts full comparable content and original image bytes, clears pending state, then reloads without another publication. Both normal cases reach revision 2. Conflict cases keep the original record intact, create a distinct recovered copy with correct account/metadata/content/images, and retain exactly one relevant receipt with no replay-crash marker. Retained PNG image byte payloads match their content hashes. These are actual current results, not reused prior passes.

Each owner performs one explicit storage-deletion sequence with every recorded operation passed. The subsequent assertions observe no offline account marker and zero available badges, then a disconnected item launch shows the connection-required message and no editor canvas. This proves controlled native-API deletion handling, not natural browser eviction or permanent storage guarantees.

All reports finish with complete then browser-stop, and lack application, browser-teardown or fixture-teardown errors. Source awaits fixture close before writing the final report. Four disconnection checkpoints report offline and zero active browser sockets. The final transport summaries are pre-cleanup snapshots (Chrome 2, Firefox 0, Safari 0); there is no independent final whole-fixture socket/process census in these artifacts. Browser/driver exit witnesses and successful awaited cleanup are the actual evidence.

## 🖼️ Useful images and diagnostic limits

I opened the current `doc-normal-offline.png` for Chrome, Firefox and Safari, plus Safari `sheet-normal-offline.png`. They visibly show the expected synthetic text/value and original colored image content, with local/offline save state; no blank editor or missing primary content was observed. The remaining PNGs were integrity-checked but not individually visually reviewed here. These are synthetic disposable fixture documents, not private user data or a general UI design approval.

Firefox's first persistence prompt is allowed and changes persisted false→true; later checks stay true. Chrome/Safari report false before and after, while actual retained-content checks pass. Firefox logs retain platform GPU/remote-settings messages and expected TLS certificate-ignore warnings; these results do not establish production rendering performance or public certificate deployment.

Safari's separate ordinary-home capability probe retains the same sentinel in localStorage/IndexedDB/cache and worker state across a PID-changing restart, with no persistence request and passing online/offline canvas baselines. Its status is capability evidence distinct from application acceptance. Automation log source collection reports complete, but retained output is truncated: **345 matched / 328 retained lines, 17 omitted, 65,505 bytes**. Do not claim exhaustive retained automation diagnostics. The application subsequently passes its own 39 stages.

The current physical Safari key-loss case, historical Chrome storage-loss question and Firefox phone limitation remain separate and unresolved by these desktop passes. This review adds no paid allocation, capability override, retry allowance, natural-reclaim proof or overall merge approval.
