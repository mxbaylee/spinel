# 🧪 SPN-090 current CI and mobile responsiveness review A

**Current CI `42095169754`, attempt 1, passed all 33 jobs and all seven required gates on `29b465b42f5616a1c3e18007cd9561b6a008e211`. The selected mobile responsiveness owner independently passes this retained-data audit.** No skipped, cancelled or failed selected job is hidden in the terminal job list. This is not physical-device or overall SPN-090 merge approval.

## 🔗 Exact source, selection and aggregate integrity

The plan pins base `2f442317dd2e1c188ae4a810ac094fd1162a4a2a`, source `29b465b4`, tested merge `e2ecf005b2b4c4afe261be50b5784a98389f2a51`. The independently retained commit API proof and local source tree agree on `091d6bf932c08031c62c555adcff6e3a3cbfe16d` with the exact base/source parents. Plan digest is `139c140f6e3570a4dabf4f4f06b729c9c0e47163fe7cb485bbe8d95479d1c589`.

The range was unavailable (`paths: null`), so the classifier honestly selected **full coverage**, not a reduced metadata-only plan. All 15 suite decisions are selected. I verified the ci-plan ZIP digest/CRC, three results ZIP digests and original member identities, identical embedded plans/digests, and reran the current pure `verifyCoverage` function against the retained aggregate results. Selected work must succeed; missing/failed/skipped selected work cannot pass. The seven exact gates are:

- Pull request `127483176592` — success.
- Typecheck `127483692234` — success.
- Lint `127483692247` — success.
- Backlog `127483692705` — success.
- Lib tests `127488210915` — success.
- Unit tests `127488312213` — success.
- Playwright smoke `127501209033` — success.

The three aggregate ZIPs are artifacts `13447956802` (unit), `13448246053` (lib), and `13448219732` (browser). Exact hashes/member hashes and selected coverage are retained in `ci-gates-proof-a.json`. The guarded aggregate audit passed in **214 ms / 90,432 KiB**, normal pressure. Terminal job success for other selected owners is reconciled here; this report does not claim a full raw trace audit of both callback artifacts or the desktop responsiveness artifact.

## 📱 Current mobile artifact and first attempts

Mobile job `127483692419` passed. Original artifact `13449891163` is 2,083,438 bytes, SHA-256 `bfc71fefda48f64e76662c985ca088685f3e9714b4be44f5c560a9f9944fe7db`. All **18 original members** passed CRC and exact extracted byte/hash comparison. Eight metrics records, two profile/hash/clock records, post-burst and both boundary cases are retained. All nine harness source hashes in metrics match current source Git blobs. Candidate records use the exact tested merge; historical baseline records use `2c84a18449c7dae09e2817989fac6236be96ef98` with the current harness.

All **11 Playwright cases** have one result, retry 0, passed, no errors and duration below the registered timeout: four baseline cases and seven candidate cases. No first application failure or repaired runtime retry is present in this run. Candidate plain-1/2/3 measured:

- Capacity pair p95: **24.6 / 22.6 / 22.5 ms**, below 50 ms.
- Capacity pair maximum: **97.7 / 37.9 / 91.1 ms**, below 100 ms. Plain-1 has only about **2.3 ms** margin; no stability guarantee is inferred.
- Actual six-state policy-idle pair: **3.3 / 3.2 / 5.7 ms**, below the same 50 ms p95 / 100 ms maximum limits.
- Key-to-frame p95: **88.1 / 85.5 / 84.8 ms**, below 200 ms.
- Longest task: **165 / 242 / 153 ms**, below 500 ms.
- First verified browser-local empty drain: **445.7 / 366.7 / 382.3 ms**, below 1,000 ms.

These distributions were recomputed from raw retained records, including 65 capacity groups of 32 states and the real returned history/collaboration idle owners, rather than accepted from summary flags. Each plain run has 2,086 key events, high-water 32/32, empty final pending queues and valid non-invalidated local drain witnesses. Late external polling bounds are descriptive, not substituted for the local empty witness.

## ✅ Content, history, boundaries and cleanup

Sender, peer and saved content retain the exact expected 2,088-character hash and correct independent selections. Candidate Undo/Redo passes. Plain-1 exercises **all 66 groups**, reaches the empty two-character document with history 0 undos/66 redos, then restores 66 undos/0 redos and the complete content. Other candidate samples exercise one group. No unexpected reloads are recorded. Historical baseline capacity refusal is explicitly recorded as its known baseline outcome; it is not a candidate pass or a hidden current failure.

The continuation case has 2,087 input events, sender/peer/saved expected continued content (2,089 characters), quiet-gap and first-frame/native-read observations, no reload, and all fixed bounds passed. Its continuation key-to-frame/native read are 79.8/80.7 ms. Composition and revoked-guest cases retain zero dropped events; composing Enter leaves text/history unchanged, final composition drains, and the held revoked write is not forwarded. `physicalIme: false` is explicit.

Current source awaits fixture close after evidence/observer cleanup; the successful test result includes that finally path. CDP detach exceptions are caught, so the artifacts do not prove every detach succeeded or provide an independent final process inventory. Do not expand the cleanup claim beyond successful fixture/test completion.

## 🚧 Profile and acceptance limits

The retained paired comparison passes with no failures/unavailable entries, and profile file hashes match receipts. I did not rerun whole-profile analysis or a benchmark. Profile clock brackets are broad: approximately **1,428.9 ms baseline / 2,523.1 ms candidate**. Baseline analysis reports one negative delta/two reordered samples; candidate reports zero. Candidate reducer samples exist but no certain containing task is attributed. The comparison's whole-task upper-bound reductions are not exact reducer CPU durations or proof of a historical pause's cause. Profile samples are descriptive, with candidate timing caps enforced on the three unprofiled cases.

The raw mobile audit passed first execution under serial 60-second/2 GiB guard: **1,541 ms / 223,824 KiB**, normal pressure. Original ZIPs, metadata, job log, scripts, proofs and watchdog receipts are retained. The first job-log download was refused by gh's terminal-escape guard; the same completed log was then fetched to a file with its explicit escape-output option. This tooling disposition is saved in `mobile-log-fetch-disposition-a.json`; no test was repeated.

This run does not repair or explain prior SPN-146 slow failures, nor complete SPN-090's phone lifecycle. The Safari third-key failure and historical Chrome storage boundary remain separate failed physical outcomes, and Firefox's physical limitation remains explicit. Current source gates and this mobile owner are accepted without waivers; no new device allowance, causal claim or merge authorization follows.
