import test from 'node:test';
import assert from 'node:assert/strict';
import { lifecycle } from './lifecycle.ts';
const request = '[HTTP] --> POST /wd/hub/session/secret/context {"name":"private"}';
const proxy = (options: unknown) => '[debug] [WD Proxy] Proxying [POST /session] to [POST http://127.0.0.1:9515/wd/hub/session] with body: '+JSON.stringify({desiredCapabilities:{chromeOptions:options, token:'private-secret'}});
test('keeps bounded ordered owned markers and only reset capability categories', () => {
 const result=lifecycle([request,"[debug] [AndroidDriver] Found existing Chromedriver for context 'CHROMIUM'. Using it.", '[debug] [AndroidDriver] ChromeDriver is not associated with a window. Re-initializing the session.',proxy({androidUseRunningApp:false,credentials:'private-secret'}),`[debug] [ADB] Running '/private/adb' with args: ["-s","private-device","shell","pm","clear","com.android.chrome"]`,'[HTTP] <-- POST /wd/hub/session/secret/context 200 10 ms'].join('\n'));
 assert.deepEqual(result.rows.map(x=>x.category),['request','existing-chromium-driver','chromedriver-reinitialize','chromedriver-new-session','chrome-clear-data-command','response']);
 assert.equal(result.rows[3].runningApp,'false');
 assert.ok(result.rows.filter(x=>x.category==='request'||x.category==='response').every(x=>x.command==='POST context'));
 assert.ok(result.rows.slice(1,5).every(x=>x.nearestRequestUncorrelated==='POST context' && !('command' in x)));
 assert.equal(/private|secret|127\.0\.0\.1|credentials/.test(JSON.stringify(result)),false);
});
test('does not match marker text inside request payloads, another logger, another package or shell string',()=>{
 const result=lifecycle([request+' "ChromeDriver is not associated with a window. Re-initializing the session."','[debug] [other] ChromeDriver is not associated with a window. Re-initializing the session.',`[ADB] Running '/adb' with args: ["shell","pm","clear","private.package"]`,`[ADB] Running '/adb' with args: ["shell","pm clear com.android.chrome"]`].join('\n'));
 assert.equal(result.rows.length,1);
});
test('missing malformed and truncated capabilities stay unavailable and overflow stays visible',()=>{
 assert.equal(lifecycle(proxy({})).rows[0].runningApp,'omitted');
 assert.equal(lifecycle(proxy({androidUseRunningApp:true})).rows[0].runningApp,'true');
 assert.equal(lifecycle(proxy({androidUseRunningApp:'secret'})).rows[0].runningApp,'invalid');
 assert.equal(lifecycle(proxy(null)).rows[0].runningApp,'unavailable');
 assert.equal(lifecycle(proxy({}).slice(0,-1)).malformed,1);
 const full=lifecycle(Array(130).fill(request).join('\n'));assert.equal(full.rows.length,128);assert.equal(full.omitted,2);
});

test('overlapping sessions are never asserted as transaction ownership and option arrays stay unknown',()=>{
 const mixed=lifecycle(request+'\n[HTTP] --> GET /session/other-session/contexts\n[AndroidDriver] ChromeDriver is not associated with a window. Re-initializing the session.\n[HTTP] <-- POST /session/secret/context 200');
 assert.equal(mixed.rows[2].nearestRequestUncorrelated,'GET contexts');
 assert.equal(mixed.rows[2].command,undefined);
 assert.equal(mixed.rows[3].command,'POST context');
 assert.equal(lifecycle(proxy([])).rows[0].runningApp,'unavailable');
 const w3c=proxy({}).replace(/with body: .*/, 'with body: '+JSON.stringify({capabilities:{alwaysMatch:{chromeOptions:{}},firstMatch:[{chromeOptions:{androidUseRunningApp:true}}]}}));
 assert.equal(lifecycle(w3c).rows[0].runningApp,'unavailable');
});

test('competing legacy/W3C and Chrome option representations remain unavailable',()=>{
 for(const data of [{desiredCapabilities:{chromeOptions:{}},capabilities:{alwaysMatch:{'goog:chromeOptions':{androidUseRunningApp:true}}}}, {desiredCapabilities:{chromeOptions:{},'goog:chromeOptions':{androidUseRunningApp:true}}}]){
 const line=proxy({}).replace(/with body: .*/, 'with body: '+JSON.stringify(data));
 assert.equal(lifecycle(line).rows[0].runningApp,'unavailable');
 }
});
