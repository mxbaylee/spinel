# 🔎 Local Chrome reader — repair revalidation A

Reviewed repaired reader `f267b3903fd53fd19a423075614ff44f2eaf9a6038c37f98a7f6005ed35aa72c`, parser `01dfbb32ba888b6b47a3f8bbca381aca9a6af80425660db01b0948c3c0eb8427`, tests `ef9b33f69f3e9836b86d6d4145e433666bab4dfe535798e62ed650268fc4a0c1`. **Two small closure items remain before this exact script is admitted.** No GET or workload executed by reviewer A.

The first review's request-association issue is resolved by choosing the smaller honest contract: lifecycle markers contain `nearestRequestUncorrelated`, not an owned command; response records obtain their method/path from their own line. The explicit interpretation denies transaction/session ownership. Arrays and any W3C firstMatch are now unavailable, with an added overlap/unsupported-shape control.

Explicit elapsed checks after headers, each body read and analysis prevent a late parse from becoming request success. Cancellation is bounded to one second, first request/analysis failure is retained across cleanup failure, and receipt-write failure is caught rather than replacing the primary exception. These repairs address the reported operational paths without repeating requests.

Remaining items:

- Both `desiredCapabilities` and `capabilities.alwaysMatch` can still coexist with conflicting options; nullish selection silently chooses the legacy root. Likewise two competing `goog:chromeOptions` / `chromeOptions` dictionaries can contradict one another. Mark competing representations unavailable (no need to implement a merge), and add one pure negative control. This was part of the original capability-representation finding.
- The final filesystem write itself remains unbounded. Confirm the planned finite outer watchdog covers the whole script including preflight/finalization. Include `cleanupFailure` and `finalizationFailure` in the compact terminal stdout summary so final receipt-write failure cannot hide secondary failure information. No retry of the receipt or GET is needed.

All existing one-GET, exact 946,296-byte/SHA binding, raw-memory-only, 128-row and no-device constraints remain sound. This prospective review does not approve capability changes, establish historical causality or declare the old phone lane passed. The original review is preserved at `review-a.md`.

## ✅ Final repaired-script admission

The remaining items are now closed by concrete readback. Competing legacy/W3C roots and competing Chrome-options dictionaries return unavailable; the fifth pure control covers both. The terminal compact summary includes both cleanup and finalization secondary failure fields. Execution is explicitly through `scripts/serial.ts` and `/tmp/spn146-runtime-watchdog.ts`, whose normal-pressure preflight and sampled 60-second/2 GiB task bound cover the entire child, including filesystem finalization. The GET itself retains its explicit 8-second deadline and cancellation adds at most the declared one-second local wait; the outer guard is not permission to extend the GET. An external abort may leave only the earlier partial receipt and watchdog evidence, never an accepted read.

Final reviewed SHA-256 identities:

- Reader: `e67143216ea873b75cf4ec61e36b9b322f7252af258897f287cfcf30dc87e331`.
- Parser: `a1a0906e3e5013a80f11f135aee4434c4ddcf7acd8d042047c6a26b59c5e7138`.
- Tests: `7df40cf5eca1175aabea5a67e75a5edadab6fdf3d438a40d7e48b42d8aca38e7`.

**No remaining pre-execution blocker found for the single declared completed-session GET on these exact scripts**, under that outer guard and credential handling with tracing disabled/no credentials in argv or output. The final five-control receipt is distinct from the preserved original three-control run. This admission changes no raw-byte binding, output privacy, no-retry or zero-allocation rule. It authorizes no capability/device experiment and supplies no historical-cause or acceptance claim. No reviewer execution occurred.
