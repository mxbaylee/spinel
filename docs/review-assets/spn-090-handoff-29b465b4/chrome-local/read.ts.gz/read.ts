import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { lifecycle } from './lifecycle.ts';
const output='/tmp/spn090-chrome-local/result.json';
const sha=(value:Buffer|string)=>createHash('sha256').update(value).digest('hex');
const report:any={operation:'one-completed-Chrome-Appium-log-GET',providerSessionsAllocated:0,
 session:'a8f526a009be0531c2bae649c0376b20d0b95ed7', historicalRun:'41969903466',
 expectedSha256:'70973043443adeff797a47c01c5bed721d673c48541d9f4c6c7513f027455e6b',expectedBytes:946296,
 source:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),
 parserSha256:sha(await readFile('/tmp/spn090-chrome-local/lifecycle.ts')),
 readerSha256:sha(await readFile('/tmp/spn090-chrome-local/read.ts')),
 status:'prepared',bytes:0,requests:0,rawResponseRetained:false,authenticationRetained:false};
assert.equal(report.source,'29b465b42f5616a1c3e18007cd9561b6a008e211');
await writeFile(output,JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600});
const started=performance.now(), controller=new AbortController();
const timer=setTimeout(()=>controller.abort(),8000);
let reader:ReadableStreamDefaultReader<Uint8Array>|undefined;
const check=()=>{if(performance.now()-started>=8000)throw new Error('request-deadline');};
try {
 check();
 const username=process.env.SPINEL_BS_USERNAME,key=process.env.SPINEL_BS_ACCESS_KEY;
 if(!username||!key)throw new Error('missing-credentials');
 report.requests=1;
 await writeFile(output,JSON.stringify(report,null,2)+'\n',{mode:0o600});
 const url=`https://api.browserstack.com/automate/sessions/${report.session}/appiumlogs`;
 const response=await fetch(url,{method:'GET',redirect:'error',signal:controller.signal,
 headers:{Authorization:'Basic '+Buffer.from(username+':'+key).toString('base64'),Accept:'text/plain'}});
 check();report.httpStatus=response.status;
 if(response.status!==200||response.url!==url)throw new Error('response-refused');
 const declared=response.headers.get('content-length');
 if(declared&&Number(declared)>1024*1024)throw new Error('response-too-large');
 reader=response.body?.getReader();if(!reader)throw new Error('response-empty');
 const chunks:Uint8Array[]=[];
 for(;;){const chunk=await reader.read();check();if(chunk.done)break;report.bytes+=chunk.value.byteLength;
 if(report.bytes>1024*1024)throw new Error('response-too-large');chunks.push(chunk.value);}
 const bytes=Buffer.concat(chunks);report.sha256=sha(bytes);
 if(report.bytes!==report.expectedBytes||report.sha256!==report.expectedSha256)throw new Error('retained-log-identity-changed');
 const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
 report.analysis=lifecycle(text);check();report.status='available';
} catch(error) {
 report.status='failed';
 const message=error instanceof Error?error.message:'';
 report.failure=['request-deadline','missing-credentials','response-refused','response-too-large','response-empty','retained-log-identity-changed'].includes(message)?message:'request-or-analysis-failed';
 process.exitCode=1;
} finally {
 clearTimeout(timer);controller.abort();
 if(reader){
  let cleanupTimer:ReturnType<typeof setTimeout>|undefined;
  try { await Promise.race([reader.cancel(),new Promise((_,reject)=>{cleanupTimer=setTimeout(()=>reject(new Error('cleanup-timeout')),1000);})]); }
  catch { report.cleanupFailure='reader-cancel-unavailable';if(report.status!=='failed'){report.status='failed';report.failure='reader-cancel-unavailable';process.exitCode=1;} }
  finally {clearTimeout(cleanupTimer);}
 }
 report.elapsedMs=performance.now()-started;
 try {await writeFile(output,JSON.stringify(report,null,2)+'\n',{mode:0o600});} catch {report.finalizationFailure='receipt-write-failed';if(report.status!=='failed'){report.status='failed';report.failure='receipt-write-failed';process.exitCode=1;}}
}
console.log(JSON.stringify({status:report.status,requests:report.requests,bytes:report.bytes,sha256:report.sha256,
 rows:report.analysis?.rows.length,omitted:report.analysis?.omitted,failure:report.failure,cleanupFailure:report.cleanupFailure,finalizationFailure:report.finalizationFailure,providerSessionsAllocated:0}));
