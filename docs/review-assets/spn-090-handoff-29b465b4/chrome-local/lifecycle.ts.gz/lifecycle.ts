import { createHash } from 'node:crypto';
export function lifecycle(text: string) {
  const rows: { line: number; category: string; command?: string; nearestRequestUncorrelated?: string; runningApp?: string }[] = [];
  let omitted = 0, malformed = 0, loggerLines = 0;
  let active: string | null = null;
  const keep = (line: number, category: string, extra = {}) => {
    if (rows.length === 128) omitted++;
    else rows.push({ line, category, ...extra });
  };
  const lines = text.split(/\r\n|\n|\r/);
  for (const [index, raw] of lines.entries()) {
    const stripped = raw.replace(/^\d{4}-\d{1,2}-\d{1,2}[ T]\d{2}:\d{2}:\d{2}(?:[.:]\d{1,6})?(?:Z)?\s+-?\s*/, '');
    const parsed = /^(?:\[debug\]\s*)?\[([^\]\r\n]{1,100})\]\s*(.*)$/.exec(stripped);
    if (!parsed) continue;
    const [, logger, body] = parsed;
    loggerLines++;
    if (logger === 'HTTP') {
      const request = /^--> (POST|GET|DELETE) (?:\/wd\/hub)?\/session\/[a-zA-Z0-9-]{1,100}\/(context|contexts|appium\/device\/(?:terminate_app|app_state|current_package))(?:\s|$)/.exec(body);
      if (request) {
        active = request[1] + ' ' + request[2];
        keep(index + 1, 'request', { command: active });
      } else if (/^--> /.test(body)) active = null;
      if (/^<-- /.test(body)) {
        const response = /^<-- (POST|GET|DELETE) (?:\/wd\/hub)?\/session\/[a-zA-Z0-9-]{1,100}\/(context|contexts|appium\/device\/(?:terminate_app|app_state|current_package))(?:\s|$)/.exec(body);
        if (response) keep(index + 1, 'response', { command: response[1] + ' ' + response[2] });
        active = null;
      }
    }
    if (/^(?:AndroidDriver|UiAutomator2Driver)(?:@[a-f0-9]+)?$/.test(logger)) {
      if (body === 'ChromeDriver is not associated with a window. Re-initializing the session.')
        keep(index + 1, 'chromedriver-reinitialize', { nearestRequestUncorrelated: active ?? 'unavailable' });
      if (/^Found existing Chromedriver for context 'CHROMIUM'\. Using it\.$/.test(body))
        keep(index + 1, 'existing-chromium-driver', { nearestRequestUncorrelated: active ?? 'unavailable' });
    }
    if (/^(?:WD Proxy|JSONWP Proxy|Chromedriver)(?:@[a-f0-9]+)?$/.test(logger)) {
      const proxy = /^Proxying \[POST \/session\] to \[POST http:\/\/127\.0\.0\.1:\d{1,5}\/(?:wd\/hub\/)?session\] with body: (.*)$/.exec(body);
      if (proxy) {
        try {
          const data = JSON.parse(proxy[1]);
          const record=(v:any)=>v!==null&&typeof v==='object'&&!Array.isArray(v);
          const ambiguous = data.capabilities?.firstMatch !== undefined || (data.desiredCapabilities !== undefined && data.capabilities !== undefined);
          const caps = data.desiredCapabilities ?? data.capabilities?.alwaysMatch;
          const options = caps?.['goog:chromeOptions'] ?? caps?.chromeOptions;
          const value = options?.androidUseRunningApp;
          // Missing root/option objects are not an observed omitted capability.
          const runningApp = ambiguous || (caps?.['goog:chromeOptions'] !== undefined && caps?.chromeOptions !== undefined) || !record(caps) || !record(options)
            ? 'unavailable' : value === undefined ? 'omitted' : value === true ? 'true' : value === false ? 'false' : 'invalid';
          keep(index + 1, 'chromedriver-new-session', { nearestRequestUncorrelated: active ?? 'unavailable', runningApp });
        } catch { malformed++; }
      }
    }
    if (/^ADB(?:@[a-f0-9]+)?$/.test(logger)) {
      const args = /^Running '[^'\r\n]{1,300}' with args: (\[.*\])$/.exec(body);
      if (args) {
        try {
          const values = JSON.parse(args[1]);
          if (!Array.isArray(values) || !values.every(v => typeof v === 'string' || typeof v === 'number')) { malformed++; continue; }
          const offset = values.indexOf('shell');
          if (offset >= 0 && values.length === offset + 4 && values[offset + 1] === 'pm' && values[offset + 2] === 'clear' && values[offset + 3] === 'com.android.chrome')
            keep(index + 1, 'chrome-clear-data-command', { nearestRequestUncorrelated: active ?? 'unavailable' });
        } catch { malformed++; }
      }
    }
  }
  return { schema: 1, inputSha256: createHash('sha256').update(text).digest('hex'), lines: lines.length,
    loggerLines, malformed, omitted, rows, coverage: 'partial-recognized-markers-only',
    interpretation: 'Ordered log markers only. Nearest request is uncorrelated: no transaction/session ownership, global absence, provider-version or causal proof.' };
}
