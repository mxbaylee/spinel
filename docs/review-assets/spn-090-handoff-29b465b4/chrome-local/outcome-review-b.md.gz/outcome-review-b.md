# 🔎 SPN-090 completed Chrome log — independent outcome review B

## Disposition

The single bounded local read succeeded and supplies useful, explicitly partial lifecycle evidence. It narrows the next source investigation to ChromeDriver reattachment after native termination/relaunch, rather than only initial allocation. It does **not** prove a clear-data operation, identify the historical storage-loss cause, or change the failed phone lane into acceptance. No new GET, device allocation, browser execution or test was performed by this reviewer.

## 📌 Identity and bounded execution

Inspected `result.json`, reader/parser/test source, initial and repaired A reviews, test receipts, `read.log` and `read-watchdog.json`. Reader SHA-256 is `e67143216ea873b75cf4ec61e36b9b322f7252af258897f287cfcf30dc87e331`; parser is `a1a0906e3e5013a80f11f135aee4434c4ddcf7acd8d042047c6a26b59c5e7138`; tests are `7df40cf5eca1175aabea5a67e75a5edadab6fdf3d438a40d7e48b42d8aca38e7`. These match the final admitted scripts.

The receipt records one HTTP 200 GET of completed session `a8f526a009be0531c2bae649c0376b20d0b95ed7`, historical run `41969903466`, zero allocated sessions, and 946,296 bytes with SHA-256 `70973043443adeff797a47c01c5bed721d673c48541d9f4c6c7513f027455e6b`. I also read `/tmp/spn090-input/chrome-completed-logs.json`: its CI read `42095761076`, attempt 1, reports exactly the same endpoint/session/byte count/hash. This is receipt-level byte-identity reconciliation; raw responses were intentionally not retained and I did not independently rehash their original bodies.

Reader source identity `29b465b42f5616a1c3e18007cd9561b6a008e211` identifies the diagnostic checkout, not the historical application build. The GET took 710.126 ms; the outer guard passed in 905 ms, peak 202,592 KiB, pressure 1. No cleanup/finalization failure is recorded. The reader enforces one fixed endpoint, redirect rejection, explicit 8-second checks, a 1 MiB ceiling, exact bytes/hash, bounded cancellation and an outer guard covering finalization. Credentials remain environment-only; raw body remains memory-only. This establishes authenticated access for this endpoint/read, not general provider capability.

## 🧭 What the retained order establishes

- Initial new-session marker: line 192, supported parsed Chrome options with `androidUseRunningApp` omitted.
- Native terminate request/response markers: 2461/2476; app-state request/response markers: 2478/2488.
- Later context request: 2660; existing `CHROMIUM` driver: 2665; driver reinitialization: 2670; new ChromeDriver session: 2709; context response: 2719. The later parsed options also omit `androidUseRunningApp`.

The reinitialization is therefore present after the termination/app-state markers in log order, not only at first startup. However, the parser intentionally drops transaction/session ownership and response outcome details. `nearestRequestUncorrelated` is only a nearby command marker. Existing driver-object reuse is not proof of the same Chrome process/profile; a new ChromeDriver automation session is not evidence of a newly allocated physical BrowserStack device. Omission at both session markers does not show a true-to-false capability transition.

Coverage is **128 retained rows, 71 omitted recognized rows, one malformed targeted record**, from 4,317 lines/4,315 recognized logger lines. Unknown message shapes are outside the parser contract. No Chrome-clear-data row appears among the retained 128; this cannot establish absence in the full log, including after truncation. The separate CI parser's 12 malformed records describes a different parser contract and is not contradictory to this parser's one malformed targeted record.

## 🔬 Mechanism and next source boundary

Official ChromeDriver documentation describes `androidUseRunningApp` as attaching to an already running application instead of launching with a clear data directory. This makes a reattachment capability route relevant, but does not establish what the historical provider executed. [ChromeDriver Android documentation](https://developer.chrome.com/docs/chromedriver/get-started/android).

Current upstream Appium ChromeDriver code restarts through `start(this.capabilities, false)` after stopping its driver session/process. That illustrates why capabilities chosen at initial startup may also govern later reattachment. It is current, unpinned upstream evidence—not a binding to the historical provider's installed wrapper or modifications. [Appium ChromeDriver source](https://raw.githubusercontent.com/appium/appium-chromedriver/master/lib/chromedriver.ts).

The smallest justified next step is a static, version-bound examination of the **initial session construction versus existing-CHROMIUM reinitialization** path: identify the actual Appium/UiAutomator2/appium-chromedriver versions, their capability forwarding and restart reuse, and whether a supported attach-existing-app option can apply specifically when the already-running native Chrome instance must retain its profile. Existing CI metadata reports browser and ChromeDriver `152.0.7977.54`; those versions alone do not identify the Appium wrapper or provider behavior.

A global initial `androidUseRunningApp: true` change is not yet justified: initial allocation may legitimately need to start an application that is not running, while post-relaunch attachment has a different precondition. Any future proposal must retain those distinct preconditions and existing profile/storage witnesses, without skipping termination, reseeding data or silently replacing the physical session. Do not infer that another generic `noReset`/`fullReset` setting fixes the observed boundary.

## 🚧 Acceptance limits

No storage erasure command is successfully observed and attributed here; browser eviction, a profile switch, provider reset and a ChromeDriver launch remain unproven alternatives. The ordered rows justify the source-boundary investigation, not a new phone experiment or a blind retry. Existing historical failure and closed allowance remain unchanged. No additional provider fetch is needed merely to turn this partial result into an absence claim; first establish the supported, version-specific boundary using already retained metadata and public source authority.
