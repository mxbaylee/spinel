# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: doc-responsiveness.spec.ts >> desktop sustained native typing plain-1
- Location: e2e/doc-responsiveness.spec.ts:316:5

# Error details

```
Error: Trace extraction timed out.
```

# Test source

```ts
  1  | import { appendFile, writeFile } from 'node:fs/promises';
  2  | import type { CDPSession } from '@playwright/test';
  3  | 
  4  | export async function bounded<T>(operation: Promise<T>, ms: number, label: string): Promise<T> {
  5  |   let timer: ReturnType<typeof setTimeout> | undefined;
  6  |   try {
  7  |     return await Promise.race([
  8  |       operation,
  9  |       new Promise<never>((_, reject) => {
> 10 |         timer = setTimeout(() => reject(new Error(`${label} timed out.`)), ms);
     |                                         ^ Error: Trace extraction timed out.
  11 |       }),
  12 |     ]);
  13 |   } finally {
  14 |     clearTimeout(timer);
  15 |   }
  16 | }
  17 | 
  18 | export async function retainDiagnosticTrace(cdp: CDPSession, path: string) {
  19 |   let stream: string | undefined;
  20 |   let listener: ((event: { stream?: string }) => void) | undefined;
  21 |   let stopped = false;
  22 |   const collect = async () => {
  23 |     const complete = new Promise<{ stream?: string }>((resolve) => {
  24 |       listener = resolve;
  25 |       cdp.once('Tracing.tracingComplete', listener);
  26 |     });
  27 |     await cdp.send('Tracing.end');
  28 |     stream = (await complete).stream;
  29 |     if (!stream) throw new Error('Missing diagnostic trace stream.');
  30 |     await writeFile(path, '');
  31 |     let bytes = 0;
  32 |     for (;;) {
  33 |       if (stopped) throw new Error('Trace collection cancelled.');
  34 |       const chunk = await cdp.send('IO.read', { handle: stream, size: 1048576 });
  35 |       if (stopped) throw new Error('Trace collection cancelled.');
  36 |       const data = chunk.base64Encoded
  37 |         ? Buffer.from(chunk.data, 'base64')
  38 |         : Buffer.from(chunk.data);
  39 |       bytes += data.length;
  40 |       if (bytes > 128 * 1024 * 1024) throw new Error('Diagnostic trace exceeded 128 MiB bound.');
  41 |       await appendFile(path, data);
  42 |       if (chunk.eof) return bytes;
  43 |     }
  44 |   };
  45 |   try {
  46 |     return await bounded(collect(), 10_000, 'Trace extraction');
  47 |   } finally {
  48 |     stopped = true;
  49 |     if (listener) cdp.off('Tracing.tracingComplete', listener);
  50 |     if (stream)
  51 |       await bounded(cdp.send('IO.close', { handle: stream }), 2_000, 'Trace close').catch(() => {});
  52 |     // The caller always detaches the session, rejecting any outstanding CDP read.
  53 |   }
  54 | }
  55 | 
```