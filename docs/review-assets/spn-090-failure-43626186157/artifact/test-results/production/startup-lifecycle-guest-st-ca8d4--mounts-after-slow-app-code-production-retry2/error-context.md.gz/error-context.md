# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: startup-lifecycle.spec.ts >> guest startup reporting ends when a ready guest mounts after slow app code
- Location: e2e/startup-lifecycle.spec.ts:81:1

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e4]:
  - banner [ref=e5]:
    - generic "Spinel" [ref=e6] [cursor=pointer]:
      - img "Spinel" [ref=e7]
    - generic [ref=e32]:
      - status "Connection status" [ref=e33]: Online
      - button "Online — connected to Spinel" [ref=e34] [cursor=pointer]
    - radiogroup "Appearance" [ref=e39]:
      - radio "Follow system" [checked] [ref=e40] [cursor=pointer]
      - radio [checked] [aria-hidden] [ref=e43]
      - radio "Light" [ref=e44] [cursor=pointer]
      - radio [aria-hidden] [ref=e47]
      - radio "Dark" [ref=e48] [cursor=pointer]
      - radio [aria-hidden] [ref=e51]
  - complementary "Space contents" [ref=e52]:
    - button "Collapse navigation" [ref=e54] [cursor=pointer]
    - navigation "Pages" [ref=e57]:
      - heading "Shared timer fixture" [level=2] [ref=e58]:
        - generic [aria-hidden] [ref=e59]: 🪷
        - text: Shared timer fixture
      - region "Space pages" [ref=e60]:
        - list
        - paragraph [ref=e61]: No pages yet.
  - main [ref=e62]:
    - generic [ref=e63]:
      - generic [ref=e75]:
        - paragraph [ref=e76]: Space · Shared timer fixture
        - heading "Shared timer fixture" [level=1] [ref=e77]
      - generic [ref=e78]: View only
      - generic [ref=e79]: Guest
    - generic [ref=e80]:
      - heading "This Space is empty" [level=2] [ref=e92]
      - paragraph [ref=e93]: Pages will appear here when an editor adds them.
```