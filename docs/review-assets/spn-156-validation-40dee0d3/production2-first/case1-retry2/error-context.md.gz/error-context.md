# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: offline-device.spec.ts >> real browser quota failure retains pending work and images without a partial new download
- Location: e2e/offline-device.spec.ts:442:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 32
+ Received  + 16

@@ -957,42 +957,13 @@
      "kind": "sheet",
      "name": "Sheet images",
      "outbox": Object {
        "account": "ad5af733-bc4e-4095-9c98-ef7682aa685f",
        "checkpoint": Object {
-         "buffer": Array [
-           Array [
-             Object {
-               "id": "sheet.mutation.set-range-values",
-               "params": Object {
-                 "cellValue": Object {
-                   "0": Object {
-                     "3": Object {
-                       "f": null,
-                       "fd": null,
-                       "ft": null,
-                       "p": undefined,
-                       "s": Object {
-                         "cl": Object {
-                           "rgb": "#221832",
-                         },
-                       },
-                       "si": null,
-                       "t": 2,
-                       "v": 552,
-                     },
-                   },
-                 },
-                 "subUnitId": "tab",
-                 "trigger": "sheet.command.set-range-values",
-                 "unitId": "94585f83-500f-448f-888c-592e25b8f90b",
-               },
-             },
-           ],
-         ],
+         "buffer": Array [],
          "inflight": Array [],
-         "revision": 1,
+         "revision": 2,
          "sent": null,
          "snapshot": Object {
            "appVersion": "1.1.0",
            "calculationSettings": Object {
              "iterativeCalculation": false,
@@ -1041,10 +1012,17 @@
                "backgroundImage": Object {
                  "imageSourceType": "URL",
                  "source": "/api/items/94585f83-500f-448f-888c-592e25b8f90b/images/89bf4146dcd93b96daf4de6b65cf891d809bebc29b140ab8ed12cf7ed07e5a0f",
                },
                "cellData": Object {
+                 "0": Object {
+                   "3": Object {
+                     "s": "8run6L",
+                     "t": 2,
+                     "v": 552,
+                   },
+                 },
                  "1": Object {
                    "0": Object {
                      "p": Object {
                        "body": Object {
                          "customBlocks": Array [
@@ -1145,11 +1123,17 @@
                "showGridlines": 1,
                "tabColor": "",
                "zoomRatio": 1,
              },
            },
-           "styles": Object {},
+           "styles": Object {
+             "8run6L": Object {
+               "cl": Object {
+                 "rgb": "#221832",
+               },
+             },
+           },
          },
          "unitId": "94585f83-500f-448f-888c-592e25b8f90b",
          "version": 1,
        },
        "item": "94585f83-500f-448f-888c-592e25b8f90b",
```

# Test source

```ts
  422 |     await f.page.getByRole('menuitem', { name: 'Offline copies', exact: true }).click();
  423 |     await f.page
  424 |       .getByRole('button', { name: `Remove ${doc.name} from this device`, exact: true })
  425 |       .click();
  426 |     await expect(f.page.getByRole('link', { name: 'Open recovery', exact: true })).toHaveAttribute(
  427 |       'href',
  428 |       `/?offlineRecovery=${doc.id}`,
  429 |     );
  430 |     expect(await deviceCopy(f.page, f.actor.id, doc.id)).toEqual(retained);
  431 |     expect(
  432 |       await f.control.request
  433 |         .get(`/sync-api/spaces/${root.id}/items/${doc.id}/snapshot?unitId=${unitId}`)
  434 |         .then((response) => response.json()),
  435 |     ).toEqual(original);
  436 |     expect(f.errors).toEqual([]);
  437 |   } finally {
  438 |     await f.close();
  439 |   }
  440 | });
  441 | 
  442 | test('real browser quota failure retains pending work and images without a partial new download', async ({
  443 |   browser,
  444 |   baseURL,
  445 | }, info) => {
  446 |   test.setTimeout(240_000);
  447 |   const f = await fixture(browser, baseURL!, info, 'sheet', { images: true });
  448 |   const cdp = await f.context.newCDPSession(f.page);
  449 |   const probeName = `spinel-e2e-quota-${f.actor.id}`;
  450 |   try {
  451 |     await f.download();
  452 |     const original = await f.read();
  453 |     await f.network.setOffline(true);
  454 |     await edit(f.page, 'sheet', '552');
  455 |     await savedLocally(f.page);
  456 |     const retained = await deviceCopy(f.page, f.actor.id, f.item.id);
  457 |     expect(pending(retained?.item?.outbox?.checkpoint)).toBe(true);
  458 |     await device(f.page);
  459 |     await f.network.setOffline(false);
  460 |     const target = await importImages(f, baseURL!, 'Large offline image', true);
  461 |     await f.page.goto('/');
  462 |     let fetchedImages = 0;
  463 |     f.page.on('response', (response) => {
  464 |       if (response.url().includes(`/api/items/${target.id}/images/`) && response.ok())
  465 |         fetchedImages++;
  466 |     });
  467 |     await f.page.evaluate(
  468 |       (databaseName) =>
  469 |         new Promise<void>((resolve, reject) => {
  470 |           const opening = indexedDB.open(databaseName);
  471 |           opening.onupgradeneeded = () => opening.result.createObjectStore('probe');
  472 |           opening.onerror = () => reject(opening.error);
  473 |           opening.onsuccess = () => {
  474 |             opening.result.close();
  475 |             resolve();
  476 |           };
  477 |         }),
  478 |       probeName,
  479 |     );
  480 |     const usage = await cdp.send('Storage.getUsageAndQuota', { origin: baseURL! });
  481 |     const initialQuota = usage.usage + 64 * 1024;
  482 |     await cdp.send('Storage.overrideQuotaForOrigin', {
  483 |       origin: baseURL!,
  484 |       quotaSize: initialQuota,
  485 |     });
  486 |     expect(await cdp.send('Storage.getUsageAndQuota', { origin: baseURL! })).toMatchObject({
  487 |       overrideActive: true,
  488 |       quota: initialQuota,
  489 |     });
  490 |     // Chromium caches available bucket space for 30 seconds. Successful probes
  491 |     // stay stored until cleanup, keeping the filler bytes present for the test.
  492 |     // https://github.com/chromium/chromium/blob/156.0.8078.4/content/browser/indexed_db/instance/bucket_context.h
  493 |     await expect
  494 |       .poll(() => probeQuota(f.page, probeName), {
  495 |         timeout: 45_000,
  496 |         intervals: [1000],
  497 |       })
  498 |       .toBe('QuotaExceededError');
  499 |     // Cached allowance can let the initial probes exceed the original limit.
  500 |     // Re-measure, leaving room for the small runtime reservation but less than
  501 |     // the real 1.23 MB image. Prove the final limit rejects a smaller payload.
  502 |     const exhausted = await cdp.send('Storage.getUsageAndQuota', { origin: baseURL! });
  503 |     const quotaSize = exhausted.usage + 512 * 1024;
  504 |     await cdp.send('Storage.overrideQuotaForOrigin', { origin: baseURL!, quotaSize });
  505 |     expect(await probeQuota(f.page, probeName, 768 * 1024)).toBe('QuotaExceededError');
  506 |     const armed = await cdp.send('Storage.getUsageAndQuota', { origin: baseURL! });
  507 |     expect(armed).toMatchObject({ overrideActive: true, quota: quotaSize });
  508 |     expect(armed.quota - armed.usage).toBeGreaterThanOrEqual(256 * 1024);
  509 |     expect(armed.quota - armed.usage).toBeLessThan(768 * 1024);
  510 |     await info.attach('spn-055-quota-boundary', {
  511 |       body: Buffer.from(JSON.stringify({ before: usage, exhausted, armed }, null, 2)),
  512 |       contentType: 'application/json',
  513 |     });
  514 |     await listDownload(f.page, target.name);
  515 |     await expect(f.page.getByRole('alert').filter({ hasText: /space/i })).toBeVisible({
  516 |       timeout: 120_000,
  517 |     });
  518 |     expect(fetchedImages).toBeGreaterThan(0);
  519 |     const failedCopy = await deviceCopy(f.page, f.actor.id, target.id);
  520 |     expect(failedCopy?.item).toBeUndefined();
  521 |     expect(failedCopy?.images).toEqual([]);
> 522 |     expect(await deviceCopy(f.page, f.actor.id, f.item.id)).toEqual(retained);
      |                                                             ^ Error: expect(received).toEqual(expected) // deep equality
  523 |     assertImageBytes(retained!);
  524 |     expect(await f.read()).toEqual(original);
  525 |     await cdp.send('Storage.overrideQuotaForOrigin', { origin: baseURL! });
  526 |     await listDownload(f.page, target.name);
  527 |     await downloaded(f.page, target.name);
  528 |     const copied = await deviceCopy(f.page, f.actor.id, target.id);
  529 |     expect(copied?.item?.bundle.itemId).toBe(target.id);
  530 |     assertImageBytes(copied!);
  531 |     expect(await deviceCopy(f.page, f.actor.id, f.item.id)).toEqual(retained);
  532 |     expect(f.errors).toEqual([]);
  533 |   } finally {
  534 |     await cdp.send('Storage.overrideQuotaForOrigin', { origin: baseURL! }).catch(() => {});
  535 |     await cdp
  536 |       .send('IndexedDB.deleteDatabase', { securityOrigin: baseURL!, databaseName: probeName })
  537 |       .catch(() => {});
  538 |     await f.close();
  539 |   }
  540 | });
  541 | 
  542 | test('failed required-image reads keep an earlier complete copy and never mark a first download available', async ({
  543 |   browser,
  544 |   baseURL,
  545 | }, info) => {
  546 |   test.setTimeout(180_000);
  547 |   const f = await fixture(browser, baseURL!, info, 'sheet', { images: true });
  548 |   try {
  549 |     await f.download();
  550 |     const complete = await deviceCopy(f.page, f.actor.id, f.item.id);
  551 |     const target = await importImages(f, baseURL!, 'Image download interrupted');
  552 |     const failed = new Set<string>();
  553 |     const pattern = '**/api/items/*/images/*';
  554 |     await f.page.route(pattern, (route) => {
  555 |       failed.add(new URL(route.request().url()).pathname.split('/')[3]);
  556 |       return route.abort('failed');
  557 |     });
  558 |     await f.page.goto('/');
  559 |     await expect.poll(() => failed.has(f.item.id), { timeout: 60_000 }).toBe(true);
  560 |     await listDownload(f.page, target.name);
  561 |     await expect(
  562 |       f.page
  563 |         .getByRole('alert')
  564 |         .filter({ hasText: 'Could not download. Check your connection and try again.' }),
  565 |     ).toBeVisible({ timeout: 60_000 });
  566 |     expect(failed.has(target.id)).toBe(true);
  567 |     expect(await deviceCopy(f.page, f.actor.id, f.item.id)).toEqual(complete);
  568 |     expect((await deviceCopy(f.page, f.actor.id, target.id))?.item).toBeUndefined();
  569 |     await device(f.page);
  570 |     await expect(
  571 |       row(f.page, f.item.name).getByText('Available offline', { exact: true }),
  572 |     ).toBeVisible();
  573 |     await expect(panel(f.page).getByRole('link', { name: target.name })).toHaveCount(0);
  574 |     await f.page.unroute(pattern);
  575 |     await f.page.goto('/');
  576 |     await listDownload(f.page, target.name);
  577 |     await downloaded(f.page, target.name);
  578 |     assertImageBytes((await deviceCopy(f.page, f.actor.id, target.id))!);
  579 |     expect(f.errors).toEqual([]);
  580 |   } finally {
  581 |     await f.close();
  582 |   }
  583 | });
  584 | 
  585 | test('external store, metadata and image deletion are reported honestly; damaged pending data needs explicit discard', async ({
  586 |   browser,
  587 |   baseURL,
  588 | }, info) => {
  589 |   test.setTimeout(240_000);
  590 |   const f = await fixture(browser, baseURL!, info, 'sheet', { images: true });
  591 |   const cdp = await f.context.newCDPSession(f.page);
  592 |   try {
  593 |     await f.download();
  594 |     const original = await f.read();
  595 |     await f.network.setOffline(true);
  596 |     await edit(f.page, 'sheet', '554');
  597 |     await savedLocally(f.page);
  598 |     await device(f.page);
  599 |     const marker = await f.page.evaluate(() => localStorage.getItem('spinel.offline.account'));
  600 |     expect(marker).toBe(f.actor.id);
  601 |     await cdp.send('IndexedDB.deleteDatabase', {
  602 |       securityOrigin: baseURL!,
  603 |       databaseName: `spinel-offline-${f.actor.id}`,
  604 |     });
  605 |     await refresh(f.page);
  606 |     await expect(panel(f.page).getByText(/The saved device data is missing/)).toBeVisible();
  607 |     await expect(panel(f.page).getByRole('listitem')).toHaveCount(0);
  608 |     expect(await accountDatabases(cdp, baseURL!)).not.toContain(`spinel-offline-${f.actor.id}`);
  609 |     await f.network.setOffline(false);
  610 |     await device(f.page);
  611 |     expect(await accountDatabases(cdp, baseURL!)).not.toContain(`spinel-offline-${f.actor.id}`);
  612 |     // Explicit preparation is allowed to make a new store; passive observation was not.
  613 |     await f.download();
  614 |     await f.network.setOffline(true);
  615 |     await edit(f.page, 'sheet', '555');
  616 |     await savedLocally(f.page);
  617 |     const retained = await deviceCopy(f.page, f.actor.id, f.item.id);
  618 |     await device(f.page);
  619 |     const estimatedBytes = displayedBytes(
  620 |       await row(f.page, f.item.name).locator('.device-storage-meta').innerText(),
  621 |     );
  622 |     const metadata = await replaceDeviceMetadata(f.page, f.actor.id, null);
```