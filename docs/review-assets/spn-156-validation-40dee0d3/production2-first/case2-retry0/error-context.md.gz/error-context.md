# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: offline-device.spec.ts >> writer locks and a newly pending copy prevent clean removal; explicit discard preserves the original
- Location: e2e/offline-device.spec.ts:819:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: 'Offline documents', exact: true }).getByRole('status')
Expected substring: "was removed from this device"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('region', { name: 'Offline documents', exact: true }).getByRole('status') with timeout 5000ms
  - waiting for getByRole('region', { name: 'Offline documents', exact: true }).getByRole('status')

```

```yaml
- banner:
  - status "Connection status": Online
- dialog "Discard offline changes?":
  - heading "Discard offline changes?" [level=2]
  - button "Close dialog": ×
  - paragraph: Offline sheet
  - paragraph: This removes the device copy and all its saved offline changes. Changes that have not reached the server will be lost. This cannot be undone. The original document stays unchanged.
  - alert: Close this document in every tab before changing its device copy.
  - button "Discard offline changes"
  - button "Cancel"
```

# Test source

```ts
  783 |     await signIn(users[0]);
  784 |     await page.goto('/');
  785 |     await listDownload(page, document.name);
  786 |     await downloaded(page, document.name);
  787 |     const expected = [`spinel-offline-${users[0].id}`];
  788 |     expect(await accountDatabases(cdp, baseURL!)).toEqual(expected);
  789 |     await device(page);
  790 |     await expect(panel(page).getByRole('link', { name: document.name })).toHaveAttribute(
  791 |       'href',
  792 |       `/?item=${document.id}`,
  793 |     );
  794 |     await page.reload();
  795 |     await expect(panel(page).getByRole('link', { name: document.name })).toBeVisible();
  796 |     for (const user of [users[1], users[3]]) {
  797 |       await signIn(user);
  798 |       await expect(page.getByText(document.name, { exact: true })).toHaveCount(0);
  799 |       expect(await accountDatabases(cdp, baseURL!)).toEqual(expected);
  800 |     }
  801 |     await signIn(users[0]);
  802 |     await expect(panel(page).getByRole('link', { name: document.name })).toBeVisible();
  803 |     await cdp.send('IndexedDB.deleteDatabase', {
  804 |       securityOrigin: baseURL!,
  805 |       databaseName: expected[0],
  806 |     });
  807 |     await refresh(page);
  808 |     await expect(panel(page).getByRole('link', { name: document.name })).toHaveCount(0);
  809 |     await page.reload();
  810 |     await expect(panel(page).getByRole('button', { name: 'Refresh', exact: true })).toBeEnabled();
  811 |     expect(await accountDatabases(cdp, baseURL!)).toEqual([]);
  812 |     expect(errors).toEqual([]);
  813 |   } finally {
  814 |     await context.close();
  815 |     db.close();
  816 |   }
  817 | });
  818 | 
  819 | test('writer locks and a newly pending copy prevent clean removal; explicit discard preserves the original', async ({
  820 |   browser,
  821 |   baseURL,
  822 | }, info) => {
  823 |   test.setTimeout(240_000);
  824 |   const f = await fixture(browser, baseURL!, info, 'sheet');
  825 |   try {
  826 |     await f.download();
  827 |     const original = await f.read();
  828 |     const complete = await deviceCopy(f.page, f.actor.id, f.item.id);
  829 |     const management = await f.context.newPage();
  830 |     await device(management);
  831 |     await removeDialog(management, f.item.name);
  832 |     await management.getByRole('button', { name: 'Remove from device', exact: true }).click();
  833 |     await expect(management.getByRole('dialog').getByRole('alert')).toContainText(
  834 |       'Close this document',
  835 |     );
  836 |     expect(await deviceCopy(management, f.actor.id, f.item.id)).toEqual(complete);
  837 |     await management.getByRole('button', { name: 'Cancel', exact: true }).click();
  838 |     await device(f.page); // Close the native writer without starting a background download refresh.
  839 |     await removeDialog(management, f.item.name);
  840 |     await management.getByRole('button', { name: 'Remove from device', exact: true }).click();
  841 |     await expect(panel(management).getByRole('status')).toContainText(
  842 |       'was removed from this device',
  843 |     );
  844 |     expect((await deviceCopy(management, f.actor.id, f.item.id))?.item).toBeUndefined();
  845 |     expect(await f.read()).toEqual(original);
  846 |     await f.download();
  847 |     await refresh(management);
  848 |     await removeDialog(management, f.item.name);
  849 |     await expect(
  850 |       management.getByRole('dialog', { name: 'Remove device copy?', exact: true }),
  851 |     ).toBeVisible();
  852 |     await f.network.setOffline(true);
  853 |     await edit(f.page, 'sheet', '556');
  854 |     await savedLocally(f.page);
  855 |     const retained = await deviceCopy(f.page, f.actor.id, f.item.id);
  856 |     await device(f.page); // Retire the real writer, keeping its committed pending queue.
  857 |     await management.getByRole('button', { name: 'Remove from device', exact: true }).click();
  858 |     const protectedDialog = management.getByRole('dialog', {
  859 |       name: 'Keep your offline changes',
  860 |       exact: true,
  861 |     });
  862 |     await expect(protectedDialog.getByRole('status')).toContainText('Nothing was removed.');
  863 |     expect(await deviceCopy(management, f.actor.id, f.item.id)).toEqual(retained);
  864 |     await protectedDialog.getByRole('button', { name: 'Keep on device', exact: true }).click();
  865 |     await expect(
  866 |       panel(management).getByRole('button', { name: `Remove ${f.item.name} from device` }),
  867 |     ).toBeFocused();
  868 |     f.network.holdResume();
  869 |     await f.network.setOffline(false);
  870 |     await f.page.goto('/');
  871 |     await f.page
  872 |       .getByRole('button', { name: `More actions for ${f.item.name}`, exact: true })
  873 |       .click();
  874 |     await f.page.getByRole('menuitem', { name: 'Remove from device', exact: true }).click();
  875 |     await expect(f.page.getByRole('link', { name: 'Open recovery', exact: true })).toHaveAttribute(
  876 |       'href',
  877 |       `/?offlineRecovery=${f.item.id}`,
  878 |     );
  879 |     expect(await deviceCopy(f.page, f.actor.id, f.item.id)).toEqual(retained);
  880 |     await removeDialog(management, f.item.name);
  881 |     await management.getByRole('button', { name: 'Discard offline changes…', exact: true }).click();
  882 |     await management.getByRole('button', { name: 'Discard offline changes', exact: true }).click();
> 883 |     await expect(panel(management).getByRole('status')).toContainText(
      |                                                         ^ Error: expect(locator).toContainText(expected) failed
  884 |       'was removed from this device',
  885 |     );
  886 |     expect((await deviceCopy(management, f.actor.id, f.item.id))?.item).toBeUndefined();
  887 |     expect(await f.read()).toEqual(original);
  888 |     expect(f.errors).toEqual([]);
  889 |   } finally {
  890 |     await f.close();
  891 |   }
  892 | });
  893 | 
```