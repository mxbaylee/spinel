# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: offline-sign-out.spec.ts >> offline exit locks both tabs, keeps exact Space changes, drains before an invitation and isolates the next account
- Location: e2e/offline-sign-out.spec.ts:98:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('link', { name: 'Recover Offline doc', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('link', { name: 'Recover Offline doc', exact: true }) with timeout 5000ms
  - waiting for getByRole('link', { name: 'Recover Offline doc', exact: true })

```

```yaml
- banner:
  - link "Spinel Your docs":
    - /url: /
    - img "Spinel"
    - text: Your docs
  - status "Connection status": Online
  - button "Online — connected to Spinel"
  - button "Collapse navigation" [expanded]
  - navigation "File places":
    - button "My files"
    - button "Shared with me"
  - radiogroup "Appearance":
    - radio "Follow system" [checked]
    - radio "Light"
    - radio "Dark"
  - link "Your profile":
    - /url: /profile
    - text: Offline editor ccad38f60b47bfc68793-ce031142f7067623cb53
  - button "Sign out"
- main:
  - region "Your files":
    - heading "My files" [level=1]
    - button "More actions for My files": ···
    - button "New"
    - region "Search your workspace":
      - text: Search files
      - searchbox "Search files"
      - button "Search options"
      - radiogroup "File view":
        - radio "List" [checked]
        - radio "Grid"
      - group: Search help
      - paragraph:
        - text: "Searching:"
        - strong: All accessible files
    - list "Folder contents":
      - listitem:
        - button "Trash Recently deleted files":
          - strong: Trash
          - text: Recently deleted files
    - paragraph: This folder is empty.
```

# Test source

```ts
  130 |         page.getByRole('heading', { name: 'Local access is locked.', exact: true }),
  131 |       ).toBeVisible();
  132 |       await expect(page.locator('.univer-container')).toHaveCount(0);
  133 |       await expect(page.getByText(f.item.name, { exact: true })).toHaveCount(0);
  134 |     }
  135 |     await expect(profile.getByText(/1 document has pending or unchecked changes/)).toBeVisible();
  136 |     expect(f.auth.session(initialCookie)?.user_id).toBe(f.actor.id);
  137 |     expect(await stored(profile, f.actor.id, f.item.id)).toEqual(checkpoint);
  138 |     await capture(profile, info);
  139 |     await profile.setViewportSize({ width: 1440, height: 1100 });
  140 |     await profile.emulateMedia({ colorScheme: 'light' });
  141 |     await profile.getByRole('button', { name: 'Keep changes', exact: true }).click();
  142 |     await expect(
  143 |       profile.getByRole('status').filter({ hasText: 'Sign-out is saved for retry.' }),
  144 |     ).toBeVisible();
  145 |     // A normal cold entry also stays behind the exit barrier.
  146 |     await f.page.goto('/');
  147 |     await expect(
  148 |       f.page.getByRole('heading', { name: 'Local access is locked.', exact: true }),
  149 |     ).toBeVisible();
  150 |     expect(await stored(f.page, f.actor.id, f.item.id)).toEqual(checkpoint);
  151 |     const operator = f.auth.createUser('Exit fixture operator', true);
  152 |     const invite = new InvitationService(f.auth, baseURL!).create(operator.id);
  153 |     f.context.on('request', (request) => {
  154 |       if (
  155 |         /\/api\/auth\/(?:invite\/(?:details|options)|authentication\/options)/.test(request.url())
  156 |       )
  157 |         entryRequests.push(new URL(request.url()).pathname);
  158 |     });
  159 |     await f.network.setOffline(false);
  160 |     await expect.poll(() => refused).toBeGreaterThan(0);
  161 |     expect(f.auth.session(initialCookie)?.user_id).toBe(f.actor.id);
  162 |     await profile.goto(invite.url);
  163 |     await expect(profile).toHaveURL(baseURL! + '/invite');
  164 |     await expect(
  165 |       profile.getByRole('heading', { name: 'Local access is locked.', exact: true }),
  166 |     ).toBeVisible();
  167 |     await expect(profile.getByRole('button', { name: 'Join with a passkey' })).toHaveCount(0);
  168 |     expect(entryRequests).toEqual([]);
  169 |     await profile.getByRole('button', { name: 'Keep changes', exact: true }).click();
  170 |     allowLogout = true;
  171 |     await profile.getByRole('button', { name: 'Try sign-out again', exact: true }).click();
  172 |     await expect(
  173 |       profile.getByRole('button', { name: 'Join with a passkey', exact: true }),
  174 |     ).toBeVisible();
  175 |     expect(f.auth.session(initialCookie)).toBeUndefined();
  176 |     expect(await stored(profile, f.actor.id, f.item.id)).toEqual(checkpoint);
  177 |     // Complete the original invitation task after the barrier; no token was persisted.
  178 |     await f.page.close();
  179 |     await virtualPasskey(f.context, profile);
  180 |     await profile.getByLabel('Your name').fill('Next account');
  181 |     await profile.getByRole('button', { name: 'Join with a passkey', exact: true }).click();
  182 |     await expect(profile.getByRole('heading', { name: 'My files', exact: true })).toBeVisible();
  183 |     await expect(profile.getByText(f.item.name, { exact: true })).toHaveCount(0);
  184 |     await profile.goto(`/?offlineRecovery=${f.item.id}`);
  185 |     await expect(profile.getByRole('region', { name: 'Offline copy', exact: true })).toHaveCount(0);
  186 |     await expect(profile.locator('.univer-container')).toHaveCount(0);
  187 |     expect(await stored(profile, f.actor.id, f.item.id)).toEqual(checkpoint);
  188 |     expect(
  189 |       await profile.evaluate(() => JSON.stringify(Object.entries(localStorage))),
  190 |     ).not.toContain(new URL(invite.url).searchParams.get('token'));
  191 |     // Preparing B through the real Dashboard must preserve A's compatibility
  192 |     // hold and private checkpoint, even while B cannot see A's documents.
  193 |     const nextSession = await f.context.request.get('/api/auth/session');
  194 |     expect(nextSession.status()).toBe(200);
  195 |     const nextAccount = (await nextSession.json()).user.id as string;
  196 |     expect(nextAccount).not.toBe(f.actor.id);
  197 |     const created = await f.context.request.post('/api/items', {
  198 |       headers: { Origin: baseURL! },
  199 |       data: { name: 'Second account offline Doc', kind: 'doc', parentId: null },
  200 |     });
  201 |     expect(created.status(), await created.text()).toBe(201);
  202 |     const nextItem = (await created.json()).item as { id: string; name: string };
  203 |     await profile.goto('/');
  204 |     await profile
  205 |       .getByRole('button', { name: `More actions for ${nextItem.name}`, exact: true })
  206 |       .click();
  207 |     await profile
  208 |       .getByRole('menuitem', { name: 'Available offline on this device', exact: true })
  209 |       .click();
  210 |     await expect(
  211 |       profile
  212 |         .getByRole('status')
  213 |         .filter({ hasText: `${nextItem.name} is available offline on this device.` }),
  214 |     ).toHaveText(`${nextItem.name} is available offline on this device.`, { timeout: 120_000 });
  215 |     const holds = await runtimeAccounts(profile);
  216 |     expect(holds[f.actor.id]).toEqual({ format: 1, sdkVersion: '1.3.1' });
  217 |     expect(holds[nextAccount]).toEqual({ format: 1, sdkVersion: '1.3.1' });
  218 |     expect(
  219 |       await profile.evaluate(
  220 |         async () => (await caches.keys()).filter((name) => name.startsWith('spinel-shell-')).length,
  221 |       ),
  222 |     ).toBeLessThanOrEqual(3);
  223 |     expect(await stored(profile, f.actor.id, f.item.id)).toEqual(checkpoint);
  224 |     await expect(profile.getByText(f.item.name, { exact: true })).toHaveCount(0);
  225 |     // A fresh server-verified original account reclaims only its own unchanged queue.
  226 |     await f.context.addCookies([f.cookie(f.actor.id)]);
  227 |     await profile.goto('/');
  228 |     await expect(
  229 |       profile.getByRole('link', { name: `Recover ${f.item.name}`, exact: true }),
> 230 |     ).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  231 |     await f.network.setOffline(true);
  232 |     await profile.goto(f.href);
  233 |     await usableCanvas(profile);
  234 |     await savedLocally(profile);
  235 |     expect(await copy(profile, 'doc')).toContain('Kept through account exit 5581');
  236 |     expect(await f.read()).toEqual(before);
  237 |     expect(f.errors).toEqual([]);
  238 |   } finally {
  239 |     await f.close();
  240 |   }
  241 | });
  242 | 
  243 | test('locked deletion is explicit, refuses an active writer and clears only this account’s local changes', async ({
  244 |   browser,
  245 |   baseURL,
  246 | }, info) => {
  247 |   test.setTimeout(150_000);
  248 |   const f = await fixture(browser, baseURL!, info, 'sheet');
  249 |   try {
  250 |     await f.download();
  251 |     const original = await f.read();
  252 |     await f.network.setOffline(true);
  253 |     await edit(f.page, 'sheet', '5582');
  254 |     await savedLocally(f.page);
  255 |     const retained = await stored(f.page, f.actor.id, f.item.id);
  256 |     const profile = await f.context.newPage();
  257 |     await profile.goto('/profile');
  258 |     await profile.getByRole('button', { name: 'Sign out', exact: true }).click();
  259 |     await expect(profile.getByText(/1 document has pending or unchecked changes/)).toBeVisible();
  260 |     await expect(f.page.locator('.univer-container')).toHaveCount(0);
  261 |     const key = `spinel-offline:${f.actor.id}:${f.item.id}`;
  262 |     await f.page.evaluate(
  263 |       (name) =>
  264 |         new Promise<void>((acquired) => {
  265 |           let release!: () => void;
  266 |           const held = new Promise<void>((done) => {
  267 |             release = done;
  268 |           });
  269 |           (window as Window & { releaseExitWriter?: () => void }).releaseExitWriter = release;
  270 |           void navigator.locks.request(name, async () => {
  271 |             acquired();
  272 |             await held;
  273 |           });
  274 |         }),
  275 |       key,
  276 |     );
  277 |     const remove = profile.getByRole('button', { name: 'Delete offline data…', exact: true });
  278 |     const open = () => remove.click();
  279 |     const dialog = profile.getByRole('dialog', {
  280 |       name: 'Delete this account’s offline data?',
  281 |       exact: true,
  282 |     });
  283 |     await open();
  284 |     await expect(dialog).toBeVisible();
  285 |     await profile.keyboard.press('Escape');
  286 |     await expect(dialog).toHaveCount(0);
  287 |     await expect(remove).toBeFocused();
  288 |     expect(await stored(profile, f.actor.id, f.item.id)).toEqual(retained);
  289 |     await open();
  290 |     await dialog.getByRole('button', { name: 'Delete offline data', exact: true }).click();
  291 |     await expect(dialog.getByRole('alert')).toContainText(/Close|another tab|open/i);
  292 |     expect(await stored(profile, f.actor.id, f.item.id)).toEqual(retained);
  293 |     await f.page.evaluate(() =>
  294 |       (window as Window & { releaseExitWriter?: () => void }).releaseExitWriter?.(),
  295 |     );
  296 |     await dialog.getByRole('button', { name: 'Delete offline data', exact: true }).click();
  297 |     await expect(
  298 |       profile.getByText(
  299 |         'Offline data for this account was deleted from this device. Server documents were not changed.',
  300 |         { exact: true },
  301 |       ),
  302 |     ).toBeVisible();
  303 |     expect(await stored(profile, f.actor.id, f.item.id)).toBeUndefined();
  304 |     expect(await f.read()).toEqual(original);
  305 |     await expect(
  306 |       profile.getByRole('status').filter({ hasText: 'Sign-out is saved for retry.' }),
  307 |     ).toBeVisible();
  308 |     expect(f.errors).toEqual([]);
  309 |   } finally {
  310 |     await f.close();
  311 |   }
  312 | });
  313 | 
  314 | test('ordinary passkeys work without Web Locks and an old logout response cannot clear the new cookie', async ({
  315 |   browser,
  316 |   baseURL,
  317 | }, info) => {
  318 |   const db = openDatabase(`test-results/${info.project.name}/app.sqlite`);
  319 |   const auth = new AuthStore(db);
  320 |   const operator = auth.createUser('No-lock enrollment operator ' + info.testId, true);
  321 |   const invite = new InvitationService(auth, baseURL!).create(operator.id);
  322 |   const context = await browser.newContext({ baseURL });
  323 |   await context.addInitScript(() =>
  324 |     Object.defineProperty(navigator, 'locks', { value: undefined, configurable: true }),
  325 |   );
  326 |   const oldPage = await context.newPage();
  327 |   const responseReady = deferred(),
  328 |     release = deferred();
  329 |   let pending: Promise<number> | undefined;
  330 |   try {
```