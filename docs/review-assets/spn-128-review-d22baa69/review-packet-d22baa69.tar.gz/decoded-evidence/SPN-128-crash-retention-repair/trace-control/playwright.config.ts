import { defineConfig } from '@playwright/test';
export default defineConfig({ testDir: '/tmp/spn128-trace-control', testMatch: 'trace-ownership.spec.ts', outputDir: '/tmp/spn128-trace-control/results', workers: 1, retries: 0, timeout: 30000, reporter: [['list'], ['json', { outputFile: '/tmp/spn128-trace-control/results.json' }]], use: { headless: true } });
