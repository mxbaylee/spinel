# ✅ SPN-146 single-clone binding repair — independent final source review A

**Exact reviewed head:** `49cb60b1d3336112eaf24a501caa33b490feb791`; tree `52f2824ef5fac8544e6cd26023641a37e6fc8154`; original ticket/base `2f442317dd2e1c188ae4a810ac094fd1162a4a2a`.

**Independent score: 98/100. No unresolved source-publication blocker found.** This qualifies the complete candidate for validation publication subject to the other independent exact-head review and the maintained sequencing prerequisites. It does not establish hosted/type/runtime/application acceptance or authorize merge. The rejected exact8872 report remains separately preserved at `single-clone-candidate-review-a.md` with94/100.

## 🛠️ Finding resolved on this commit

I inspected the complete8872-to-49cb delta and the runtime fixture extraction. `managerFixture` now binds **the actual `core.getBodySliceForSplitTextXAction` function** when no counter is supplied. A wrapper is installed only when a real body-slice counter exists. Ordinary `flush` likewise passes no callback in the no-counter case. The timing builder invokes the no-counter fixture, so the previously identified candidate-only test-wrapper overhead is absent from that path. Counted semantic diagnostics still include direct slicing; no normalization work disappears from their accounting.

The conditional function binding is directly visible in source; affected actual complete-module, linear-copy, single-clone, installer and historical-hash controls passed. The builder's source/file identities bind the updated fixture; its separately prepared bundle is still truthfully labeled dirty-predecessor preparation, not a hosted exact-head execution. No browser ran to address the finding.

## 🔗 Complete candidate and evidence assessment

The original ticket/full-scope assessment in the rejected review remains applicable and was reconciled against this complete head: one qualified native single-character prefix/tail path changes, using the same public slice and final `TextX.push` ownership clone. Admission, unsupported/accessor fallback, undo, tiny-head native fold, Enter semantics, timers, publication and access boundaries remain intact. Full ES named/CJS namespace imports, missing-slicer negatives, historical missing-iterator control, atomic two-format validation, exact97d upgrade and earlier historical hashes are preserved. Production patch, runtime builder/body/analyzer and workflow bytes are unchanged from8872; only the fixture binding and its supporting records changed.

The original51-payload manifest now explicitly names8872 as its source commit. I independently verified the new **20 payloads /569,675 decoded bytes and five current source bindings** from exact49cb Git blobs, including both stored/decoded sizes and SHA-256 hashes. First audit execution passed **479ms/175,648KiB**, normal pressure under the serial60s/2GiB watchdog. External proof/script/log/watchdog are `single-clone-binding-proof-a.*` and `single-clone-binding-proof-watchdog-a.json`. The original51-payload proof remains separate; no source identities were silently updated and no workload was replayed.

The nine affected integration groups passed **19,595ms/568,352KiB**; full lint/format/dependencies passed **16,978ms/731,824KiB**. Bundle preparation passed **1,591ms/574,992KiB**,4,465,453bytes/888modules. These complement unchanged production evidence from the208 Docs controls,29 runtime controls and app build; counts are not added together as unique tests.

The repeated full-project typecheck was **resource-aborted**, with pressure2 first observed at5,074ms/1,418,960KiB and retained peak1,601,648KiB. No compiler diagnostic or pass is inferred. The initial bundle admission was refused under pressure2 before execution; later normal-pressure preparation is its first actual execution. Changed-fixture/import-graph types passed311ms with sampled90,448KiB; that sample is not an instantaneous compiler peak. The earlier full-type pass belongs to8872; **current full-project type acceptance remains hosted and pending**.

## 🧮 Full rubric and all-persona judgment

- **35/35 scope/acceptance:** the complete original XL native-flush outcome is retained, including unprofiled2086-key/16-paragraph budgets, all content/history/peer/access/cleanup owners and supported causal disposition. Conditional landing bookkeeping does not claim completion.
- **25/25 correctness/integrity/access:** public normalization and owned output remain intact; actual full-module bindings and fail-closed installer boundaries are covered. The timing-fixture defect is repaired without altering production semantics.
- **18/20 meaningful verification:** strong raw/descriptor/alias/mutation/sequential/native-module controls and source-bound lower-layer work proofs support publication. Two points reflect the remaining browser/application fidelity and current-head hosted boundary, including resource-blocked full types; these are required pending checks, not waived scope.
- **10/10 CI/operations:** current-source file routing remains complete/fail-closed. Exact97d predecessor, same-repository branch, synchronize-only and attempt1 guard define one explicit changed-algorithm experiment. Ordinary97d CI must finish and be retained before publication as the maintained plan requires; this review does not assert its latest terminal state.
- **10/10 maintainability/process/over-complexity:** conditional instrumentation is simpler and more faithful than always wrapping native work. The production proposal removes a redundant clone without bypassing public ownership or introducing caches/frameworks. Necessary historical transforms retain upgrade and negative-control provenance rather than speculative flexibility.

The full PR remains above the10k soft boundary. The preceding complete raw diff was689files/15,866additions/547deletions, with the focused repair adding evidence/docs plus a27-line fixture delta; these raw counts are not the PR checker's exclusion-adjusted total. This sustained XL investigation carries a real review cost. Splitting its acceptance repair into a supposedly completed parent would conceal unmet requirements; no such split or unrelated scope is admitted. Maintain the explicit original outcome, failed experiments and remaining work in the final PR description.

Owner and Collaborator retain exact formatting/content/history plus responsiveness. Operator gains truthful finite experiments, bounded resources and inspectable failures. Link guest retains edit/authority fences and the same native latency contract. No persona tradeoff justifies relaxed maxima, missing selected owners or lost content.

## 🚦 Publication versus acceptance

The concrete single-clone mechanism and completed lower-layer falsification support the **one prospectively declared changed-candidate qualification**, after both exact-head grades and sequencing checks. It uses the original constant-guard baseline, four fixed input pairs, both manager formats and both orders:32 observations,16 comparisons, each≥20% AND≥1ms faster with guard work included. This is not a renewal of97d's failed13/16 experiment; its original artifact/result stays failed and closed. The application profiling-window allowance stays closed.

All current-head hosted gates, full types, this fixed component result and unprofiled application contracts remain pending. Even a passing component cannot alone explain the historical129.1/114.4/131.2ms maxima or establish full application performance. Preserve first semantic/resource/criterion failures without resampling, GC subtraction, changed thresholds or averaging away misses. SPN-146 remains incomplete; no merge approval is given.
