import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root='/tmp/spn146-linear-hosted',sha=(b:Buffer|string)=>createHash('sha256').update(b).digest('hex');
const proof:any={complete:false,source:'97d0b3203fbddc673d5a9bc729410949eb875523',run:42110760785,members:[]};
try{
const file=root+'/original.zip',zip=readFileSync(file);assert.equal(zip.length,2486861);assert.equal(sha(zip),'e105d8e249b9acf0a3e60aa06e52a1fda8262715070cd70e4edc4a4a2a988508');execFileSync('unzip',['-tqq',file]);const names=execFileSync('unzip',['-Z1',file],{encoding:'utf8'}).trim().split('\n');assert.equal(names.length,15);assert.equal(new Set(names).size,15);
for(const name of names){assert.ok(!name.startsWith('/')&&!name.includes('..'));const b=execFileSync('unzip',['-p',file,name],{maxBuffer:70*1024*1024});const dest=root+'/extracted/'+name;mkdirSync(dest.slice(0,dest.lastIndexOf('/')),{recursive:true});writeFileSync(dest,b);proof.members.push({name,bytes:b.length,sha256:sha(b)});}
const load=(name:string)=>JSON.parse(readFileSync(root+'/extracted/'+name,'utf8'));
const a=load('analysis.json');assert.equal(a.complete,true);assert.equal(a.passed,false);assert.equal(a.analysis.valid,true);assert.equal(a.analysis.disposition,'inconclusive');assert.equal(a.analysis.comparisons.length,16);
for(const c of a.analysis.comparisons){assert.ok([c.priorMs,c.candidateMs,c.reductionMs,c.reductionFraction].every(Number.isFinite));assert.equal(c.meetsCriterion,c.reductionMs>=1&&c.reductionFraction>=.2);assert.ok(Math.abs(c.priorMs-c.candidateMs-c.reductionMs)<1e-8);}
for(const [key,name] of [['progressSha256','progress.json'],['observationWatchdogSha256','observation-watchdog.json'],['observationSha256','observation.json']])assert.equal(a[key],proof.members.find((m:any)=>m.name===name).sha256);
proof.comparisons=a.analysis.comparisons;proof.clock=a.analysis.clock;proof.analysisKeys=Object.keys(a);proof.analysisInnerKeys=Object.keys(a.analysis);proof.gcControl=a.analysis.gcControl;proof.intervalSummary=a.analysis.intervals.map((r:any)=>({keys:Object.keys(r),...Object.fromEntries(Object.entries(r).filter(([k])=>!['gcOverlaps','gcContextPoints','containing'].includes(k))),gcOverlapCount:r.gcOverlaps?.length,gcContextCount:r.gcContextPoints?.length}));
proof.preparation=load('preparation.json');proof.progress=load('progress.json');proof.conversion=load('conversion.json');proof.traceReceipt=load('runtime.pftrace.gz.receipt.json');proof.watchdogs=Object.fromEntries(['preparation','observation','analysis'].map(x=>[x,load(x+'-watchdog.json')]));
const o=load('observation.json');proof.observationKeys=Object.keys(o);proof.observationSummary=Object.fromEntries(Object.entries(o).filter(([k])=>!['observation'].includes(k)));proof.observedKeys=Object.keys(o.observation);proof.observationRecords=o.observation.records.map((r:any)=>Object.fromEntries(Object.entries(r).filter(([k])=>!['output','input','publications','before','after'].includes(k))));
assert.equal(o.observation.records.length,32);assert.equal(o.observation.finished,true);proof.complete=true;
}catch(e){proof.error=String(e);throw e;}finally{writeFileSync(root+'/proof-a.json',JSON.stringify(proof,null,2)+'\n');}
console.log(JSON.stringify({complete:proof.complete,members:proof.members.length,meets:proof.comparisons.filter((c:any)=>c.meetsCriterion).length,failures:proof.comparisons.filter((c:any)=>!c.meetsCriterion),observationKeys:proof.observationKeys,recordKeys:Object.keys(proof.observationRecords[0]),analysisKeys:proof.analysisKeys,innerKeys:proof.analysisInnerKeys}));
