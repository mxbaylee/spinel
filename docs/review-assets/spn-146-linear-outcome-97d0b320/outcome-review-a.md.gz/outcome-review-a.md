# ⚡ SPN-146 linear-copy hosted outcome — independent review A

**The single changed-algorithm qualification failed its unchanged criterion.** Run **42110760785**, attempt1, job **127537374251**, source `97d0b3203fbddc673d5a9bc729410949eb875523`, completed all32 observations and valid analysis, but only **13 of16 comparisons** met both≥20% and≥1ms improvement. The result is **complete, valid, passed:false, inconclusive**. This allowance is consumed and closed. No browser/converter replay, new experiment or threshold change is supported by this audit.

## 🔗 Source, original artifact and actual execution

Original artifact13455300311 is **2,486,861 bytes**, SHA-256 `e105d8e249b9acf0a3e60aa06e52a1fda8262715070cd70e4edc4a4a2a988508`. All15 original members pass CRC, with complete byte counts and SHA-256 inventory/extraction retained in `proof-a.json`. Original observation is62,733,415 bytes; it is preserved, not replaced by the compact proof.

I independently fetched terminal run/job metadata. The job checked out the reviewed head rather than an ordinary PR merge; source/preparation/observation bind exact97d, whose Git tree is `25ef4ccac4cb1df608dbc254a339bf8f15970a1f`. Builder/lock/harness hashes match this source; preparation, emitted entry/bundle and observation hashes agree. The candidate ES/CJS hashes are the repaired `4b30f509…` / `4ade808b…`; the original constant-guard baseline and both previous candidates remain separately identified. The input provenance's hostedSource1eeb identifies the retained input capture, not the current candidate.

The clean dependency/browser/converter setup, preparation and fixed32 observation steps passed. The conversion/assessment step failed on the registered positive criterion; final evidence upload succeeded. No capability/parse/resource failure is being used to replace or excuse that actual timing outcome.

Independent integrity/structure audit passed first execution **1,441 ms /458,160 KiB**. The separate source/hash/raw-order/criterion crosscheck passed **310 ms /90,400 KiB** after correctly waiting on the serial lock. Both used the60-second/2GiB normal-pressure watchdog. Scripts/logs/receipts and `compact-proof-a.json` retain the checks. No manager workload, browser, converter or complete trace-event analysis was repeated.

## 📉 Exact failed comparisons and phases

All32 records have the fixed format/cache/order/variant identities, passed semantic/parity flags and completed cleanup. I checked their ordering and positive durations, phase arithmetic and all16 comparison arithmetic against the raw observation records, not only summary flags. The three failures all concern retained completed-state1440:

- **ES, candidate→prior order:** prior **11.0 ms**, candidate **13.7 ms**; candidate is **2.7 ms slower** (−24.55% reduction). Prior history/collaboration: **6.1/4.9 ms**. Candidate: **6.1/7.2 ms**, with the remaining whole-call overhead retained rather than discarded.
- **CJS, prior→candidate:** **8.9→7.5 ms**; **1.4 ms /15.73%** improvement. The absolute test passes but20% fails. Prior phases **4.3/4.6 ms**; candidate **3.0/4.0 ms**.
- **CJS, candidate→prior:** **12.7→12.4 ms**; **0.3 ms /2.36%** improvement. Both thresholds fail. Prior phases **6.9/5.4 ms**; candidate **6.8/5.6 ms**.

All16 exact comparisons are retained in the compact proof. Thirteen favorable comparisons cannot satisfy an all16 requirement; no pooling, exclusion or reinterpretation changes that result. These component milliseconds are not the full application's registered capacity/idle measurements and do not close the historical129.1/114.4/131.2ms failures.

## 🧬 Trace, GC and profile limits

The retained trace uses the declared64MiB non-overwriting protobuf transport. Completion reports no data loss. I verified both stored/decoded raw protobuf hashes (**939,762 decoded bytes**) and stored/decoded derived JSON hashes (**1,510,685 decoded bytes**) against transport/conversion receipts. The pinned v59.1 Linux converter receipt reports complete11,247-packet framing, successful conversion/query children, no error/data_loss statistics rows, no truncation/output-close failure, and removed temporary directory. This audit verified those identities/receipts without running the converter or independently re-parsing protobuf packets.

The retained analysis has all96 whole/history/collaboration intervals and **0.184ms marker clock uncertainty**. It records1,637 GC-associated duration events,1,290 unknown-duration context records, and356 positive-duration records in the post-observation GC control. GC-associated events can nest and are not independent additive pause totals.

For the slower ES1440 candidate, retained analysis reports GC-associated overlaps in both phases (14history/53collaboration duration overlaps,11/72 unknown-duration points). The matching prior phases have no such recorded overlaps/points. The two failing CJS1440 comparisons have zero recorded duration overlaps and unknown-duration points in their phases. These are descriptive observations, not evidence that all unrecorded GC/runtime pauses were absent, nor that GC caused the ES difference. **No pause subtraction or favorable reclassification is permitted.**

The profile is hash-bound and retained:6,166 samples,64 negative deltas and a **510.9ms start bracket**. It does not support exact per-window CPU-sample attribution or a new historical-cause claim. Component service sinks/timers and shared ES Core remain explicit fidelity limits; complete app subscriptions/history/publication are owned by application acceptance.

## 🧹 Resource and cleanup outcome

Hosted preparation passed in914.6ms, peak673,220KiB. Observation passed in9,004.6ms, peak**1,875,684KiB** below2GiB, no first resource violation. The source reports CDP/context/browser cleanup fulfilled. Progress is terminal passed with no first/persistence failure or dropped events. Final watchdog owned inventories contain only their watchdog parent, with no remaining observed child/browser.

Analysis took532.8ms, peak290,444KiB; its watchdog outcome is failed because the child rejected the criterion, while resource failure/firstViolation remain null. Converter children were closed and temporary data removed. This distinguishes correct owned cleanup and complete evidence from a passing experiment.

## 🚦 Required disposition

Retain this original failure, all comparisons and cleanup, and close the explicit97d allowance. The source may have meaningful copy reductions and many favorable component pairs, but it has **not qualified under its preregistered rule**. Do not relabel the rule exploratory after observing misses, loosen it, renew the same experiment, choose another window or use later green application CI as a causal waiver.

Ordinary current-head CI was still running at this audit's assignment; it remains a separate acceptance owner and should finish with its actual first outcomes preserved. Even if those checks pass, the current component/causal obligation needs an honest supported disposition before SPN-146 can complete. No new discriminating mechanism is established by this read alone, and no further execution is admitted here. The full original ticket and historical failure limits remain unresolved; no merge approval is given.
