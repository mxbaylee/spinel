# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: doc-responsiveness.spec.ts >> desktop sustained native typing profile
- Location: e2e/doc-responsiveness.spec.ts:316:5

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Test source

```ts
  657 |           reloads: initialReloads.reloads,
  658 |         };
  659 |         evidence.preUndoIntegrity = preUndoIntegrity;
  660 |         const sealedNative = await readDocResponsiveness(f.page, false, {
  661 |           action: 'seal',
  662 |           epoch: drainArm!.epoch,
  663 |           generation: drainArm!.generation,
  664 |           unitId: drainArm!.unitId,
  665 |           timeOrigin: drainArm!.timeOrigin,
  666 |         });
  667 |         const drainWitness = sealedNative?.drainWitness as DocDrainWitness | null | undefined;
  668 |         evidence.drainWitness = drainWitness;
  669 |         expect(drainWitness).toBeTruthy();
  670 |         expect(drainWitness!.invalidated).toBe(false);
  671 |         expect(drainWitness!.invalidations).toEqual([]);
  672 |         expect(drainWitness!.epoch).toBe(drainArm!.epoch);
  673 |         expect(drainWitness!.generation).toBe(drainArm!.generation);
  674 |         expect(drainWitness!.unitId).toBe(native.unitId);
  675 |         expect(drainWitness!.timeOrigin).toBe(input.timeOrigin);
  676 |         expect(drainWitness!.expectedCompletedStates).toBe(expectedInputCount);
  677 |         expect(drainWitness!.completedStates).toBe(expectedInputCount);
  678 |         expect(drainWitness!.lastCompletedStateAt!).toBeGreaterThanOrEqual(input.keydownAt.at(-1)!);
  679 |         expect(drainWitness!.firstEmpty).toBeTruthy();
  680 |         expect(drainWitness!.firstEmpty).toEqual(native.drainWitness?.firstEmpty);
  681 |         expect(drainWitness!.firstEmpty!.observedAt).toBeGreaterThanOrEqual(
  682 |           drainWitness!.lastCompletedStateAt!,
  683 |         );
  684 |         expect(drainWitness!.firstEmpty!.pending).toEqual({ history: 0, collaboration: 0 });
  685 |         expect(drainWitness!.firstEmpty!.history).toEqual(native.history);
  686 |         expect(drainWitness!.firstEmpty!.highWater).toEqual(native.highWater);
  687 |         expect(drainWitness!.sealedAt!).toBeGreaterThanOrEqual(preUndoIntegrity.observedAt);
  688 |         const historyProgress: Record<string, unknown> = { phase: 'not-started' };
  689 |         evidence.undoRedoObservation = historyProgress;
  690 |         const undoRedo = await verifyUndoRedo(
  691 |           f,
  692 |           preUndoIntegrity,
  693 |           sample === 'plain-1',
  694 |           reloadObservers,
  695 |           clockOrigins,
  696 |           historyProgress,
  697 |         );
  698 |         evidence.undoRedo = undoRedo;
  699 |         expect(drainWitness!.sealedAt!).toBeLessThanOrEqual(undoRedo.beforeUndoAt);
  700 |         await expect
  701 |           .poll(async () => (await f.read()).body!.dataStream)
  702 |           .toBe(undoRedo.outcome === 'passed' ? expectedText : '\r\n');
  703 |         await Promise.all([online(f.page), online(f.other)]);
  704 |         expect(f.errors).toEqual([]);
  705 |         expect(input.keydownAt).toHaveLength(expectedInputCount);
  706 |         expect(input.keyToFrameMs).toHaveLength(expectedInputCount);
  707 |         evidence.correctness =
  708 |           undoRedo.outcome === 'passed'
  709 |             ? 'exact saved/live peer text, sender/peer selections, undo/redo and Online passed'
  710 |             : 'baseline redo refused at capacity; exact prior typing and Undo verified; recovered saved empty state';
  711 |         // Schema 4 retains the strict baseline history outcome and separately
  712 |         // observes capacity/idle work. Drain acceptance now uses the preregistered
  713 |         // browser-local witness; the unchanged late-read scalar remains descriptive.
  714 |         if (!baseline) {
  715 |           expect(native.highWater.history).toBeLessThanOrEqual(DOC_RESPONSIVENESS_GROUP_LIMIT);
  716 |           expect(native.highWater.collaboration).toBeLessThanOrEqual(
  717 |             DOC_RESPONSIVENESS_GROUP_LIMIT,
  718 |           );
  719 |           expect(capacityFlushes.length).toBeGreaterThan(0);
  720 |           for (const entry of native.flushes) {
  721 |             expect(['capacity', 'idle']).toContain(entry.reason);
  722 |             expect(Number.isInteger(entry.history) && entry.history >= 0).toBe(true);
  723 |             expect(Number.isInteger(entry.collaboration) && entry.collaboration >= 0).toBe(true);
  724 |             const pending = Math.max(entry.history, entry.collaboration);
  725 |             expect(pending).toBeGreaterThan(0);
  726 |             expect(pending).toBeLessThanOrEqual(DOC_RESPONSIVENESS_GROUP_LIMIT);
  727 |             if (entry.reason === 'capacity') expect(pending).toBe(DOC_RESPONSIVENESS_GROUP_LIMIT);
  728 |             if (entry.reason === 'idle') {
  729 |               expect(Number.isFinite(entry.quietForMs)).toBe(true);
  730 |               expect(entry.quietForMs!).toBeGreaterThanOrEqual(300);
  731 |             }
  732 |           }
  733 |           if (!profiled) {
  734 |             expect(frame.p95).toBeLessThanOrEqual(budgets[preset].inputP95Ms);
  735 |             expect(longTasks.max).toBeLessThanOrEqual(budgets[preset].longTaskMaxMs);
  736 |             // Idle samples must never dilute the registered capacity distribution.
  737 |             expect(capacityFlush!.p95).toBeLessThanOrEqual(budgets[preset].flushP95Ms);
  738 |             expect(capacityFlush!.max).toBeLessThanOrEqual(budgets[preset].flushMaxMs);
  739 |             if (idleFlush) {
  740 |               expect(idleFlush.p95).toBeLessThanOrEqual(budgets[preset].flushP95Ms);
  741 |               expect(idleFlush.max).toBeLessThanOrEqual(budgets[preset].flushMaxMs);
  742 |             }
  743 |             expect(flushMaximum!).toBeLessThanOrEqual(budgets[preset].flushMaxMs);
  744 |             expect(localDrainMs).not.toBeNull();
  745 |             expect(localDrainMs!).toBeLessThanOrEqual(1000);
  746 |           }
  747 |         }
  748 |         const finalReloads = await readReloads(reloadObservers);
  749 |         completeReloadObservation(finalReloads);
  750 |         expect(finalReloads.reloads).toEqual(undoRedo.reloads);
  751 |         evidence.reloadObservers = finalReloads.status;
  752 |         expect((evidence.diagnosticTrace as { complete: boolean }).complete).toBe(true);
  753 |         const captured = await retainNativeDiagnostic();
  754 |         expect(captured.collectionError).toBeUndefined();
  755 |         expect(captured.phaseError).toBeNull();
  756 |         expect(captured.captureError).toBeNull();
> 757 |         expect((captured.idle as unknown[]).length).toBeGreaterThan(0);
      |                                                     ^ Error: expect(received).toBeGreaterThan(expected)
  758 |         evidence.completed = true;
  759 |       } finally {
  760 |         if (finishInput)
  761 |           evidence.partialInput = await finishInput().catch((error) => ({ error: String(error) }));
  762 |         if (profiling) {
  763 |           const result = await cdp.send('Profiler.stop').catch(() => null);
  764 |           if (result)
  765 |             evidence.profileSha256 = await retainProfile(result.profile, profilerClock, info);
  766 |         }
  767 |         if (finishTrace && !evidence.diagnosticTrace) evidence.diagnosticTrace = await finishTrace();
  768 |         try { await retainNativeDiagnostic(); }
  769 |         catch (error) { evidence.nativeDiagnosticRetentionError = String(error); }
  770 |         evidence.errors = f.errors;
  771 |         evidence.finalNative = await readDocResponsiveness(f.page).catch(() => null);
  772 |         if (reloadObservers) {
  773 |           const finalReloads = await readReloads(reloadObservers).catch(() => null);
  774 |           if (finalReloads) {
  775 |             evidence.reloadObservers = finalReloads.status;
  776 |             evidence.finalReloads = finalReloads.reloads;
  777 |           }
  778 |           await Promise.all([reloadObservers.sender.dispose(), reloadObservers.peer.dispose()]);
  779 |         }
  780 |         await writeFile(info.outputPath('spn108-metrics.json'), JSON.stringify(evidence, null, 2));
  781 |         await cdp.detach().catch(() => {});
  782 |         await f.close();
  783 |       }
  784 |     });
  785 | 
  786 | /** Only the separate continuation case reads native state at its final key's first frame. */
  787 | async function observeContinuationFrame(page: Page, unitId: string) {
  788 |   const handle = await page.evaluateHandle(
  789 |     ({ unitId, expectedKeys }) => {
  790 |       const installedAt = performance.now();
  791 |       let keyCount = 0;
  792 |       let frame: number | undefined;
  793 |       let result: {
  794 |         keyAt: number;
  795 |         frameAt: number;
  796 |         readStartedAt: number;
  797 |         readReturnedAt: number;
  798 |         responses: number;
  799 |         snapshot: DocResponsivenessEvidence | null;
  800 |       } | null = null;
  801 |       const keydown = (event: KeyboardEvent) => {
  802 |         if (
  803 |           !(event.target instanceof Element) ||
  804 |           !event.target.matches('[contenteditable="true"][data-u-comp="editor"]')
  805 |         )
  806 |           return;
  807 |         keyCount++;
  808 |         if (keyCount !== expectedKeys) return;
  809 |         const keyAt = performance.now();
  810 |         frame = requestAnimationFrame(() => {
  811 |           frame = undefined;
  812 |           const frameAt = performance.now();
  813 |           let snapshot: DocResponsivenessEvidence | null = null;
  814 |           let responses = 0;
  815 |           const read = (event: Event) => {
  816 |             const evidence = (event as CustomEvent<DocResponsivenessEvidence>).detail;
  817 |             if (evidence?.unitId !== unitId) return;
  818 |             responses++;
  819 |             snapshot = evidence;
  820 |           };
  821 |           window.addEventListener('spinel-doc-responsiveness-evidence', read);
  822 |           const readStartedAt = performance.now();
  823 |           try {
  824 |             window.dispatchEvent(
  825 |               new CustomEvent('spinel-doc-responsiveness-read', { detail: { includeText: true } }),
  826 |             );
  827 |           } finally {
  828 |             window.removeEventListener('spinel-doc-responsiveness-evidence', read);
  829 |             result = {
  830 |               keyAt,
  831 |               frameAt,
  832 |               readStartedAt,
  833 |               readReturnedAt: performance.now(),
  834 |               responses,
  835 |               snapshot,
  836 |             };
  837 |           }
  838 |         });
  839 |       };
  840 |       document.addEventListener('keydown', keydown, { capture: true, passive: true });
  841 |       return {
  842 |         read: () => ({ installedAt, unitId, expectedKeys, keyCount, result }),
  843 |         dispose() {
  844 |           document.removeEventListener('keydown', keydown, true);
  845 |           if (frame !== undefined) cancelAnimationFrame(frame);
  846 |         },
  847 |       };
  848 |     },
  849 |     { unitId, expectedKeys: expectedInputCount + 1 },
  850 |   );
  851 |   return {
  852 |     read: () => handle.evaluate((value) => value.read()),
  853 |     async dispose() {
  854 |       await handle.evaluate((value) => value.dispose()).catch(() => {});
  855 |       await handle.dispose();
  856 |     },
  857 |   };
```