import { AppearanceStore } from '../src/server/appearance/store.ts';
import { mkdir } from 'node:fs/promises';
import { expect, test } from '@playwright/test';
import type { Locator, Page } from '@playwright/test';
import sharp from 'sharp';
import { sheetImageFixture } from './sheet-image-fixture.ts';
import { openDatabase } from '../server/database.ts';
import { AuthStore, COOKIE_NAME } from '../src/server/auth/store.ts';
import { WorkspaceStore } from '../src/server/workspace/store.ts';
import type { OfflineBundle } from '../src/shared/offlineBundle.ts';
import { copy, fixture, selectCell, stored, synced, usableCanvas } from './offline-fixture.ts';
import {
  DOCS_NORMAL_EDITOR_UNIT_ID_KEY,
  DocumentFlavor,
  LocaleType,
  getDocsEmptySnapshot,
  createParagraphId,
  createSectionId,
} from '@univerjs/core';

test('hiding preserves a prepared share and its offline discovery preference without bypassing revoke or sign-out cleanup', async ({
  browser,
  baseURL,
}, info) => {
  test.setTimeout(180_000);
  const context = await browser.newContext({ baseURL, viewport: { width: 1280, height: 900 } });
  const page = await context.newPage();
  const db = openDatabase(`test-results/${info.project.name}/app.sqlite`);
  const auth = new AuthStore(db);
  const workspace = new WorkspaceStore(auth);
  const owner = auth.createUser(`Hidden copy owner ${info.testId}`);
  const reader = auth.createUser(`Hidden copy reader ${info.testId}`);
  const doc = workspace.create(owner.id, {
    name: 'Kept on this device',
    kind: 'doc',
    parentId: null,
  });
  workspace.share(owner.id, doc.id, reader.id, 'viewer');
  const session = auth.createSession(reader.id);
  await context.addCookies([
    {
      name: COOKIE_NAME,
      value: session.token,
      url: baseURL!.replace('http:', 'https:'),
      secure: true,
      httpOnly: true,
      sameSite: 'Strict',
    },
  ]);
  const rowAction = async (action: string) => {
    await page.getByRole('button', { name: `More actions for ${doc.name}`, exact: true }).click();
    await page.getByRole('menuitem', { name: action, exact: true }).click();
  };
  const showHidden = async () => {
    await page
      .getByRole('button', { name: 'More actions for Shared with me', exact: true })
      .click();
    await page.getByRole('menuitem', { name: 'Show hidden', exact: true }).click();
  };
  const download = async () => {
    await rowAction('Available offline on this device');
    await expect(page.getByRole('status').filter({ hasText: 'available offline' })).toHaveText(
      `${doc.name} is available offline on this device.`,
      { timeout: 120_000 },
    );
  };
  try {
    await page.goto('/?shared=1');
    await expect
      .poll(() => page.evaluate(() => Boolean(navigator.serviceWorker.controller)))
      .toBe(true);
    await download();
    const before = (await stored(page, reader.id, doc.id))!.bundle;
    await rowAction('Hide');
    await expect(
      page.getByText(`${doc.name} is hidden from Shared with me and search.`, { exact: true }),
    ).toBeVisible();
    await expect
      .poll(() =>
        page.evaluate(
          ({ accountId, itemId }) =>
            new Promise<boolean>((resolve, reject) => {
              const opening = indexedDB.open(`spinel-offline-${accountId}`);
              opening.onerror = () => reject(opening.error);
              opening.onsuccess = () => {
                const db = opening.result;
                const read = db.transaction('meta').objectStore('meta').get('catalog');
                read.onerror = () => {
                  db.close();
                  reject(read.error);
                };
                read.onsuccess = () => {
                  db.close();
                  resolve(
                    read.result.shared.some(
                      (item: { id: string; hidden?: boolean }) => item.id === itemId && item.hidden,
                    ),
                  );
                };
              };
            }),
          { accountId: reader.id, itemId: doc.id },
        ),
      )
      .toBe(true);
    expect((await stored(page, reader.id, doc.id))!.bundle).toEqual(before);
    await context.setOffline(true);
    await page.reload();
    await expect(page.getByRole('heading', { name: 'Shared with me', exact: true })).toBeVisible();
    await expect(page.getByRole('button', { name: `${doc.name} Doc`, exact: true })).toHaveCount(0);
    await showHidden();
    await expect(page.getByRole('button', { name: `${doc.name} Doc`, exact: true })).toBeVisible();
    await page.getByRole('button', { name: `${doc.name} Doc`, exact: true }).click();
    await expect(page.getByRole('region', { name: 'Offline copy', exact: true })).toBeVisible();
    expect((await stored(page, reader.id, doc.id))!.bundle).toEqual(before);
    await context.setOffline(false);
    workspace.share(owner.id, doc.id, reader.id, null);
    await page.goto('/?shared=1');
    await expect.poll(() => stored(page, reader.id, doc.id), { timeout: 30_000 }).toBeUndefined();
    await showHidden();
    await expect(page.getByRole('button', { name: `${doc.name} Doc`, exact: true })).toHaveCount(0);
    workspace.share(owner.id, doc.id, reader.id, 'viewer');
    await page.reload();
    await showHidden();
    await download();
    const retained = await stored(page, reader.id, doc.id);
    expect(retained?.bundle.access).toBe('viewer');
    await page.goto('/profile');
    await expect(page.getByRole('heading', { name: 'Your profile', exact: true })).toBeVisible();
    // Clean downloads are kept and locked by default. Keep logout offline long
    // enough to exercise the separate, explicit account-data deletion choice.
    await context.setOffline(true);
    await page.getByRole('button', { name: 'Sign out', exact: true }).click();
    await expect(page).toHaveURL(baseURL! + '/sign-in');
    await expect(
      page.getByRole('heading', { name: 'Local access is locked.', exact: true }),
    ).toBeVisible();
    await expect(page.getByText(doc.name, { exact: true })).toHaveCount(0);
    await expect(page.locator('.univer-container')).toHaveCount(0);
    expect(await page.evaluate(() => localStorage.getItem('spinel.offline.account'))).toBeNull();
    expect(await stored(page, reader.id, doc.id)).toEqual(retained);
    await page.getByRole('button', { name: 'Delete offline data…', exact: true }).click();
    await page
      .getByRole('dialog', { name: 'Delete this account’s offline data?', exact: true })
      .getByRole('button', { name: 'Delete offline data', exact: true })
      .click();
    await expect.poll(() => stored(page, reader.id, doc.id)).toBeUndefined();
    await expect(
      page.getByText(
        'Offline data for this account was deleted from this device. Server documents were not changed.',
        { exact: true },
      ),
    ).toBeVisible();
    await context.setOffline(false);
    await expect(
      page.getByRole('button', { name: 'Sign in with a passkey', exact: true }),
    ).toBeVisible({ timeout: 30_000 });
    expect(auth.session(session.token)).toBeUndefined();
  } finally {
    await context.close();
    db.close();
  }
});

const coverImage = async (background: string) => ({
  data: (
    await sharp({ create: { width: 32, height: 32, channels: 3, background } })
      .png()
      .toBuffer()
  ).toString('base64'),
});
async function assertLiveOfflineCover(page: Page, menuAppearance = false) {
  await expect(page.locator('.editor-frame')).toHaveCount(1);
  await expect(page.getByRole('button', { name: 'Change appearance', exact: true })).toHaveCount(0);
  await expect(page.locator('.appearance-banner img')).toHaveAttribute(
    'src',
    /^data:image\/webp;base64,/,
  );
  if (menuAppearance) {
    await page.getByRole('button', { name: 'Document actions', exact: true }).click();
    await expect(page.getByRole('menuitem', { name: 'Appearance…', exact: true })).toBeDisabled();
    await page.keyboard.press('Escape');
  }
  const requests: string[] = [];
  const observe = (request: import('@playwright/test').Request) => {
    if (new URL(request.url()).pathname.startsWith('/api/appearance/'))
      requests.push(request.url());
  };
  page.on('request', observe);
  const original = await page.evaluate(() => localStorage.getItem('spinel-theme'));
  const images: string[] = [];
  for (const theme of ['light', 'dark']) {
    await page.evaluate((theme) => {
      localStorage.setItem('spinel-theme', theme);
      window.dispatchEvent(new StorageEvent('storage', { key: 'spinel-theme', newValue: theme }));
      window.dispatchEvent(new Event('focus'));
    }, theme);
    await expect(page.locator('html')).toHaveAttribute('data-theme', theme);
    await expect(page.locator('.appearance-banner img')).toHaveAttribute(
      'src',
      /^data:image\/webp;base64,/,
    );
    images.push((await page.locator('.appearance-banner img').getAttribute('src'))!);
  }
  expect(images[0]).not.toBe(images[1]);
  expect(requests).toEqual([]);
  page.off('request', observe);
  await page.evaluate((original) => {
    if (original === null) localStorage.removeItem('spinel-theme');
    else localStorage.setItem('spinel-theme', original);
    window.dispatchEvent(new StorageEvent('storage', { key: 'spinel-theme', newValue: original }));
  }, original);
}

async function installationResources(page: Page) {
  const observed = await page.evaluate(async () => {
    const paths = [
      '/manifest.webmanifest',
      '/app-icon-180.png',
      '/app-icon-192.png',
      '/app-icon-512.png',
    ];
    return Promise.all(
      paths.map(async (path) => {
        // Force the real worker path, rather than accepting an incidental HTTP-cache hit.
        const response = await fetch(path, {
          cache: 'reload',
          credentials: 'omit',
          redirect: 'error',
          signal: AbortSignal.timeout(5000),
        });
        if (!response.ok || response.redirected || response.url !== location.origin + path)
          throw new Error(`Installation resource unavailable: ${path}`);
        const bytes = await response.arrayBuffer();
        if (!bytes.byteLength || bytes.byteLength > 100_000)
          throw new Error(`Installation resource size is invalid: ${path}`);
        const sha256 = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))]
          .map((byte) => byte.toString(16).padStart(2, '0'))
          .join('');
        const mime = response.headers.get('Content-Type')?.split(';')[0].trim();
        if (path === '/manifest.webmanifest')
          return {
            path,
            mime,
            sha256,
            bytes: bytes.byteLength,
            manifest: JSON.parse(new TextDecoder().decode(bytes)),
          };
        const image = new Image();
        const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
        try {
          image.src = url;
          await image.decode();
          return {
            path,
            mime,
            sha256,
            bytes: bytes.byteLength,
            width: image.naturalWidth,
            height: image.naturalHeight,
          };
        } finally {
          URL.revokeObjectURL(url);
        }
      }),
    );
  });
  expect(observed[0]).toMatchObject({
    path: '/manifest.webmanifest',
    mime: 'application/manifest+json',
    manifest: { id: '/', name: 'Spinel', start_url: '/', scope: '/', display: 'standalone' },
  });
  expect(observed[0].manifest.icons).toEqual(
    [192, 512].map((size) => ({
      src: `/app-icon-${size}.png`,
      sizes: `${size}x${size}`,
      type: 'image/png',
      purpose: 'any maskable',
    })),
  );
  for (const [index, size] of [180, 192, 512].entries())
    expect(observed[index + 1]).toMatchObject({
      path: `/app-icon-${size}.png`,
      mime: 'image/png',
      width: size,
      height: size,
    });
  return observed;
}

// Offline downloads need the production build's shell manifest (docs/offline.md).
test('downloaded Sheets and Docs open offline with local images; nothing else does', async ({
  browser,
  baseURL,
}, info) => {
  test.setTimeout(180_000);
  const context = await browser.newContext({ baseURL, viewport: { width: 1440, height: 1100 } });
  const page = await context.newPage();
  const db = openDatabase(`test-results/${info.project.name}/app.sqlite`);
  const auth = new AuthStore(db),
    workspace = new WorkspaceStore(auth);
  const user = auth.createUser(`Offline ${info.testId}`);
  const doc = workspace.create(user.id, { name: 'Offline notes', kind: 'doc', parentId: null });
  const appearance = new AppearanceStore(workspace);
  await appearance.update({ userId: user.id, customData: {} }, doc.id, {
    revision: 0,
    icon: 'lucide:book-open',
    iconColor: 'primary-soft',
    cover: {
      source: 'upload',
      images: { light: await coverImage('#ffd2e2'), dark: await coverImage('#382233') },
      position: 50,
    },
  });

  workspace.create(user.id, { name: 'Online only', kind: 'sheet', parentId: null });
  await context.addCookies([
    {
      name: COOKIE_NAME,
      value: auth.createSession(user.id).token,
      url: baseURL!.replace('http:', 'https:'),
      secure: true,
      httpOnly: true,
      sameSite: 'Strict',
    },
  ]);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  // IMAGE() loads its URL directly; offline copies show stored values only.
  const tracked: string[] = [];
  context.on('request', (request) => {
    if (new URL(request.url()).hostname === 'tracker.invalid') tracked.push(request.url());
  });
  try {
    const snapshot = await sheetImageFixture();
    (snapshot.sheets.tab.cellData as Record<number, unknown>)[4] = {
      // No stored value: the default mode would compute it on open.
      0: { f: '=IMAGE("https://tracker.invalid/pixel.png")' },
    };
    const imported = await context.request.post('/api/items/import', {
      headers: { Origin: baseURL! },
      data: { filename: 'Sheet images.univer.json', parentId: null, snapshot },
    });
    expect(imported.status(), await imported.text()).toBe(201);
    const sheet = (await imported.json()).item as { id: string; name: string };

    await page.goto('/');
    await expect
      .poll(() => page.evaluate(() => Boolean(navigator.serviceWorker.controller)))
      .toBe(true);
    // An unprepared device keeps nothing (pwa.spec.ts checks the same on HTTPS).
    expect(await page.evaluate(() => caches.keys())).toEqual([]);
    for (const name of [sheet.name, doc.name]) {
      await page.getByRole('button', { name: `More actions for ${name}`, exact: true }).click();
      await page
        .getByRole('menuitem', { name: 'Available offline on this device', exact: true })
        .click();
      await expect(page.getByRole('status').filter({ hasText: 'available offline' })).toHaveText(
        `${name} is available offline on this device.`,
        { timeout: 120_000 },
      );
    }
    // Editor feedback must announce the result without moving or remounting the
    // viewport-sized native editor. Listing feedback remains inline above.
    await page.setViewportSize({ width: 390, height: 844 });
    await page.getByRole('button', { name: `${doc.name} Doc`, exact: true }).click();
    await expect(page.getByRole('status', { name: 'Save status', exact: true })).toHaveText(
      'Synced. All changes are saved on the server and this device.',
      { timeout: 30_000 },
    );
    let nativeCanvas = await page.locator('.editor-frame canvas').first().elementHandle();
    expect(nativeCanvas).not.toBeNull();
    const stableEditor = async () => {
      expect(
        await page
          .locator('.editor-frame canvas')
          .first()
          .evaluate((node, original) => node === original, nativeCanvas!),
      ).toBe(true);
      expect(
        await page.locator('.editor-frame').evaluate((node) => {
          const box = node.getBoundingClientRect();
          return box.top === 0 && box.bottom <= innerHeight;
        }),
      ).toBe(true);
      expect(await page.evaluate(() => document.documentElement.scrollHeight <= innerHeight)).toBe(
        true,
      );
    };
    const offlineAction = async (name: string) => {
      await page.getByRole('button', { name: 'Document actions', exact: true }).click();
      await page.getByRole('menuitem', { name, exact: true }).click();
    };
    const availability = page.getByRole('dialog', { name: 'Offline availability', exact: true });
    await stableEditor();
    await offlineAction('Remove from device');
    await expect(availability.getByRole('alert')).toHaveText(
      'Close this document in every tab before changing its device copy.',
    );
    await stableEditor();
    await availability.getByRole('button', { name: 'Done', exact: true }).click();
    await expect(availability).toHaveCount(0);
    await expect(page.getByRole('button', { name: 'Document actions', exact: true })).toBeFocused();
    // An open writable copy may have uncaptured native input. Close it before
    // removing, then preserve the next mounted editor through download feedback.
    await page.getByRole('button', { name: 'Back to files', exact: true }).click();
    await page.getByRole('button', { name: `More actions for ${doc.name}`, exact: true }).click();
    await page.getByRole('menuitem', { name: 'Remove from device', exact: true }).click();
    await expect(
      page.getByRole('status').filter({ hasText: `${doc.name} was removed` }),
    ).toHaveText(`${doc.name} was removed from this device.`);
    await page.getByRole('button', { name: `${doc.name} Doc`, exact: true }).click();
    await expect(page.getByRole('status', { name: 'Save status', exact: true })).toHaveText(
      'All changes saved.',
      { timeout: 30_000 },
    );
    await nativeCanvas!.dispose();
    nativeCanvas = await page.locator('.editor-frame canvas').first().elementHandle();
    expect(nativeCanvas).not.toBeNull();
    const bundlePath = `**/api/items/${doc.id}/offline-bundle`;
    await page.route(bundlePath, (route) =>
      route.fulfill({
        status: 503,
        json: { error: 'Offline download is temporarily unavailable.' },
      }),
    );
    await offlineAction('Available offline on this device');
    await expect(availability.getByRole('alert')).toHaveText(
      'Offline download is temporarily unavailable.',
    );
    await stableEditor();
    await mkdir('test-results/theme-screenshots', { recursive: true });
    await page.screenshot({
      path: `test-results/theme-screenshots/spn-049-offline-failure-phone-${info.project.name}.png`,
      fullPage: true,
      animations: 'disabled',
    });
    await page.keyboard.press('Escape');
    await expect(availability).toHaveCount(0);
    await expect(page.getByRole('button', { name: 'Document actions', exact: true })).toBeFocused();
    await page.unroute(bundlePath);
    await offlineAction('Available offline on this device');
    await expect(availability.getByRole('status')).toHaveText(
      `${doc.name} is available offline on this device.`,
      { timeout: 120_000 },
    );
    for (const [theme, width] of [
      ['light', 1440],
      ['dark', 1440],
      ['light', 390],
    ] as const) {
      await page.emulateMedia({ colorScheme: theme });
      await page.setViewportSize({ width, height: 844 });
      await stableEditor();
      await page.screenshot({
        path: `test-results/theme-screenshots/spn-049-offline-success-${theme}-${width}-${info.project.name}.png`,
        fullPage: true,
        animations: 'disabled',
      });
    }
    await availability.getByRole('button', { name: 'Done', exact: true }).click();
    await expect(availability).toHaveCount(0);
    await stableEditor();
    await page.getByRole('button', { name: 'Back to files', exact: true }).click();
    await page.emulateMedia({ colorScheme: 'light' });
    await page.setViewportSize({ width: 1440, height: 1100 });
    // Only the public app shell is cached; documents live in IndexedDB.
    const cached = await page.evaluate(async () => {
      const names = await caches.keys();
      const paths: string[] = [];
      for (const name of names)
        for (const request of await (await caches.open(name)).keys())
          paths.push(new URL(request.url).pathname);
      return { names, paths };
    });
    expect(cached.names).toHaveLength(1);
    expect(cached.names[0]).toMatch(/^spinel-shell-[0-9a-f]{16}$/);
    expect(cached.paths).toContain('/');
    for (const path of cached.paths) expect(path).toMatch(/^\/$|^\/assets\/[^/]+$/);
    expect(
      await page.evaluate(async () => (await indexedDB.databases()).map((entry) => entry.name)),
    ).toContain(`spinel-offline-${user.id}`);
    const installation = await installationResources(page);

    // A failed background refresh keeps the last complete copy.
    const stored = () =>
      page.evaluate(
        ({ name, itemId }) =>
          new Promise<{ revision: number; downloadedAt: number }>((resolve, reject) => {
            const open = indexedDB.open(name);
            open.onerror = () => reject(open.error);
            open.onsuccess = () => {
              const request = open.result
                .transaction('items', 'readonly')
                .objectStore('items')
                .get(itemId);
              request.onerror = () => reject(request.error);
              request.onsuccess = () => {
                open.result.close();
                const { revision, downloadedAt } = request.result;
                resolve({ revision, downloadedAt });
              };
            };
          }),
        { name: `spinel-offline-${user.id}`, itemId: sheet.id },
      );
    const before = await stored();
    let refused = 0;
    await page.route('**/api/items/*/images/*', (route) => {
      refused++;
      return route.abort();
    });
    await page.reload();
    await expect.poll(() => refused, { timeout: 60_000 }).toBeGreaterThan(0);
    await page.getByRole('button', { name: `More actions for ${sheet.name}`, exact: true }).click();
    await expect(
      page.getByRole('menuitem', { name: 'Remove from device', exact: true }),
    ).toBeVisible();
    await page.keyboard.press('Escape');
    await page.unrouteAll({ behavior: 'wait' });
    expect(await stored()).toEqual(before);

    await page.emulateMedia({ colorScheme: 'light' });
    await page.goto(`/?item=${doc.id}`);
    await expect(
      page.getByRole('button', { name: 'Save details: Synced', exact: true }),
    ).toBeVisible();
    await page.getByRole('button', { name: 'Document actions', exact: true }).click();
    await page.getByRole('menuitem', { name: 'Appearance…', exact: true }).click();
    await expect(page.getByRole('button', { name: 'Save appearance', exact: true })).toBeVisible();
    await context.setOffline(true);
    await expect(page.getByText('Connect to change appearance.', { exact: true })).toBeVisible();
    await page.getByRole('button', { name: 'Close', exact: true }).click();
    await assertLiveOfflineCover(page, true);
    const api: string[] = [];
    page.on('request', (request) => {
      if (/^\/api\/(items|appearance)(\/|$)/.test(new URL(request.url()).pathname))
        api.push(request.url());
    });
    await page.goto('/');
    // A catalog saved by an older app may still contain pins. Opening it must
    // preserve the downloaded files without restoring the removed feature.
    await page.evaluate(
      ({ accountId, legacyPin }) =>
        new Promise<void>((resolve, reject) => {
          const opening = indexedDB.open(`spinel-offline-${accountId}`);
          opening.onerror = () => reject(opening.error);
          opening.onsuccess = () => {
            const database = opening.result;
            const transaction = database.transaction('meta', 'readwrite');
            const meta = transaction.objectStore('meta');
            const catalog = meta.get('catalog');
            catalog.onsuccess = () => meta.put({ ...catalog.result, pins: [legacyPin] }, 'catalog');
            transaction.oncomplete = () => {
              database.close();
              resolve();
            };
            transaction.onabort = () => {
              database.close();
              reject(transaction.error);
            };
          };
        }),
      { accountId: user.id, legacyPin: doc },
    );
    await page.reload();
    const connection = page.getByRole('button', {
      name: 'Offline — not connected to Spinel',
      exact: true,
    });
    await expect(connection).toBeVisible({ timeout: 30_000 });
    // A prepared cold launch retains its public manifest and every installation
    // PNG, including the iOS touch icon. This does not claim an OS installation.
    expect(await installationResources(page)).toEqual(installation);
    await connection.hover();
    await expect(
      page.getByRole('dialog', { name: 'Connection details', exact: true }),
    ).toContainText('Files as of');
    await expect(page.locator('.banner').filter({ hasText: 'Files as of' })).toHaveCount(0);
    await page.keyboard.press('Escape');
    await expect(page.getByRole('dialog', { name: 'Connection details', exact: true })).toHaveCount(
      0,
    );
    const row = (name: string) =>
      page
        .getByRole('list', { name: 'Folder contents' })
        .getByRole('listitem')
        .filter({
          has: page.locator('.dashboard-file-open', { hasText: name }),
        });
    await expect(row(sheet.name)).toContainText('Available offline');
    await expect(row(doc.name)).toContainText('Available offline');
    await expect(row('Online only')).toContainText('Needs a connection');
    // Same-account online history must not hide the local catalog behind a search
    // that offline launch cannot execute or clear.
    await page.evaluate((accountId) => {
      const session = JSON.parse(sessionStorage.getItem('spinel:dashboard-navigation-session')!);
      if (!session?.generation || session.accountId !== accountId)
        throw new Error('Missing current retrieval epoch');
      history.replaceState(
        {
          spinelDashboard: {
            version: 1,
            accountId,
            generation: session.generation,
            value: {
              folderId: null,
              shared: false,
              query: { q: 'Private previous query', type: '', owner: '', tag: '', modified: '' },
              draft: 'Private previous query',
              allFiles: false,
              layout: 'list',
              scroll: 0,
            },
          },
        },
        '',
        '/',
      );
      history.pushState(null, '', '/?shared=1');
      window.dispatchEvent(new PopStateEvent('popstate'));
    }, user.id);
    await expect(page.getByRole('heading', { name: 'Shared with me', exact: true })).toBeVisible();
    await page.goBack();
    await expect(row(doc.name)).toContainText('Available offline');
    await expect(page.getByRole('searchbox', { name: 'Search files' })).toHaveCount(0);

    await expect(page.getByRole('complementary', { name: 'Pinned items' })).toHaveCount(0);
    await expect(page.getByRole('button', { name: /^(Pin|Unpin) / })).toHaveCount(0);
    // Local mode offers nothing that would reach the server.
    for (const name of [sheet.name, doc.name, 'Online only']) {
      await row(name)
        .getByRole('button', { name: `More actions for ${name}`, exact: true })
        .click();
      await expect(page.getByRole('menuitem')).toHaveText(['Open']);
      await page.keyboard.press('Escape');
    }

    await row(sheet.name)
      .getByRole('button', { name: `${sheet.name} Sheet`, exact: true })
      .click();
    await expect(page.getByRole('status', { name: 'Save status', exact: true })).toHaveText(
      'Saved on this device — waiting to sync.',
      { timeout: 30_000 },
    );
    await expect(page.getByLabel('Spreadsheet grid', { exact: true })).toBeVisible();
    await expect(page.getByRole('button', { name: 'Back to files', exact: true })).toHaveCount(1);
    await expect(page.getByRole('navigation', { name: 'Breadcrumb', exact: true })).toHaveCount(0);
    await expect
      .poll(() =>
        page.evaluate(() => {
          const frame = document.querySelector('.editor-frame')!.getBoundingClientRect();
          return frame.top === 0 && frame.bottom <= innerHeight + 1;
        }),
      )
      .toBe(true);
    await expect(page.getByRole('button', { name: 'Bold', exact: true })).toBeEnabled();
    const rgb = [
      [255, 153, 0],
      [34, 85, 238],
      [34, 187, 102],
    ];
    const pixels = async () => {
      const { data, info: meta } = await sharp(await page.locator('.univer-container').screenshot())
        .removeAlpha()
        .raw()
        .toBuffer({ resolveWithObject: true });
      const counts = [0, 0, 0];
      for (let offset = 0; offset < data.length; offset += meta.channels)
        rgb.forEach((color, index) => {
          if (color.every((value, channel) => Math.abs(data[offset + channel] - value) < 12))
            counts[index]++;
        });
      return counts;
    };
    // Floating, in-cell and background images all come from verified local bytes.
    await expect
      .poll(async () => (await pixels()).every((count) => count > 1000), { timeout: 25_000 })
      .toBe(true);

    await page.goBack();
    await row(doc.name)
      .getByRole('button', { name: `${doc.name} Doc`, exact: true })
      .click();
    await expect(page.getByRole('status', { name: 'Save status', exact: true })).toHaveText(
      'Saved on this device — waiting to sync.',
      { timeout: 30_000 },
    );
    await page.evaluate(() => {
      localStorage.setItem('spinel-theme', 'light');
      window.dispatchEvent(new StorageEvent('storage', { key: 'spinel-theme', newValue: 'light' }));
    });
    await expect(page.locator('html')).toHaveAttribute('data-theme', 'light');
    await expect(page.locator('.appearance-banner img')).toHaveAttribute(
      'src',
      /^data:image\/webp;base64,/,
    );
    const coverLight = await page.locator('.appearance-banner img').getAttribute('src');
    await page.evaluate(() => {
      localStorage.setItem('spinel-theme', 'dark');
      window.dispatchEvent(new StorageEvent('storage', { key: 'spinel-theme', newValue: 'dark' }));
    });
    await expect(page.locator('.appearance-banner img')).toHaveAttribute(
      'src',
      /^data:image\/webp;base64,/,
    );
    await expect
      .poll(() => page.locator('.appearance-banner img').getAttribute('src'))
      .not.toBe(coverLight);
    await expect(
      page.locator('.editor-identity [data-profile-icon="lucide:book-open"]'),
    ).toBeVisible();
    await expect(page.locator('.editor-identity .item-icon')).toHaveAttribute(
      'style',
      /--fill-primary-soft-fg/,
    );
    await expect(page.locator('.editor-identity .item-icon')).toHaveAttribute(
      'style',
      /--fill-primary-soft-bg/,
    );
    await page.goBack();
    await row('Online only')
      .getByRole('button', { name: 'Online only Sheet', exact: true })
      .click();
    await expect(page.getByText('Online only needs a connection.')).toBeVisible();
    expect(api).toEqual([]);
    expect(tracked).toEqual([]);

    // Pages that need the server get the generic offline page, never the shell.
    await page.goto('/share/offline-link');
    await expect(page.getByRole('heading', { name: "You're offline" })).toBeVisible();

    // Another tab releasing the device closes local data here too. Reopening
    // requires an explicit action so a changed cookie cannot remount private UI.
    await page.goto('/');
    await expect(connection).toBeVisible({ timeout: 30_000 });
    await connection.hover();
    await expect(
      page.getByRole('dialog', { name: 'Connection details', exact: true }),
    ).toContainText('Files as of');
    await page.keyboard.press('Escape');
    const other = await context.newPage();
    await other.goto('/');
    await other.evaluate(() => localStorage.removeItem('spinel.offline.account'));
    await expect(
      page.getByRole('heading', { name: 'This tab is locked.', exact: true }),
    ).toBeVisible();
    await expect(page.getByRole('button', { name: 'Reopen Spinel', exact: true })).toBeVisible();
    await expect(page.getByText(sheet.name)).toHaveCount(0);
    await other.close();

    // Signing in online again claims the device back for its downloads.
    await context.setOffline(false);
    await page.goto('/');
    await expect
      .poll(() => page.evaluate(() => localStorage.getItem('spinel.offline.account')))
      .toBe(user.id);
    // Let the background refresh finish before the session ends under it.
    await page.waitForLoadState('networkidle');

    // A session the server ended (a 401) stops offline access on this device,
    // so the next offline launch opens no local data.
    await context.clearCookies();
    await page.goto('/');
    await expect(page).toHaveURL(/\/sign-in/);
    await expect
      .poll(() => page.evaluate(() => localStorage.getItem('spinel.offline.account')))
      .toBeNull();
    await context.setOffline(true);
    await page.goto('/');
    await expect(page.getByRole('heading', { name: "You're offline" })).toBeVisible();
    await expect(page.getByText(sheet.name)).toHaveCount(0);
    expect(errors).toEqual([]);
  } finally {
    await context.close();
    db.close();
  }
});

test('a prepared Space Doc opens natively offline from its normal link and My files, without substituting an unavailable child', async ({
  browser,
  baseURL,
}, info) => {
  test.setTimeout(180_000);
  // Reuse the production fixture and keep one native browser editor resident.
  const context = await browser.newContext({
    baseURL,
    viewport: { width: 1440, height: 1100 },
    permissions: ['clipboard-read', 'clipboard-write'],
  });
  const page = await context.newPage();
  const db = openDatabase(`test-results/${info.project.name}/app.sqlite`);
  const auth = new AuthStore(db);
  const user = auth.createUser(`Offline Space ${info.testId}`);
  await context.addCookies([
    {
      name: COOKIE_NAME,
      value: auth.createSession(user.id).token,
      url: baseURL!.replace('http:', 'https:'),
      secure: true,
      httpOnly: true,
      sameSite: 'Strict',
    },
  ]);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  const orangePixels = async (surface: Locator) => {
    const { data, info: image } = await sharp(await surface.screenshot())
      .removeAlpha()
      .raw()
      .toBuffer({ resolveWithObject: true });
    let count = 0;
    for (let offset = 0; offset < data.length; offset += image.channels)
      if ([255, 153, 0].every((value, channel) => Math.abs(data[offset + channel] - value) < 12))
        count++;
    return count;
  };
  try {
    // The everyday API is enabled by default; no review flag or special server.
    const created = await context.request.post('/api/items', {
      headers: { Origin: baseURL! },
      data: { name: 'Offline field kit', kind: 'space', parentId: null },
    });
    expect(created.status(), await created.text()).toBe(201);
    const root = (await created.json()).item as { id: string; name: string };
    const child = async (name: string) => {
      const response = await context.request.post(`/api/spaces/${root.id}/items`, {
        headers: { Origin: baseURL! },
        data: { name, kind: 'doc', parentId: root.id },
      });
      expect(response.status(), await response.text()).toBe(201);
      return (await response.json()).item as { id: string; name: string };
    };
    const doc = await child('Prepared field notes');
    const coverResponse = await context.request.patch(
      `/api/appearance/spaces/${root.id}/items/${doc.id}`,
      {
        headers: { Origin: baseURL! },
        data: {
          revision: 0,
          cover: {
            source: 'upload',
            images: { light: await coverImage('#ffd2e2'), dark: await coverImage('#382233') },
            position: 50,
          },
        },
      },
    );
    expect(coverResponse.status()).toBe(200);
    const missing = await child('Unprepared field notes');
    const rootHref = `/spaces/${root.id}`;
    const docHref = `${rootHref}?item=${doc.id}`;
    const childApi = `/api/spaces/${root.id}/items/${doc.id}`;
    const text = 'Native offline field notes 314';

    // Preparing a directly opened child must also retain its outer Space root,
    // even when this browser has never visited My files to cache a catalog.
    await page.emulateMedia({ colorScheme: 'light' });
    await page.goto(docHref);
    await expect(page).toHaveURL(baseURL! + docHref);
    await expect
      .poll(() => page.evaluate(() => Boolean(navigator.serviceWorker.controller)))
      .toBe(true);
    const editor = page.getByRole('region', { name: 'Doc document', exact: true });
    const saved = () =>
      expect(editor.getByRole('status', { name: 'Save status', exact: true })).toHaveText(
        'All changes saved.',
        { timeout: 30_000 },
      );
    await saved();
    await editor.locator('.univer-container').click({ position: { x: 130, y: 200 } });
    await page.keyboard.type(text);
    await page.keyboard.press('Enter');
    await saved();
    const insert = editor.getByRole('tab', { name: 'Insert', exact: true });
    await insert.click();
    await expect(insert).toHaveAttribute('aria-selected', 'true');
    const uploaded = page.waitForResponse(
      (response) =>
        response.request().method() === 'POST' &&
        new URL(response.url()).pathname === `${childApi}/images`,
    );
    const chooser = page.waitForEvent('filechooser');
    await editor.getByRole('button', { name: 'Image', exact: true }).click();
    await (
      await chooser
    ).setFiles({
      name: 'field-marker.png',
      mimeType: 'image/png',
      buffer: await sharp({
        create: { width: 120, height: 72, channels: 4, background: '#ff9900' },
      })
        .png()
        .toBuffer(),
    });
    expect((await uploaded).status()).toBe(201);
    await expect
      .poll(() => orangePixels(editor.locator('.univer-container')), { timeout: 25_000 })
      .toBeGreaterThan(1000);
    await saved();

    await page.getByRole('button', { name: 'Document actions', exact: true }).click();
    await page.getByRole('menuitem', { name: 'Offline copies', exact: true }).click();
    const availability = page.getByRole('region', { name: 'Offline availability', exact: true });
    const downloaded = page.waitForResponse(
      (response) => new URL(response.url()).pathname === `${childApi}/offline-bundle`,
      { timeout: 120_000 },
    );
    await availability
      .getByRole('button', { name: `Make ${doc.name} available offline on this device` })
      .click();
    const response = await downloaded;
    expect(response.status()).toBe(200);
    const bundle = (await response.json()) as OfflineBundle;
    expect(bundle).toMatchObject({
      accountId: user.id,
      spaceId: root.id,
      itemId: doc.id,
      kind: 'doc',
    });
    if (bundle.kind !== 'doc') throw new Error('The prepared child must be a Doc.');
    expect(bundle.snapshot.body?.dataStream).toContain(text);
    expect(bundle.snapshot.drawingsOrder).toHaveLength(1);
    expect(bundle.images).toHaveLength(1);
    await expect(availability.getByRole('status')).toHaveText(
      `${doc.name} is available offline on this device.`,
      { timeout: 120_000 },
    );
    await page
      .getByRole('dialog', { name: 'Offline copies', exact: true })
      .getByRole('button', { name: 'Close dialog', exact: true })
      .click();

    const assertPreparedDoc = async () => {
      await expect(page.getByRole('heading', { name: doc.name, exact: true })).toBeVisible();
      const copy = page.getByRole('region', { name: 'Offline copy', exact: true });
      await expect(copy.getByRole('status', { name: 'Save status', exact: true })).toHaveText(
        'Saved on this device — waiting to sync.',
        { timeout: 30_000 },
      );
      await expect(copy.getByRole('button', { name: 'Bold', exact: true })).toBeEnabled();
      const surface = copy.locator('.univer-container');
      // Inspect the native drawing itself: a cached manifest or image URL alone
      // would not prove that verified image bytes reach the offline renderer.
      await expect.poll(() => orangePixels(surface), { timeout: 25_000 }).toBeGreaterThan(1000);
      // Focus the text row above the drawing, not the image selection. Native
      // copy of a selected drawing legitimately has no plain-text payload.
      await surface.click({ position: { x: 220, y: 175 } });
      await page.keyboard.press('Control+a');
      await page.evaluate(() => navigator.clipboard.writeText('not copied'));
      await page.keyboard.press('Control+c');
      await expect.poll(() => page.evaluate(() => navigator.clipboard.readText())).toContain(text);
      await page.keyboard.press('ArrowRight');
    };

    await context.setOffline(true);
    await assertLiveOfflineCover(page);
    await page.reload();
    await expect(page).toHaveURL(baseURL! + docHref);
    await assertPreparedDoc();
    await mkdir('test-results/theme-screenshots', { recursive: true });
    for (const [theme, width, variant] of [
      ['light', 1440, 'light'],
      ['dark', 1440, 'dark'],
      ['light', 390, 'phone'],
    ] as const) {
      await page.setViewportSize({ width, height: 1100 });
      await page.emulateMedia({ colorScheme: theme });
      await expect(page.locator('html')).toHaveAttribute('data-theme', theme);
      await expect(
        page
          .getByRole('region', { name: 'Offline copy', exact: true })
          .getByRole('status', { name: 'Save status', exact: true }),
      ).toHaveText('Saved on this device — waiting to sync.');
      await expect(
        page
          .getByRole('region', { name: 'Offline copy', exact: true })
          .getByRole('button', { name: 'Bold', exact: true }),
      ).toBeEnabled();
      const screenshot = `test-results/theme-screenshots/spn-092-space-native-doc-offline-${variant}-${info.project.name}.png`;
      await page.screenshot({ path: screenshot, fullPage: true });
      await info.attach(`Native prepared Space Doc and image (${variant})`, {
        path: screenshot,
        contentType: 'image/png',
      });
    }
    await page.setViewportSize({ width: 1440, height: 1100 });

    const remoteReads: string[] = [];
    page.on('request', (request) => {
      const path = new URL(request.url()).pathname;
      if (/^\/(?:api\/(?:spaces|items)(?:\/|$)|space-api\/)/.test(path)) remoteReads.push(path);
    });
    await page.getByRole('button', { name: 'My files', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'My files', exact: true })).toBeVisible();
    const contents = page.getByRole('list', { name: 'Folder contents', exact: true });
    const rootRow = contents.getByRole('listitem').filter({
      has: page.locator('.dashboard-file-open', { hasText: root.name }),
    });
    await expect(rootRow).toContainText('Space');
    await expect(contents.getByText(doc.name, { exact: true })).toHaveCount(0);
    await expect(contents.getByText(missing.name, { exact: true })).toHaveCount(0);
    await rootRow.getByRole('button', { name: `${root.name} Space`, exact: true }).click();
    await expect(page).toHaveURL(baseURL! + rootHref);
    await assertPreparedDoc();

    const missingHref = `${rootHref}?item=${missing.id}`;
    await page.goto(missingHref);
    await expect(page).toHaveURL(baseURL! + missingHref);
    await expect(
      page.getByRole('status').filter({ hasText: 'This page needs a connection.' }),
    ).toHaveText(
      'This page needs a connection. It has not been prepared in this Space on this device.',
    );
    await expect(page.getByRole('heading', { name: root.name, exact: true })).toBeVisible();
    await expect(page.getByRole('region', { name: 'Offline copy', exact: true })).toHaveCount(0);
    await expect(page.locator('.univer-container')).toHaveCount(0);
    // A prepared sibling remains a deliberate navigation choice, never a
    // substitute for the explicit child in the address bar.
    await expect(
      page
        .getByRole('navigation', { name: 'Prepared pages', exact: true })
        .getByRole('link', { name: doc.name, exact: true }),
    ).toHaveAttribute('href', docHref);
    expect(remoteReads).toEqual([]);
    expect(errors).toEqual([]);
    // The account destination remains available from a prepared Space, including
    // the local sign-out that locks its saved documents until online sign-in.
    await page.getByRole('button', { name: 'Your profile', exact: true }).click();
    await expect(page).toHaveURL(baseURL! + '/profile');
    await expect(page.getByRole('heading', { name: 'Your profile', exact: true })).toBeVisible();
    await page.getByRole('button', { name: 'Sign out', exact: true }).click();
    await expect(page).toHaveURL(baseURL! + '/sign-in');
  } finally {
    await context.close();
    db.close();
  }
});

// Warm and deep-link opens must restore real native content, not just the frame.
test('a warm Dashboard and a failed first-list deep link restore the downloaded Doc content', async ({
  browser,
  baseURL,
}, info) => {
  test.setTimeout(180_000);
  const text = 'Downloaded Doc 090: every saved word survives a warm open and first-list failure.';
  const seed = getDocsEmptySnapshot(
    'warm-doc-090',
    LocaleType.EN_US,
    'Warm saved notes',
    DocumentFlavor.MODERN,
  );
  seed.body = {
    ...seed.body,
    dataStream: text + '\r\n',
    paragraphs: [{ startIndex: text.length, paragraphId: createParagraphId(new Set()) }],
    sectionBreaks: [{ startIndex: text.length + 1, sectionId: createSectionId(new Set()) }],
  };
  const f = await fixture(browser, baseURL!, info, 'doc', { seed });
  const { page, item } = f;
  const restoredContent = async () => {
    await usableCanvas(page);
    const content = await copy(page, 'doc');
    expect(content.trim()).toBe(text);
    await expect(page.getByText("This item isn't available")).toHaveCount(0);
    await expect(page.getByText('Failed to fetch')).toHaveCount(0);
  };
  try {
    await f.download();
    await page.getByRole('button', { name: 'Back to files', exact: true }).click();
    await f.network.setOffline(true);
    await page.getByRole('button', { name: `${item.name} Doc`, exact: true }).click();
    await restoredContent();
    // A new Dashboard has no in-memory metadata. Its live session succeeds,
    // but only the prepared catalog can supply the failed list/item request.
    await f.network.setOffline(false);
    await page.route('**/api/items{,/**}', (route) => route.abort('internetdisconnected'));
    await page.goto(f.href);
    await restoredContent();
    // A real denied response remains authoritative even with the same saved copy.
    await page.unrouteAll();
    await page.route(`**/api/items/${item.id}`, (route) =>
      route.fulfill({
        status: 403,
        contentType: 'application/json',
        body: JSON.stringify({ error: 'Access denied.' }),
      }),
    );
    await page.goto(f.href);
    await expect(page.getByText("This item isn't available")).toBeVisible();
    await expect(page.getByRole('region', { name: 'Offline copy', exact: true })).toHaveCount(0);
  } finally {
    await f.close();
  }
});

// A network transition is not permission to dispose a native editor's unfinished
// input. One real Sheet draft exercises the shared Dashboard/OfflineViewer lifetime.
test('a warm offline Sheet keeps unfinished native input through reconnect and delayed failed metadata', async ({
  browser,
  baseURL,
}, info) => {
  test.setTimeout(180_000);
  const f = await fixture(browser, baseURL!, info, 'sheet');
  const { page, item } = f;
  let releaseMetadata = () => {};
  try {
    await f.download();
    await page.getByRole('button', { name: 'Back to files', exact: true }).click();
    await f.network.setOffline(true);
    await page.getByRole('button', { name: `${item.name} Sheet`, exact: true }).click();
    await usableCanvas(page);
    await selectCell(page, 'D1');
    const draft = 'Unfinished warm reconnect cell 090';
    await page.keyboard.insertText(draft);
    const input = page.locator(
      `[id="__editor_${DOCS_NORMAL_EDITOR_UNIT_ID_KEY}"][contenteditable="true"][data-u-comp="editor"]`,
    );
    await expect(input).toBeFocused();
    const canvas = await page.locator('.univer-container canvas').first().elementHandle();
    const baseline = await f.read();
    let metadataRequested = false;
    const metadataGate = new Promise<void>((resolve) => {
      releaseMetadata = resolve;
    });
    await page.route(`**/api/items/${item.id}`, async (route) => {
      metadataRequested = true;
      await metadataGate;
      await route.abort('internetdisconnected');
    });
    await f.network.setOffline(false);
    // The native socket is the connection authority; a background metadata read
    // can remain pending without replacing the editor or claiming the draft saved.
    await expect(page.getByRole('status', { name: 'Connection status', exact: true })).toHaveText(
      'Online',
    );
    // The fixed Dashboard issues no replacement metadata fetch. If the old
    // handoff returns, this route holds it pending and then rejects it; neither
    // phase may unmount the editor. The native binding owns its separate
    // /collaboration authority checks and socket reconnect throughout.
    await page.evaluate(
      () =>
        new Promise<void>((done) =>
          requestAnimationFrame(() => requestAnimationFrame(() => done())),
        ),
    );
    const sameEditor = async () => {
      expect(
        await page
          .locator('.univer-container canvas')
          .first()
          .evaluate((node, original) => node === original, canvas!),
      ).toBe(true);
      await input.focus();
      await page.keyboard.press('Control+a');
      await page.keyboard.press('Control+c');
      await expect
        .poll(async () => (await page.evaluate(() => navigator.clipboard.readText())).trim())
        .toBe(draft);
      expect((await f.read()).snapshot).toEqual(baseline.snapshot);
    };
    await sameEditor();
    expect(metadataRequested).toBe(false);
    releaseMetadata();
    await expect.poll(() => page.locator('.univer-container canvas').count()).toBeGreaterThan(0);
    await sameEditor();
    await page.unrouteAll();
    await page.keyboard.press('Enter');
    await synced(page);
    await expect
      .poll(
        async () =>
          (await f.read()).snapshot.sheets[baseline.snapshot.sheetOrder[0]].cellData?.[0]?.[3]?.v,
      )
      .toBe(draft);
  } finally {
    releaseMetadata();
    await f.close();
  }
});
