# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: collaboration.spec.ts >> revoking one login preserves another login’s queued edit and stops later broadcasts
- Location: e2e/collaboration.spec.ts:362:1

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=f1e4]:
  - banner [ref=f1e5]:
    - button "Spinel home" [ref=f1e6] [cursor=pointer]:
      - img "Spinel" [ref=f1e8]
      - generic [ref=f1e33]: spinel
    - radiogroup "Appearance" [ref=f1e36]:
      - radio "Follow system" [checked] [ref=f1e37] [cursor=pointer]
      - radio [checked] [aria-hidden] [ref=f1e40]
      - radio "Light" [ref=f1e41] [cursor=pointer]
      - radio [aria-hidden] [ref=f1e44]
      - radio "Dark" [ref=f1e45] [cursor=pointer]
      - radio [aria-hidden] [ref=f1e48]
  - main [ref=f1e49]:
    - region [ref=f1e50]:
      - paragraph [ref=f1e51]: PRIVATE BY INVITATION
      - heading "Your workspace." [level=1] [ref=f1e52]
      - paragraph [ref=f1e53]: Sheets and Docs, together in a private place.
      - generic [ref=f1e54]:
        - paragraph [ref=f1e55]: Use a passkey from your browser, password manager or phone.
        - button "Sign in with a passkey" [ref=f1e56] [cursor=pointer]
      - button "Need help?" [ref=f1e60] [cursor=pointer]
  - contentinfo [ref=f1e61]: Have a shared link? Open it directly to view the document.
```

# Test source

```ts
  346 |     // Replacing the selected remote range proves the cursor jump used this live document.
  347 |     await page.keyboard.type('XX');
  348 |     await saved(page);
  349 |     await expect.poll(read).toBe('Owner Shared anchor CollaboratXX\r\n');
  350 |     await other.reload();
  351 |     await saved(other);
  352 |     expect(errors).toEqual([]);
  353 |   } finally {
  354 |     await second.close();
  355 |     db.prepare('DELETE FROM workspace_items WHERE id=?').run(item.id);
  356 |     for (const user of [owner, editor])
  357 |       db.prepare('DELETE FROM auth_users WHERE id=?').run(user.id);
  358 |     db.close();
  359 |   }
  360 | });
  361 | 
  362 | test('revoking one login preserves another login’s queued edit and stops later broadcasts', async ({
  363 |   page,
  364 |   context,
  365 |   browser,
  366 |   baseURL,
  367 | }, info) => {
  368 |   test.setTimeout(60_000);
  369 |   const db = openDatabase(
  370 |     info.project.name === 'development'
  371 |       ? 'test-results/development/app.sqlite'
  372 |       : 'test-results/production/app.sqlite',
  373 |   );
  374 |   const auth = new AuthStore(db),
  375 |     workspace = new WorkspaceStore(auth),
  376 |     owner = auth.createUser('Two logins');
  377 |   const item = workspace.create(owner.id, {
  378 |     name: 'Private after revoke',
  379 |     kind: 'sheet',
  380 |     parentId: null,
  381 |   });
  382 |   const sessions = [auth.createSession(owner.id), auth.createSession(owner.id)];
  383 |   const second = await browser.newContext({ viewport: { width: 1440, height: 1100 } });
  384 |   const network = await syncNetwork(second);
  385 |   const other = await second.newPage();
  386 |   let release!: () => void;
  387 |   const pending = new Promise<void>((resolve) => {
  388 |     release = resolve;
  389 |   });
  390 |   let held = false,
  391 |     revokedClosed = 0,
  392 |     otherClosed = 0;
  393 |   const revokedMessages: string[] = [];
  394 |   page.on('websocket', (socket) => {
  395 |     socket.on('framereceived', (frame) => revokedMessages.push(String(frame.payload)));
  396 |     socket.on('close', () => {
  397 |       revokedClosed++;
  398 |     });
  399 |   });
  400 |   other.on('websocket', (socket) =>
  401 |     socket.on('close', () => {
  402 |       otherClosed++;
  403 |     }),
  404 |   );
  405 |   for (const [index, c] of [context, second].entries())
  406 |     await c.addCookies([
  407 |       {
  408 |         name: COOKIE_NAME,
  409 |         value: sessions[index].token,
  410 |         url: baseURL!.replace('http:', 'https:'),
  411 |         secure: true,
  412 |         httpOnly: true,
  413 |         sameSite: 'Strict',
  414 |       },
  415 |     ]);
  416 |   try {
  417 |     await page.goto(`/?item=${item.id}`);
  418 |     await other.goto(`${baseURL}/?item=${item.id}`);
  419 |     for (const target of [page, other]) {
  420 |       await expect(target.getByRole('status', { name: 'Save status' })).toHaveText(
  421 |         'All changes saved.',
  422 |         { timeout: 30_000 },
  423 |       );
  424 |       // Saved content does not prove that this login has joined the room.
  425 |       await expect(
  426 |         target.getByRole('status', { name: 'Connection status', exact: true }),
  427 |       ).toHaveText('Online');
  428 |     }
  429 |     network.interceptWrites(async (write) => {
  430 |       held = true;
  431 |       await pending;
  432 |       write.forward();
  433 |     });
  434 |     const box = other
  435 |       .getByRole('region', { name: 'Sheet document', exact: true })
  436 |       .getByRole('textbox')
  437 |       .nth(2);
  438 |     await box.fill('A1');
  439 |     await box.press('Enter');
  440 |     await other.keyboard.type('private-after-revoke');
  441 |     await other.keyboard.press('Enter');
  442 |     await expect.poll(() => held).toBe(true);
  443 |     const revokedClosedBefore = revokedClosed;
  444 |     const otherClosedBefore = otherClosed;
  445 |     auth.revokeSession(sessions[0].session.token_hash);
> 446 |     await expect.poll(() => revokedClosed).toBeGreaterThan(revokedClosedBefore);
      |                                            ^ Error: expect(received).toBeGreaterThan(expected)
  447 |     expect(otherClosed).toBe(otherClosedBefore);
  448 |     // The revoked login has no unfinished work, so SPN-053's clean 401 handoff
  449 |     // closes its editor. The other login's independently queued edit must survive.
  450 |     await expect(page).toHaveURL(/\/sign-in(?:\?|$)/);
  451 |     await expect(
  452 |       page.getByRole('button', { name: 'Sign in with a passkey', exact: true }),
  453 |     ).toBeVisible();
  454 |     await expect(page.locator('.univer-container canvas')).toHaveCount(0);
  455 |     expect((await context.request.get(`${baseURL}/api/items/${item.id}/sheet`)).status()).toBe(401);
  456 |     const boundary = revokedMessages.length;
  457 |     release();
  458 |     await expect(other.getByRole('status', { name: 'Save status' })).toHaveText(
  459 |       'All changes saved.',
  460 |       { timeout: 30_000 },
  461 |     );
  462 |     const saved = (await (await second.request.get(`${baseURL}/api/items/${item.id}/sheet`)).json())
  463 |       .snapshot;
  464 |     expect(saved.sheets[saved.sheetOrder[0]].cellData[0][0].v).toBe('private-after-revoke');
  465 |     expect(
  466 |       revokedMessages.slice(boundary).some((message) => message.includes('private-after-revoke')),
  467 |     ).toBe(false);
  468 |     await expect(other.getByRole('button', { name: 'Bold', exact: true })).toBeEnabled();
  469 |     await expect(page).toHaveURL(/\/sign-in$/);
  470 |     await expect(page.getByRole('heading', { name: 'Your workspace.', exact: true })).toBeVisible();
  471 |     await other.reload();
  472 |     await expect(other.getByRole('status', { name: 'Save status' })).toHaveText(
  473 |       'All changes saved.',
  474 |       { timeout: 30_000 },
  475 |     );
  476 |   } finally {
  477 |     release();
  478 |     network.interceptWrites(undefined);
  479 |     try {
  480 |       await network.drainWrites();
  481 |     } finally {
  482 |       await second.close();
  483 |       db.prepare('DELETE FROM workspace_items WHERE id=?').run(item.id);
  484 |       db.prepare('DELETE FROM auth_users WHERE id=?').run(owner.id);
  485 |       db.close();
  486 |     }
  487 |   }
  488 | });
  489 | 
```