import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {dirname,join} from 'node:path';
const root='/tmp/spn090-native-fe',source='fe1fddd818cf66661c4e43c20dd856d87a685383';
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const load=(p:string)=>JSON.parse(readFileSync(join(root,p),'utf8'));
const proof:any={complete:false,source,run:42112723484,attempt:1,members:[],sourceFiles:[]};
try{
 const artifact=load('artifacts.json').artifacts.find((a:any)=>a.id===13455566513),run=load('run.json'),jobs=load('jobs.json').jobs;
 assert.equal(run.head_sha,source);assert.equal(run.run_attempt,1);assert.equal(run.status,'completed');assert.equal(run.conclusion,'failure');
 assert.equal(jobs.length,3);assert.equal(jobs.find((j:any)=>j.id===127544196608).conclusion,'failure');assert.equal(jobs.filter((j:any)=>j.conclusion==='success').length,2);
 assert.equal(artifact.workflow_run.head_sha,source);assert.equal(artifact.workflow_run.id,proof.run);
 const z=readFileSync(join(root,'original.zip'));assert.equal(z.length,702105);assert.equal(z.length,artifact.size_in_bytes);assert.equal('sha256:'+sha(z),artifact.digest);proof.artifact=artifact;
 execFileSync('unzip',['-tqq',join(root,'original.zip')]);
 const names=execFileSync('unzip',['-Z1',join(root,'original.zip')],{encoding:'utf8'}).trim().split('\n');assert.equal(names.length,17);assert.equal(new Set(names).size,17);
 for(const name of names){assert.ok(!name.startsWith('/')&&!name.split('/').includes('..')&&!name.endsWith('/'));const b=execFileSync('unzip',['-p',join(root,'original.zip'),name],{maxBuffer:2*1024*1024});const out=join(root,'extracted',name);mkdirSync(dirname(out),{recursive:true});writeFileSync(out,b);proof.members.push({name,bytes:b.length,sha256:sha(b)});}
 const r=load('extracted/firefox/acceptance.json');assert.equal(r.sourceSha,source);assert.equal(r.testedSha,'6d739a6e643c45962004e6457d9f4aa41fc88ec0');assert.equal(r.attempt,'1');assert.equal(r.status,'failed');assert.equal(r.run,run.html_url);
 const stages=(name:string)=>r.stages.filter((s:any)=>s.name===name);const deletion=stages('storage-deletion');assert.equal(deletion.length,1);proof.deletion=deletion[0].deletion;
 assert.equal(proof.deletion.status,'failed');assert.equal(proof.deletion.timeoutMs,28000);assert.equal(proof.deletion.operations.length,7);assert.equal(proof.deletion.operations.filter((o:any)=>o.status==='failed').length,1);assert.match(proof.deletion.operations.at(-1).name,/^indexedDB.deleteDatabase:/);assert.match(proof.deletion.operations.at(-1).error,/deadline exceeded/);assert.ok(!proof.deletion.error.includes('Private database is still open'));
 assert.equal(stages('pending-restart-retained').length,4);assert.equal(stages('normal-reconnect-exact-content-once').length,2);assert.equal(stages('conflict-copy-preserves-original').length,2);assert.equal(stages('complete').length,0);assert.equal(stages('cleared-storage-is-not-advertised').length,0);assert.equal(stages('missing-data-cannot-open-offline').length,0);
 assert.equal(r.launches.length,3);const stops=stages('browser-stop');assert.equal(stops.length,3);for(let i=0;i<3;i++){assert.deepEqual(r.launches[i].profile,r.launches[0].profile);assert.equal(stops[i].browserPid,r.launches[i].browserPid);assert.equal(stops[i].browserExited,true);assert.equal(stops[i].driverExited,true);}
 assert.ok(!r.teardownError&&!r.fixtureTeardownError);proof.launches=r.launches;proof.stops=stops;proof.stageNames=r.stages.map((s:any)=>s.name);proof.error=r.error;proof.page=r.page;proof.runner=r.runner;proof.tested=r.testedSha;
 for(const path of ['scripts/ci/desktop-offline.ts','scripts/ci/desktop-storage.ts','scripts/ci/desktop-browser.ts','.github/workflows/desktop-offline.yml']){const b=execFileSync('git',['show',source+':'+path]);const old=execFileSync('git',['show','29b465b42f5616a1c3e18007cd9561b6a008e211:'+path]);assert.deepEqual(b,old);proof.sourceFiles.push({path,sha256:sha(b),unchangedFrom29:true});}
 proof.sourceTree=execFileSync('git',['rev-parse',source+'^{tree}'],{encoding:'utf8'}).trim();proof.complete=true;
}catch(e){proof.error=String(e);throw e;}finally{writeFileSync(join(root,'proof-a.json'),JSON.stringify(proof,null,2)+'\n');}
console.log(JSON.stringify({complete:proof.complete,members:proof.members.length,sourceTree:proof.sourceTree,stages:proof.stageNames.length,firstFailure:proof.deletion.operations.at(-1)}));
