import {readFile,writeFile,readdir,mkdtemp,rm} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
const repo='/Users/mxbaylee/projects/spinel-spn-090-production',tmp=await mkdtemp('/tmp/spn090-native-fe-index-'),dir='/tmp/spn090-native-fe';
const git=(args:string[],input?:Buffer|string)=>execFileSync('git',args,{cwd:repo,env:{...process.env,GIT_INDEX_FILE:tmp+'/index'},input,encoding:'utf8'}).trim();
const source=git(['rev-parse','HEAD']),prefix='docs/review-assets/spn-090-native-failure-fe1fddd8';
if(source!=='fe1fddd818cf66661c4e43c20dd856d87a685383')throw Error('unexpected source');
const manifest:any={source,disposition:'First Firefox desktop storage-loss deletion timeout. No rerun, causal proof or acceptance waiver.',payloads:[]};
try{
 git(['read-tree',source]);
 async function add(name:string,raw:Buffer){const stored=name.endsWith('.zip')?raw:gzipSync(raw),path=prefix+'/'+name+(name.endsWith('.zip')?'':'.gz'),blob=git(['hash-object','-w','--stdin'],stored);git(['update-index','--add','--cacheinfo','100644',blob,path]);manifest.payloads.push({path,rawBytes:raw.length,storedBytes:stored.length,rawSha256:createHash('sha256').update(raw).digest('hex'),storedSha256:createHash('sha256').update(stored).digest('hex')});}
 for(const e of await readdir(dir,{withFileTypes:true}))if(e.isFile()&&/\.(md|ts|json|log|zip)$/.test(e.name))await add(e.name,await readFile(dir+'/'+e.name));
 const blob=git(['hash-object','-w','--stdin'],JSON.stringify(manifest,null,2)+'\n');git(['update-index','--add','--cacheinfo','100644',blob,prefix+'/manifest.json']);
 const tree=git(['write-tree']),commit=git(['commit-tree',tree,'-p',source,'-m','docs(SPN-090): preserve current Firefox deletion failure']);
 const receipt={source,tree,commit,prefix,payloads:manifest.payloads.length};await writeFile('/tmp/spn090-native-fe-archive.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));
}finally{await rm(tmp,{recursive:true,force:true});}
