# 🧽 SPN-090 fe1fddd8 Firefox storage-loss failure — independent audit A

**Native acceptance is blocked.** [Run 42112723484, attempt 1](https://github.com/mxbaylee/spinel/actions/runs/42112723484), Firefox job **127544196608**, failed the private IndexedDB deletion deadline. Chrome/Safari jobs succeeded; their success does not replace this failed owner. No workload/provider rerun, code change or deadline waiver was performed or admitted.

## 🔗 Exact evidence and source

Source **`fe1fddd818cf66661c4e43c20dd856d87a685383`**, tested merge **`6d739a6e643c45962004e6457d9f4aa41fc88ec0`**, base **`2f442317dd2e1c188ae4a810ac094fd1162a4a2a`**. GitHub's saved `tested-commit.json` confirms those two parents and tree **`c7d0a88043e1a8faabb8cf6dd661e0ea5f45649f`**, equal to the reviewed source tree. The tested merge was not locally present; the raw GitHub commit response supplies that identity rather than inventing a local verification.

Original artifact **13455566513** is preserved as `original.zip`: **702,105 bytes**, SHA-256 **`9c5a995ae30d865add44c030bf1ed53e2bdadae2ffba66419e14fdde34028f5d`**. All **17 members** passed ZIP CRC, full sizes and individual SHA-256 inventory, with exact extracted bytes retained. `audit-a.ts`, `proof-a.json`, `audit-a.log` and `watchdog-a.json` preserve the first passing audit: **377 ms / 191,184 KiB**, normal pressure under serial/60s/2GiB guard. Raw run/jobs/artifact metadata and failed-job log are retained. This was archive/source inspection only.

Actual Firefox **159.0.1**, geckodriver **0.37.1**, macOS26 ARM64. The relevant desktop-offline/storage/browser/workflow files are byte-identical to their previously reviewed 29b465b4 versions; the new Sheet oracle and Chrome-only BrowserStack capabilities do not execute in this desktop deletion path. This is not evidence that those new changes caused the failure.

## ⏱️ What failed, and what completed

The report retains **33 stages**, three same-profile browser launches and three witnessed browser/driver exits. Four pending-edit restart cases, both exact normal reconnects and both conflict-copy outcomes completed before loss simulation. The final intended loss sequence was:

1. Script-free `/favicon.svg` verified (1ms).
2. One registration enumerated (2ms), then unregister returned true (31ms).
3. One current shell cache enumerated (1ms), then delete returned true (3ms).
4. Local storage clear returned zero (1ms).
5. One `indexedDB.deleteDatabase` request for the fixture account started **21:30:14.979Z**, then failed after **27,999ms** with **Storage deletion deadline exceeded** under the shared **28,000ms** budget.

The source rejects immediately on `onblocked` with **Private database is still open**. That error was **not** observed: the deadline won before a success/error/blocked callback settled the request. Subsequent worker/cache/database absence verification, online missing-copy advertisement check and offline refusal check were **not reached**. The deadline does not establish that the database remained present forever, nor that a blocked event could not occur after the retained report.

The error remains the deletion assertion. A secondary failure diagnostic tried `document.body.innerText` on an SVG document and got body-null; that explains missing textual page details without replacing the first failure. I opened the actual `failure-screen.png`: it shows the expected localhost favicon SVG in Firefox, not the Spinel editor. It does not prove controller or connection absence. Final browser/driver exits are positively recorded; no teardown/fixture-teardown error is reported. Fixture close is awaited by source but has no separate positive terminal journal.

## 🔬 Causal evidence and limits

**An open database connection is a plausible hypothesis, not a demonstrated cause.** Production account stores attach versionchange handlers that close their database, and the harness snapshot helper closes its own read connection in `finally`. This static inspection does not enumerate live connections or queued operations at failure.

The selected page has no scripts, but the code does not establish an uncontrolled fresh document, inventory every same-origin client, or stop/restart the browser between unregister and deletion. A successful unregister result alone does not prove worker termination: the specification resolves true before conditional registration clearing, which can wait for clients and pending events. That makes the worker/client lifetime boundary a concrete evidence gap. [Service Workers unregister and clearing algorithms](https://www.w3.org/TR/2026/CRD-service-workers-20261029/#unregister-algorithm).

IndexedDB deletion first waits behind prior requests, then dispatches versionchange/blocked handling and waits for connections to close. Thus a deadline with no blocked callback does not uniquely identify an open connection; queued work, callback delivery or implementation behavior remain possible. The retained driver logs add no database-specific causal witness. [IndexedDB deletion algorithm](https://www.w3.org/TR/IndexedDB-3/#delete-a-database).

## 🚦 Smallest justified next question and ownership

Preserve this exact failed outcome. **Existing open SPN-141 already owns observable producer quiescence, targeted deletion, denial/blocking/timeout and both post-loss assertions.** Its historical failure was cache recreation after successful deletion; this new failure is a different first boundary in the same owned loss-preparation contract. Do not call them the same proven cause, invent a new owner, or silently import an unmerged repair. Current scope remains SPN-146/SPN-090; this review does not authorize resuming another ticket.

The lowest useful next step is static reconciliation with that already-maintained quiescence boundary and a bounded deterministic deletion/lifecycle control: distinguish a never-settling request from explicit blocked/error, preserve the first event/deadline, prove all intended clients relinquish control, and require exact one deletion plus strict absence afterward. Any new native diagnosis needs a separately prospective fixed-source plan that records controller/registration/client and request-event state without reading user contents, extending budgets, adding sleeps, clearing repeatedly or restarting only after a failure to manufacture success. Existing retained evidence alone cannot identify the owner of an open connection, so it does not admit an unchanged native retry.

No physical-phone conclusion follows from this desktop failure, and no original phone acceptance requirement is removed. SPN-090 remains unmerged and this selected native owner remains failed.
