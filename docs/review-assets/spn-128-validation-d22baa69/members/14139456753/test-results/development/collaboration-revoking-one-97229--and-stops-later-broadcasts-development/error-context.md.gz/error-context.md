# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: collaboration.spec.ts >> revoking one login preserves another login’s queued edit and stops later broadcasts
- Location: e2e/collaboration.spec.ts:365:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=f1e4]:
  - banner [ref=f1e5]:
    - button "Spinel home" [ref=f1e6] [cursor=pointer]:
      - img "Spinel" [ref=f1e8]
      - generic [ref=f1e33]: spinel
    - radiogroup "Appearance" [ref=f1e36]:
      - radio "Follow system" [checked] [ref=f1e37] [cursor=pointer]
      - radio [checked] [aria-hidden] [ref=f1e40]
      - radio "Light" [ref=f1e41] [cursor=pointer]
      - radio [aria-hidden] [ref=f1e44]
      - radio "Dark" [ref=f1e45] [cursor=pointer]
      - radio [aria-hidden] [ref=f1e48]
  - main [ref=f1e49]:
    - region [ref=f1e50]:
      - paragraph [ref=f1e51]: PRIVATE BY INVITATION
      - heading "Your workspace." [level=1] [ref=f1e52]
      - paragraph [ref=f1e53]: Sheets and Docs, together in a private place.
      - generic [ref=f1e54]:
        - paragraph [ref=f1e55]: Use a passkey from your browser, password manager or phone.
        - button "Sign in with a passkey" [ref=f1e56] [cursor=pointer]
      - button "Need help?" [ref=f1e60] [cursor=pointer]
  - contentinfo [ref=f1e61]: Have a shared link? Open it directly to view the document.
```

# Test source

```ts
  362 |   }
  363 | });
  364 | 
  365 | test('revoking one login preserves another login’s queued edit and stops later broadcasts', async ({
  366 |   page,
  367 |   context,
  368 |   browser,
  369 |   baseURL,
  370 | }, info) => {
  371 |   test.setTimeout(60_000);
  372 |   const db = openDatabase(
  373 |     info.project.name === 'development'
  374 |       ? 'test-results/development/app.sqlite'
  375 |       : 'test-results/production/app.sqlite',
  376 |   );
  377 |   const auth = new AuthStore(db),
  378 |     workspace = new WorkspaceStore(auth);
  379 |   let ownerId: string | undefined, itemId: string | undefined;
  380 |   let second: BrowserContext | undefined;
  381 |   let network: Awaited<ReturnType<typeof syncNetwork>> | undefined;
  382 |   let observation: Awaited<ReturnType<typeof observeSessionRevocation>> | undefined;
  383 |   let primaryFailed = false,
  384 |     contractCompleted = false;
  385 |   let cleanupFailures: string[] = [],
  386 |     attachmentFailures: string[] = [];
  387 |   let release!: () => void;
  388 |   const pending = new Promise<void>((resolve) => {
  389 |     release = resolve;
  390 |   });
  391 |   let held = false,
  392 |     forwarded = false,
  393 |     otherClosed = 0;
  394 |   try {
  395 |     const owner = auth.createUser('Two logins');
  396 |     ownerId = owner.id;
  397 |     const item = workspace.create(owner.id, {
  398 |       name: 'Private after revoke',
  399 |       kind: 'sheet',
  400 |       parentId: null,
  401 |     });
  402 |     itemId = item.id;
  403 |     const sessions = [auth.createSession(owner.id), auth.createSession(owner.id)];
  404 |     second = await browser.newContext({ viewport: { width: 1440, height: 1100 } });
  405 |     network = await syncNetwork(second);
  406 |     const other = await second.newPage();
  407 |     const socketURL = new URL(`/sync-api/items/${item.id}/socket`, baseURL);
  408 |     socketURL.protocol = socketURL.protocol === 'https:' ? 'wss:' : 'ws:';
  409 |     observation = await observeSessionRevocation(page, socketURL.href);
  410 |     other.on('websocket', (socket) => {
  411 |       if (new URL(socket.url()).pathname !== socketURL.pathname) return;
  412 |       socket.on('close', () => {
  413 |         otherClosed++;
  414 |       });
  415 |     });
  416 |     await second.grantPermissions(['clipboard-read', 'clipboard-write']);
  417 |     for (const [index, c] of [context, second].entries())
  418 |       await c.addCookies([
  419 |         {
  420 |           name: COOKIE_NAME,
  421 |           value: sessions[index].token,
  422 |           url: baseURL!.replace('http:', 'https:'),
  423 |           secure: true,
  424 |           httpOnly: true,
  425 |           sameSite: 'Strict',
  426 |         },
  427 |       ]);
  428 |     await page.goto(`/?item=${item.id}`);
  429 |     await other.goto(`${baseURL}/?item=${item.id}`);
  430 |     for (const target of [page, other]) {
  431 |       await expect(target.getByRole('status', { name: 'Save status' })).toHaveText(
  432 |         'All changes saved.',
  433 |         { timeout: 30_000 },
  434 |       );
  435 |       // Saved content does not prove that this login has joined the room.
  436 |       await expect(
  437 |         target.getByRole('status', { name: 'Connection status', exact: true }),
  438 |       ).toHaveText('Online');
  439 |     }
  440 |     await expect.poll(() => observation!.snapshot().openSockets).toBeGreaterThan(0);
  441 |     network.interceptWrites(async (write) => {
  442 |       held = true;
  443 |       await pending;
  444 |       forwarded = write.forward();
  445 |     });
  446 |     const box = other
  447 |       .getByRole('region', { name: 'Sheet document', exact: true })
  448 |       .getByRole('textbox')
  449 |       .nth(2);
  450 |     await box.fill('A1');
  451 |     await box.press('Enter');
  452 |     await other.keyboard.type('private-after-revoke');
  453 |     await other.keyboard.press('Enter');
  454 |     await expect.poll(() => held).toBe(true);
  455 |     observation.checkpoint('edit-held');
  456 |     const otherClosedBefore = otherClosed;
  457 |     observation.beforeRevoke();
  458 |     auth.revokeSession(sessions[0].session.token_hash);
  459 |     observation.checkpoint('revocation-written');
  460 |     // The same five-second deadline still requires a real protocol close for
  461 |     // every socket established before revocation, even if navigation wins.
> 462 |     await expect.poll(() => observation!.isClosed(), { timeout: 5000 }).toBe(true);
      |                                                                         ^ Error: expect(received).toBe(expected) // Object.is equality
  463 |     observation.checkpoint('closure-observed');
  464 |     expect(otherClosed).toBe(otherClosedBefore);
  465 |     // The revoked login has no unfinished work, so SPN-053's clean 401 handoff
  466 |     // closes its editor. The other login's independently queued edit must survive.
  467 |     await expect(page).toHaveURL(/\/sign-in(?:\?|$)/);
  468 |     await expect(
  469 |       page.getByRole('button', { name: 'Sign in with a passkey', exact: true }),
  470 |     ).toBeVisible();
  471 |     await expect(page.locator('.univer-container canvas')).toHaveCount(0);
  472 |     observation.checkpoint('sign-in');
  473 |     const denied = await context.request.get(`${baseURL}/api/items/${item.id}/sheet`);
  474 |     observation.assertRevoked(denied.status());
  475 |     observation.checkpoint('request-denied');
  476 |     const boundary = observation.frameCount();
  477 |     release();
  478 |     observation.checkpoint('edit-released');
  479 |     await expect(other.getByRole('status', { name: 'Save status' })).toHaveText(
  480 |       'All changes saved.',
  481 |       { timeout: 30_000 },
  482 |     );
  483 |     expect(forwarded).toBe(true);
  484 |     expect(otherClosed).toBe(otherClosedBefore);
  485 |     const savedResponse = await second.request.get(`${baseURL}/api/items/${item.id}/sheet`);
  486 |     expect(savedResponse.status()).toBe(200);
  487 |     const saved = (await savedResponse.json()).snapshot;
  488 |     expect(saved.sheets[saved.sheetOrder[0]].cellData[0][0].v).toBe('private-after-revoke');
  489 |     observation.checkpoint('saved');
  490 |     // No frame may reach the revoked socket after closure. Do not retain private
  491 |     // frame content just to search for one fixture string.
  492 |     expect(observation.frameCount()).toBe(boundary);
  493 |     await expect(other.getByRole('button', { name: 'Bold', exact: true })).toBeEnabled();
  494 |     await expect(page).toHaveURL(/\/sign-in$/);
  495 |     await expect(page.getByRole('heading', { name: 'Your workspace.', exact: true })).toBeVisible();
  496 |     expect(otherClosed).toBe(otherClosedBefore);
  497 |     await other.reload();
  498 |     await expect(other.getByRole('status', { name: 'Save status' })).toHaveText(
  499 |       'All changes saved.',
  500 |       { timeout: 30_000 },
  501 |     );
  502 |     await expectNativeSheetValue(other, 'A1', 'private-after-revoke');
  503 |     observation.checkpoint('reloaded');
  504 |     expect(observation.frameCount()).toBe(boundary);
  505 |     observation.assertRevoked(
  506 |       (await context.request.get(`${baseURL}/api/items/${item.id}/sheet`)).status(),
  507 |     );
  508 |     expect(observation.frameCount()).toBe(boundary);
  509 |     contractCompleted = true;
  510 |   } catch (error) {
  511 |     primaryFailed = true;
  512 |     throw error;
  513 |   } finally {
  514 |     release();
  515 |     network?.interceptWrites(undefined);
  516 |     cleanupFailures = await cleanupSessionRevocation([
  517 |       { name: 'writes', run: () => network?.drainWrites() },
  518 |       { name: 'observer', run: () => observation?.stop() },
  519 |       { name: 'context', run: () => second?.close() },
  520 |       {
  521 |         name: 'database',
  522 |         run: () => {
  523 |           try {
  524 |             if (itemId) db.prepare('DELETE FROM workspace_items WHERE id=?').run(itemId);
  525 |           } finally {
  526 |             try {
  527 |               if (ownerId) db.prepare('DELETE FROM auth_users WHERE id=?').run(ownerId);
  528 |             } finally {
  529 |               db.close();
  530 |             }
  531 |           }
  532 |         },
  533 |       },
  534 |     ]);
  535 |     attachmentFailures = await cleanupSessionRevocation([
  536 |       {
  537 |         name: 'diagnostics',
  538 |         run: () =>
  539 |           info.attach('session-revocation-observation', {
  540 |             contentType: 'application/json',
  541 |             body: Buffer.from(
  542 |               JSON.stringify(
  543 |                 {
  544 |                   version: 1,
  545 |                   project: info.project.name,
  546 |                   retry: info.retry,
  547 |                   tested: process.env.GITHUB_SHA ?? null,
  548 |                   node: process.version,
  549 |                   browser: browser.version(),
  550 |                   contractCompleted,
  551 |                   primaryFailed,
  552 |                   cleanupFailures,
  553 |                   observation: observation?.snapshot() ?? null,
  554 |                 },
  555 |                 null,
  556 |                 2,
  557 |               ),
  558 |             ),
  559 |           }),
  560 |       },
  561 |     ]);
  562 |   }
```