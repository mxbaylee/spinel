# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: collaboration.spec.ts >> two document editors merge text and navigate to a collaborator selection
- Location: e2e/collaboration.spec.ts:200:1

# Error details

```
Error: First peer observed after 767 ms; both peers after 1071 ms

expect(received).toBeLessThan(expected)

Expected: < 1000
Received:   1071
```

# Test source

```ts
  225 |     httpOnly: true,
  226 |     sameSite: 'Strict' as const,
  227 |   });
  228 |   await context.grantPermissions(['clipboard-read', 'clipboard-write']);
  229 |   await second.grantPermissions(['clipboard-read', 'clipboard-write']);
  230 |   await context.addCookies([cookie(owner.id)]);
  231 |   await second.addCookies([cookie(editor.id)]);
  232 |   await page.setViewportSize({ width: 1440, height: 1100 });
  233 |   const read = async () =>
  234 |     (await (await context.request.get(`/api/items/${item.id}/doc`)).json()).snapshot.body
  235 |       .dataStream as string;
  236 |   const saved = (target: typeof page) =>
  237 |     expect(target.getByRole('status', { name: 'Save status' })).toHaveText('All changes saved.', {
  238 |       timeout: 30_000,
  239 |     });
  240 |   const focus = (target: typeof page) =>
  241 |     target.locator('.univer-container').click({ position: { x: 130, y: 200 } });
  242 |   const errors: string[] = [];
  243 |   for (const target of [page, other]) target.on('pageerror', (error) => errors.push(error.message));
  244 |   try {
  245 |     await page.goto(`/?item=${item.id}`);
  246 |     await saved(page);
  247 |     await focus(page);
  248 |     await page.keyboard.type('Shared anchor');
  249 |     await saved(page);
  250 |     // This separate API reconstructs a native snapshot on its first read. Its
  251 |     // cold materializer is not the peer-to-peer UI latency measured below.
  252 |     await expect.poll(read, { timeout: 30_000 }).toBe('Shared anchor\r\n');
  253 |     await other.goto(`${baseURL}/?item=${item.id}`);
  254 |     await saved(other);
  255 |     await focus(page);
  256 |     await page.keyboard.press('Home');
  257 |     await focus(other);
  258 |     await other.keyboard.press('End');
  259 |     await page.getByRole('button', { name: 'People in this document', exact: true }).click();
  260 |     await expect(
  261 |       page
  262 |         .getByRole('dialog', { name: 'People in this document', exact: true })
  263 |         .getByRole('button', { name: 'Go to Doc collaborator', exact: true }),
  264 |     ).toHaveAttribute('data-selection', '13:13:1:TEXT::-1');
  265 |     await page
  266 |       .getByRole('dialog', { name: 'People in this document', exact: true })
  267 |       .getByRole('button', { name: 'Close dialog', exact: true })
  268 |       .click();
  269 |     await other.getByRole('button', { name: 'People in this document', exact: true }).click();
  270 |     await expect(
  271 |       other
  272 |         .getByRole('dialog', { name: 'People in this document', exact: true })
  273 |         .getByRole('button', { name: 'Go to Doc owner', exact: true }),
  274 |     ).toHaveAttribute('data-selection', '0:0:1:TEXT::-1');
  275 |     await other
  276 |       .getByRole('dialog', { name: 'People in this document', exact: true })
  277 |       .getByRole('button', { name: 'Close dialog', exact: true })
  278 |       .click();
  279 |     // Refocus native inputs without moving the established start/end selections.
  280 |     for (const target of [page, other]) {
  281 |       await expect(
  282 |         target.getByRole('dialog', { name: 'People in this document', exact: true }),
  283 |       ).toHaveCount(0);
  284 |       const input = target.locator('[contenteditable="true"][data-u-comp="editor"]');
  285 |       await input.focus();
  286 |       await expect(input).toBeFocused();
  287 |     }
  288 |     await Promise.all([page.keyboard.type('Owner'), other.keyboard.type(' Collaborato')]);
  289 |     // Measure the final explicit insertion from before dispatch, while still
  290 |     // checking the complete simultaneous text burst in both live editors.
  291 |     const sentAt = Date.now();
  292 |     await Promise.all([page.keyboard.type(' '), other.keyboard.type('r')]);
  293 |     const copyText = async (target: typeof page) => {
  294 |       await target.bringToFront();
  295 |       const input = target.locator('[contenteditable="true"][data-u-comp="editor"]');
  296 |       await input.focus();
  297 |       await expect(input).toBeFocused();
  298 |       await target.keyboard.press('Control+a');
  299 |       // Each editor must complete its own copy, not read the other peer's text.
  300 |       const sentinel = `not-copied-${crypto.randomUUID()}`;
  301 |       await target.evaluate((value) => navigator.clipboard.writeText(value), sentinel);
  302 |       // Desktop Chrome fixture advertises Windows, even on a macOS test host.
  303 |       await target.keyboard.press('Control+c');
  304 |       await expect
  305 |         .poll(() => target.evaluate(() => navigator.clipboard.readText()), {
  306 |           timeout: 5000,
  307 |           intervals: [10],
  308 |         })
  309 |         .not.toBe(sentinel);
  310 |       return (await target.evaluate(() => navigator.clipboard.readText())).trim();
  311 |     };
  312 |     // Shared clipboard copies stay sequential. Focus and both fresh UI
  313 |     // observations remain inside the original strict one-second budget.
  314 |     await expect
  315 |       .poll(() => copyText(page), { timeout: 5000, intervals: [50] })
  316 |       .toBe('Owner Shared anchor Collaborator');
  317 |     const firstObserved = Date.now() - sentAt;
  318 |     await expect
  319 |       .poll(() => copyText(other), { timeout: 5000, intervals: [50] })
  320 |       .toBe('Owner Shared anchor Collaborator');
  321 |     const total = Date.now() - sentAt;
  322 |     expect(
  323 |       total,
  324 |       `First peer observed after ${firstObserved} ms; both peers after ${total} ms`,
> 325 |     ).toBeLessThan(1000);
      |       ^ Error: First peer observed after 767 ms; both peers after 1071 ms
  326 |     await other.keyboard.press('ArrowRight');
  327 |     await saved(page);
  328 |     await saved(other);
  329 |     await expect.poll(read).toBe('Owner Shared anchor Collaborator\r\n');
  330 |     await other.keyboard.press('Shift+ArrowLeft');
  331 |     await other.keyboard.press('Shift+ArrowLeft');
  332 |     await page.getByRole('button', { name: 'People in this document', exact: true }).click();
  333 |     const jump = page
  334 |       .getByRole('dialog', { name: 'People in this document', exact: true })
  335 |       .getByRole('button', { name: 'Go to Doc collaborator', exact: true });
  336 |     await expect(jump).toBeVisible();
  337 |     await expect(jump).toHaveAttribute(
  338 |       'data-selection',
  339 |       `${'Owner Shared anchor Collaborator'.length - 2}:${'Owner Shared anchor Collaborator'.length}:1:TEXT::-1`,
  340 |     );
  341 |     await jump.click();
  342 |     await expect(
  343 |       page.getByRole('dialog', { name: 'People in this document', exact: true }),
  344 |     ).toHaveCount(0);
  345 |     await expect(page.locator('[contenteditable="true"][data-u-comp="editor"]')).toBeFocused();
  346 |     // Replacing the selected remote range proves the cursor jump used this live document.
  347 |     await page.keyboard.type('XX');
  348 |     await saved(page);
  349 |     await expect.poll(read).toBe('Owner Shared anchor CollaboratXX\r\n');
  350 |     await other.reload();
  351 |     await saved(other);
  352 |     expect(errors).toEqual([]);
  353 |   } finally {
  354 |     await second.close();
  355 |     db.prepare('DELETE FROM workspace_items WHERE id=?').run(item.id);
  356 |     for (const user of [owner, editor])
  357 |       db.prepare('DELETE FROM auth_users WHERE id=?').run(user.id);
  358 |     db.close();
  359 |   }
  360 | });
  361 | 
  362 | test('revoking one login preserves another login’s queued edit and stops later broadcasts', async ({
  363 |   page,
  364 |   context,
  365 |   browser,
  366 |   baseURL,
  367 | }, info) => {
  368 |   test.setTimeout(60_000);
  369 |   const db = openDatabase(
  370 |     info.project.name === 'development'
  371 |       ? 'test-results/development/app.sqlite'
  372 |       : 'test-results/production/app.sqlite',
  373 |   );
  374 |   const auth = new AuthStore(db),
  375 |     workspace = new WorkspaceStore(auth),
  376 |     owner = auth.createUser('Two logins');
  377 |   const item = workspace.create(owner.id, {
  378 |     name: 'Private after revoke',
  379 |     kind: 'sheet',
  380 |     parentId: null,
  381 |   });
  382 |   const sessions = [auth.createSession(owner.id), auth.createSession(owner.id)];
  383 |   const second = await browser.newContext({ viewport: { width: 1440, height: 1100 } });
  384 |   const network = await syncNetwork(second);
  385 |   const other = await second.newPage();
  386 |   let release!: () => void;
  387 |   const pending = new Promise<void>((resolve) => {
  388 |     release = resolve;
  389 |   });
  390 |   let held = false,
  391 |     revokedClosed = 0,
  392 |     otherClosed = 0;
  393 |   const revokedMessages: string[] = [];
  394 |   page.on('websocket', (socket) => {
  395 |     socket.on('framereceived', (frame) => revokedMessages.push(String(frame.payload)));
  396 |     socket.on('close', () => {
  397 |       revokedClosed++;
  398 |     });
  399 |   });
  400 |   other.on('websocket', (socket) =>
  401 |     socket.on('close', () => {
  402 |       otherClosed++;
  403 |     }),
  404 |   );
  405 |   for (const [index, c] of [context, second].entries())
  406 |     await c.addCookies([
  407 |       {
  408 |         name: COOKIE_NAME,
  409 |         value: sessions[index].token,
  410 |         url: baseURL!.replace('http:', 'https:'),
  411 |         secure: true,
  412 |         httpOnly: true,
  413 |         sameSite: 'Strict',
  414 |       },
  415 |     ]);
  416 |   try {
  417 |     await page.goto(`/?item=${item.id}`);
  418 |     await other.goto(`${baseURL}/?item=${item.id}`);
  419 |     for (const target of [page, other]) {
  420 |       await expect(target.getByRole('status', { name: 'Save status' })).toHaveText(
  421 |         'All changes saved.',
  422 |         { timeout: 30_000 },
  423 |       );
  424 |       // Saved content does not prove that this login has joined the room.
  425 |       await expect(
```