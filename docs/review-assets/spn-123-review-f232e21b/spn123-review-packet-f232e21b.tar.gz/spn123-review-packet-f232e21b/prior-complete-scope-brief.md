# 📊 SPN-123 complete integrated-candidate re-review

**Exact candidate:** `7fd2b0a655513e628ab682174ae231e6a99b2874`.
**Actual base:** `c1d0d6e8ded33c10cf555ed2ed05ffd9ebc3a423`.
**Worktree:** `/Users/mxbaylee/projects/spinel-spn-123-production`, clean.
Continue the SAME independent full-ticket review. Do not consult the other
reviewer, original scored reports or old PR bodies. Prior technical findings and
verification remain in assessment-free `prior-reviews/` copies; their original
bytes remain separately preserved. No desired grade is supplied here.

## 🔗 Complete outcome and actual-main integration

Read `base-ticket.md`, the complete `candidate.diff`, source copies, canonical
SPN-123 record and `docs/diagnostics.md` emitter inventory, all four personas and
the inherited full-scope brief. Full **L** remains: production open, distinct local
durability and validated server ACK, search/restore, connection/resync/refresh/
pending queues, offline publication/recovery, native flush/checkpoint/persistence,
maintenance and bounded CPU/event-loop context; exact units/outcomes/attribution,
privacy/admission, disabled/throwing/saturated observers and native/operational
acceptance. No narrower final patch substitutes for that outcome.

Merge `d51f6375411207b52f80f0072d520b725a150219` has parents prior local
`c270973a522822876ca615cca1ef24f2cd9555e4` and actual SPN-090 squash `c1d0d6e8`.
Current head adds only documentation and evidence. All1,257 recorded non-doc
TS/TSX/JSON/workflow inputs match tested d51 exactly. The source-only integration
audit verifies505 nonoverlap parent paths unchanged; only backlog/index and
three executable paths overlap:

- `src/ui/spinelSync.test.ts` had adjacent conflicting insertions. Complete
  original18,522-byte diagnostic blocks and main1,671-byte native snapshot tests
  both remain, with required imports/mocks and both cleanup hooks. Neither set
  was shortened or its assertions relaxed.
- `web/App.tsx` retains the diagnostic connection policy alongside main's real
  browser-offline/startup admission and completion. Private collection still
  requires an admitted online account; guest/offline paths acquire no authority.
- `web/spinelSync.ts` retains diagnostic account/session lifetimes and actual
  receipt/connection outcomes alongside main's evidence-build-only scoped
  native-snapshot request and listener cleanup. The detached test-evidence value
  is not a production diagnostic or a writable native model. Production emitter
  endpoints, units and bounds are unchanged; the maintained inventory still fits.

Main's application-delivery/service-worker routing, real invitation POST/readback
readiness, raster input, renderer/install resources and BrowserStack retirement
remain exact. The restored `writeFile` feedback import and full paired-export
fixture are unchanged. All production receipt chronology/once-only/authority,
feedback staging/generation, native history and bounded sample safeguards remain.
No new visible design, package, SDK patch, queue, service or recovery authority.

Operator receives honest bounded diagnostics. Owner/Collaborator retain content,
unfinished input and separately named persistence/ACK boundaries. Link guest
remains excluded from collection and private offline/account authority. Complete
scope stays L;19,373 counted lines retain the explicit soft-limit disposition.
Bookkeeping removes only123 relative to actual base and records[098,090,123],
next161, November14 grooming, CLI-generated24 open tickets.

## 🧪 New local evidence and first check correction

The sole local slot, pinned Node26.13.0, shared serial runner and existing normal
pressure/2GiB/eight-minute guard were used. No build/browser/fullSDK/native-platform
matrix was repeated. All checks below passed first execution on committed d51:

- 167/167 existing controls across six files:4,251ms/940,304KiB. Sync-wrapper
  native-snapshot scope/disposal; diagnostic account/browser/operation/local
  persistence; refused ACK real native cases and observer failure controls.
- Full TypeScript:9,581ms/1,681,200KiB, compiler Go640MiB/GOGC50/GOMAXPROCS2.
- Targeted lint:124ms, shorter than200ms RSS sampling (not zero memory).
- Actual changed-route native/collector off-on sample:1,202ms/337,936KiB. All50
  source/SDK hashes current; all14 off/on/saturated native outcomes identical,
  with complete content/resources/history/saved peers/once-only receipts/revocation.
  The independent pressure case reconciles500=64admitted+244queue+192transport;
  second batch genuinely returns429. Off/on medians0.666785/0.713622ms per save,
  +0.046837ms difference; ranges overlap. Exact raw measurements, exclusions and
  hash bindings are retained. This is not browser/network/SQLite/IDB/feedback
  latency or a causal old/new benchmark. Prior sample was49/50 current hashes:
  diagnostics route had changed with actual098 feedback; it stays historical.
- Index147ms and formatting484ms preceded commit. Actual d51 policy778ms/274,176KiB;
  final7fd policy749ms/274,592KiB checks CLI backlog/PR, all15 selected suites,
  16 source/dependency cases and60 missing/skipped/failed/cancelled rejections.
  Local plan proof is not actual hosted selection or a CI result.

The first precommit `git diff --check --cached` compared incoming merge content
against old c270 and flagged14 existing whitespace lines in090 raw failure
contexts. Original main bytes were preserved. The corrected actual-base check
against c1d passes; no new warning was suppressed and no runtime was rerun.
Original diagnostic collection warnings are retained in logs. Cleanup recorded
normal pressure, no owned processes and absent shared lock. Final evidence-only
format272ms/200,032KiB changed no source bytes.

## 🧾 Original failures and remaining gates

Original6ef CI43633378605 attempt1 remains failed: TS2304 missingwriteFile,
development1 and production1 ReferenceErrors on each configured retry0/1/2,
and fail-closed Playwright aggregate. Its29 successful CI workers do not waive
four failed jobs or42 development cases left unrun after maxFailures. Original
Storybook43633378587, Desktop43633378724 and Spaces43633378630 passed. Across
47jobs:41success,4failure,2inapplicable Story deployment skips. The complete
terminal source/plan/log/artifact record is separately published under archive
`7d4c215d1075d3aa640a029366bddea58f7627ca`; no rerun/cancellation converted it.

Earlier refused-ACK false success and seven native regression/three withheld-
guard negatives remain unchanged. Earlier mobile maxima110.4/104.2/117.4ms,
JXA/Firefox/storage/history/reset, callback baseline and resource failures keep
their original source and unknown causes. Current local results do not relabel
them. The failed pre-098 ACK compiler, original6ef compiler failure and local
c270/newd51 type passes are separate outcomes.

All fresh current-head hosted gates, actual native Chrome/Firefox/Safari,
production diagnostics/export, responsiveness/callback, browser/Storybook/Spaces,
Linux maintenance/operational and sized-restore acceptance remain pending.
Reviewers never deduct for CI RESULTS; judge delivered source/tests/workflow,
run relevant feasible local checks only after root grants the slot, and list
every actionable step to100 with locations, fixes, deductions and environment.
Independent review remains read-only. No source push, metadata edit, CI dispatch,
merge or cleanup is authorized by this packet.
