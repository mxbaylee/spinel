---
id: SPN-123
emoji: 📊
effort: L
impact_operator: M
impact_owner: S
impact_collaborator: S
impact_guest: S
score: 22
depends_on: []
decisions: []
---

# 📊 SPN-123 Complete operation and sync diagnostic coverage

## Story

As the [Operator](../product/personas.md#operator), I want diagnostic observations to explain slow operations and recovery, so that I can investigate a report using the existing downloads.

## Scenarios

### Explain an operation and its surrounding system state

Given an everyday operation, sync recovery or maintenance transition,
When it succeeds, fails or is cancelled,
Then the registered observations describe its bounded timing, outcome and relevant queue or phase state,
And a broken, disabled or overloaded observer cannot change document contents, access, saving or edit delivery.

## Rules

- Follow [sustainable testing](../testing.md); keep the Verify plan and progress evidence current. [Policy](../implementation/SPN-115.md#guidance-for-every-open-ticket-and-progress-checkpoint), owner 2026-11-01.

- Effort L, full-scope review 2026-10-29: The fixed operation/sync/flush/checkpoint/maintenance/runtime inventory must have bounded cardinality, privacy and measured overhead. Extend existing sinks; a new tracing, analytics-storage or profiling service requires an explicit scope decision. [All-ticket assessment](../implementation/grooming-2026-10-29.md#all-ticket-effort-and-impact-review).

- Implement the [approved coverage and boundaries](../implementation/SPN-123.md), owner approval and delegated grooming judgment, 2026-10-29. Reuse the existing registry, collectors, store and exports; SPN-098 owns feedback/download UI and SPN-110 owns retention.
- Wire open-to-ready, save-to-durable-acknowledgment, search and snapshot-restore duration/outcome. Name local durable persistence and server acknowledgment separately; an offline save cannot claim a server acknowledgment.
- Record reconnect/resync reason and duration, pending count/oldest age and offline publication/recovery outcomes; preserve attribution and distinguish browser claims from server observations.
- Extend existing native flush duration with reason/group sizes and failure outcome; count checkpoint captures/skips and persistence outcomes. Preserve exceptions and the measured operation's behavior.
- Observe maintenance phases/drain/verification outcomes and bounded CPU/event-loop context. Keep all clocks, units, sampling and timing boundaries explicit; these observations cannot prove causes of old unprofiled pauses.
- Keep registered content-free fields, fixed reason codes, opaque authorized context, account/session binding, guest collection exclusion, collection bounds and visible drop accounting. Deliberately review browser event admission; never permit arbitrary server events or metadata from a client.
- Inventory each promised emitter and its regression. At kickoff verify these existing seams; a required new durable queue, cross-process trace protocol, SDK patch or analytics service triggers an explicit scope/estimate reassessment before building it.

## Out of scope

- New dashboards/services, general HTTP tracing, raw document/input capture, full production CPU tracing, new SDK algorithms, feedback UX, retention policy and CI routing.

## Verify

- Extend existing diagnostics fixtures and native observation helpers; use controlled clocks for schema/timing boundaries and injected disabled/throwing/overloaded observers. Isolate accounts/sinks and verify one logical outcome without double-counting retries; cleanup must not swallow the original operation failure.
- Focused/integration tests own units, admission and attribution; native runs own unchanged content/history/access and measured observer overhead. Track emitter, registry/store, sync/maintenance and harness dependencies in routing, and retain off/on source-identical samples separately from diagnostic profiles.

- Inject known success/failure/delay, reconnect, offline and maintenance conditions and verify exact timing boundaries, units, attribution and one defined outcome per logical operation. Prove counters do not double-count transport retries.
- Verify browser allowlists and cross-account/guest rejection, disabled/throwing observers, collection pressure, drops and export schema compatibility. Compare bounded overhead with collection off/on; retain identical native content, history, access and saved/peer assertions.
