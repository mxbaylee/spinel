import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
const scripts = JSON.parse(readFileSync('package.json', 'utf8')).scripts;
const checks = [
  ['scripts/dependencies/no-univer-pro.ts'],
  ['node_modules/oxlint/bin/oxlint', '--deny-warnings', '.'],
  ['node_modules/prettier/bin/prettier.cjs', ...scripts['format:check'].split(' ').slice(1)],
];
for (const args of checks) {
  console.log(JSON.stringify({ command: process.execPath, args }));
  execFileSync(process.execPath, args, { stdio: 'inherit' });
}
