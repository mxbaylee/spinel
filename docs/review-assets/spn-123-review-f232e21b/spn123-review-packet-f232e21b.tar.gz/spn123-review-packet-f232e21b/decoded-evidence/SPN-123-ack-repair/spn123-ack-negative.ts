import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const path = 'lib/sync-client/src/client.ts';
const repaired = readFileSync(path);
const original = execFileSync('git', ['show', 'cae5a58689b049e4f62c3a815482e21bb5212f49:' + path]);
const hash = (bytes: Uint8Array) => createHash('sha256').update(bytes).digest('hex');
const prefix = '/tmp/spinel-dependabot-2026-11-11/spn123-ack-negative';
let status: number | null = null;
try {
  writeFileSync(path, original);
  try {
    execFileSync(process.execPath, ['/tmp/spinel-dependabot-2026-11-11/watch.ts', 'spn123-ack-negative', process.execPath,
      'node_modules/vitest/vitest.mjs', 'run', 'lib/sync-client/tests/diagnostics.test.ts', '-t', 'a refused client cannot report success',
      '--config', '/tmp/spinel-dependabot-2026-11-11/spn123-vitest.config.ts', '--configLoader', 'native', '--cache=false'], { stdio: 'pipe' });
    status = 0;
  } catch (error) {
    const result = error as { status: number | null; stdout: Buffer; stderr: Buffer };
    status = result.status;
    writeFileSync(prefix + '.log', Buffer.concat([result.stdout, result.stderr]));
  }
} finally {
  writeFileSync(path, repaired);
  writeFileSync(prefix + '-identity.json', JSON.stringify({ sourceParent: 'cae5a58689b049e4f62c3a815482e21bb5212f49', originalSource: hash(original), repairedSource: hash(repaired), testSource: hash(readFileSync('lib/sync-client/tests/diagnostics.test.ts')), restoredSource: hash(readFileSync(path)), status }, null, 2) + '\n');
}
if (status !== 1) throw new Error('Withheld guard did not fail the regressions as expected');
