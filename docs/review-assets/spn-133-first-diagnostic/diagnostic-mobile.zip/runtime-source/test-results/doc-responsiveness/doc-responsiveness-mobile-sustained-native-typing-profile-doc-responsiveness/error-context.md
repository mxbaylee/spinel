# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: doc-responsiveness.spec.ts >> mobile sustained native typing profile
- Location: e2e/doc-responsiveness.spec.ts:316:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  510 |                         highWater: snapshot.highWater,
  511 |                         history: snapshot.history,
  512 |                       }
  513 |                     : null,
  514 |                 };
  515 |                 drainDiagnostics.polls.push(poll);
  516 |                 if (
  517 |                   !drainDiagnostics.firstEmpty &&
  518 |                   snapshot?.pending.history === 0 &&
  519 |                   snapshot.pending.collaboration === 0
  520 |                 )
  521 |                   drainDiagnostics.firstEmpty = poll;
  522 |               }
  523 |             },
  524 |             {
  525 |               // A 4×-throttled observation of the existing 14.857 s pair may
  526 |               // exceed 30 s. Only baseline collection has this wider window;
  527 |               // candidate acceptance remains the separate <=1,000 ms drain gate.
  528 |               timeout: baseline ? 120_000 : 30_000,
  529 |               intervals: [25],
  530 |             },
  531 |           )
  532 |           .toEqual({ history: 0, collaboration: 0 });
  533 |         evidence.drainObservationMs = performance.now() - drainStarted;
  534 |         const finishInputRequestedAt = performance.now();
  535 |         const input = await finishInput();
  536 |         drainDiagnostics.finishInputNodeBracket = {
  537 |           requestAt: finishInputRequestedAt,
  538 |           returnedAt: performance.now(),
  539 |         };
  540 |         finishInput = undefined;
  541 |         const finalNativeRequestedAt = performance.now();
  542 |         const native = (await readDocResponsiveness(f.page))!;
  543 |         drainDiagnostics.finalNativeNodeBracket = {
  544 |           requestAt: finalNativeRequestedAt,
  545 |           returnedAt: performance.now(),
  546 |         };
  547 |         evidence.native = native;
  548 |         evidence.input = input;
  549 |         const frame = distribution(input.keyToFrameMs);
  550 |         const gaps = input.keydownAt.slice(1).map((at, index) => at - input.keydownAt[index]!);
  551 |         const longTasks = distribution(input.longTasks.map((task) => task.durationMs));
  552 |         const capacityFlushes = native.flushes.filter((entry) => entry.reason === 'capacity');
  553 |         const idleFlushes = native.flushes.filter((entry) => entry.reason === 'idle');
  554 |         const capacityFlush = capacityFlushes.length
  555 |           ? distribution(capacityFlushes.map((entry) => entry.durationMs))
  556 |           : null;
  557 |         const idleFlush = idleFlushes.length
  558 |           ? distribution(idleFlushes.map((entry) => entry.durationMs))
  559 |           : null;
  560 |         const flushMaximum = native.flushes.length
  561 |           ? Math.max(...native.flushes.map((entry) => entry.durationMs))
  562 |           : null;
  563 |         const drainUpperBoundMs = native.observedAt - input.keydownAt.at(-1)!;
  564 |         const localDrainMs = native.drainWitness?.firstEmpty
  565 |           ? native.drainWitness.firstEmpty.observedAt - input.keydownAt.at(-1)!
  566 |           : null;
  567 |         evidence.summary = {
  568 |           frameOpportunityMs: frame,
  569 |           interKeyGapMs: distribution(gaps),
  570 |           debounceBreakingGaps: gaps.filter((gap) => gap >= 300).length,
  571 |           longTaskMs: longTasks,
  572 |           totalBlockingMs: input.longTasks.reduce(
  573 |             (sum, task) => sum + Math.max(0, task.durationMs - 50),
  574 |             0,
  575 |           ),
  576 |           capacityFlushPairMs: capacityFlush,
  577 |           idleFlushPairMs: idleFlush,
  578 |           pairedFlushMaximumMs: flushMaximum,
  579 |           postFinalKeyDrainUpperBoundMs: drainUpperBoundMs,
  580 |           firstVerifiedBrowserLocalDrainMs: localDrainMs,
  581 |           lateReadMinusLocalWitnessMs:
  582 |             localDrainMs === null ? null : drainUpperBoundMs - localDrainMs,
  583 |           drainAcceptanceMetric: 'first-verified-browser-local-empty',
  584 |         };
  585 |         evidence.budgetResults = {
  586 |           inputP95: frame.p95 <= budgets[preset].inputP95Ms,
  587 |           longestTask: longTasks.max <= budgets[preset].longTaskMaxMs,
  588 |           capacityFlushP95: capacityFlush ? capacityFlush.p95 <= budgets[preset].flushP95Ms : null,
  589 |           idleFlushP95: idleFlush ? idleFlush.p95 <= budgets[preset].flushP95Ms : null,
  590 |           flushMaximum: flushMaximum === null ? null : flushMaximum <= budgets[preset].flushMaxMs,
  591 |           boundedHistory: native.highWater.history <= DOC_RESPONSIVENESS_GROUP_LIMIT,
  592 |           boundedCollaboration: native.highWater.collaboration <= DOC_RESPONSIVENESS_GROUP_LIMIT,
  593 |           observedCapacityFlushes: capacityFlushes.length > 0,
  594 |           browserLocalDrainedWithinOneSecond: localDrainMs === null ? null : localDrainMs <= 1000,
  595 |         };
  596 |         evidence.lateReadDiagnostic = {
  597 |           withinOneSecond: drainUpperBoundMs <= 1000,
  598 |           acceptanceGate: false,
  599 |         };
  600 |         evidence.heapAfter = await cdp.send('Runtime.getHeapUsage');
  601 |         if (profiling) {
  602 |           const { profile } = await cdp.send('Profiler.stop');
  603 |           profiling = false;
  604 |           evidence.profileSha256 = await retainProfile(profile, profilerClock, info);
  605 |           evidence.compositionCpu = compositionCpu(profile, profilerClock!, input.longTasks);
  606 |         }
  607 |         if (finishTrace) {
  608 |           evidence.traceClockEnd = await f.page.evaluate(() => performance.mark('spn133-clock-end').startTime);
  609 |           evidence.diagnosticTrace = await finishTrace();
> 610 |           expect((evidence.diagnosticTrace as { complete: boolean }).complete).toBe(true);
      |                                                                                ^ Error: expect(received).toBe(expected) // Object.is equality
  611 |         }
  612 |         evidence.timingCompleteAt = await now(f.page);
  613 |         evidence.timingComplete = true;
  614 |         const savedStarted = performance.now();
  615 |         await saved(f.page);
  616 |         evidence.postFinalKeySavedUpperBoundMs =
  617 |           (await f.page.evaluate(() => performance.now())) - input.keydownAt.at(-1)!;
  618 |         await exactText(f.page, expectedText);
  619 |         await exactText(f.other, expectedText);
  620 |         evidence.postFinalKeyPeerUpperBoundMs =
  621 |           (await f.page.evaluate(() => performance.now())) - input.keydownAt.at(-1)!;
  622 |         await expect
  623 |           .poll(async () => (await f.read()).body!.dataStream, { timeout: 30_000 })
  624 |           .toBe(expectedText);
  625 |         evidence.convergenceObservationMs = performance.now() - savedStarted;
  626 |         expect(native.selection).toMatchObject({
  627 |           start: expectedInputCount,
  628 |           end: expectedInputCount,
  629 |         });
  630 |         expect((await readDocResponsiveness(f.other))?.selection).toMatchObject({
  631 |           start: 0,
  632 |           end: 0,
  633 |         });
  634 |         const initial = await integrity(f, clockOrigins);
  635 |         exactIntegrity(initial, expectedText, expectedInputCount);
  636 |         expect(initial.sender.history).toEqual(native.history);
  637 |         const initialReloads = await readReloads(reloadObservers);
  638 |         completeReloadObservation(initialReloads);
  639 |         expect(initialReloads.reloads).toEqual([]);
  640 |         const preUndoIntegrity: DocPreUndoIntegrity = {
  641 |           ...initial,
  642 |           passed: true,
  643 |           reloads: initialReloads.reloads,
  644 |         };
  645 |         evidence.preUndoIntegrity = preUndoIntegrity;
  646 |         const sealedNative = await readDocResponsiveness(f.page, false, {
  647 |           action: 'seal',
  648 |           epoch: drainArm!.epoch,
  649 |           generation: drainArm!.generation,
  650 |           unitId: drainArm!.unitId,
  651 |           timeOrigin: drainArm!.timeOrigin,
  652 |         });
  653 |         const drainWitness = sealedNative?.drainWitness as DocDrainWitness | null | undefined;
  654 |         evidence.drainWitness = drainWitness;
  655 |         expect(drainWitness).toBeTruthy();
  656 |         expect(drainWitness!.invalidated).toBe(false);
  657 |         expect(drainWitness!.invalidations).toEqual([]);
  658 |         expect(drainWitness!.epoch).toBe(drainArm!.epoch);
  659 |         expect(drainWitness!.generation).toBe(drainArm!.generation);
  660 |         expect(drainWitness!.unitId).toBe(native.unitId);
  661 |         expect(drainWitness!.timeOrigin).toBe(input.timeOrigin);
  662 |         expect(drainWitness!.expectedCompletedStates).toBe(expectedInputCount);
  663 |         expect(drainWitness!.completedStates).toBe(expectedInputCount);
  664 |         expect(drainWitness!.lastCompletedStateAt!).toBeGreaterThanOrEqual(input.keydownAt.at(-1)!);
  665 |         expect(drainWitness!.firstEmpty).toBeTruthy();
  666 |         expect(drainWitness!.firstEmpty).toEqual(native.drainWitness?.firstEmpty);
  667 |         expect(drainWitness!.firstEmpty!.observedAt).toBeGreaterThanOrEqual(
  668 |           drainWitness!.lastCompletedStateAt!,
  669 |         );
  670 |         expect(drainWitness!.firstEmpty!.pending).toEqual({ history: 0, collaboration: 0 });
  671 |         expect(drainWitness!.firstEmpty!.history).toEqual(native.history);
  672 |         expect(drainWitness!.firstEmpty!.highWater).toEqual(native.highWater);
  673 |         expect(drainWitness!.sealedAt!).toBeGreaterThanOrEqual(preUndoIntegrity.observedAt);
  674 |         const historyProgress: Record<string, unknown> = { phase: 'not-started' };
  675 |         evidence.undoRedoObservation = historyProgress;
  676 |         const undoRedo = await verifyUndoRedo(
  677 |           f,
  678 |           preUndoIntegrity,
  679 |           sample === 'plain-1',
  680 |           reloadObservers,
  681 |           clockOrigins,
  682 |           historyProgress,
  683 |         );
  684 |         evidence.undoRedo = undoRedo;
  685 |         expect(drainWitness!.sealedAt!).toBeLessThanOrEqual(undoRedo.beforeUndoAt);
  686 |         await expect
  687 |           .poll(async () => (await f.read()).body!.dataStream)
  688 |           .toBe(undoRedo.outcome === 'passed' ? expectedText : '\r\n');
  689 |         await Promise.all([online(f.page), online(f.other)]);
  690 |         expect(f.errors).toEqual([]);
  691 |         expect(input.keydownAt).toHaveLength(expectedInputCount);
  692 |         expect(input.keyToFrameMs).toHaveLength(expectedInputCount);
  693 |         evidence.correctness =
  694 |           undoRedo.outcome === 'passed'
  695 |             ? 'exact saved/live peer text, sender/peer selections, undo/redo and Online passed'
  696 |             : 'baseline redo refused at capacity; exact prior typing and Undo verified; recovered saved empty state';
  697 |         // Schema 4 retains the strict baseline history outcome and separately
  698 |         // observes capacity/idle work. Drain acceptance now uses the preregistered
  699 |         // browser-local witness; the unchanged late-read scalar remains descriptive.
  700 |         if (!baseline) {
  701 |           expect(native.highWater.history).toBeLessThanOrEqual(DOC_RESPONSIVENESS_GROUP_LIMIT);
  702 |           expect(native.highWater.collaboration).toBeLessThanOrEqual(
  703 |             DOC_RESPONSIVENESS_GROUP_LIMIT,
  704 |           );
  705 |           expect(capacityFlushes.length).toBeGreaterThan(0);
  706 |           for (const entry of native.flushes) {
  707 |             expect(['capacity', 'idle']).toContain(entry.reason);
  708 |             expect(Number.isInteger(entry.history) && entry.history >= 0).toBe(true);
  709 |             expect(Number.isInteger(entry.collaboration) && entry.collaboration >= 0).toBe(true);
  710 |             const pending = Math.max(entry.history, entry.collaboration);
```