import base from '../../../vitest.config.ts';
export default { ...base, cacheDir: "/Users/mxbaylee/projects/spinel-spn-106-current-main-20261114/node_modules/.cache/spn106-review-a-ae39/vite", test: { ...base.test, cache: false } };
