import config from '/Users/mxbaylee/projects/spinel-spn-106-current-main-20261114/vitest.config.ts';
export default { ...config, cacheDir: '/tmp/spn106-review-b-vite-cache' };
