# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: maintenance.spec.ts >> supervised maintenance keeps pending native work, fences old edits, and recovers through cold controls
- Location: e2e/maintenance.spec.ts:203:1

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByRole('region', { name: 'Workspace maintenance controls', exact: true }).getByRole('button', { name: 'Pause edits', exact: true })
Expected: enabled
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" getByRole('region', { name: 'Workspace maintenance controls', exact: true }).getByRole('button', { name: 'Pause edits', exact: true }) with timeout 5000ms
  - waiting for getByRole('region', { name: 'Workspace maintenance controls', exact: true }).getByRole('button', { name: 'Pause edits', exact: true })

```

```yaml
- banner:
  - link "Spinel Your docs":
    - /url: /
    - img "Spinel"
    - text: Your docs
  - status "Connection status": Online
  - button "Online — connected to Spinel"
  - navigation "Workspace":
    - link "Admin":
      - /url: /admin
  - radiogroup "Appearance":
    - radio "Follow system" [checked]
    - radio "Light"
    - radio "Dark"
  - link "Your profile":
    - /url: /profile
    - text: Operator
- main:
  - paragraph: SERVER OPERATOR
  - heading "Administration" [level=1]
  - navigation "Administration sections":
    - link "People":
      - /url: "#people"
    - link "Invites":
      - /url: "#invites"
    - link "Connections":
      - /url: "#connections"
    - link "Backups & health":
      - /url: "#health"
  - region "Invites":
    - heading "Invites" [level=2]
    - button "Create invite"
    - paragraph: Invite a new everyday account, or help an active account register a replacement passkey.
    - region "Invite ready":
      - heading "Invite ready" [level=3]
      - paragraph: Copy this link now and send it to the intended person. It will not be shown again after you leave this section.
      - text: New invite link
      - textbox "New invite link": http://localhost:3198/invite?token=4WWFf1XkCbIv43pGMH1S9QQKy8vRJd2vJj0dFMMvdEA
      - button "Copy invite link"
      - paragraph: If copying is unavailable, select the address and copy it manually.
    - status: Invite created. Copy its address before leaving this section.
    - list "Invites":
      - listitem:
        - strong: New account
        - paragraph: Available
        - paragraph: Expires 11/21/2026, 6:31:15 PM
        - button "Actions for invite 1": ···
```

# Test source

```ts
  144 |   expect(response.status).toBe(200);
  145 |   const status = (await response.json()) as MaintenancePublicStatus;
  146 |   expect(Object.keys(status).sort()).toEqual(['available', 'epoch', 'notice', 'phase']);
  147 |   return status;
  148 | }
  149 | 
  150 | async function publishNotice(
  151 |   operator: Page,
  152 |   repeated: ReturnType<typeof nextRepeatedTime>,
  153 |   info?: TestInfo,
  154 | ) {
  155 |   await controls(operator)
  156 |     .getByRole('button', { name: 'Maintenance actions', exact: true })
  157 |     .click();
  158 |   await operator.getByRole('menuitem', { name: 'Schedule a notice…', exact: true }).click();
  159 |   const dialog = operator.getByRole('dialog', {
  160 |     name: 'Schedule a maintenance notice',
  161 |     exact: true,
  162 |   });
  163 |   // A repeated local time requires an explicit occurrence and persists one absolute instant.
  164 |   const localTime = dialog.getByLabel('Date and time', { exact: true });
  165 |   const timeZone = dialog.getByLabel('Time zone', { exact: true });
  166 |   await localTime.fill(repeated.localTime);
  167 |   await timeZone.fill(repeated.timeZone);
  168 |   await dialog.getByLabel('Estimated minutes', { exact: true }).fill('45');
  169 |   await expect(localTime).toHaveValue(repeated.localTime);
  170 |   await expect(timeZone).toHaveValue(repeated.timeZone);
  171 |   // The wrapping label contains the option text. Match the control's accessible
  172 |   // name, rather than getByLabel's exact concatenation of all descendants.
  173 |   const occurrence = dialog.getByRole('combobox', {
  174 |     name: 'This time occurs twice',
  175 |     exact: true,
  176 |   });
  177 |   await expect(occurrence).toBeVisible();
  178 |   await expect(occurrence).toHaveValue('');
  179 |   await expect(occurrence.locator('option')).toHaveText([
  180 |     'Choose an occurrence',
  181 |     /^First occurrence/,
  182 |     /^Second occurrence/,
  183 |   ]);
  184 |   await expect(occurrence.locator('option').nth(2)).toHaveAttribute(
  185 |     'value',
  186 |     String(repeated.startsAt),
  187 |   );
  188 |   await dialog.getByRole('button', { name: 'Verify with a passkey', exact: true }).click();
  189 |   await expect(dialog.getByRole('button', { name: 'Publish notice', exact: true })).toBeDisabled();
  190 |   await expect(occurrence).toBeVisible();
  191 |   await expect(occurrence).toHaveValue('');
  192 |   await occurrence.selectOption(String(repeated.startsAt));
  193 |   await expect(occurrence).toHaveValue(String(repeated.startsAt));
  194 |   if (info) await capture(operator, info, 'notice-time-choice');
  195 |   const response = operator.waitForResponse(
  196 |     (value) => new URL(value.url()).pathname === '/api/admin/maintenance/notice',
  197 |   );
  198 |   await dialog.getByRole('button', { name: 'Publish notice', exact: true }).click();
  199 |   expect((await response).status()).toBe(200);
  200 |   await expect(controls(operator).getByText('Scheduled notice', { exact: true })).toBeVisible();
  201 | }
  202 | 
  203 | test('supervised maintenance keeps pending native work, fences old edits, and recovers through cold controls', async ({
  204 |   playwright,
  205 | }, info) => {
  206 |   test.skip(
  207 |     info.project.name !== 'production' || process.platform !== 'linux',
  208 |     'Closed-process verification uses the Linux production supervisor.',
  209 |   );
  210 |   test.setTimeout(300_000);
  211 |   const app = await startMaintenanceFixture();
  212 |   let browser: Browser | undefined;
  213 |   const failures: string[] = [];
  214 |   try {
  215 |     // Phase A: real Operator controls without a resident native editor. Closing
  216 |     // this whole browser before Phase B releases its renderers and SDK imports.
  217 |     browser = await playwright.chromium.launch(info.project.use.launchOptions);
  218 |     const operatorContext = await browser.newContext({
  219 |       baseURL: app.origin,
  220 |       acceptDownloads: true,
  221 |       viewport: { width: 1280, height: 900 },
  222 |       colorScheme: 'light',
  223 |       reducedMotion: 'reduce',
  224 |     });
  225 |     const operator = await operatorContext.newPage();
  226 |     operator.setDefaultTimeout(15_000);
  227 |     operator.on('pageerror', (error) => failures.push(error.message));
  228 |     await passkey(operator);
  229 |     await operator.goto(app.setupLink);
  230 |     await operator.getByRole('button', { name: 'Create admin passkey', exact: true }).click();
  231 |     await expect(
  232 |       operator.getByRole('heading', { name: 'Administration', exact: true }),
  233 |     ).toBeVisible();
  234 |     await operator.goto('/admin#invites');
  235 |     await operator.getByRole('button', { name: 'Create invite', exact: true }).click();
  236 |     await operator
  237 |       .getByRole('dialog', { name: 'Create invite', exact: true })
  238 |       .getByRole('button', { name: 'Create invite', exact: true })
  239 |       .click();
  240 |     const invitation = await operator.getByLabel('New invite link', { exact: true }).inputValue();
  241 |     await operator.goto('/admin#health');
  242 |     await expect(
  243 |       controls(operator).getByRole('button', { name: 'Pause edits', exact: true }),
> 244 |     ).toBeEnabled();
      |       ^ Error: expect(locator).toBeEnabled() failed
  245 |     const repeated = nextRepeatedTime();
  246 |     await publishNotice(operator, repeated, info);
  247 |     const announced = await publicStatus(app.publicOrigin);
  248 |     expect(announced.phase).toBe('running');
  249 |     expect(announced.notice).toMatchObject({
  250 |       startsAt: repeated.startsAt,
  251 |       timeZone: repeated.timeZone,
  252 |       durationMinutes: 45,
  253 |       state: 'scheduled',
  254 |     });
  255 |     await expect(
  256 |       banner(operator).getByText('Maintenance scheduled', { exact: true }),
  257 |     ).toBeVisible();
  258 |     await capture(operator, info, 'scheduled');
  259 | 
  260 |     // A ready encrypted export remains private and inert during maintenance.
  261 |     // Start it through the real passkey flow before rotating the workspace epoch.
  262 |     const downloads = operator.getByRole('region', {
  263 |       name: 'Workspace backup download',
  264 |       exact: true,
  265 |     });
  266 |     await expect(
  267 |       downloads.getByRole('button', { name: 'Prepare workspace backup', exact: true }),
  268 |     ).toBeEnabled();
  269 |     await downloads.getByRole('button', { name: 'Prepare workspace backup', exact: true }).click();
  270 |     const prepareBackup = operator.getByRole('dialog', {
  271 |       name: 'Prepare encrypted backup',
  272 |       exact: true,
  273 |     });
  274 |     const preparedBackup = operator.waitForResponse(
  275 |       (response) =>
  276 |         new URL(response.url()).pathname === '/api/admin/backups/exports' &&
  277 |         response.request().method() === 'POST',
  278 |     );
  279 |     const backupProof = operator.waitForResponse(
  280 |       (response) => new URL(response.url()).pathname === '/api/auth/reauthentication/verify',
  281 |     );
  282 |     await prepareBackup
  283 |       .getByRole('button', { name: 'Verify and prepare backup', exact: true })
  284 |       .click();
  285 |     expect((await backupProof).status()).toBe(200);
  286 |     const preparedReply = await preparedBackup;
  287 |     expect(preparedReply.status()).toBe(202);
  288 |     expect(preparedReply.request().headers()['x-spinel-epoch']).toBe(app.running.epoch);
  289 |     const backupJobId = (await preparedReply.json()).job.id as string;
  290 |     await expect(prepareBackup).toHaveCount(0);
  291 |     await expect(downloads.getByText('Encrypted backup ready.', { exact: true })).toBeVisible({
  292 |       timeout: 30_000,
  293 |     });
  294 |     const retainedDownloads = await downloads.elementHandle();
  295 |     const retainedDelivery = await downloads
  296 |       .locator('iframe[title="Encrypted backup delivery"]')
  297 |       .elementHandle();
  298 |     expect(retainedDownloads).not.toBeNull();
  299 |     expect(retainedDelivery).not.toBeNull();
  300 |     const stableDownload = async () => {
  301 |       expect(
  302 |         await downloads.evaluate((node, original) => node === original, retainedDownloads!),
  303 |       ).toBe(true);
  304 |       expect(
  305 |         await downloads
  306 |           .locator('iframe[title="Encrypted backup delivery"]')
  307 |           .evaluate((node, original) => node === original, retainedDelivery!),
  308 |       ).toBe(true);
  309 |       expect(await retainedDelivery!.evaluate((node) => node.isConnected)).toBe(true);
  310 |     };
  311 |     await operator.evaluate(() => window.scrollTo({ top: 0, left: 0, behavior: 'instant' }));
  312 | 
  313 |     // Another already-open Operator tab has the same cookie, but no resume capability.
  314 |     const unprivilegedTab = await operatorContext.newPage();
  315 |     unprivilegedTab.setDefaultTimeout(15_000);
  316 |     unprivilegedTab.on('pageerror', (error) => failures.push(error.message));
  317 |     await unprivilegedTab.goto('/admin#health');
  318 |     await expect(
  319 |       controls(unprivilegedTab).getByRole('button', { name: 'Pause edits', exact: true }),
  320 |     ).toBeEnabled();
  321 | 
  322 |     let pauseRequests = 0;
  323 |     operator.on('request', (request) => {
  324 |       if (new URL(request.url()).pathname === '/api/admin/maintenance/pause') pauseRequests++;
  325 |     });
  326 |     await controls(operator).getByRole('button', { name: 'Pause edits', exact: true }).click();
  327 |     const pauseDialog = operator.getByRole('dialog', {
  328 |       name: 'Pause workspace edits?',
  329 |       exact: true,
  330 |     });
  331 |     await capture(operator, info, 'pause-confirmation', false);
  332 |     const proofResponse = operator.waitForResponse(
  333 |       (response) => new URL(response.url()).pathname === '/api/auth/reauthentication/verify',
  334 |     );
  335 |     await pauseDialog.getByRole('button', { name: 'Verify with a passkey', exact: true }).click();
  336 |     const proof = (await (await proofResponse).json()) as { verifiedUntil: number };
  337 |     await expect(
  338 |       pauseDialog.getByRole('button', { name: 'Pause edits', exact: true }),
  339 |     ).toBeEnabled();
  340 |     expect(pauseRequests).toBe(0);
  341 |     const pauseResponse = operator.waitForResponse(
  342 |       (response) => new URL(response.url()).pathname === '/api/admin/maintenance/pause',
  343 |     );
  344 |     await pauseDialog.getByRole('button', { name: 'Pause edits', exact: true }).click();
```