# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: admin-layout.spec.ts >> pending invitations prevent section changes, manual copying works, and leaving discards the secret
- Location: e2e/admin-layout.spec.ts:131:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('textbox', { name: 'New invite link' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('textbox', { name: 'New invite link' }) with timeout 5000ms
  - waiting for getByRole('textbox', { name: 'New invite link' })

```

```yaml
- banner:
  - status "Connection status": Online
- dialog "Create invite":
  - heading "Create invite" [level=2]
  - button "Close dialog" [disabled]: ×
  - text: Invite for
  - combobox "Invite for" [disabled]:
    - option "A new account" [selected]
    - option "Recover Invite layout d247d1107d58feeba083-518f29cc69d9fac6cad2-0 (af417212-b656-425e-8108-65fdf46cd018) (admin)"
    - option "Recover Invite layout d247d1107d58feeba083-518f29cc69d9fac6cad2-0 (c9e805ab-4552-486c-b5a0-b577b6ada37d) (admin)"
  - text: Expires in
  - combobox "Expires in" [disabled]:
    - option "1 hour"
    - option "1 day"
    - option "7 days" [selected]
    - option "30 days"
  - button "Cancel" [disabled]
  - button "Creating…" [disabled]
```

# Test source

```ts
  89  |       for (const theme of ['light', 'dark'] as const) {
  90  |         await page
  91  |           .locator('.workspace > header')
  92  |           .getByRole('radio', { name: theme === 'light' ? 'Light' : 'Dark', exact: true })
  93  |           .click();
  94  |         for (const section of ['People', 'Invites', 'Connections', 'Backups & health']) {
  95  |           await nav.getByRole('link', { name: section, exact: true }).click();
  96  |           await expect(page.getByRole('heading', { name: section, exact: true })).toBeVisible();
  97  |           await expect(nav.getByRole('link', { name: section, exact: true })).toHaveAttribute(
  98  |             'aria-current',
  99  |             'page',
  100 |           );
  101 |           const refreshName =
  102 |             section === 'People'
  103 |               ? 'Refresh users'
  104 |               : section === 'Invites'
  105 |                 ? 'Create invite'
  106 |                 : section === 'Connections'
  107 |                   ? 'Refresh connected assistants'
  108 |                   : 'Refresh backup status';
  109 |           await expect(page.getByRole('button', { name: refreshName, exact: true })).toBeEnabled();
  110 |           for (const link of await nav.getByRole('link').all()) {
  111 |             await expect(link).toBeInViewport();
  112 |             expect((await link.boundingBox())!.height).toBeGreaterThanOrEqual(44);
  113 |           }
  114 |           await expect
  115 |             .poll(() => page.evaluate(() => document.documentElement.scrollWidth <= innerWidth))
  116 |             .toBe(true);
  117 |           expect(await page.locator('body').innerText()).not.toContain(privateItem.name);
  118 |           await page.screenshot({
  119 |             path: `test-results/theme-screenshots/admin-${info.project.name}-${width}-${theme}-${section.toLowerCase().replaceAll(/[^a-z]+/g, '-')}.png`,
  120 |             fullPage: true,
  121 |           });
  122 |         }
  123 |       }
  124 |       expect(errors).toEqual([]);
  125 |     } finally {
  126 |       db.close();
  127 |     }
  128 |   });
  129 | }
  130 | 
  131 | test('pending invitations prevent section changes, manual copying works, and leaving discards the secret', async ({
  132 |   page,
  133 |   context,
  134 |   baseURL,
  135 | }, info) => {
  136 |   const db = openDatabase(`test-results/${info.project.name}/app.sqlite`),
  137 |     auth = new AuthStore(db);
  138 |   const operator = auth.createUser(`Invite layout ${info.testId}-${info.retry}`, true);
  139 |   await context.addCookies([
  140 |     {
  141 |       name: COOKIE_NAME,
  142 |       value: auth.createSession(operator.id).token,
  143 |       url: baseURL!.replace('http:', 'https:'),
  144 |       secure: true,
  145 |       httpOnly: true,
  146 |       sameSite: 'Strict',
  147 |     },
  148 |   ]);
  149 |   let release = () => {},
  150 |     releaseReadback = () => {};
  151 |   let created = false,
  152 |     heldReadback = false;
  153 |   const readbackGate = new Promise<void>((resolve) => {
  154 |     releaseReadback = resolve;
  155 |   });
  156 |   const gate = new Promise<void>((resolve) => {
  157 |     release = resolve;
  158 |   });
  159 |   await page.route('**/api/auth/invites', async (route) => {
  160 |     if (route.request().method() === 'POST') {
  161 |       await gate;
  162 |       const response = await route.fetch();
  163 |       created = true;
  164 |       await route.fulfill({ response });
  165 |     } else if (created && !heldReadback) {
  166 |       heldReadback = true;
  167 |       await readbackGate;
  168 |       await route.fulfill({
  169 |         status: 503,
  170 |         contentType: 'application/json',
  171 |         body: JSON.stringify({ error: 'Could not refresh invitations.' }),
  172 |       });
  173 |     } else await route.continue();
  174 |   });
  175 |   try {
  176 |     await page.goto('/admin#invites');
  177 |     await page.getByRole('button', { name: 'Create invite', exact: true }).click();
  178 |     const dialog = page.getByRole('dialog', { name: 'Create invite', exact: true });
  179 |     await dialog.getByRole('button', { name: 'Create invite', exact: true }).click();
  180 |     await expect(dialog.getByRole('button', { name: 'Creating…' })).toBeDisabled();
  181 |     await page.evaluate(() => {
  182 |       location.hash = 'people';
  183 |     });
  184 |     await expect(page).toHaveURL(/#invites$/);
  185 |     await page.keyboard.press('Escape');
  186 |     await expect(dialog).toBeVisible();
  187 |     release();
  188 |     const address = page.getByRole('textbox', { name: 'New invite link' });
> 189 |     await expect(address).toBeVisible();
      |                           ^ Error: expect(locator).toBeVisible() failed
  190 |     await expect(address).toBeFocused();
  191 |     // The once-only address remains the focus target while a slow readback keeps Create disabled.
  192 |     await expect(page.getByRole('button', { name: 'Create invite', exact: true })).toBeDisabled();
  193 |     const healthLink = page.getByRole('link', { name: 'Backups & health', exact: true });
  194 |     await expect(healthLink).toHaveAttribute('aria-disabled', 'true');
  195 |     // Seeing the created link is not completion: the real readback still owns
  196 |     // the navigation fence. Dispatch the disabled anchor's event directly to
  197 |     // exercise its handler; Playwright correctly refuses a user click here.
  198 |     await healthLink.dispatchEvent('click');
  199 |     await expect(page).toHaveURL(/#invites$/);
  200 |     await page.evaluate(() => {
  201 |       location.hash = 'health';
  202 |     });
  203 |     await expect(page).toHaveURL(/#invites$/);
  204 |     releaseReadback();
  205 |     await expect(healthLink).not.toHaveAttribute('aria-disabled', 'true');
  206 |     await expect(page.getByRole('button', { name: 'Refresh invites', exact: true })).toBeEnabled();
  207 |     await expect(address).toBeFocused();
  208 |     const secret = await address.inputValue();
  209 |     await page.evaluate(() => {
  210 |       Object.defineProperty(navigator, 'clipboard', {
  211 |         configurable: true,
  212 |         value: {
  213 |           writeText: async () => {
  214 |             throw new Error('Unavailable');
  215 |           },
  216 |         },
  217 |       });
  218 |     });
  219 |     await page.getByRole('button', { name: 'Copy invite link' }).click();
  220 |     await expect(
  221 |       page.getByRole('region', { name: 'Invites', exact: true }).getByRole('status'),
  222 |     ).toHaveText('Select the link below and copy it manually.');
  223 |     await expect(address).toHaveValue(secret);
  224 |     const nav = page.getByRole('navigation', { name: 'Administration sections' });
  225 |     await healthLink.click();
  226 |     await expect(
  227 |       page.getByRole('heading', { name: 'Backups & health', exact: true }),
  228 |     ).toBeVisible();
  229 |     await nav.getByRole('link', { name: 'People', exact: true }).click();
  230 |     await expect(page.getByRole('heading', { name: 'People', exact: true })).toBeVisible();
  231 |     await nav.getByRole('link', { name: 'Invites', exact: true }).click();
  232 |     await expect(page.getByRole('list', { name: 'Invites' })).toBeVisible();
  233 |     await expect(address).toHaveCount(0);
  234 |     expect(await page.content()).not.toContain(secret);
  235 |     await page.reload();
  236 |     await expect(page.getByRole('list', { name: 'Invites' })).toBeVisible();
  237 |     await expect(address).toHaveCount(0);
  238 |     expect(await (await context.request.get('/api/auth/invites')).text()).not.toContain(secret);
  239 |   } finally {
  240 |     release();
  241 |     releaseReadback();
  242 |     db.close();
  243 |   }
  244 | });
  245 | 
  246 | test('a response from an unmounted section cannot redirect a current administration view', async ({
  247 |   page,
  248 |   context,
  249 |   baseURL,
  250 | }, info) => {
  251 |   const db = openDatabase(`test-results/${info.project.name}/app.sqlite`),
  252 |     auth = new AuthStore(db);
  253 |   const operator = auth.createUser(`Stale layout ${info.testId}-${info.retry}`, true);
  254 |   await context.addCookies([
  255 |     {
  256 |       name: COOKIE_NAME,
  257 |       value: auth.createSession(operator.id).token,
  258 |       url: baseURL!.replace('http:', 'https:'),
  259 |       secure: true,
  260 |       httpOnly: true,
  261 |       sameSite: 'Strict',
  262 |     },
  263 |   ]);
  264 |   let release = () => {},
  265 |     started = () => {};
  266 |   const gate = new Promise<void>((resolve) => {
  267 |     release = resolve;
  268 |   });
  269 |   const requested = new Promise<void>((resolve) => {
  270 |     started = resolve;
  271 |   });
  272 |   await page.route('**/api/auth/admin/users', async (route) => {
  273 |     started();
  274 |     await gate;
  275 |     await route.fulfill({
  276 |       status: 401,
  277 |       contentType: 'application/json',
  278 |       body: JSON.stringify({ error: 'Expired old response' }),
  279 |     });
  280 |   });
  281 |   try {
  282 |     await page.goto('/admin');
  283 |     await requested;
  284 |     await page
  285 |       .getByRole('navigation', { name: 'Administration sections' })
  286 |       .getByRole('link', { name: 'Invites', exact: true })
  287 |       .click();
  288 |     await expect(page.getByRole('button', { name: 'Create invite', exact: true })).toBeEnabled();
  289 |     const response = page.waitForResponse('**/api/auth/admin/users');
```