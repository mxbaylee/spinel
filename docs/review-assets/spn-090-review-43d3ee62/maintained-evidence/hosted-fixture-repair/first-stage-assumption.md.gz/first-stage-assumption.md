# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: startup-lifecycle.spec.ts >> guest startup reporting ends when a ready guest mounts after slow app code
- Location: e2e/startup-lifecycle.spec.ts:81:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('status').filter({ hasText: /^Still starting:/ })
Expected substring: "Still starting: service worker"
Received string:    "Still starting: app code (14 s)"
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByRole('status').filter({ hasText: /^Still starting:/ }) with timeout 5000ms
  - waiting for getByRole('status').filter({ hasText: /^Still starting:/ })
    6 × locator resolved to <p role="status">Still starting: app code (10 s)</p>
      - unexpected value "Still starting: app code (10 s)"
    2 × locator resolved to <p role="status">Still starting: app code (11 s)</p>
      - unexpected value "Still starting: app code (11 s)"
    2 × locator resolved to <p role="status">Still starting: app code (12 s)</p>
      - unexpected value "Still starting: app code (12 s)"
    2 × locator resolved to <p role="status">Still starting: app code (13 s)</p>
      - unexpected value "Still starting: app code (13 s)"
    2 × locator resolved to <p role="status">Still starting: app code (14 s)</p>
      - unexpected value "Still starting: app code (14 s)"

```

```yaml
- status: "Still starting: app code (14 s)"
```

# Test source

```ts
  9   |   await page.clock.install();
  10  |   await page.addInitScript(() => {
  11  |     // Bootstrap starts the first one-second interval before importing application.
  12  |     // Track its real browser handle without replacing the production callback.
  13  |     const browserWindow: Window = window;
  14  |     const set = browserWindow.setInterval.bind(browserWindow);
  15  |     const clear = browserWindow.clearInterval.bind(browserWindow);
  16  |     const probe = { reporter: null as number | null, cleared: false };
  17  |     Object.assign(window, { startupTimerProbe: probe });
  18  |     browserWindow.setInterval = (callback, delay, ...args) => {
  19  |       const handle = set(callback, delay, ...args);
  20  |       if (delay === 1000 && probe.reporter === null) probe.reporter = handle;
  21  |       return handle;
  22  |     };
  23  |     browserWindow.clearInterval = (handle) => {
  24  |       if (handle === probe.reporter) probe.cleared = true;
  25  |       clear(handle);
  26  |     };
  27  |   });
  28  | });
  29  | 
  30  | async function reporterCleared(page: Page, cleared: boolean) {
  31  |   await expect
  32  |     .poll(() =>
  33  |       page.evaluate(() => {
  34  |         const probe = (
  35  |           window as unknown as {
  36  |             startupTimerProbe: { reporter: number | null; cleared: boolean };
  37  |           }
  38  |         ).startupTimerProbe;
  39  |         return { started: probe.reporter !== null, cleared: probe.cleared };
  40  |       }),
  41  |     )
  42  |     .toEqual({ started: true, cleared });
  43  | }
  44  | 
  45  | async function beyondDeadline(page: Page, elapsed = 120_000) {
  46  |   // Change wall time, then tick once. Do not exhaust unrelated HTTP deadlines
  47  |   // or replay two minutes of guest polling just to test the startup reporter.
  48  |   await page.clock.setSystemTime((await page.evaluate(() => Date.now())) + elapsed);
  49  |   await page.clock.runFor(1000);
  50  | }
  51  | 
  52  | async function readySpace(page: Page) {
  53  |   await page.route('**' + guestPath, (route) =>
  54  |     route.fulfill({
  55  |       json: { item: { id, kind: 'space', name: 'Shared timer fixture', access: 'viewer' } },
  56  |     }),
  57  |   );
  58  |   await page.route('**/api/guest-spaces/' + id, (route) =>
  59  |     route.fulfill({
  60  |       json: {
  61  |         space: {
  62  |           id,
  63  |           kind: 'space',
  64  |           name: 'Shared timer fixture',
  65  |           parentId: null,
  66  |           spaceId: null,
  67  |           position: null,
  68  |           createdAt: 0,
  69  |           updatedAt: 0,
  70  |         },
  71  |         access: 'viewer',
  72  |         items: [],
  73  |       },
  74  |     }),
  75  |   );
  76  | }
  77  | 
  78  | // This is an actual application -> GuestApp -> Space mount with deterministic
  79  | // HTTP responses. Native editing has its own owners; no SDK editor is needed
  80  | // to verify entry lifecycle, DOM removal and timer disposal.
  81  | test('guest startup reporting ends when a ready guest mounts after slow app code', async ({
  82  |   page,
  83  |   context,
  84  | }) => {
  85  |   await readySpace(page);
  86  |   let release!: () => void;
  87  |   const gate = new Promise<void>((resolve) => {
  88  |     release = resolve;
  89  |   });
  90  |   let requested!: (owner: 'service worker' | 'app code') => void;
  91  |   const applicationRequested = new Promise<'service worker' | 'app code'>((resolve) => {
  92  |     requested = resolve;
  93  |   });
  94  |   // Production precaches the imported application through its real worker;
  95  |   // page.route cannot intercept that worker-owned fetch. Keep both owners gated.
  96  |   await context.route(
  97  |     /\/(?:application\.tsx(?:\?.*)?|assets\/application-[^/]+\.js)$/,
  98  |     async (route) => {
  99  |       requested(route.request().serviceWorker() ? 'service worker' : 'app code');
  100 |       await gate;
  101 |       await route.continue();
  102 |     },
  103 |   );
  104 |   try {
  105 |     await page.goto('/share/' + id, { waitUntil: 'commit' });
  106 |     const owner = await applicationRequested;
  107 |     test.info().annotations.push({ type: 'application delivery gate', description: owner });
  108 |     await beyondDeadline(page, 9000);
> 109 |     await expect(slowLine(page)).toContainText('Still starting: ' + owner);
      |                                  ^ Error: expect(locator).toContainText(expected) failed
  110 |     await expect(
  111 |       page.getByRole('heading', { name: 'This Space is empty', exact: true }),
  112 |     ).toHaveCount(0);
  113 |     await reporterCleared(page, false);
  114 |     release();
  115 |     await expect(
  116 |       page.getByRole('heading', { name: 'This Space is empty', exact: true }),
  117 |     ).toBeVisible();
  118 |     await expect(
  119 |       page.getByRole('heading', { name: 'Shared timer fixture', exact: true, level: 1 }),
  120 |     ).toBeVisible();
  121 |     await expect(slowLine(page)).toHaveCount(0);
  122 |     await reporterCleared(page, true);
  123 |     await beyondDeadline(page);
  124 |     await expect(slowLine(page)).toHaveCount(0);
  125 |   } finally {
  126 |     release();
  127 |   }
  128 | });
  129 | 
  130 | for (const state of ['unavailable', 'revoked', 'unsupported'] as const) {
  131 |   test(`guest startup reporting ends for ${state} entry`, async ({ page }) => {
  132 |     if (state === 'unsupported')
  133 |       await page.addInitScript(() => {
  134 |         Object.defineProperty(navigator, 'locks', { value: undefined, configurable: true });
  135 |       });
  136 |     await page.route('**' + guestPath, (route) =>
  137 |       route.fulfill({ status: state === 'revoked' ? 404 : 503, json: {} }),
  138 |     );
  139 |     await page.goto('/share/' + id + (state === 'unsupported' ? '#timer-fixture' : ''));
  140 |     if (state === 'unsupported')
  141 |       await expect(page.getByRole('alert')).toHaveText(
  142 |         'Open this link in a current browser that supports Web Locks.',
  143 |       );
  144 |     else
  145 |       await expect(
  146 |         page.getByRole('heading', {
  147 |           name: state === 'revoked' ? 'This link no longer works.' : "You're offline",
  148 |           exact: true,
  149 |         }),
  150 |       ).toBeVisible();
  151 |     await reporterCleared(page, true);
  152 |     await beyondDeadline(page);
  153 |     await expect(slowLine(page)).toHaveCount(0);
  154 |   });
  155 | }
  156 | 
  157 | test('account startup reporting remains live while actual admission is pending', async ({
  158 |   page,
  159 | }) => {
  160 |   let requested!: () => void;
  161 |   const sessionRequested = new Promise<void>((resolve) => {
  162 |     requested = resolve;
  163 |   });
  164 |   await page.route('**/api/auth/session', () => {
  165 |     requested();
  166 |   });
  167 |   await page.goto('/sign-in');
  168 |   await sessionRequested;
  169 |   await beyondDeadline(page, 9000);
  170 |   await expect(slowLine(page)).toContainText('Still starting: sign-in check');
  171 |   await reporterCleared(page, false);
  172 | });
  173 | 
```