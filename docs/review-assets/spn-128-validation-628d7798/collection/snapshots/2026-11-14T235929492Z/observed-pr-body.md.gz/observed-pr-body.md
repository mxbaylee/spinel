## 🌷 What changes

A supported `recover-original --operation <UUID>` supervisor command restores the independently preserved original after an interrupted restore, including after the original confirmation authority expired. It uses fresh deliberate authority on the private service-UID control socket, independently authenticates the frozen original, retains closed partial replacement bytes as private evidence, and reuses rollback reconciliation and the original-recovery permit to commit a new generation. Ambiguous/missing evidence keeps the workspace closed. A committed backup, unrelated operation or later acknowledged generation cannot be overwritten.

**Current candidate:** `628d77987e7d9a08863465a7553a2ed82579728b`, based on actual main `8e9dccbd90f04ad79bd12cba3695e5c4ff04e02d` (SPN-123, following SPN-120). Both exact-head independent reviews are complete; **no validation push or current-head hosted result is claimed**. Review and local checks are complete; source publication and fresh hosted acceptance are next.

The complete **L** outcome includes bounded separately journaled cold attempts, authority and custody checks, native/session/capability reconciliation, private trial/readiness, durable commit, refusal/replay protection, exact-process cleanup, Linux crash coverage and runbooks. The original intent remains immutable. Frozen-source identity is verified against its independent witness; final live identity is verified against the reconciled prepared output, with content/access checked separately. Reconciliation legitimately changes session/capability/generation metadata.

The Operator receives finite private recovery without document access; Owner and Collaborator retain their latest content and filing/access; Link guests' revoked sessions/capabilities stay revoked. [Canonical decisions, full scope and failure dispositions](https://github.com/mxbaylee/spinel/blob/628d77987e7d9a08863465a7553a2ed82579728b/docs/implementation/SPN-128.md) and the [supported runbook](https://github.com/mxbaylee/spinel/blob/628d77987e7d9a08863465a7553a2ed82579728b/docs/maintenance.md) retain the reasons and boundaries.

## 🔬 How it was verified

The tested source is `ae97ca8b6587617ecccce5bbb80e0da4a4aa295a`, with exact parents `e4639be69b49fc90620f3198c666869eba16b0d2` (scope checkpoint atop previously reviewed8184) and actual main `8e9dccbd`. Final628d changes only maintained documentation/evidence. Root's final integration audit binds **1,397 non-documentation paths unchanged after testing**, **84 incoming source paths equal main** and **20 retained source paths equal prior source**. The maintenance supervisor is the sole executable overlap: its cold-command body remains exact8184, while phase-transition and verification implementations remain exact8e9.

The earlier pending-index audit's420 incoming/62 retained paths describe that earlier stage. Final packet proof separately binds419 incoming/62 retained paths and explicitly accounts for23 intentional canonical/inventory/bookkeeping/evidence changes. These counts have different scopes and are not interchangeable.

[Current raw logs, watchdog receipts, source audit and cleanup provenance](https://github.com/mxbaylee/spinel/tree/628d77987e7d9a08863465a7553a2ed82579728b/docs/implementation/evidence/SPN-128-8e9-integration) retain the finite first-attempt checks:

- Recovery clock/custody/state: **30 passed,21 Linux-only skipped**;1,231ms,423,632KiB peak.
- Maintenance gate and diagnostics supervisor/store/runtime: **28 passed**;923ms,343,024KiB.
- Privacy/bootstrap/renderer/routing/owned-app controls: **36 passed**;2,178ms,287,120KiB.
- Full integrated typecheck: passed;9,093ms,1,794,624KiB with `GOMEMLIMIT=640MiB GOGC=50 GOMAXPROCS=2`.
- Complete lint/dependencies/format: passed;11,319ms,816,336KiB.
- Index/backlog/exact-title PR shape: passed;147ms/141ms/366ms. Index/backlog ended before an RSS sample; PR peak186,704KiB. Final628d PR shape passed again in361ms/178,880KiB with the transparent10,292-line soft warning; its original log/receipt is retained in the published current review archive.

Pinned Node26.13.0, candidate-private caches/workspace links, shared serial lock and normal-pressure preflight/continuous2GiB/eight-minute guard were used. No current implementer workload failed or aborted; none was retried. Cleanup observed no shared lock or matching owned workload. No install or donor mutation occurred: all external lock entries equal immutable donor7a, and the only changed workspace lock entry adds existing `@spinel/diagnostics` to sync-client. Package/lock bytes are not claimed identical.

The clock regression control derives restart time from persisted `intent.authority.expiresAt`, then each cold `attempt.deadline`, preserving earlier virtual advances. Both actual fixture processes receive the same offset. The old six-minute advance fails the unchanged strict expiry assertion against the already expanded thirty-minute lifetime; production authority, clocks and budgets are unchanged. Linux crash cuts fsync markers after actual effects and block until external SIGKILL, without relying on observer throws.

Existing focused suites own authority/custody/state and observer/process-cleanup negative cases; actual Linux processes own durability/custody/replay, and browser/native owners retain content/access/startup/build acceptance. Existing routing controls pass and required shared-dependency selection remains intact. The portable suite does not establish Linux behavior or duplicate the full hosted matrix.

**Hosted acceptance remains pending on this exact head:** corrected Linux crash/cold-command grants/custody/refusal/replay/cleanup; applicable first-attempt browser/native/build acceptance; and all seven required gates—Backlog, Pull request, Lint, Typecheck, Unit tests, Lib tests and Playwright smoke. Review grades do not replace those gates.

### 🧾 Preserved first failures

Original head `a6dd085d549d1a6e7b3894ccaa8d3c4fa03bcbb3`, [CI41501654342 attempt1](https://github.com/mxbaylee/spinel/actions/runs/41501654342/attempts/1), recovery job125560262408: **9 failed/651 passed**, with stale six-minute fixture expiry assertions. The persisted-deadline fixture change repairs that contract; the old-six-minute negative control proves detection. Corrected actual Linux execution is still pending. That run was cancelled overall; its mobile worker was cancelled, Unit tests/Playwright smoke aggregates failed, and its supervised-restore worker's success is historical only.

Earlier run41349831332 retained a mobile116.3ms result against100ms and a supervised-restore ECONNRESET while polling the second Sheet after acknowledged edits, before offline/restore. No original trace proves the reset cause. Passing retries, incoming fixture repairs and new diagnostics cannot reconstruct it. Original mirror/folder-readiness failures and their superseding main decisions remain in the canonical record.

Earlier independent reviewer attempts retain their setup/preflight/resource limits:3812 reviewer A had a preflight refusal, then an admitted1,134ms/366,784KiB abort with no completed results, and separately passed five privacy controls; reviewer B's first missing-`sysctl` PATH attempt failed before tests, then its corrected privacy/clock checks passed. At8184, reviewer A's21-control preflight refusal created no child/receipt, followed by a separately granted four-control pass; B independently executed30passed/21Linux-skipped recovery and21script controls. These are source-qualified historical records, not current executions.

## 📡 Diagnostic upkeep

The [emitter inventory](https://github.com/mxbaylee/spinel/blob/628d77987e7d9a08863465a7553a2ed82579728b/docs/diagnostics.md#emitter-maintenance-inventory) explicitly covers cold recovery. `maintenance.phase` reports distinct supervisor states, not recovery success; `maintenance.verification` describes only actual `verify()` calls, including committed-original replay. Unresolved recovery uses journal/image/private-trial evidence without inventing a verification observation. No event schema, content field, authority token or attribution expansion is introduced. Fixed fields, monotonic units, bounded loss accounting, independent supervisor writer, truncate fencing and active-export protection remain. Throwing diagnostic observers cannot replace authoritative operation errors. Incoming native/history/offline/runtime observations and owned-app fixture lifecycle remain intact.

## 🎨 Designs and screenshots

No UI change. The existing original-recovered outcome/banner remains; this command, authority and fixture integration adds no visual component or interaction state. Existing rendering/native acceptance remains applicable, without invented screenshot approval.

## 👥 Independent review

Both SAME independent nonimplementing reviewers assessed the complete L outcome on **628d77987e7d9a08863465a7553a2ed82579728b** against actual8e9. Root fully read both reports and checked their raw outcomes. **Agent review only.**

- [Reviewer A, `/root/spn128_current_a`](https://github.com/mxbaylee/spinel/blob/2fd164eefdf0302b9d3e3a3cfab4c25bb6905507/docs/review-assets/spn-128-review-628d7798/reviews/spn128-review-628d7798-a.md): **100/100**, rubric35/25/20/10/10; no actionable findings, deductions or remaining repair steps. Independently passed28observer/gate tests (940ms/308,832KiB) and20owned-process/privacy controls (1,975ms/285,776KiB), **48 total**, first attempts.
- [Reviewer B, `/root/spn128_current_b`](https://github.com/mxbaylee/spinel/blob/2fd164eefdf0302b9d3e3a3cfab4c25bb6905507/docs/review-assets/spn-128-review-628d7798/reviews/spn128-review-628d7798-b.md): **100/100**, rubric35/25/20/10/10; no actionable findings, deductions or remaining repair steps. Independently passed58portable controls with21Linux-only skips (1,821ms/387,024KiB) and36script/process controls (2,207ms/286,704KiB), **94 total**, first attempts.

[Original command logs/guard receipts](https://github.com/mxbaylee/spinel/tree/2fd164eefdf0302b9d3e3a3cfab4c25bb6905507/docs/review-assets/spn-128-review-628d7798/execution) and [source/cleanup/root audit evidence](https://github.com/mxbaylee/spinel/tree/2fd164eefdf0302b9d3e3a3cfab4c25bb6905507/docs/review-assets/spn-128-review-628d7798/audit) remain byte-preserved. Neither score claims hosted acceptance or permits merging before the required gates.

The full grade-free packet binds actual main, original specification, canonical decisions, source/binary diff, decoded evidence and final source/dependency proofs. Root packet audit verified1,609 payload hashes,1,599 actual Git source bindings,1,594 byte-exact source copies plus five explicitly masked Markdown copies,1,258 exact TypeScript copies,21 decoded gzip sources and the complete byte-exact binary diff. Four initial audit readers and the corrected final reader are preserved; their corrections handled heterogeneous manifest schemas, without packet/source mutation. Packet manifest SHA256: `412da891417cff6d99ca32c46bcb84e0fceb2eb36b0edb41f811c8585769a5f9`.

Current immutable [review archive](https://github.com/mxbaylee/spinel/tree/2fd164eefdf0302b9d3e3a3cfab4c25bb6905507/docs/review-assets/spn-128-review-628d7798) is published and remotely verified at tag `archive/spn-128-review-628d7798-20261114`, direct child628d and confined to its evidence path. Root independently verified all42 Git files/41 payloads,34 original copies and all1,610 packet TAR members byte-for-byte before publication. Manifest SHA256 `d9568cae959f0d36ef295e8ba56d3b589d210621bab96d90fbcd797bcf3a00b5`; packet tar SHA256 `1387355963760c1fce1d0bdc81bcaa4176defe46ac919be17d0654b4888e0cee`, all1,610 member files byte-exact. The archive records two preparation-only corrections (AppleDouble tar extras and an uninitialized-private-index status check), preserving original helpers and the first rejected tar separately; candidate/packet and execution outcomes were unchanged. Published historical records remain linked without copying them again:

- [8184 full review preservation](https://github.com/mxbaylee/spinel/tree/568c42e30022e9dadb3f6c9f84d7fa979b76fe7e/docs/review-assets/spn-128-review-81841c50).
- [3812 full review preservation](https://github.com/mxbaylee/spinel/tree/ba660d31d96949680e48ba44f33e2a46caac0dd8/docs/implementation/evidence/SPN-128-review-3812ed9b).
- [Original local2fcbbec7 evidence](https://github.com/mxbaylee/spinel/tree/7447da12a6c1a2f29c4b4d9b870b901f15c501bb/docs/review-assets/spn-128-current-local), [original a6dd local evidence](https://github.com/mxbaylee/spinel/tree/ba5c9fd5868e5448882e976edc202ede4b234dd3/docs/review-assets/spn-128-current-local), [original earlier CI evidence](https://github.com/mxbaylee/spinel/tree/41e2a2868be914adec6da5eeccc0faba589c3ef2/docs/review-assets/spn-128-previous-ci).

## 📐 Split out and decided

**10,292 counted textual changed lines**, using backlog exclusions. The soft-limit crossing comes from required source-audit/execution evidence; executable scope remains the coherent L recovery outcome. Splitting its evidence would detach acceptance from this PR. No retained requirement is deferred or hidden in another ticket. SPN-125 pruning remains separately owned; the SPN-124 authority lifetime is already integrated. All four persona tradeoffs and the explicit split assessment remain in the canonical record.

## 🚦 Run checkpoint

Same draft/open PR229; root freshly verified remote branch `codex/spn-128-original-recovery` at `a6dd085d549d1a6e7b3894ccaa8d3c4fa03bcbb3`. PR metadata still reports the old `18a8759c` base SHA before the new push; that stale checkout metadata does not describe this actual-main integration. Actual remote main is verified at `8e9dccbd`. Root will recheck ancestry and the exact remote head before any authorized normal fast-forward validation push. Local complete candidate628d is detached at `/Users/mxbaylee/projects/spinel-spn-128-production`. Missing old registered worktree metadata and original unique refs/history remain preserved. Current source is unpushed; no remote mutation occurred in this preparation.

SPN-098/090/120/123 are integrated; this candidate records completions `[098,090,120,123,128]`, next ID161 and November14 grooming. Next: normal fast-forward publication of this exact reviewed source, then actual current-head hosted acceptance/all seven gates before any squash merge. Root archive/body audit and review-archive publication are complete.

Terminal CI/run identities, final merge SHA, completion record and guarded obsolete-branch cleanup links are **reserved pending actual outcomes**. Do not replace these pending fields with prior-source passes. Candidate-pinned links above become resolvable after authorized source publication.
