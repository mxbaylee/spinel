# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: supervised-restore.spec.ts >> a catalog restore survives double-clicks, cancel and a lost reply, and fences old clients
- Location: e2e/supervised-restore.spec.ts:314:1

# Error details

```
Error: tracing.start: Tracing has been already started
```

# Test source

```ts
  1   | import { randomUUID } from 'node:crypto';
  2   | import { copyFile, chmod, writeFile } from 'node:fs/promises';
  3   | import { join } from 'node:path';
  4   | import { expect, test } from '@playwright/test';
  5   | import type {
  6   |   APIResponse,
  7   |   Browser,
  8   |   BrowserContext,
  9   |   Page,
  10  |   Request,
  11  |   TestInfo,
  12  | } from '@playwright/test';
  13  | import type { MaintenancePublicStatus } from '../src/shared/maintenance.ts';
  14  | import { startMaintenanceFixture } from './maintenance-fixture.ts';
  15  | import { maintenanceErrorCode } from './maintenance-evidence.ts';
  16  | 
  17  | /** SPN-112 and SPN-124 in real browsers against the Linux supervisor: catalog
  18  |  * selection, double-click, cancel, a lost confirmation reply, an admitted upload
  19  |  * outlasting its passkey window, and old clients meeting the restored workspace. */
  20  | 
  21  | const startupEvidence = new WeakMap<BrowserContext, string[]>();
  22  | async function observeStartup(context: BrowserContext) {
  23  |   const events: string[] = [];
  24  |   startupEvidence.set(context, events);
  25  |   // These contexts are created manually, so the project trace setting does not
  26  |   // cover them. Capture the original attempt, before any page can navigate.
> 27  |   await context.tracing.start({ screenshots: true, snapshots: true });
      |                         ^ Error: tracing.start: Tracing has been already started
  28  |   context.on('page', (page) => {
  29  |     page.on('console', (message) => {
  30  |       if (message.type() === 'error' && message.text().startsWith('[spinel:startup]'))
  31  |         events.push(message.text());
  32  |     });
  33  |     page.on('pageerror', (error) => events.push(`pageerror: ${error.name}`));
  34  |   });
  35  | }
  36  | 
  37  | type Fixture = Awaited<ReturnType<typeof startMaintenanceFixture>>;
  38  | 
  39  | async function passkey(context: BrowserContext, page: Page) {
  40  |   const cdp = await context.newCDPSession(page);
  41  |   await cdp.send('WebAuthn.enable');
  42  |   const { authenticatorId } = await cdp.send('WebAuthn.addVirtualAuthenticator', {
  43  |     options: {
  44  |       protocol: 'ctap2',
  45  |       transport: 'internal',
  46  |       hasResidentKey: true,
  47  |       hasUserVerification: true,
  48  |       isUserVerified: true,
  49  |       automaticPresenceSimulation: true,
  50  |     },
  51  |   });
  52  |   return { cdp, authenticatorId };
  53  | }
  54  | 
  55  | async function credentialsOf({ cdp, authenticatorId }: Awaited<ReturnType<typeof passkey>>) {
  56  |   return (await cdp.send('WebAuthn.getCredentials', { authenticatorId })).credentials;
  57  | }
  58  | 
  59  | /** A virtual authenticator belongs to one page. Signing in from a new tab copies its passkey. */
  60  | async function signInFromNewPage(
  61  |   context: BrowserContext,
  62  |   credentials: Awaited<ReturnType<typeof credentialsOf>>,
  63  | ) {
  64  |   const page = await context.newPage();
  65  |   page.setDefaultTimeout(15_000);
  66  |   const next = await passkey(context, page);
  67  |   for (const credential of credentials)
  68  |     await next.cdp.send('WebAuthn.addCredential', {
  69  |       authenticatorId: next.authenticatorId,
  70  |       credential,
  71  |     });
  72  |   await page.goto('/sign-in');
  73  |   await page.getByRole('button', { name: 'Sign in with a passkey', exact: true }).click();
  74  |   return page;
  75  | }
  76  | 
  77  | async function publicStatus(origin: string) {
  78  |   const response = await fetch(`${origin}/api/maintenance`);
  79  |   expect(response.status).toBe(200);
  80  |   return (await response.json()) as MaintenancePublicStatus;
  81  | }
  82  | 
  83  | const saveStatus = (page: Page) => page.getByRole('status', { name: 'Save status', exact: true });
  84  | const restoreRegion = (page: Page) =>
  85  |   page.getByRole('region', { name: 'Restore workspace', exact: true });
  86  | 
  87  | async function selectCell(page: Page, cell: string) {
  88  |   const address = page
  89  |     .getByRole('region', { name: 'Sheet document', exact: true })
  90  |     .locator('[data-u-comp="defined-name"] input');
  91  |   await address.fill(cell);
  92  |   await address.press('Enter');
  93  | }
  94  | 
  95  | async function typeCell(page: Page, cell: string, text: string) {
  96  |   await selectCell(page, cell);
  97  |   await page.keyboard.insertText(text);
  98  |   await page.keyboard.press('Enter');
  99  | }
  100 | 
  101 | function outbox(page: Page, accountId: string, itemId: string) {
  102 |   return page.evaluate(
  103 |     async ({ accountId, itemId }) => {
  104 |       const name = `spinel-offline-${accountId}`;
  105 |       if (!(await indexedDB.databases()).some((database) => database.name === name)) return '';
  106 |       return new Promise<string>((resolve, reject) => {
  107 |         const opening = indexedDB.open(name);
  108 |         opening.onerror = () => reject(opening.error);
  109 |         opening.onsuccess = () => {
  110 |           const database = opening.result;
  111 |           const read = database.transaction('items').objectStore('items').get(itemId);
  112 |           read.onerror = () => {
  113 |             database.close();
  114 |             reject(read.error);
  115 |           };
  116 |           read.onsuccess = () => {
  117 |             database.close();
  118 |             resolve(JSON.stringify(read.result?.outbox ?? null));
  119 |           };
  120 |         };
  121 |       });
  122 |     },
  123 |     { accountId, itemId },
  124 |   );
  125 | }
  126 | 
  127 | /** Counts real requests by route so double-clicks and retries are observable. */
```