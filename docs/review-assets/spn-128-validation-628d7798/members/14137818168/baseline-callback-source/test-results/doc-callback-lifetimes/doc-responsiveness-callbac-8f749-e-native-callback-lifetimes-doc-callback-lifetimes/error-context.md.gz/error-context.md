# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: doc-responsiveness-callbacks.spec.ts >> mobile native callback lifetimes
- Location: e2e/doc-responsiveness-callbacks.spec.ts:109:3

# Error details

```
Test timeout of 420000ms exceeded.
```

```
Error: Callback observation timedOut.
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]:
      - link [ref=e6] [cursor=pointer]:
        - /url: /
        - img "Spinel" [ref=e8]
      - generic [ref=e33]:
        - status "Connection status" [ref=e34]: Online
        - button "Online — connected to Spinel" [ref=e35] [cursor=pointer]
    - button "Browse files" [ref=e38] [cursor=pointer]
    - generic [ref=e40]:
      - radiogroup "Appearance" [ref=e42]:
        - radio "Follow system" [checked] [ref=e43] [cursor=pointer]
        - radio [checked] [aria-hidden] [ref=e46]
        - radio "Light" [ref=e47] [cursor=pointer]
        - radio [aria-hidden] [ref=e50]
        - radio "Dark" [ref=e51] [cursor=pointer]
        - radio [aria-hidden] [ref=e54]
      - link "Your profile" [ref=e55] [cursor=pointer]:
        - /url: /profile
  - main [ref=e63]:
    - region "Your files" [ref=e64]:
      - generic [ref=e65]:
        - heading "My files" [level=1] [ref=e66]
        - generic [ref=e67]:
          - button "More actions for My files" [ref=e68] [cursor=pointer]: ···
          - button "New" [ref=e69] [cursor=pointer]
      - region "Search your workspace" [ref=e70]:
        - generic [ref=e71]:
          - generic [ref=e72]:
            - generic [ref=e73]:
              - text: Search files
              - searchbox "Search files" [ref=e74]
            - button "Search options" [ref=e75] [cursor=pointer]
            - radiogroup "File view" [ref=e76]:
              - radio "List" [checked] [ref=e77] [cursor=pointer]
              - radio [checked] [aria-hidden] [ref=e79]
              - radio "Grid" [ref=e80] [cursor=pointer]
              - radio [aria-hidden] [ref=e86]
          - group [ref=e87]:
            - generic "Search help" [ref=e88] [cursor=pointer]
        - paragraph [ref=e89]:
          - text: "Searching:"
          - strong [ref=e90]: All accessible files
      - list "Folder contents" [ref=e92]:
        - listitem [ref=e93]:
          - button "Sustained typing Doc" [ref=e94] [cursor=pointer]:
            - generic [aria-hidden] [ref=e96]: 🍀
            - generic [ref=e97]:
              - strong [ref=e98]: Sustained typing
              - generic [ref=e99]:
                - generic [ref=e100]: Doc
                - generic [ref=e111]: Owner
          - time [ref=e113]: 11/14/2026
          - button "More actions for Sustained typing" [ref=e115] [cursor=pointer]: ···
        - listitem [ref=e116]:
          - button "Trash Recently deleted files" [ref=e117] [cursor=pointer]:
            - generic [ref=e122]:
              - strong [ref=e123]: Trash
              - generic [ref=e124]: Recently deleted files
```

# Test source

```ts
  17  | } from './doc-responsiveness-callback-trace.ts';
  18  | import { fixture, focusEmptyDoc, exactText, saved, online } from './doc-responsiveness-fixture.ts';
  19  | import {
  20  |   callbackProgress,
  21  |   persistCallbackManifest,
  22  |   settleCallbackObservation,
  23  | } from './doc-responsiveness-callback-progress.ts';
  24  | import type { CallbackObservation } from './doc-responsiveness-callback-progress.ts';
  25  | import { observeInput, readDocResponsiveness } from './doc-responsiveness.ts';
  26  | import { convertDocCallbackTrace } from './doc-responsiveness-callback-converter.ts';
  27  | import { verifyDocTraceProcessor } from '../scripts/ci/doc-trace-processor.ts';
  28  | 
  29  | // Separate traced observations preserve all existing unprofiled SPN-108 gates.
  30  | const paragraphs = Array.from(
  31  |   { length: 16 },
  32  |   (_, index) =>
  33  |     `Line ${index + 1}: Read the whole paragraph, including the far right edge. ` +
  34  |     'Keep the original page size and all of this text when navigating.',
  35  | );
  36  | const expectedText = paragraphs.join('\r') + '\r\n';
  37  | const expectedKeydowns = 2086;
  38  | const hash = (bytes: string | Buffer) => createHash('sha256').update(bytes).digest('hex');
  39  | const baseline = process.env.SPN113_BASELINE === '1';
  40  | const categories = DOC_CALLBACK_TRACE_SETTINGS.traceConfig.includedCategories;
  41  | const harnessPaths = [
  42  |   'e2e/doc-responsiveness-callbacks.spec.ts',
  43  |   'e2e/doc-responsiveness-callback-sources.ts',
  44  |   'e2e/doc-responsiveness-callback-trace.ts',
  45  |   'e2e/doc-responsiveness-callback-proto.ts',
  46  |   'e2e/doc-responsiveness-callback-converter.ts',
  47  |   'scripts/ci/doc-trace-processor.ts',
  48  |   'e2e/doc-responsiveness-callback-progress.ts',
  49  |   'e2e/doc-responsiveness-fixture.ts',
  50  |   'e2e/doc-responsiveness.ts',
  51  |   'scripts/ci/doc-callback-lifetimes.ts',
  52  |   'web/docResponsivenessEvidence.ts',
  53  |   'src/ui/docIdleEpisode.ts',
  54  |   'src/ui/nativeDocFlush.ts',
  55  |   'src/ui/nativeDocFlushDiagnostic.ts',
  56  |   'playwright.config.ts',
  57  |   'package-lock.json',
  58  | ];
  59  | 
  60  | interface SelectionEvidence {
  61  |   unitId: string;
  62  |   start?: number;
  63  |   end?: number;
  64  |   anchor: { visible: boolean; width: number; height: number } | null;
  65  |   scale: { x: number; y: number };
  66  |   commands: Array<{ id: string; unitId?: string; zoomRatio?: number }>;
  67  | }
  68  | 
  69  | async function selection(page: Page) {
  70  |   return page.evaluate(() => {
  71  |     let result: SelectionEvidence | null = null;
  72  |     const receive = (event: Event) => {
  73  |       result = (event as CustomEvent<SelectionEvidence>).detail;
  74  |     };
  75  |     window.addEventListener('spinel-doc-selection-evidence', receive);
  76  |     try {
  77  |       window.dispatchEvent(new Event('spinel-doc-selection-read'));
  78  |     } finally {
  79  |       window.removeEventListener('spinel-doc-selection-evidence', receive);
  80  |     }
  81  |     return result;
  82  |   }) as Promise<SelectionEvidence | null>;
  83  | }
  84  | 
  85  | const observations = new Map<TestInfo, CallbackObservation>();
  86  | // Playwright runs this even when its deadline interrupts the test body. No page
  87  | // request or async trace collection can prevent this terminal checkpoint.
  88  | // Playwright requires a destructured fixture argument; this hook needs no browser request.
  89  | // oxlint-disable-next-line no-empty-pattern
  90  | test.afterEach(async ({}, info) => {
  91  |   const observation = observations.get(info);
  92  |   if (!observation) return;
  93  |   try {
  94  |     if (info.status !== 'passed') {
  95  |       // This reduces the separate teardown allowance, never extends acceptance.
  96  |       info.setTimeout(30_000);
  97  |     }
  98  |     await settleCallbackObservation(observation, info.status ?? 'unknown');
  99  |   } finally {
  100 |     observation.detach();
  101 |     observations.delete(info);
  102 |   }
  103 |   if (info.status === 'passed' && observation.progress.persistenceFailure)
  104 |     throw new Error('Callback progress evidence could not be persisted.');
  105 | });
  106 | 
  107 | test.describe.configure({ retries: 0, mode: 'default' });
  108 | for (const preset of ['desktop', 'mobile'] as const)
  109 |   test(`${preset} native callback lifetimes`, async ({ browser, baseURL }, info) => {
  110 |     test.setTimeout(420_000);
  111 |     const progress = callbackProgress(info.outputPath('spn134-progress.json'));
  112 |     const controller = new AbortController();
  113 |     const observation: NonNullable<ReturnType<typeof observations.get>> = {
  114 |       progress,
  115 |       detach: () => {},
  116 |       abort: () =>
> 117 |         controller.abort(new Error(`Callback observation ${info.status ?? 'interrupted'}.`)),
      |                          ^ Error: Callback observation timedOut.
  118 |       interrupt: async () => {},
  119 |     };
  120 |     observations.set(info, observation);
  121 |     const running = (async () => {
  122 |       const converter = process.env.SPINEL_TRACE_PROCESSOR;
  123 |       if (!converter) throw new Error('Missing explicitly prepared callback trace converter.');
  124 |       const converterAuthority = await verifyDocTraceProcessor(converter);
  125 |       const mobile = preset === 'mobile';
  126 |       const f = await fixture(browser, baseURL!, info, mobile, controller.signal);
  127 |       let detachPromise: Promise<void> | undefined;
  128 |       let fixtureClosePromise: Promise<void> | undefined;
  129 |       let cdp: Awaited<ReturnType<typeof f.first.newCDPSession>> | undefined;
  130 |       const detachSession = () => {
  131 |         if (!cdp) return Promise.resolve();
  132 |         if (!detachPromise) {
  133 |           progress.phase('cdp-detach');
  134 |           detachPromise = cdp.detach();
  135 |         }
  136 |         return detachPromise;
  137 |       };
  138 |       const closeFixture = () => {
  139 |         if (!fixtureClosePromise) {
  140 |           progress.cleanup();
  141 |           fixtureClosePromise = f.close().then(() => {
  142 |             progress.phase('fixture-cleanup-complete');
  143 |           });
  144 |         }
  145 |         return fixtureClosePromise;
  146 |       };
  147 |       observation.interrupt = () => Promise.allSettled([detachSession(), closeFixture()]);
  148 |       try {
  149 |         // One measured renderer. The existing responsiveness suite separately keeps
  150 |         // all two-editor convergence, Undo/Redo, renewed-input and permission gates.
  151 |         await f.second.close();
  152 |         const page = f.page;
  153 |         const onCrash = () => progress.lifecycle('page-crash');
  154 |         const onPageClose = () => progress.lifecycle('page-close');
  155 |         const onContextClose = () => progress.lifecycle('context-close');
  156 |         const onDisconnected = () => progress.lifecycle('browser-disconnected');
  157 |         page.on('crash', onCrash);
  158 |         page.on('close', onPageClose);
  159 |         f.first.on('close', onContextClose);
  160 |         browser.on('disconnected', onDisconnected);
  161 |         observation.detach = () => {
  162 |           page.off('crash', onCrash);
  163 |           page.off('close', onPageClose);
  164 |           f.first.off('close', onContextClose);
  165 |           browser.off('disconnected', onDisconnected);
  166 |         };
  167 |         const activeCdp = await page.context().newCDPSession(page);
  168 |         cdp = activeCdp;
  169 |         controller.signal.throwIfAborted();
  170 |         let tracing = false;
  171 |         let frameId = '';
  172 |         let failure: unknown;
  173 |         let finishInput: Awaited<ReturnType<typeof observeInput>> | undefined;
  174 |         const output = info.outputPath('spn113-evidence.json');
  175 |         const evidence: Record<string, unknown> = {
  176 |           schema: 2,
  177 |           cleanup: { sessionDetached: false, fixtureClosed: false },
  178 |           role: baseline ? 'baselineObservation' : 'candidate',
  179 |           preset,
  180 |           attempt: info.retry,
  181 |           runner: {
  182 |             run: process.env.GITHUB_RUN_ID ?? null,
  183 |             attempt: process.env.GITHUB_RUN_ATTEMPT ?? null,
  184 |             name: process.env.RUNNER_NAME ?? 'local',
  185 |           },
  186 |           source: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
  187 |           dirtyPaths: execFileSync('git', ['status', '--porcelain'], { encoding: 'utf8' }).trim(),
  188 |           browser: browser.version(),
  189 |           runtime: process.version,
  190 |           playwright: JSON.parse(
  191 |             await readFile('node_modules/@playwright/test/package.json', 'utf8'),
  192 |           ).version,
  193 |           harnessSha256: Object.fromEntries(
  194 |             await Promise.all(harnessPaths.map(async (path) => [path, hash(await readFile(path))])),
  195 |           ),
  196 |           fixture: {
  197 |             paragraphs: 16,
  198 |             typedCharacters: 2071,
  199 |             enterKeys: 15,
  200 |             nativeKeydowns: expectedKeydowns,
  201 |             nativeTextLength: expectedText.length,
  202 |             sha256: hash(expectedText),
  203 |             input: 'keyboard.type, zero requested delay; Enter between all sixteen paragraphs',
  204 |           },
  205 |           instrumentation: {
  206 |             converterAuthority,
  207 |             categories,
  208 |             ...DOC_CALLBACK_TRACE_SETTINGS,
  209 |             storage: DOC_CALLBACK_TRACE_STORAGE,
  210 |             sourceMaps: 'hidden; exact built bundle source content',
  211 |             cpuThrottle: mobile ? 4 : 1,
  212 |             mountedEditors: 1,
  213 |             viewport: mobile ? { width: 390, height: 844 } : { width: 1440, height: 1000 },
  214 |             touch: mobile,
  215 |             deviceScaleFactor: 1,
  216 |             playwrightTrace: false,
  217 |             latencyBudgetsEnforced: false,
```