const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./OfflineViewer-ChPNJZlh.js","./rolldown-runtime-sJBDdmOt.js","./iframe-DWuaBe0G.js","./preload-helper-2GovK0wV.js","./iframe-mgzSPPzi.css","./runtime-CVQXCeMv.js","./offlineStore-DaXuz41F.js","./es-CiDtaHHR.js","./ProfileIcon-W7m9hFg9.js","./appearance-DZlA4KQB.js","./emoji-D4-LI5S6.js","./workspace-qGa9Un5K.js","./checkpoint-DOmrlApW.js","./download-DUdFm8Va.js","./maintenanceFetch-CDYvbqP4.js","./documentAccess-dBMpAeSF.js","./DocEditor-z-U1z_Mw.js","./lib-BDI0EMBO.js","./es-u6eIf-Dy.js","./es-TK9smiUK.js","./floating-ui.react-dom-BszG6aoE.js","./react-dom-COkRlRxm.js","./client-Ds-n6ge3.js","./editorTheme-De1eR7Wg.js","./autofill-double-icon-Dp1PEW_V.js","./es-Bx7c0sHl.js","./en-US-CcLYWxHQ.js","./lib-Cj-7oXXK.css","./doc-formulas-_X1zy9oz.js","./docPreset-DdVOJnsp.js","./documentReady-B0sk9BA-.js","./documentReady-svcR7Vps.css","./docPreset-DMXBypQZ.css","./facade-YSJWuZhE.js","./EditorFrame-T_eCwHG1.js","./GemLogo-bToLmXL5.js","./gemGeometry-CCewQaPB.js","./Appearance-DnHrzb92.js","./Controls-BVCMZaNu.js","./EntityIcon-mDU0dmYc.js","./PopoverClose-DKuSBWHl.js","./Controls-6GPmlRwP.css","./ProfileSettings-lSaCCQrU.js","./api-BuPca0Pz.js","./dashboardNavigation-ByXR0CuS.js","./profile-BQR24URV.js","./profile-DeEBLEXH.css","./Appearance-DXI6v1kJ.css","./ConnectionStatus-J8_TN4FZ.js","./editorFrame-iBNWeN3I.js","./editorFrame-C38zpcVS.css","./Collaborators-M_v0IaEs.js","./facade-Cxp4L4aA.js","./PresenceLabel-D8dTLxiS.js","./SaveStatus-bK0sk6cI.js","./SaveStatus-mVcC3r32.css","./nativeCopy-CfiIOsHs.js","./snapshotIdentity-CGJHxBlR.js","./portable-kkPWuy9t.js","./creation-BDaL5umO.js","./CopyFile-ExYJf_ec.js","./fileDialog-CfmkpWpi.js","./fileDialog-BUnPxS8B.css","./CopyFile-BQQaXgft.css","./guestRevocation-DqJg0TCz.js","./sync-client-DPP92foi.js","./es-lZu3t79K.js","./es-UbcnSMdw.js","./DocFormulas-DegttTN9.js","./useDiagnostics-BaG_cYGL.js","./DocFormulas-fBFn_ung.css","./EditorTools-C2FRjXFu.js","./VersionNames-Bu_iGRxk.js","./historyApi-D4O0w-mV.js","./PdfExport-CAXKczNK.js","./FileExports-wyYO1ySQ.js","./editorReady-CMid4ivx.js","./nativeSyncPermissions-DhYqvTBY.js","./SheetEditor-Dep_3I-1.js","./sheetPreset-DuNTjF9a.js","./sheetPreset-BqfQ6-l-.css","./presetStyles-Cavt-NOm.js","./presetStyles-C90jFwF1.css"])))=>i.map(i=>d[i]);
import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{n as t,t as n}from"./preload-helper-2GovK0wV.js";import{b as r,n as i}from"./iframe-DWuaBe0G.js";import{n as a,t as o}from"./EntityIcon-mDU0dmYc.js";import{n as s,s as c}from"./Controls-BVCMZaNu.js";import{a as l,l as u,o as d}from"./Appearance-DnHrzb92.js";import{n as f,r as p,u as m}from"./spaceNavigation-Bs_dmASv.js";import{n as h,t as g}from"./EditorFrame-T_eCwHG1.js";import{a as _,i as v,n as y,r as b}from"./spaceCopies-GP9etmxW.js";import"./spaceOffline-DQzHufaA.js";import{n as x,t as S}from"./SpaceShell-Dn6MzI7j.js";function C({local:e,user:t,onExit:n,onProfile:r}){let[i,a]=(0,E.useState)(()=>p(location)),[o,s]=(0,E.useState)(null),[c,l]=(0,E.useState)(!1),u=_(t,e,()=>null);return(0,E.useEffect)(()=>{if(!c)return;let e=e=>{e.preventDefault(),e.returnValue=``};return window.addEventListener(`beforeunload`,e),()=>window.removeEventListener(`beforeunload`,e)},[c]),(0,E.useEffect)(()=>{let e=()=>a(p(location));return window.addEventListener(`popstate`,e),()=>window.removeEventListener(`popstate`,e)},[]),(0,D.jsx)(w,{user:t,local:e,route:i,downloads:u.downloads,onExit:n,onProfile:r,connection:o??`offline`,renderViewer:(e,n)=>(0,D.jsx)(E.Suspense,{fallback:(0,D.jsx)(`p`,{role:`status`,children:`Opening offline copy…`}),children:(0,D.jsx)(O,{accountId:t.id,itemId:e.itemId,spaceId:n,onDirty:l,onConnectionState:s},n+`:`+e.itemId)})},t.id+`:`+e.user.id+`:`+JSON.stringify(i))}function w({local:e,user:t,route:n,downloads:r,onExit:i,onProfile:a,renderViewer:o,connection:s=`offline`}){let c=y({...e,downloads:[...r.values()]},t.id,n),[l,u]=(0,E.useState)(()=>c.selected?c:null);(0,E.useLayoutEffect)(()=>{!l&&c.selected&&u(c)},[l,c]);let d=c;if(l?.selected&&l.spaceId&&e.user.id===t.id){let e=r.get(l.selected.itemId),t=e?.spaceId===l.spaceId?e:{...l.selected,available:!1,problem:`The saved device copy could not be verified.`},n=b(r.values(),l.spaceId);n.some(e=>e.itemId===t.itemId)||n.push(t),d={...l,copies:b(n,l.spaceId),selected:t}}return(0,D.jsx)(T,{user:t,selection:d,onExit:i,onProfile:a,connection:s,viewer:d.selected&&d.spaceId?o(l?.selected??d.selected,d.spaceId):null})}function T({user:e,selection:t,onExit:n,onProfile:r,viewer:i,connection:a=`offline`}){let{root:c,spaceId:d,copies:f,selected:p,problem:h}=t,_=u(c?.appearance?.accent),v=p?.available===!1,y=v?`Needs attention`:p?.readOnly?`Read only`:`On this device`,b=(0,D.jsxs)(S,{user:e,connection:a,documentOpen:!!p,onExit:n,onProfile:r,navigation:d&&f.length?e=>(0,D.jsxs)(`nav`,{className:`space-navigation`,"aria-label":`Prepared pages`,children:[(0,D.jsx)(`h2`,{children:`On this device`}),(0,D.jsx)(`p`,{className:`space-copy-caption`,children:c?.name??`This Space`}),(0,D.jsx)(`div`,{className:`space-tree-scroll`,children:(0,D.jsx)(`ul`,{className:`space-copy-list`,children:f.map(t=>(0,D.jsxs)(`li`,{children:[(0,D.jsxs)(`a`,{className:`space-page-link`,href:m(d,{kind:`page`,id:t.itemId}),"aria-current":t.itemId===p?.itemId?`page`:void 0,onClick:e,children:[(0,D.jsx)(l,{name:t.name,kind:t.kind,appearance:t.appearance,size:20}),(0,D.jsx)(`span`,{children:t.name})]}),t.available===!1&&(0,D.jsx)(`span`,{className:`sp-muted`,children:`Needs attention`})]},t.itemId))})}),(0,D.jsx)(`p`,{className:`space-copy-caption`,children:`Reconnect to browse all pages in this Space.`})]}):void 0,children:[(0,D.jsxs)(`header`,{className:`space-page-header`,hidden:!(!p||h),children:[(0,D.jsx)(o,{kind:p?.kind??`space`,size:32}),(0,D.jsxs)(`div`,{className:`space-page-identity`,children:[(0,D.jsx)(`p`,{children:c?`Space · `+c.name:`Space`}),(0,D.jsx)(`h1`,{children:p?.name??(h===`index`?`Your Spaces`:c?.name??`Space unavailable`)})]}),p&&(0,D.jsx)(`span`,{className:`space-access`,children:y})]}),h?(0,D.jsxs)(`div`,{className:`space-content space-offline-empty`,children:[(0,D.jsx)(`p`,{role:`status`,children:k[h]}),(0,D.jsx)(s,{onClick:n,children:`My files`})]}):p&&(0,D.jsxs)(D.Fragment,{children:[(0,D.jsx)(`p`,{className:`space-limitations`,role:v?`status`:void 0,"aria-label":v?`Device copy status`:void 0,children:v?(0,D.jsxs)(D.Fragment,{children:[p.problem??`The saved device copy could not be verified.`,` Keep this page open while you save or recover your work.`]}):(0,D.jsxs)(D.Fragment,{children:[`Prepared `,new Date(p.downloadedAt).toLocaleString(),`. Reconnect to get the latest changes.`]})}),(0,D.jsx)(`div`,{className:`space-native-editor space-offline-viewer`,style:_,children:i})]})]});return p&&!h?(0,D.jsx)(g,{appearanceTarget:{id:p.itemId,name:p.name,kind:p.kind,spaceId:d,appearance:p.appearance},appearanceDisabled:!0,offlineAccountId:e.id,name:p.name,contextLabel:c?`Space · ${c.name}`:void 0,connection:a,access:y,onBack:n,backLabel:`My files`,children:b}):b}var E,D,O,k;function A(){return(A=e((()=>{d(),h(),E=r(),a(),c(),x(),v(),f(),D=i(),t(),O=(0,E.lazy)(()=>n(()=>import(`./OfflineViewer-ChPNJZlh.js`).then(e=>({default:e.OfflineViewer})),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82]),import.meta.url)),k={account:`These offline copies belong to another account. Sign in with the account that prepared this device.`,index:`Reconnect to browse your Spaces. Pages you prepared on this device can be opened from their Space links.`,route:`This Space link is unavailable. Reconnect and open the Space from My files.`,trash:`Space Trash needs a connection. You can still open the pages prepared on this device.`,missing:`This page needs a connection. It has not been prepared in this Space on this device.`,empty:`No pages from this Space are prepared on this device. Reconnect and make a Doc or Sheet available offline.`},C.__docgenInfo={description:``,methods:[],displayName:`OfflineSpace`,props:{local:{required:!0,tsType:{name:`signature`,type:`object`,raw:`{
  user: OfflineUser;
  catalog: OfflineCatalog;
  downloads: OfflineDownload[];
}`,signature:{properties:[{key:`user`,value:{name:`signature`,type:`object`,raw:`{ id: string; name: string }`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`name`,value:{name:`string`,required:!0}}]},required:!0}},{key:`catalog`,value:{name:`signature`,type:`object`,raw:`{
  syncedAt: number;
  /** Creation acknowledgements committed before the full-list request began; absent means zero. */
  creationRevision?: number;
  /** The shared list has its own request/acknowledgement cutoff. */
  sharedCreationRevision?: number;
  /** Accepted metadata awaiting its own authoritative list, even after device removal. */
  creationMetadata?: { item: WorkspaceItem; revision: number }[];
  items: FileItem[];
  shared: FileItem[];
  /** The last-loaded ancestors, item and children for each opened folder or item. */
  views: Record<string, FileItem[]>;
}`,signature:{properties:[{key:`syncedAt`,value:{name:`number`,required:!0}},{key:`creationRevision`,value:{name:`number`,required:!1},description:`Creation acknowledgements committed before the full-list request began; absent means zero.`},{key:`sharedCreationRevision`,value:{name:`number`,required:!1},description:`The shared list has its own request/acknowledgement cutoff.`},{key:`creationMetadata`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{ item: WorkspaceItem; revision: number }`,signature:{properties:[{key:`item`,value:{name:`WorkspaceItem`,required:!0}},{key:`revision`,value:{name:`number`,required:!0}}]}}],raw:`{ item: WorkspaceItem; revision: number }[]`,required:!1},description:`Accepted metadata awaiting its own authoritative list, even after device removal.`},{key:`items`,value:{name:`Array`,elements:[{name:`union`,raw:`WorkspaceItem | SpaceFile`,elements:[{name:`WorkspaceItem`},{name:`intersection`,raw:`Omit<WorkspaceItem, 'kind'> & { kind: 'space' }`,elements:[{name:`Omit`,elements:[{name:`WorkspaceItem`},{name:`literal`,value:`'kind'`}],raw:`Omit<WorkspaceItem, 'kind'>`},{name:`signature`,type:`object`,raw:`{ kind: 'space' }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'space'`,required:!0}}]}}]}]}],raw:`FileItem[]`,required:!0}},{key:`shared`,value:{name:`Array`,elements:[{name:`union`,raw:`WorkspaceItem | SpaceFile`,elements:[{name:`WorkspaceItem`},{name:`intersection`,raw:`Omit<WorkspaceItem, 'kind'> & { kind: 'space' }`,elements:[{name:`Omit`,elements:[{name:`WorkspaceItem`},{name:`literal`,value:`'kind'`}],raw:`Omit<WorkspaceItem, 'kind'>`},{name:`signature`,type:`object`,raw:`{ kind: 'space' }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'space'`,required:!0}}]}}]}]}],raw:`FileItem[]`,required:!0}},{key:`views`,value:{name:`Record`,elements:[{name:`string`},{name:`Array`,elements:[{name:`union`,raw:`WorkspaceItem | SpaceFile`,elements:[{name:`WorkspaceItem`},{name:`intersection`,raw:`Omit<WorkspaceItem, 'kind'> & { kind: 'space' }`,elements:[{name:`Omit`,elements:[{name:`WorkspaceItem`},{name:`literal`,value:`'kind'`}],raw:`Omit<WorkspaceItem, 'kind'>`},{name:`signature`,type:`object`,raw:`{ kind: 'space' }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'space'`,required:!0}}]}}]}]}],raw:`FileItem[]`}],raw:`Record<string, FileItem[]>`,required:!0},description:`The last-loaded ancestors, item and children for each opened folder or item.`}]},required:!0}},{key:`downloads`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  appearance?: ItemAppearance;
  itemId: string;
  spaceId?: string;
  name: string;
  kind: 'sheet' | 'doc';
  readOnly: boolean;
  revision: number;
  downloadedAt: number;
  pending?: boolean;
  /** A record alone is not proof that its images and public runtime still exist. */
  available?: boolean;
  problem?: string;
  uncertain?: boolean;
  /** A durable new file which has not yet been acknowledged by the server. */
  creation?: {
    parentId: string | null;
    createdAt: number;
    access?: Exclude<ItemAccess, 'viewer'>;
    ownerName?: string;
    createdByName?: string;
    problem?: string;
    canRelocate?: boolean;
  };
  /** Last acknowledged metadata for a locally created file, independent of stale catalogs. */
  createdFile?: WorkspaceItem;
  /** Monotonic local acknowledgement order; later full-list requests supersede this fallback. */
  createdFileRevision?: number;
}`,signature:{properties:[{key:`appearance`,value:{name:`ItemAppearance`,required:!1}},{key:`itemId`,value:{name:`string`,required:!0}},{key:`spaceId`,value:{name:`string`,required:!1}},{key:`name`,value:{name:`string`,required:!0}},{key:`kind`,value:{name:`union`,raw:`'sheet' | 'doc'`,elements:[{name:`literal`,value:`'sheet'`},{name:`literal`,value:`'doc'`}],required:!0}},{key:`readOnly`,value:{name:`boolean`,required:!0}},{key:`revision`,value:{name:`number`,required:!0}},{key:`downloadedAt`,value:{name:`number`,required:!0}},{key:`pending`,value:{name:`boolean`,required:!1}},{key:`available`,value:{name:`boolean`,required:!1},description:`A record alone is not proof that its images and public runtime still exist.`},{key:`problem`,value:{name:`string`,required:!1}},{key:`uncertain`,value:{name:`boolean`,required:!1}},{key:`creation`,value:{name:`signature`,type:`object`,raw:`{
  parentId: string | null;
  createdAt: number;
  access?: Exclude<ItemAccess, 'viewer'>;
  ownerName?: string;
  createdByName?: string;
  problem?: string;
  canRelocate?: boolean;
}`,signature:{properties:[{key:`parentId`,value:{name:`union`,raw:`string | null`,elements:[{name:`string`},{name:`null`}],required:!0}},{key:`createdAt`,value:{name:`number`,required:!0}},{key:`access`,value:{name:`Exclude`,elements:[{name:`union`,raw:`GrantRole | 'owner'`,elements:[{name:`union`,raw:`GuestRole | 'admin'`,elements:[{name:`union`,raw:`'viewer' | 'editor'`,elements:[{name:`literal`,value:`'viewer'`},{name:`literal`,value:`'editor'`}]},{name:`literal`,value:`'admin'`}]},{name:`literal`,value:`'owner'`}]},{name:`literal`,value:`'viewer'`}],raw:`Exclude<ItemAccess, 'viewer'>`,required:!1}},{key:`ownerName`,value:{name:`string`,required:!1}},{key:`createdByName`,value:{name:`string`,required:!1}},{key:`problem`,value:{name:`string`,required:!1}},{key:`canRelocate`,value:{name:`boolean`,required:!1}}]},required:!1},description:`A durable new file which has not yet been acknowledged by the server.`},{key:`createdFile`,value:{name:`WorkspaceItem`,required:!1},description:`Last acknowledged metadata for a locally created file, independent of stale catalogs.`},{key:`createdFileRevision`,value:{name:`number`,required:!1},description:`Monotonic local acknowledgement order; later full-list requests supersede this fallback.`}]}}],raw:`OfflineDownload[]`,required:!0}}]}},description:``},user:{required:!0,tsType:{name:`SpaceUser`},description:``}}},w.__docgenInfo={description:`A route opens once; later inventory changes affect labels, not its editor lifetime.`,methods:[],displayName:`OfflineSpaceRoute`,props:{local:{required:!0,tsType:{name:`signature`,type:`object`,raw:`{
  user: OfflineUser;
  catalog: OfflineCatalog;
  downloads: OfflineDownload[];
}`,signature:{properties:[{key:`user`,value:{name:`signature`,type:`object`,raw:`{ id: string; name: string }`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`name`,value:{name:`string`,required:!0}}]},required:!0}},{key:`catalog`,value:{name:`signature`,type:`object`,raw:`{
  syncedAt: number;
  /** Creation acknowledgements committed before the full-list request began; absent means zero. */
  creationRevision?: number;
  /** The shared list has its own request/acknowledgement cutoff. */
  sharedCreationRevision?: number;
  /** Accepted metadata awaiting its own authoritative list, even after device removal. */
  creationMetadata?: { item: WorkspaceItem; revision: number }[];
  items: FileItem[];
  shared: FileItem[];
  /** The last-loaded ancestors, item and children for each opened folder or item. */
  views: Record<string, FileItem[]>;
}`,signature:{properties:[{key:`syncedAt`,value:{name:`number`,required:!0}},{key:`creationRevision`,value:{name:`number`,required:!1},description:`Creation acknowledgements committed before the full-list request began; absent means zero.`},{key:`sharedCreationRevision`,value:{name:`number`,required:!1},description:`The shared list has its own request/acknowledgement cutoff.`},{key:`creationMetadata`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{ item: WorkspaceItem; revision: number }`,signature:{properties:[{key:`item`,value:{name:`WorkspaceItem`,required:!0}},{key:`revision`,value:{name:`number`,required:!0}}]}}],raw:`{ item: WorkspaceItem; revision: number }[]`,required:!1},description:`Accepted metadata awaiting its own authoritative list, even after device removal.`},{key:`items`,value:{name:`Array`,elements:[{name:`union`,raw:`WorkspaceItem | SpaceFile`,elements:[{name:`WorkspaceItem`},{name:`intersection`,raw:`Omit<WorkspaceItem, 'kind'> & { kind: 'space' }`,elements:[{name:`Omit`,elements:[{name:`WorkspaceItem`},{name:`literal`,value:`'kind'`}],raw:`Omit<WorkspaceItem, 'kind'>`},{name:`signature`,type:`object`,raw:`{ kind: 'space' }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'space'`,required:!0}}]}}]}]}],raw:`FileItem[]`,required:!0}},{key:`shared`,value:{name:`Array`,elements:[{name:`union`,raw:`WorkspaceItem | SpaceFile`,elements:[{name:`WorkspaceItem`},{name:`intersection`,raw:`Omit<WorkspaceItem, 'kind'> & { kind: 'space' }`,elements:[{name:`Omit`,elements:[{name:`WorkspaceItem`},{name:`literal`,value:`'kind'`}],raw:`Omit<WorkspaceItem, 'kind'>`},{name:`signature`,type:`object`,raw:`{ kind: 'space' }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'space'`,required:!0}}]}}]}]}],raw:`FileItem[]`,required:!0}},{key:`views`,value:{name:`Record`,elements:[{name:`string`},{name:`Array`,elements:[{name:`union`,raw:`WorkspaceItem | SpaceFile`,elements:[{name:`WorkspaceItem`},{name:`intersection`,raw:`Omit<WorkspaceItem, 'kind'> & { kind: 'space' }`,elements:[{name:`Omit`,elements:[{name:`WorkspaceItem`},{name:`literal`,value:`'kind'`}],raw:`Omit<WorkspaceItem, 'kind'>`},{name:`signature`,type:`object`,raw:`{ kind: 'space' }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'space'`,required:!0}}]}}]}]}],raw:`FileItem[]`}],raw:`Record<string, FileItem[]>`,required:!0},description:`The last-loaded ancestors, item and children for each opened folder or item.`}]},required:!0}},{key:`downloads`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  appearance?: ItemAppearance;
  itemId: string;
  spaceId?: string;
  name: string;
  kind: 'sheet' | 'doc';
  readOnly: boolean;
  revision: number;
  downloadedAt: number;
  pending?: boolean;
  /** A record alone is not proof that its images and public runtime still exist. */
  available?: boolean;
  problem?: string;
  uncertain?: boolean;
  /** A durable new file which has not yet been acknowledged by the server. */
  creation?: {
    parentId: string | null;
    createdAt: number;
    access?: Exclude<ItemAccess, 'viewer'>;
    ownerName?: string;
    createdByName?: string;
    problem?: string;
    canRelocate?: boolean;
  };
  /** Last acknowledged metadata for a locally created file, independent of stale catalogs. */
  createdFile?: WorkspaceItem;
  /** Monotonic local acknowledgement order; later full-list requests supersede this fallback. */
  createdFileRevision?: number;
}`,signature:{properties:[{key:`appearance`,value:{name:`ItemAppearance`,required:!1}},{key:`itemId`,value:{name:`string`,required:!0}},{key:`spaceId`,value:{name:`string`,required:!1}},{key:`name`,value:{name:`string`,required:!0}},{key:`kind`,value:{name:`union`,raw:`'sheet' | 'doc'`,elements:[{name:`literal`,value:`'sheet'`},{name:`literal`,value:`'doc'`}],required:!0}},{key:`readOnly`,value:{name:`boolean`,required:!0}},{key:`revision`,value:{name:`number`,required:!0}},{key:`downloadedAt`,value:{name:`number`,required:!0}},{key:`pending`,value:{name:`boolean`,required:!1}},{key:`available`,value:{name:`boolean`,required:!1},description:`A record alone is not proof that its images and public runtime still exist.`},{key:`problem`,value:{name:`string`,required:!1}},{key:`uncertain`,value:{name:`boolean`,required:!1}},{key:`creation`,value:{name:`signature`,type:`object`,raw:`{
  parentId: string | null;
  createdAt: number;
  access?: Exclude<ItemAccess, 'viewer'>;
  ownerName?: string;
  createdByName?: string;
  problem?: string;
  canRelocate?: boolean;
}`,signature:{properties:[{key:`parentId`,value:{name:`union`,raw:`string | null`,elements:[{name:`string`},{name:`null`}],required:!0}},{key:`createdAt`,value:{name:`number`,required:!0}},{key:`access`,value:{name:`Exclude`,elements:[{name:`union`,raw:`GrantRole | 'owner'`,elements:[{name:`union`,raw:`GuestRole | 'admin'`,elements:[{name:`union`,raw:`'viewer' | 'editor'`,elements:[{name:`literal`,value:`'viewer'`},{name:`literal`,value:`'editor'`}]},{name:`literal`,value:`'admin'`}]},{name:`literal`,value:`'owner'`}]},{name:`literal`,value:`'viewer'`}],raw:`Exclude<ItemAccess, 'viewer'>`,required:!1}},{key:`ownerName`,value:{name:`string`,required:!1}},{key:`createdByName`,value:{name:`string`,required:!1}},{key:`problem`,value:{name:`string`,required:!1}},{key:`canRelocate`,value:{name:`boolean`,required:!1}}]},required:!1},description:`A durable new file which has not yet been acknowledged by the server.`},{key:`createdFile`,value:{name:`WorkspaceItem`,required:!1},description:`Last acknowledged metadata for a locally created file, independent of stale catalogs.`},{key:`createdFileRevision`,value:{name:`number`,required:!1},description:`Monotonic local acknowledgement order; later full-list requests supersede this fallback.`}]}}],raw:`OfflineDownload[]`,required:!0}}]}},description:``},user:{required:!0,tsType:{name:`SpaceUser`},description:``},route:{required:!0,tsType:{name:`union`,raw:`| { kind: 'index' }
| { kind: 'space'; spaceId: string; selection: SpaceSelection }
| { kind: 'unavailable' }`,elements:[{name:`signature`,type:`object`,raw:`{ kind: 'index' }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'index'`,required:!0}}]}},{name:`signature`,type:`object`,raw:`{ kind: 'space'; spaceId: string; selection: SpaceSelection }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'space'`,required:!0}},{key:`spaceId`,value:{name:`string`,required:!0}},{key:`selection`,value:{name:`union`,raw:`{ kind: 'default' } | { kind: 'page'; id: string } | { kind: 'trash' }`,elements:[{name:`signature`,type:`object`,raw:`{ kind: 'default' }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'default'`,required:!0}}]}},{name:`signature`,type:`object`,raw:`{ kind: 'page'; id: string }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'page'`,required:!0}},{key:`id`,value:{name:`string`,required:!0}}]}},{name:`signature`,type:`object`,raw:`{ kind: 'trash' }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'trash'`,required:!0}}]}}],required:!0}}]}},{name:`signature`,type:`object`,raw:`{ kind: 'unavailable' }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'unavailable'`,required:!0}}]}}]},description:``},downloads:{required:!0,tsType:{name:`ReadonlyMap`,elements:[{name:`string`},{name:`signature`,type:`object`,raw:`{
  appearance?: ItemAppearance;
  itemId: string;
  spaceId?: string;
  name: string;
  kind: 'sheet' | 'doc';
  readOnly: boolean;
  revision: number;
  downloadedAt: number;
  pending?: boolean;
  /** A record alone is not proof that its images and public runtime still exist. */
  available?: boolean;
  problem?: string;
  uncertain?: boolean;
  /** A durable new file which has not yet been acknowledged by the server. */
  creation?: {
    parentId: string | null;
    createdAt: number;
    access?: Exclude<ItemAccess, 'viewer'>;
    ownerName?: string;
    createdByName?: string;
    problem?: string;
    canRelocate?: boolean;
  };
  /** Last acknowledged metadata for a locally created file, independent of stale catalogs. */
  createdFile?: WorkspaceItem;
  /** Monotonic local acknowledgement order; later full-list requests supersede this fallback. */
  createdFileRevision?: number;
}`,signature:{properties:[{key:`appearance`,value:{name:`ItemAppearance`,required:!1}},{key:`itemId`,value:{name:`string`,required:!0}},{key:`spaceId`,value:{name:`string`,required:!1}},{key:`name`,value:{name:`string`,required:!0}},{key:`kind`,value:{name:`union`,raw:`'sheet' | 'doc'`,elements:[{name:`literal`,value:`'sheet'`},{name:`literal`,value:`'doc'`}],required:!0}},{key:`readOnly`,value:{name:`boolean`,required:!0}},{key:`revision`,value:{name:`number`,required:!0}},{key:`downloadedAt`,value:{name:`number`,required:!0}},{key:`pending`,value:{name:`boolean`,required:!1}},{key:`available`,value:{name:`boolean`,required:!1},description:`A record alone is not proof that its images and public runtime still exist.`},{key:`problem`,value:{name:`string`,required:!1}},{key:`uncertain`,value:{name:`boolean`,required:!1}},{key:`creation`,value:{name:`signature`,type:`object`,raw:`{
  parentId: string | null;
  createdAt: number;
  access?: Exclude<ItemAccess, 'viewer'>;
  ownerName?: string;
  createdByName?: string;
  problem?: string;
  canRelocate?: boolean;
}`,signature:{properties:[{key:`parentId`,value:{name:`union`,raw:`string | null`,elements:[{name:`string`},{name:`null`}],required:!0}},{key:`createdAt`,value:{name:`number`,required:!0}},{key:`access`,value:{name:`Exclude`,elements:[{name:`union`,raw:`GrantRole | 'owner'`,elements:[{name:`union`,raw:`GuestRole | 'admin'`,elements:[{name:`union`,raw:`'viewer' | 'editor'`,elements:[{name:`literal`,value:`'viewer'`},{name:`literal`,value:`'editor'`}]},{name:`literal`,value:`'admin'`}]},{name:`literal`,value:`'owner'`}]},{name:`literal`,value:`'viewer'`}],raw:`Exclude<ItemAccess, 'viewer'>`,required:!1}},{key:`ownerName`,value:{name:`string`,required:!1}},{key:`createdByName`,value:{name:`string`,required:!1}},{key:`problem`,value:{name:`string`,required:!1}},{key:`canRelocate`,value:{name:`boolean`,required:!1}}]},required:!1},description:`A durable new file which has not yet been acknowledged by the server.`},{key:`createdFile`,value:{name:`WorkspaceItem`,required:!1},description:`Last acknowledged metadata for a locally created file, independent of stale catalogs.`},{key:`createdFileRevision`,value:{name:`number`,required:!1},description:`Monotonic local acknowledgement order; later full-list requests supersede this fallback.`}]}}],raw:`ReadonlyMap<string, OfflineDownload>`},description:``},connection:{required:!1,tsType:{name:`union`,raw:`'online' | 'offline' | 'reconnecting'`,elements:[{name:`literal`,value:`'online'`},{name:`literal`,value:`'offline'`},{name:`literal`,value:`'reconnecting'`}]},description:``,defaultValue:{value:`'offline'`,computed:!1}}}},T.__docgenInfo={description:`The real shell and prepared-page list; stories supply a labeled native-viewer fixture.`,methods:[],displayName:`OfflineSpaceView`,props:{user:{required:!0,tsType:{name:`SpaceUser`},description:``},selection:{required:!0,tsType:{name:`signature`,type:`object`,raw:`{
  spaceId: string | null;
  root: SpaceFile | null;
  copies: OfflineDownload[];
  selected: OfflineDownload | null;
  problem: 'account' | 'index' | 'route' | 'trash' | 'missing' | 'empty' | null;
}`,signature:{properties:[{key:`spaceId`,value:{name:`union`,raw:`string | null`,elements:[{name:`string`},{name:`null`}],required:!0}},{key:`root`,value:{name:`union`,raw:`SpaceFile | null`,elements:[{name:`intersection`,raw:`Omit<WorkspaceItem, 'kind'> & { kind: 'space' }`,elements:[{name:`Omit`,elements:[{name:`WorkspaceItem`},{name:`literal`,value:`'kind'`}],raw:`Omit<WorkspaceItem, 'kind'>`},{name:`signature`,type:`object`,raw:`{ kind: 'space' }`,signature:{properties:[{key:`kind`,value:{name:`literal`,value:`'space'`,required:!0}}]}}]},{name:`null`}],required:!0}},{key:`copies`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  appearance?: ItemAppearance;
  itemId: string;
  spaceId?: string;
  name: string;
  kind: 'sheet' | 'doc';
  readOnly: boolean;
  revision: number;
  downloadedAt: number;
  pending?: boolean;
  /** A record alone is not proof that its images and public runtime still exist. */
  available?: boolean;
  problem?: string;
  uncertain?: boolean;
  /** A durable new file which has not yet been acknowledged by the server. */
  creation?: {
    parentId: string | null;
    createdAt: number;
    access?: Exclude<ItemAccess, 'viewer'>;
    ownerName?: string;
    createdByName?: string;
    problem?: string;
    canRelocate?: boolean;
  };
  /** Last acknowledged metadata for a locally created file, independent of stale catalogs. */
  createdFile?: WorkspaceItem;
  /** Monotonic local acknowledgement order; later full-list requests supersede this fallback. */
  createdFileRevision?: number;
}`,signature:{properties:[{key:`appearance`,value:{name:`ItemAppearance`,required:!1}},{key:`itemId`,value:{name:`string`,required:!0}},{key:`spaceId`,value:{name:`string`,required:!1}},{key:`name`,value:{name:`string`,required:!0}},{key:`kind`,value:{name:`union`,raw:`'sheet' | 'doc'`,elements:[{name:`literal`,value:`'sheet'`},{name:`literal`,value:`'doc'`}],required:!0}},{key:`readOnly`,value:{name:`boolean`,required:!0}},{key:`revision`,value:{name:`number`,required:!0}},{key:`downloadedAt`,value:{name:`number`,required:!0}},{key:`pending`,value:{name:`boolean`,required:!1}},{key:`available`,value:{name:`boolean`,required:!1},description:`A record alone is not proof that its images and public runtime still exist.`},{key:`problem`,value:{name:`string`,required:!1}},{key:`uncertain`,value:{name:`boolean`,required:!1}},{key:`creation`,value:{name:`signature`,type:`object`,raw:`{
  parentId: string | null;
  createdAt: number;
  access?: Exclude<ItemAccess, 'viewer'>;
  ownerName?: string;
  createdByName?: string;
  problem?: string;
  canRelocate?: boolean;
}`,signature:{properties:[{key:`parentId`,value:{name:`union`,raw:`string | null`,elements:[{name:`string`},{name:`null`}],required:!0}},{key:`createdAt`,value:{name:`number`,required:!0}},{key:`access`,value:{name:`Exclude`,elements:[{name:`union`,raw:`GrantRole | 'owner'`,elements:[{name:`union`,raw:`GuestRole | 'admin'`,elements:[{name:`union`,raw:`'viewer' | 'editor'`,elements:[{name:`literal`,value:`'viewer'`},{name:`literal`,value:`'editor'`}]},{name:`literal`,value:`'admin'`}]},{name:`literal`,value:`'owner'`}]},{name:`literal`,value:`'viewer'`}],raw:`Exclude<ItemAccess, 'viewer'>`,required:!1}},{key:`ownerName`,value:{name:`string`,required:!1}},{key:`createdByName`,value:{name:`string`,required:!1}},{key:`problem`,value:{name:`string`,required:!1}},{key:`canRelocate`,value:{name:`boolean`,required:!1}}]},required:!1},description:`A durable new file which has not yet been acknowledged by the server.`},{key:`createdFile`,value:{name:`WorkspaceItem`,required:!1},description:`Last acknowledged metadata for a locally created file, independent of stale catalogs.`},{key:`createdFileRevision`,value:{name:`number`,required:!1},description:`Monotonic local acknowledgement order; later full-list requests supersede this fallback.`}]}}],raw:`OfflineDownload[]`,required:!0}},{key:`selected`,value:{name:`union`,raw:`OfflineDownload | null`,elements:[{name:`signature`,type:`object`,raw:`{
  appearance?: ItemAppearance;
  itemId: string;
  spaceId?: string;
  name: string;
  kind: 'sheet' | 'doc';
  readOnly: boolean;
  revision: number;
  downloadedAt: number;
  pending?: boolean;
  /** A record alone is not proof that its images and public runtime still exist. */
  available?: boolean;
  problem?: string;
  uncertain?: boolean;
  /** A durable new file which has not yet been acknowledged by the server. */
  creation?: {
    parentId: string | null;
    createdAt: number;
    access?: Exclude<ItemAccess, 'viewer'>;
    ownerName?: string;
    createdByName?: string;
    problem?: string;
    canRelocate?: boolean;
  };
  /** Last acknowledged metadata for a locally created file, independent of stale catalogs. */
  createdFile?: WorkspaceItem;
  /** Monotonic local acknowledgement order; later full-list requests supersede this fallback. */
  createdFileRevision?: number;
}`,signature:{properties:[{key:`appearance`,value:{name:`ItemAppearance`,required:!1}},{key:`itemId`,value:{name:`string`,required:!0}},{key:`spaceId`,value:{name:`string`,required:!1}},{key:`name`,value:{name:`string`,required:!0}},{key:`kind`,value:{name:`union`,raw:`'sheet' | 'doc'`,elements:[{name:`literal`,value:`'sheet'`},{name:`literal`,value:`'doc'`}],required:!0}},{key:`readOnly`,value:{name:`boolean`,required:!0}},{key:`revision`,value:{name:`number`,required:!0}},{key:`downloadedAt`,value:{name:`number`,required:!0}},{key:`pending`,value:{name:`boolean`,required:!1}},{key:`available`,value:{name:`boolean`,required:!1},description:`A record alone is not proof that its images and public runtime still exist.`},{key:`problem`,value:{name:`string`,required:!1}},{key:`uncertain`,value:{name:`boolean`,required:!1}},{key:`creation`,value:{name:`signature`,type:`object`,raw:`{
  parentId: string | null;
  createdAt: number;
  access?: Exclude<ItemAccess, 'viewer'>;
  ownerName?: string;
  createdByName?: string;
  problem?: string;
  canRelocate?: boolean;
}`,signature:{properties:[{key:`parentId`,value:{name:`union`,raw:`string | null`,elements:[{name:`string`},{name:`null`}],required:!0}},{key:`createdAt`,value:{name:`number`,required:!0}},{key:`access`,value:{name:`Exclude`,elements:[{name:`union`,raw:`GrantRole | 'owner'`,elements:[{name:`union`,raw:`GuestRole | 'admin'`,elements:[{name:`union`,raw:`'viewer' | 'editor'`,elements:[{name:`literal`,value:`'viewer'`},{name:`literal`,value:`'editor'`}]},{name:`literal`,value:`'admin'`}]},{name:`literal`,value:`'owner'`}]},{name:`literal`,value:`'viewer'`}],raw:`Exclude<ItemAccess, 'viewer'>`,required:!1}},{key:`ownerName`,value:{name:`string`,required:!1}},{key:`createdByName`,value:{name:`string`,required:!1}},{key:`problem`,value:{name:`string`,required:!1}},{key:`canRelocate`,value:{name:`boolean`,required:!1}}]},required:!1},description:`A durable new file which has not yet been acknowledged by the server.`},{key:`createdFile`,value:{name:`WorkspaceItem`,required:!1},description:`Last acknowledged metadata for a locally created file, independent of stale catalogs.`},{key:`createdFileRevision`,value:{name:`number`,required:!1},description:`Monotonic local acknowledgement order; later full-list requests supersede this fallback.`}]}},{name:`null`}],required:!0}},{key:`problem`,value:{name:`union`,raw:`'account' | 'index' | 'route' | 'trash' | 'missing' | 'empty' | null`,elements:[{name:`literal`,value:`'account'`},{name:`literal`,value:`'index'`},{name:`literal`,value:`'route'`},{name:`literal`,value:`'trash'`},{name:`literal`,value:`'missing'`},{name:`literal`,value:`'empty'`},{name:`null`}],required:!0}}]}},description:``},viewer:{required:!0,tsType:{name:`ReactNode`},description:``},connection:{required:!1,tsType:{name:`union`,raw:`'online' | 'offline' | 'reconnecting'`,elements:[{name:`literal`,value:`'online'`},{name:`literal`,value:`'offline'`},{name:`literal`,value:`'reconnecting'`}]},description:``,defaultValue:{value:`'offline'`,computed:!1}}}}})))()}export{A as i,w as n,T as r,C as t};