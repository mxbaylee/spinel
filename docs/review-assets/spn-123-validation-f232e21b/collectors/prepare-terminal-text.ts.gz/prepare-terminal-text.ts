import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const pub='/tmp/spn123-publication-f232e21b', out='/tmp/spn123-terminal-f232e21b/archive';
const terminal=JSON.parse(readFileSync(out+'/terminal-outcomes.json','utf8'));
const summary=JSON.parse(readFileSync(out+'/acceptance-summary.json','utf8'));
const expected=summary.browsers.reduce((n:number,b:any)=>n+b.stats.expected,0);
const skipped=summary.browsers.reduce((n:number,b:any)=>n+b.stats.skipped,0);
const current=`## 🚦 Fresh f232 first-attempt hosted acceptance

All four original workflows succeeded on source \`f232e21b4910afe6209a22d8d78516c598eba1a5\`: [CI 43648312553](https://github.com/mxbaylee/spinel/actions/runs/43648312553), [Storybook 43648312505](https://github.com/mxbaylee/spinel/actions/runs/43648312505), [Desktop 43648312528](https://github.com/mxbaylee/spinel/actions/runs/43648312528), and [Spaces 43648312604](https://github.com/mxbaylee/spinel/actions/runs/43648312604). Across47 jobs:45 successes, zero failures and two inapplicable Storybook deployment skips. All45 executed jobs have complete original logs. No workflow was rerun, dispatched manually or cancelled.

The seven current-head gates—Pull request, Backlog, Lint, Typecheck, Unit tests, Lib tests and Playwright smoke—passed. CI's final aggregate132620908814 accepted all selected prerequisites. Fifteen candidate browser reports contain **${expected} expected passes, ${skipped} explicit project skips, zero unexpected or flaky cases and no failed/timed-out/interrupted attempts**. Skips remain explicit and the independent audit matches them to passing owning projects; unrun work is not inferred to pass. Both development and production diagnostic/paired-feedback scenarios now execute successfully, with the original6ef import failure preserved separately.

Actual job checkout witnesses bind tested merge \`1f17dee5a50529852b85c28e64c632404028c94c\`, parents actual312 and f232, tree \`e793569c4a93d2d81cd00dee7922441abc11b9b4\` equal to candidate. Spaces checks f232 directly. The actual hosted plan is conservative **full mode, paths:null, all15 suites selected**, raw SHA256 \`6e8e5a61567ef51dfaaffb314eafa8e4ab44bcf22e9137f70aa6df405415fbc0\`, canonical \`c6bc3724a69ee832e9fdda738efc8fb5abdee5ae84975e53d0446df30ae4d818\`. Local targeted output271,525 bytes exceeded the existing64KiB bound; absent a range-catch message, oversized fallback is a supported inference, not an asserted targeted hosted plan.

Native ordinary-profile Chrome157.0.8103.79, Firefox160.0 and Safari27.2 acceptance passed, each with four actual launches and original retained edit/image/restart/reconnect/storage evidence. Storybook checked the exact1,078-story catalog in each of five selected viewport/theme variants. Spaces'12 real provider checks passed with cleanup complete. Sized restore passed on the actual production image under1024MiB/0.75CPU/128-PID limits, including source closure, supervised maintenance and removed fixture volume; this Linux synthetic-passkey controller evidence remains distinct from physical-phone and provider evidence.

Both callback comparisons accepted with complete raw evidence ledgers/capacities/phase windows/task spans/source and cleanup records; both candidate records have zero evidence failures or candidate-policy violations. Baseline violations remain baseline observations. Desktop/mobile responsiveness each passed all seven cases and paired comparisons. Independently recomputed unprofiled maxima: input p95 **27.3ms desktop /73.7ms mobile**, longest recorded long task **0ms /158ms**, first verified browser-local empty **340.8ms /398.2ms**. Descriptive late-read upper bounds **1,004.2ms /5,906ms** are not the one-second local-drain gate. Profile runs are descriptive; mobile emulation is not physical-phone evidence. These current source-bound measurements neither explain nor erase historical110.4/104.2/117.4ms failures.

The terminal staging preserves **34 original artifact ZIP inventories /3,588 member bindings**, API size/SHA256 and per-member uncompressed CRC32/SHA256 verification, complete useful original reports/numeric records and45 raw logs. Complete original ZIPs stay private. Passing bulk derived traceEvents, Perfetto, source packs and redundant passing visuals remain explicitly supplementary/expiring, not claimed as durable full traces. One premature staging read rejected an incomplete download before consuming partial bytes; that original GET then finished with matching SHA/size. This collection-only guard failure is preserved, not a test failure or rerun.

The independent terminal acceptance audit found no gaps and verified all45 executed checkout logs, all three aggregates' exact plan bindings, all304 measurement harness bindings, all1,344 source/170 installed-library/13 shipped-image hashes in sized restore, and the11 skip occurrences against actual passing owners. Both performance baselines use explicit current harness overlays with dirty paths retained, not pristine historical checkouts. Current desktop budgets are100ms input p95/200ms longest task/1,000ms verified local drain; mobile budgets are200/500/1,000ms. Native flush capacity-p95/idle-p95/max were2.2/0.6/9.4ms desktop and9.9/6.3/36.9ms mobile, within their existing16/50ms and50/100ms p95/max bounds; history/collaboration high-water remained16. Sized restore's serving memory peak reached exactly1,073,741,824bytes: bounded successful completion, no spare-memory claim. Storybook manifests have captureScreenshots:false and are interaction/rendering evidence, not new visual approval.

**Preservation checkpoint:** independent terminal acceptance is verified; terminal archive is prepared but not yet sealed or published. Root's final Git/payload audit, fresh base/head/blocker verification and guarded squash remain pending. No merge is claimed. Separate main312 CI43646326362 and Story43646326402 passed but do not substitute for candidate acceptance.
`;
const original=readFileSync(pub+'/pr-body-publication.md','utf8');
const oldIntro=original.match(/\*\*Complete candidate:\*\*[\s\S]*?(?=\n\n## 🧭)/)?.[0];
if(!oldIntro)throw Error('Original intro missing');
let body=original.replace(oldIntro,'**Complete candidate:** `f232e21b4910afe6209a22d8d78516c598eba1a5`. **Actual main base:** `312e5546386ece21f8e0845d696598cc4d85c731` (landed SPN-120, after SPN-090 and SPN-098). **Agent review only.** Both exact-head local reviews scored100/100; all four fresh first-attempt hosted workflows now passed. Root published the review archive and body before the normal fast-forward source push at22:28:59UTC. Terminal preservation and final merge verification remain pending.');
const start=body.indexOf('**Fresh f232 acceptance remains pending:**');
const end=body.indexOf('\nThe earlier unpublished archive184a',start);
if(start<0||end<0)throw Error('Original pending section missing');
body=body.slice(0,start)+current+body.slice(end);
writeFileSync(pub+'/pr-body-terminal-prepared.md',body);
const readme=`# 📊 SPN-123 f232 first-attempt terminal validation

This staged evidence is intended for an evidence-only archive commit that is a direct child of reviewed candidate \`f232e21b4910afe6209a22d8d78516c598eba1a5\`. It changes no implementation. Actual base is \`312e5546386ece21f8e0845d696598cc4d85c731\`. The final collected snapshot is \`${terminal.snapshot}\`.

${current}

## 🔎 Original evidence and provenance

\`terminal-outcomes.json\` records each workflow/job and exact raw log hashes/checkout witnesses. \`collection-bindings.json\` binds290 copied original snapshot/log/publication/collector payloads. \`artifact-inventory.json\` records every original ZIP/member and distinguishes complete durable ZIPs, complete optionally gzip-wrapped members and omitted supplementary payloads. \`acceptance-summary.json\` and \`raw-sample-schema.json\` are derived indexes; the original reports and records remain authoritative. All attempts, annotations, errors and skips remain available. Collector scripts are archival read-only provenance, not production code or local test runs.

The published [exact-f232 review archive](https://github.com/mxbaylee/spinel/tree/f524dd4d5ddaee80b2553f1be5174d0631bc655f/docs/review-assets/spn-123-review-f232e21b) retains the complete scope/specification, source-bound grade-free packet, unmasked originals, two100/100 reports, local checks and root audits. The [original6ef failure archive](https://github.com/mxbaylee/spinel/tree/7d4c215d1075d3aa640a029366bddea58f7627ca/docs/implementation/evidence/SPN-123-validation-6ef945ea) retains the original TS2304/missing-writeFile failures, all configured retries and unrun cases; its historical wording/records are not rewritten. Earlier c270/7fd reviews and source-specific performance/native observations remain linked by the current review archive rather than recopied here.

## 🧭 Persona and retention decision

Operator needs reproducible, bounded private diagnostics without duplicating enormous passing traces. Owner needs evidence that contents/history/local persistence survive ordinary launches and recovery. Collaborator needs truthful peer/server acknowledgement, access and first-attempt timing evidence. Link guest needs scoped access/revocation/privacy, without private collection authority. Preserve complete actionable raw acceptance records and explicit provenance while retaining bulk passing trace/source packs privately and as supplementary hosted artifacts. Future whole-trace analysis requires those original private ZIPs or still-available artifacts; this archive makes no broader durability or causal claim.
`;
writeFileSync(out+'/README.md',readme);
console.log(JSON.stringify({expected,skipped,body:pub+'/pr-body-terminal-prepared.md',bodySha256:createHash('sha256').update(body).digest('hex'),readme:out+'/README.md',sealed:false}));
