import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';import{join}from'node:path';
const root='/tmp/spn123-terminal-f232e21b/archive';const inv=JSON.parse(readFileSync(join(root,'artifact-inventory.json'),'utf8'));const rows=[];
for(const a of inv.filter((a:any)=>/^doc-(callback|responsiveness)/.test(a.name))){
 const row:any={id:a.id,name:a.name,retained:a.members.filter((m:any)=>m.retainedPath).map((m:any)=>({name:m.name,bytes:m.bytes})),samples:[]};
 for(const m of a.members.filter((m:any)=>m.retainedPath&&/spn113-evidence\.json$/.test(m.name))){const v=JSON.parse(gunzipSync(readFileSync(join(root,m.retainedPath))).toString());row.samples.push({member:m.name,source:v.source,role:v.role,complete:v.complete,passed:v.passed,traceRead:v.traceRead,analysis:{accepted:v.analysis?.accepted,evidenceFailures:v.analysis?.evidenceFailures,candidateViolations:v.analysis?.candidateViolations,keys:Object.keys(v.analysis??{}),arrays:Object.fromEntries(Object.entries(v.analysis??{}).filter(([k,x])=>Array.isArray(x)).map(([k,x]:any)=>[k,x.length]))},input:{keydown:v.input?.keydownAt?.length,keyToFrame:v.input?.keyToFrameMs?.length,longTasks:v.input?.longTasks?.length}});}
 rows.push(row);
}
writeFileSync(join(root,'raw-sample-schema.json'),JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows));
