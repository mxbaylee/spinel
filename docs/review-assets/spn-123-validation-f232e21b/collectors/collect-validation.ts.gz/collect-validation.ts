import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {mkdirSync,writeFileSync,existsSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
const runFile=promisify(execFile),source='f232e21b4910afe6209a22d8d78516c598eba1a5',base='312e5546386ece21f8e0845d696598cc4d85c731';
const root='/tmp/spn123-publication-f232e21b/validation';
const stamp=new Date().toISOString().replaceAll(':','').replaceAll('.','');
const snapshot=join(root,'snapshots',stamp),logs=join(root,'logs'),zips=join(root,'original-zips');
for(const path of [snapshot,logs,zips])mkdirSync(path,{recursive:true});
const files:any[]=[],errors:any[]=[],workflows:any[]=[];
const hash=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
function save(path:string,raw:Buffer){const b=gzipSync(raw);writeFileSync(path+'.gz',b,{flag:'wx'});files.push({path:path+'.gz',bytes:b.length,sha256:hash(b),rawBytes:raw.length,rawSha256:hash(raw)});}
async function request(endpoint:string,paginated=false){return (await runFile('gh',['api','--method','GET',endpoint,...(paginated?['--paginate','--slurp']:[]),'--allow-escape-sequences'],{encoding:'buffer',maxBuffer:64*1024*1024,timeout:45000})).stdout;}
async function json(endpoint:string,name:string,paginated=false){const raw=await request(endpoint,paginated);save(join(snapshot,name+'.json'),raw);return JSON.parse(raw.toString());}
try{
 const [pr,commit]=await Promise.all([json('repos/mxbaylee/spinel/pulls/220','pr'),json('repos/mxbaylee/spinel/commits/'+source,'source-commit'),json('repos/mxbaylee/spinel/actions/runs?head_sha='+source+'&per_page=100','all-source-runs',true),json('repos/mxbaylee/spinel/commits/'+source+'/check-runs?per_page=100','check-runs',true)]);
 if(pr.head.sha!==source)throw Error('Remote head changed');
 save(join(snapshot,'observed-pr-body.md'),Buffer.from(pr.body??''));
 if(pr.merge_commit_sha)await json('repos/mxbaylee/spinel/commits/'+pr.merge_commit_sha,'observed-merge-commit');
 for(const [kind,id] of [['ci',43648312553],['storybook',43648312505],['desktop',43648312528],['spaces',43648312604]] as const){
  const [run,jp,ap]=await Promise.all([json(`repos/mxbaylee/spinel/actions/runs/${id}`,`run-${kind}`),json(`repos/mxbaylee/spinel/actions/runs/${id}/attempts/1/jobs?per_page=100`,`jobs-${kind}-attempt-1`,true),json(`repos/mxbaylee/spinel/actions/runs/${id}/artifacts?per_page=100`,`artifacts-${kind}`,true)]);
  if(run.head_sha!==source||run.run_attempt!==1||run.event!=='pull_request')throw Error('Run source/attempt/event mismatch '+id);
  const jobs=jp.flatMap((p:any)=>p.jobs),artifacts=ap.flatMap((p:any)=>p.artifacts);
  if(new Set(jobs.map((j:any)=>j.id)).size!==jobs.length)throw Error('Duplicate jobs');
  workflows.push({kind,id,attempt:1,source,status:run.status,conclusion:run.conclusion,jobs:jobs.map((j:any)=>({id:j.id,name:j.name,status:j.status,conclusion:j.conclusion})),artifacts});
  for(const job of jobs.filter((j:any)=>j.status==='completed'&&j.conclusion!=='skipped')){
   const path=join(logs,`job-${job.id}.log`);if(existsSync(path+'.gz'))continue;
   try{save(path,await request(`repos/mxbaylee/spinel/actions/jobs/${job.id}/logs`));}catch(e){errors.push({job:job.id,error:String(e)});}
  }
  for(const a of artifacts.filter((a:any)=>a.name==='ci-plan'||a.name.startsWith('ci-results-')||a.name==='spaces-acceptance')){
   const path=join(zips,`artifact-${a.id}.zip`);if(existsSync(path))continue;
   try{const b=await request(`repos/mxbaylee/spinel/actions/artifacts/${a.id}/zip`);writeFileSync(path,b,{flag:'wx'});if(a.size_in_bytes!==b.length||a.digest&&a.digest!=='sha256:'+hash(b))throw Error('Artifact size/digest mismatch');files.push({path,bytes:b.length,sha256:hash(b),artifact:a});}catch(e){errors.push({artifact:a.id,error:String(e)});}
  }
 }
}catch(e){errors.push({error:String(e)});}finally{
 const result={at:new Date().toISOString(),source,base,snapshot,readOnly:true,workflows,errors,files,allTerminal:workflows.length===4&&workflows.every(r=>r.status==='completed'),note:'First attempt only. No rerun/cancel/dispatch/metadata/source mutation. Original6ef remains historical failed validation. Do not infer no configured retry from job success.'};
 writeFileSync(join(snapshot,'collection.json'),JSON.stringify(result,null,2)+'\n');writeFileSync(join(root,'latest.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({snapshot,workflows:workflows.map(r=>({kind:r.kind,status:r.status,conclusion:r.conclusion,jobs:r.jobs.length,failed:r.jobs.filter((j:any)=>j.conclusion==='failure').map((j:any)=>({id:j.id,name:j.name})),completed:r.jobs.filter((j:any)=>j.status==='completed').length,artifacts:r.artifacts.length})),errors,files:files.length,allTerminal:result.allTerminal}));
}
