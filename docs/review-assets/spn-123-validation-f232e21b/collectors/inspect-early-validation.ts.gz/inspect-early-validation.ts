import {execFileSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const root='/tmp/spn123-publication-f232e21b/validation';
const v=JSON.parse(readFileSync(join(root,'latest.json'),'utf8'));const results=[];
for(const w of v.workflows)for(const a of w.artifacts.filter((a:any)=>a.name==='ci-plan'||a.name==='spaces-acceptance')){
 const p=join(root,'original-zips',`artifact-${a.id}.zip`);const names=execFileSync('unzip',['-Z1',p],{encoding:'utf8'}).trim().split('\n');
 for(const name of names){const b=execFileSync('unzip',['-p',p,name]);writeFileSync(join(root,`${a.id}-${name.replaceAll('/','_')}`),b);const data=JSON.parse(b.toString());results.push({artifact:a.id,name,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex'),data});}
}
const witnesses=[];for(const id of [132610953709,132610953568,132610953972,132611187353]){const log=gunzipSync(readFileSync(join(root,'logs',`job-${id}.log.gz`))).toString();const lines=log.split('\n').filter((l:string)=>/1f17dee5|f232e21b|312e5546|git log -1|tsc -p|tsgo|result.*pass|tests? passed|accepted|assertions|plan.*mode/i.test(l));witnesses.push({job:id,lines});}
writeFileSync(join(root,'early-source-plan-evidence.json'),JSON.stringify({source:v.source,base:v.base,results,witnesses},null,2)+'\n');
console.log(JSON.stringify({results,witnesses}));
