import { afterEach, expect, test, vi } from 'vitest';
import type {
  NativeSyncOptions,
  ClientState,
  IncomingFrame,
  ClientCheckpoint,
  ClientCheckpointFactory,
} from '@spinel/sync-client';
import type { Univer } from '@univerjs/core';
import { disposeSpinelSync, getSpinelSync, loadSpinelDocument } from '../../web/spinelSync.ts';
import { getSyncPresence } from '../../web/syncPresence.ts';
import type { SaveState } from '../shared/autosave.ts';
import type { ConnectionState } from '../../web/connectionState.ts';
import type { OfflineSession } from '../../web/offline/OfflineSession.ts';
import type { OfflineCreation } from '../../web/offline/offlineStore.ts';
import type { OfflineRecoveryRequest } from '../shared/offlineRecovery.ts';
import type { MaintenancePublicStatus } from '../shared/maintenance.ts';
import type { ItemAccess } from '../shared/workspace.ts';
import { isDiagnosticRecord } from '@spinel/diagnostics';
import type { DiagnosticEvent, DiagnosticRecord, DiagnosticSource } from '@spinel/diagnostics';
import { AccountDiagnostics, diagnosticsConnectionPolicy } from '../../web/diagnosticsAccount.ts';
import { BrowserDiagnostics } from '../../web/diagnostics.ts';
import { beginOperation, diagnosticSource } from '../../web/operationDiagnostics.ts';

const maintenance = vi.hoisted(() => ({ status: null as MaintenancePublicStatus | null }));
vi.mock('../../web/maintenanceState.ts', () => ({
  maintenanceEvent: 'spinel-maintenance',
  getMaintenanceStatus: () => maintenance.status,
  getMaintenanceEpoch: () => (maintenance.status?.available ? maintenance.status.epoch : undefined),
  refreshMaintenanceStatus: async () => maintenance.status,
}));

const downloadOfflineFile = vi.hoisted(() => vi.fn());
vi.mock('../../web/offline/recovery.ts', () => ({
  downloadOfflineFile,
  offlineCopyName: (title: string) => `${title} (offline copy, 2026-10-27 14:35)`,
}));

const native = vi.hoisted(() => ({
  snapshot: { id: 'unit', body: { dataStream: 'Observed native text\r\n' } },
  snapshotReads: vi.fn(),
  clients: [] as {
    options: NativeSyncOptions;
    state: ClientState;
    disposed: boolean;
    received: IncomingFrame[];
  }[],
}));
vi.mock('@univerjs/core', () => ({
  UniverInstanceType: { UNIVER_SHEET: 2, UNIVER_DOC: 1 },
  ICommandService: Symbol('ICommandService'),
}));
vi.mock('@spinel/sync-client', () => ({
  validateNativeSnapshot: vi.fn(),
  nativeSnapshot() {
    native.snapshotReads();
    return native.snapshot;
  },
  createNativeSyncClient(options: NativeSyncOptions) {
    const entry = {
      options,
      state: {
        revision: options.revision,
        pending: false,
        pendingMutations: 0,
        connected: false,
        resyncing: false,
      } as ClientState,
      disposed: false,
      received: [] as IncomingFrame[],
    };
    native.clients.push(entry);
    return {
      get confirmedRevision() {
        return entry.state.revision;
      },
      diagnosticQueue() {
        return {
          pendingCount: entry.state.pendingMutations,
          oldestPendingAgeMs: entry.state.pendingMutations ? null : 0,
        };
      },
      setConnected(connected: boolean) {
        entry.state = { ...entry.state, connected };
        options.onState(entry.state);
      },
      receive(frame: IncomingFrame) {
        entry.received.push(frame);
        if (frame.type === 'resume' || frame.type === 'ack') entry.state.revision = frame.revision;
        if (frame.type === 'ack') entry.state.pending = false;
        options.onState(entry.state);
      },
      checkpoint() {
        return {
          version: 1 as const,
          unitId: 'unit',
          revision: entry.state.revision,
          snapshot: options.snapshot,
          sent: null,
          inflight: [],
          buffer: [],
        };
      },
      async persistNow() {
        try {
          await options.persist?.(() => this.checkpoint());
          if (options.persist) entry.state.localPersistence = 'saved';
          options.onState(entry.state);
        } catch (error) {
          entry.state.localPersistence = 'failed';
          options.onState(entry.state);
          throw error;
        }
      },
      retry() {
        void this.persistNow().catch(() => {});
      },
      refuse(reason: import('@spinel/sync-client').ClientFailure) {
        entry.state = { ...entry.state, resyncing: true };
        options.onState(entry.state);
        options.onResync(reason);
      },
      dispose() {
        entry.disposed = true;
      },
    };
  },
}));

class Socket {
  static OPEN = 1;
  static instances: Socket[] = [];
  readyState = 0;
  onopen?: () => void;
  onclose?: () => void;
  onerror?: () => void;
  onmessage?: (event: { data: string }) => void;
  sent: unknown[] = [];
  url: string;
  constructor(url: URL) {
    this.url = String(url);
    Socket.instances.push(this);
  }
  open() {
    this.readyState = 1;
    this.onopen?.();
  }
  frame(value: unknown) {
    this.onmessage?.({ data: JSON.stringify(value) });
  }
  send(value: string) {
    this.sent.push(JSON.parse(value));
  }
  close() {
    if (this.readyState === 3) return;
    this.readyState = 3;
    this.onclose?.();
  }
}

const stops: (() => void)[] = [];
afterEach(() => {
  for (const stop of stops.splice(0).reverse()) stop();
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  downloadOfflineFile.mockClear();
  native.clients.length = 0;
  native.snapshot = { id: 'unit', body: { dataStream: 'Observed native text\r\n' } };
  native.snapshotReads.mockClear();
  Socket.instances.length = 0;
  maintenance.status = null;
});
const item = '11111111-1111-4111-8111-111111111111';
const child = '22222222-2222-4222-8222-222222222222';

async function fixture({
  guest = false,
  space = false,
  initializeAccess,
  onInitialPending,
  beforeWatch,
  downloaded = false,
  preparing = false,
  canRecover = false,
  canRefresh,
  maintenanceEpoch,
  access = 'editor',
  bundleAccess = access,
  diagnostics,
  clock,
  onConnection,
}: {
  guest?: boolean;
  space?: boolean;
  initializeAccess?(): void | Promise<void>;
  onInitialPending?(): void;
  beforeWatch?(): void;
  downloaded?: boolean;
  preparing?: boolean;
  canRecover?: boolean;
  canRefresh?(): boolean;
  maintenanceEpoch?: string;
  access?: ItemAccess;
  bundleAccess?: ItemAccess;
  diagnostics?: DiagnosticSource;
  clock?: () => number;
  onConnection?(state: ConnectionState): void;
} = {}) {
  vi.useFakeTimers();
  if (clock) vi.spyOn(performance, 'now').mockImplementation(clock);
  maintenance.status = maintenanceEpoch
    ? { available: true, phase: 'running', epoch: maintenanceEpoch, notice: null }
    : null;
  vi.stubGlobal('navigator', { onLine: true });
  const signIn = vi.fn();
  const reloadPage = vi.fn();
  vi.stubGlobal('location', {
    pathname: guest ? `/share/${item}` : '/',
    origin: 'https://spinel.test',
    protocol: 'https:',
    search: '',
    assign: signIn,
    reload: reloadPage,
  });
  const events = new EventTarget();
  const dispatched = vi.spyOn(events, 'dispatchEvent');
  vi.stubGlobal('window', events);
  vi.stubGlobal('document', Object.assign(new EventTarget(), { visibilityState: 'visible' }));
  vi.stubGlobal('WebSocket', Socket);
  let current = true;
  let metadata: (input: string) => Promise<Response> = async (input) =>
    Response.json(
      input.endsWith('/collaboration')
        ? { access: bundleAccess, unitId: 'unit', user: { id: 'owner' } }
        : { item: { access }, live: { unitId: 'unit' } },
    );
  const requests = vi.fn(async (input: string, _init?: RequestInit) => {
    if (input.includes('/snapshot?'))
      return Response.json({
        version: 1,
        unitId: 'unit',
        revision: 8,
        epoch: maintenanceEpoch,
        snapshot: { id: 'unit', body: { dataStream: '\r\n' } },
      });
    if (input.includes('/ticket?')) return Response.json({ version: 1, ticket: 'one-use-ticket' });
    return metadata(input);
  });
  vi.stubGlobal('fetch', requests);
  const recoveryRequest: OfflineRecoveryRequest = {
    recoveryId: '33333333-3333-4333-8333-333333333333',
    filename: 'Offline notes (offline copy, 2026-10-27 14:35).univer.json',
    snapshot: {
      id: space ? child : item,
      title: 'Offline notes (offline copy, 2026-10-27 14:35)',
      documentStyle: {},
      body: { dataStream: 'Retained local notes\r\n' },
    },
    possibleReplayCrash: false,
  };
  const copyItem = {
    id: '44444444-4444-4444-8444-444444444444',
    name: 'Offline notes (offline copy, 2026-10-27 14:35)',
  };
  const persisted: ClientCheckpoint[] = [];
  const offline = {
    enabled: downloaded,
    canRecover,
    current: true,
    pending: false,
    online: false,
    problem: '',
    accountId: 'owner',
    itemId: space ? child : item,
    bundle: { access: bundleAccess, unitId: 'unit', name: 'Offline notes', maintenanceEpoch },
    creation: undefined as OfflineCreation | undefined,
    recoveryRequest: undefined as OfflineRecoveryRequest | undefined,
    onChange: undefined as (() => void) | undefined,
    initial: () =>
      downloaded
        ? { snapshot: { id: 'unit', body: { dataStream: '\r\n' } }, revision: 8 }
        : undefined,
    toVisible: <T>(value: T) => value,
    toCanonical: <T>(value: T) => value,
    fetch: requests,
    reconcileAvailability: vi.fn(async (_checkpoint: ClientCheckpoint) => {}),
    persist: vi.fn(async (capture: ClientCheckpointFactory) => {
      persisted.push(capture());
    }),
    prepareRecovery: vi.fn(
      async (_checkpoint: ClientCheckpoint): Promise<OfflineRecoveryRequest> => {
        offline.recoveryRequest ??= structuredClone(recoveryRequest);
        return structuredClone(offline.recoveryRequest);
      },
    ),
    publishRecovery: vi.fn(
      async (_request: OfflineRecoveryRequest, _signal: AbortSignal, _maintenanceEpoch?: string) =>
        copyItem,
    ),
    exportSnapshot: vi.fn(async (_checkpoint: ClientCheckpoint) =>
      structuredClone(recoveryRequest.snapshot),
    ),
    finishRecovery: vi.fn(async (_recoveryId?: string) => {
      offline.pending = false;
    }),
    prepareImages: vi.fn(async (_value: unknown, _signal?: AbortSignal) => {}),
    refreshClean: vi.fn(async (verify: () => void) => {
      verify();
    }),
    removeClean: vi.fn(async (verify: () => void) => {
      verify();
    }),
    upgradeAccess: vi.fn(async (next: ItemAccess, _revision: number, verify: () => void) => {
      verify();
      offline.bundle = { ...offline.bundle, access: next };
    }),
    endAuthentication: vi.fn(),
    stopAuthenticationHTTP: vi.fn(),
    stopRemote: vi.fn((reason: string) => {
      offline.problem = reason;
    }),
    dispose: vi.fn(),
  };
  const univer = {
    createUnit: vi.fn(),
    __getInjector: () => ({ get: () => ({}) }),
  } as unknown as Univer;
  const abort = new AbortController();
  stops.push(() => {
    abort.abort();
    disposeSpinelSync(univer);
  });
  const reload = vi.fn();
  const lock = vi.fn();
  const upgradeAccess = vi.fn();
  await loadSpinelDocument({
    univer,
    unitId: 'unit',
    itemId: space ? child : item,
    spaceId: space ? item : undefined,
    access,
    kind: 'doc',
    signal: abort.signal,
    isCurrent: () => current,
    initializeAccess,
    upgradeAccess,
    onInitialPending,
    reload,
    lock,
    offline: downloaded || preparing ? (offline as unknown as OfflineSession) : undefined,
    canRefresh,
    diagnostics,
  });
  beforeWatch?.();
  const saves: SaveState[] = [];
  const connections: ConnectionState[] = [];
  const readonly = vi.fn(async (_preserveInput?: boolean) => {});
  const handle = getSpinelSync(univer)!.watch({
    publish: (state) => saves.push(state),
    connection: (state) => {
      connections.push(state);
      onConnection?.(state);
    },
    readonly,
  });
  await vi.advanceTimersByTimeAsync(0);
  const client = native.clients.at(-1)!;
  return {
    univer,
    saves,
    connections,
    readonly,
    handle,
    upgradeAccess,
    abort,
    requests,
    reload,
    lock,
    signIn,
    reloadPage,
    dispatched,
    client,
    offline,
    persisted,
    recoveryRequest,
    copyItem,
    socket: () => Socket.instances.at(-1)!,
    leave() {
      current = false;
    },
    metadata(reply: (input: string) => Promise<Response>) {
      metadata = reply;
    },
    maintenance(phase: MaintenancePublicStatus['phase'], epoch: string) {
      maintenance.status = { available: true, phase, epoch, notice: null };
      window.dispatchEvent(new Event('spinel-maintenance'));
    },
    pending() {
      client.state.pending = true;
      client.state.pendingMutations = 1;
      if (downloaded || preparing) offline.pending = true;
      client.options.onState(client.state);
    },
    conflict() {
      offline.stopRemote('The live document changed. Your saved device copy is retained.');
      offline.onChange?.();
    },
  };
}

function diagnosticObservations(throws = false) {
  const observations: DiagnosticEvent[] = [];
  const diagnostics: DiagnosticSource = () => ({
    context: { component: 'editor', fileId: item },
    sink(event) {
      observations.push(structuredClone(event));
      if (throws) throw new Error('The optional observer failed');
    },
  });
  return { observations, diagnostics };
}

async function collectedAccount(initialCollectionFails = false) {
  const clients: BrowserDiagnostics[] = [];
  const starts: Promise<void>[] = [];
  const batches: {
    accountId: string | null;
    generation: string;
    binding: string;
    records: DiagnosticRecord[];
  }[] = [];
  let collectionRequests = 0;
  let failedFlush = false;
  const request = vi.fn<typeof fetch>(async (url, options) => {
    if (String(url).endsWith('/collection')) {
      collectionRequests++;
      return initialCollectionFails && collectionRequests === 1
        ? Response.json({}, { status: 503 })
        : Response.json({ generation: crypto.randomUUID(), binding: 'a'.repeat(64) });
    }
    const body = JSON.parse(String(options?.body));
    expect(body.records.every(isDiagnosticRecord)).toBe(true);
    if (failedFlush) {
      failedFlush = false;
      return Response.json({}, { status: 503 });
    }
    batches.push({
      ...body,
      accountId: new Headers(options?.headers).get('X-Spinel-Diagnostic-Account'),
    });
    return Response.json({ accepted: body.records.length, dropped: 0 });
  });
  const account = new AccountDiagnostics((accountId) => {
    const client = new BrowserDiagnostics({ accountId, fetch: request });
    const start = client.start.bind(client);
    vi.spyOn(client, 'start').mockImplementation(() => {
      const pending = start();
      starts.push(pending);
      return pending;
    });
    clients.push(client);
    return client;
  });
  stops.push(() => account.stop());
  const owner = crypto.randomUUID();
  account.account(owner);
  account.connection(true);
  expect(account.begin()).toBeUndefined();
  await starts.at(-1);
  return {
    account,
    owner,
    clients,
    starts,
    batches,
    request,
    source: diagnosticSource(account, { component: 'editor', fileId: item, route: '/files/:id' }),
    connection(state: ConnectionState) {
      // App passes this exact policy to the hook. Its availability effect owns
      // hard invalidation; the separate online-hint effect has no teardown.
      const policy = diagnosticsConnectionPolicy(navigator.onLine, state);
      if (!policy.available || policy.onlineHint)
        account.connection(policy.available && document.visibilityState !== 'hidden');
    },
    failNextFlush() {
      failedFlush = true;
    },
    records() {
      return batches.flatMap((batch) => batch.records);
    },
  };
}

test('actual account collection retains open and transport reconnect observations through native room reports', async () => {
  let at = 100;
  const collection = await collectedAccount();
  const opened = beginOperation(collection.source, 'document-open', () => at);
  const f = await fixture({
    diagnostics: collection.source,
    clock: () => at,
    onConnection: collection.connection,
  });
  expect(f.connections.at(-1)).toBe('reconnecting');
  expect(collection.account.begin()).toBeDefined();
  at = 120;
  opened('success');
  f.socket().open();
  at = 130;
  f.socket().frame({
    type: 'resume',
    version: 1,
    unitId: 'unit',
    fromRevision: 8,
    revision: 8,
    edits: [],
  });
  f.pending();
  const snapshot = structuredClone(f.client.options.snapshot);
  at = 140;
  f.socket().close();
  expect(f.connections.at(-1)).toBe('reconnecting');
  expect(collection.account.begin()).toBeDefined();
  await vi.advanceTimersByTimeAsync(300);
  f.socket().open();
  at = 180;
  f.socket().frame({
    type: 'resume',
    version: 1,
    unitId: 'unit',
    fromRevision: 8,
    revision: 8,
    edits: [],
  });
  await collection.clients[0].flush();
  expect(collection.starts).toHaveLength(1);
  expect(collection.batches).toHaveLength(1);
  expect(collection.batches[0].accountId).toBe(collection.owner);
  expect(
    collection
      .records()
      .filter(({ event }) => event.name === 'operation.result')
      .map(({ event }) => event),
  ).toEqual([
    {
      name: 'operation.result',
      details: { operation: 'document-open', outcome: 'success', durationMs: 20 },
    },
  ]);
  expect(
    collection
      .records()
      .filter(({ event }) => event.name === 'sync.client.connection')
      .map(({ event }) => event),
  ).toEqual([
    {
      name: 'sync.client.connection',
      details: {
        reason: 'initial',
        outcome: 'success',
        durationMs: 30,
        pendingCount: 0,
        oldestPendingAgeMs: 0,
      },
    },
    {
      name: 'sync.client.connection',
      details: {
        reason: 'transport',
        outcome: 'success',
        durationMs: 40,
        pendingCount: 1,
        oldestPendingAgeMs: null,
      },
    },
  ]);
  expect(collection.clients[0].dropped).toBe(0);
  expect(f.client.options.snapshot).toEqual(snapshot);
  expect(f.client.state).toMatchObject({
    revision: 8,
    pending: true,
    pendingMutations: 1,
    connected: true,
  });
  expect(f.client.disposed).toBe(false);
  expect(f.saves.at(-1)?.dirty).toBe(true);
  expect(f.requests.mock.calls.some(([url]) => url.includes('/api/health'))).toBe(false);
});

test('actual collection records recovery success after the retired editor reports offline', async () => {
  let at = 100;
  const collection = await collectedAccount();
  const f = await fixture({
    downloaded: true,
    canRecover: true,
    diagnostics: collection.source,
    clock: () => at,
    onConnection: collection.connection,
  });
  f.socket().open();
  f.socket().frame({
    type: 'resume',
    version: 1,
    unitId: 'unit',
    fromRevision: 8,
    revision: 8,
    edits: [],
  });
  await vi.advanceTimersByTimeAsync(0);
  const publication = Promise.withResolvers<typeof f.copyItem>();
  f.offline.publishRecovery.mockImplementationOnce(() => publication.promise);
  f.pending();
  f.conflict();
  await vi.advanceTimersByTimeAsync(0);
  at = 180;
  publication.resolve(f.copyItem);
  await vi.advanceTimersByTimeAsync(0);
  expect(f.connections.at(-1)).toBe('offline');
  expect(collection.account.begin()).toBeDefined();
  await collection.clients[0].flush();
  expect(collection.starts).toHaveLength(1);
  expect(
    collection
      .records()
      .filter(({ event }) => event.name === 'offline.recovery')
      .map(({ event }) => event),
  ).toEqual([{ name: 'offline.recovery', details: { outcome: 'success', durationMs: 80 } }]);
  expect(collection.clients[0].dropped).toBe(0);
  expect(f.offline.finishRecovery).toHaveBeenCalledOnce();
  expect(f.offline.pending).toBe(false);
  expect(f.client.disposed).toBe(true);
  expect(f.signIn).not.toHaveBeenCalled();
});

test.each(['collection', 'flush'] as const)(
  'a failed diagnostic %s resumes on the actual online room hint without rebinding old operations',
  async (failure) => {
    const collection = await collectedAccount(failure === 'collection');
    const opened = beginOperation(collection.source, 'document-open');
    const f = await fixture({
      diagnostics: collection.source,
      onConnection: collection.connection,
    });
    f.pending();
    const snapshot = structuredClone(f.client.options.snapshot);
    if (failure === 'flush') {
      f.socket().open();
      f.socket().frame({
        type: 'resume',
        version: 1,
        unitId: 'unit',
        fromRevision: 8,
        revision: 8,
        edits: [],
      });
      collection.failNextFlush();
      await collection.clients[0].flush();
      expect(collection.account.begin()).toBeUndefined();
      f.socket().close();
      await vi.advanceTimersByTimeAsync(300);
    }
    expect(collection.starts).toHaveLength(1);
    expect(collection.account.begin()).toBeUndefined();
    f.socket().open();
    f.socket().frame({
      type: 'resume',
      version: 1,
      unitId: 'unit',
      fromRevision: 8,
      revision: 8,
      edits: [],
    });
    await collection.starts.at(-1);
    expect(collection.starts).toHaveLength(2);
    expect(collection.account.begin()).toBeDefined();
    opened('success');
    const fresh = beginOperation(collection.source, 'search');
    fresh('success');
    await collection.clients[0].flush();
    expect(
      collection
        .records()
        .filter(({ event }) => event.name === 'operation.result')
        .map(({ event }) => event),
    ).toEqual([
      {
        name: 'operation.result',
        details: { operation: 'search', outcome: 'success', durationMs: expect.any(Number) },
      },
    ]);
    expect(collection.records().some(({ event }) => event.name === 'sync.client.connection')).toBe(
      false,
    );
    expect(f.client.options.snapshot).toEqual(snapshot);
    expect(f.client.state).toMatchObject({
      revision: 8,
      pending: true,
      pendingMutations: 1,
      connected: true,
    });
    expect(f.client.disposed).toBe(false);
  },
);

test.each(['browser offline', 'account switch'] as const)(
  'actual collection drops late open/connection events after %s without altering pending native work',
  async (boundary) => {
    const collection = await collectedAccount();
    const opened = beginOperation(collection.source, 'document-open');
    const f = await fixture({
      diagnostics: collection.source,
      onConnection: collection.connection,
    });
    f.pending();
    const snapshot = structuredClone(f.client.options.snapshot);
    const nextOwner = boundary === 'account switch' ? crypto.randomUUID() : collection.owner;
    if (boundary === 'browser offline') {
      vi.stubGlobal('navigator', { onLine: false });
      window.dispatchEvent(new Event('offline'));
      expect(collection.account.begin()).toBeUndefined();
      expect(f.client.state.pending).toBe(true);
      vi.stubGlobal('navigator', { onLine: true });
      // The hook's browser listener restarts HTTP verification; room readiness
      // cannot capture a scope from a handshake that has not completed yet.
      collection.account.connection(true);
      window.dispatchEvent(new Event('online'));
      await vi.advanceTimersByTimeAsync(300);
    } else {
      collection.account.account(nextOwner);
      collection.account.connection(true);
    }
    await collection.starts.at(-1);
    f.socket().open();
    f.socket().frame({
      type: 'resume',
      version: 1,
      unitId: 'unit',
      fromRevision: 8,
      revision: 8,
      edits: [],
    });
    opened('success');
    const fresh = beginOperation(collection.source, 'search');
    fresh('success');
    await collection.clients.at(-1)!.flush();
    expect(collection.batches).toHaveLength(1);
    expect(collection.batches[0].accountId).toBe(nextOwner);
    expect(
      collection
        .records()
        .filter(({ event }) => event.name === 'operation.result')
        .map(({ event }) => event),
    ).toEqual([
      {
        name: 'operation.result',
        details: { operation: 'search', outcome: 'success', durationMs: expect.any(Number) },
      },
    ]);
    expect(collection.records().some(({ event }) => event.name === 'sync.client.connection')).toBe(
      false,
    );
    expect(collection.clients[0].dropped).toBeGreaterThan(0);
    expect(f.client.options.snapshot).toEqual(snapshot);
    expect(f.client.state).toMatchObject({
      revision: 8,
      pending: true,
      pendingMutations: 1,
      connected: true,
    });
    expect(f.client.disposed).toBe(false);
  },
);

test.each([false, true])(
  'production connection observations time room readiness once across retry (throwing observer=%s)',
  async (throws) => {
    let at = 100;
    const observed = diagnosticObservations(throws);
    const f = await fixture({ diagnostics: observed.diagnostics, clock: () => at });
    f.socket().open();
    at = 120;
    expect(observed.observations).toEqual([]);
    f.socket().frame({
      type: 'resume',
      version: 1,
      unitId: 'unit',
      fromRevision: 8,
      revision: 8,
      edits: [],
    });
    expect(f.connections.at(-1)).toBe('online');
    f.pending();
    at = 130;
    f.socket().close();
    await vi.advanceTimersByTimeAsync(300);
    f.socket().open();
    at = 180;
    f.socket().frame({
      type: 'resume',
      version: 1,
      unitId: 'unit',
      fromRevision: 8,
      revision: 8,
      edits: [],
    });
    expect(f.saves.at(-1)?.dirty).toBe(true);
    expect(observed.observations).toEqual([
      {
        name: 'sync.client.connection',
        details: {
          reason: 'initial',
          outcome: 'success',
          durationMs: 20,
          pendingCount: 0,
          oldestPendingAgeMs: 0,
        },
      },
      {
        name: 'sync.client.connection',
        details: {
          reason: 'transport',
          outcome: 'success',
          durationMs: 50,
          pendingCount: 1,
          oldestPendingAgeMs: null,
        },
      },
    ]);
  },
);

test.each(['failure', 'cancelled'] as const)(
  'production connection %s is terminal and keeps pending work',
  async (outcome) => {
    let at = 100;
    const observed = diagnosticObservations(true);
    const f = await fixture({ diagnostics: observed.diagnostics, clock: () => at });
    f.pending();
    at = 145;
    if (outcome === 'failure') {
      f.metadata(async () => Response.json({}, { status: 403 }));
      await vi.advanceTimersByTimeAsync(1000);
      expect(f.readonly).toHaveBeenCalled();
    } else f.abort.abort();
    expect(f.client.state.pending).toBe(true);
    f.abort.abort();
    expect(observed.observations).toEqual([
      {
        name: 'sync.client.connection',
        details: {
          reason: 'initial',
          outcome,
          durationMs: 45,
          pendingCount: 1,
          oldestPendingAgeMs: null,
        },
      },
    ]);
  },
);

test.each(['handed-off', 'failure', 'cancelled'] as const)(
  'clean stale refresh observes delayed %s without retaining a native failure',
  async (outcome) => {
    let at = 100;
    const observed = diagnosticObservations(true);
    const f = await fixture({
      downloaded: true,
      diagnostics: observed.diagnostics,
      clock: () => at,
    });
    const refresh = Promise.withResolvers<void>();
    f.offline.refreshClean.mockImplementationOnce(async (verify) => {
      await refresh.promise;
      verify();
    });
    f.socket().open();
    f.socket().frame({ type: 'resync', reason: 'stale' });
    await vi.advanceTimersByTimeAsync(0);
    expect(f.offline.refreshClean).toHaveBeenCalledOnce();
    expect(observed.observations.filter((event) => event.name === 'sync.client.refresh')).toEqual(
      [],
    );
    expect(f.reload).not.toHaveBeenCalled();
    at = 140;
    if (outcome === 'cancelled') f.abort.abort();
    if (outcome === 'failure') refresh.reject(new Error('Refresh unavailable'));
    else refresh.resolve();
    await vi.advanceTimersByTimeAsync(0);
    expect(observed.observations.filter((event) => event.name === 'sync.client.refresh')).toEqual([
      {
        name: 'sync.client.refresh',
        details: {
          reason: 'retention',
          outcome,
          durationMs: 40,
          pendingCount: 0,
          oldestPendingAgeMs: 0,
        },
      },
    ]);
    expect(f.client.received).toEqual([]);
    expect(f.client.state.resyncing).toBe(false);
    expect(f.reload).toHaveBeenCalledTimes(outcome === 'handed-off' ? 1 : 0);
    if (outcome === 'failure') {
      expect(f.client.disposed).toBe(false);
      expect(f.offline.problem).toContain('fresh download');
    }
  },
);

test.each(['maintenance', 'access-change'] as const)(
  'clean refresh records its actual %s reason',
  async (reason) => {
    const observed = diagnosticObservations();
    const base = '55555555-5555-4555-8555-555555555555';
    const f = await fixture({
      downloaded: true,
      diagnostics: observed.diagnostics,
      maintenanceEpoch: base,
    });
    if (reason === 'maintenance') {
      const resumed = '66666666-6666-4666-8666-666666666666';
      f.maintenance('paused', resumed);
      await vi.advanceTimersByTimeAsync(0);
      f.maintenance('running', resumed);
      await vi.advanceTimersByTimeAsync(0);
      expect(f.reloadPage).toHaveBeenCalledOnce();
    } else {
      f.metadata(async () =>
        Response.json({ access: 'viewer', unitId: 'unit', user: { id: 'owner' } }),
      );
      await vi.advanceTimersByTimeAsync(1000);
      expect(f.reload).toHaveBeenCalledWith('stale', true);
    }
    expect(observed.observations.filter((event) => event.name === 'sync.client.refresh')).toEqual([
      {
        name: 'sync.client.refresh',
        details: {
          reason,
          outcome: 'handed-off',
          durationMs: expect.any(Number),
          pendingCount: 0,
          oldestPendingAgeMs: 0,
        },
      },
    ]);
  },
);

test.each(['success', 'failure', 'cancelled'] as const)(
  'production recovery observes delayed %s and cannot be changed by a throwing observer',
  async (outcome) => {
    let at = 100;
    const observed = diagnosticObservations(true);
    const f = await fixture({
      downloaded: true,
      canRecover: true,
      diagnostics: observed.diagnostics,
      clock: () => at,
    });
    const publication = Promise.withResolvers<typeof f.copyItem>();
    f.offline.publishRecovery.mockImplementationOnce(() => publication.promise);
    f.pending();
    f.conflict();
    await vi.advanceTimersByTimeAsync(0);
    expect(f.offline.publishRecovery).toHaveBeenCalledOnce();
    expect(f.offline.finishRecovery).not.toHaveBeenCalled();
    expect(observed.observations.filter((event) => event.name === 'offline.recovery')).toEqual([]);
    at = 160;
    if (outcome === 'cancelled') f.abort.abort();
    if (outcome === 'failure') publication.reject(new Error('Publication unavailable'));
    else publication.resolve(f.copyItem);
    await vi.advanceTimersByTimeAsync(0);
    expect(observed.observations.filter((event) => event.name === 'offline.recovery')).toEqual([
      { name: 'offline.recovery', details: { outcome, durationMs: 60 } },
    ]);
    expect(f.offline.finishRecovery).toHaveBeenCalledTimes(outcome === 'success' ? 1 : 0);
    expect(f.offline.pending).toBe(outcome !== 'success');
    if (outcome === 'failure') expect(f.client.disposed).toBe(false);
  },
);

test.each(['0', '1'])(
  'native snapshot requests are read-only, scoped, current and evidence-build-only (%s)',
  async (flag) => {
    vi.stubEnv('VITE_SYNC_EVIDENCE', flag);
    const f = await fixture({ downloaded: true });
    f.pending();
    const snapshots: unknown[] = [];
    window.addEventListener('spinel-sync-native-snapshot', (event) => {
      const detail = (event as CustomEvent).detail;
      snapshots.push(structuredClone(detail));
      // An observer receives a detached value, never the writable native model.
      detail.snapshot.body.dataStream = 'Observer attempted to change a detached copy';
    });
    native.snapshotReads.mockClear();
    const request = (unitId: string) =>
      window.dispatchEvent(
        new CustomEvent('spinel-sync-native-snapshot-read', { detail: { unitId } }),
      );
    request('different-unit');
    expect(native.snapshotReads).not.toHaveBeenCalled();
    request('unit');
    expect(native.snapshotReads).toHaveBeenCalledTimes(flag === '1' ? 1 : 0);
    expect(snapshots).toHaveLength(flag === '1' ? 1 : 0);
    if (flag === '1')
      expect(snapshots[0]).toMatchObject({
        unitId: 'unit',
        revision: 8,
        snapshot: { body: { dataStream: 'Observed native text\r\n' } },
      });
    expect(native.snapshot.body.dataStream).toBe('Observed native text\r\n');
    expect(f.persisted).toEqual([]);
    expect(f.client.state.pending).toBe(true);
    native.snapshotReads.mockClear();
    f.leave();
    request('unit');
    expect(native.snapshotReads).not.toHaveBeenCalled();
    f.handle.dispose();
    request('unit');
    expect(native.snapshotReads).not.toHaveBeenCalled();
  },
);

test.each([false, true])(
  'a %s downloaded viewer upgrades the existing native binding and retains downgrade fences',
  async (downloaded) => {
    const f = await fixture({ access: 'viewer', downloaded, space: downloaded });
    const socket = f.socket();
    socket.open();
    socket.frame({
      type: 'resume',
      version: 1,
      unitId: 'unit',
      fromRevision: 8,
      revision: 8,
      edits: [],
    });
    await vi.advanceTimersByTimeAsync(0);
    f.metadata(async () =>
      Response.json(
        downloaded
          ? { access: 'editor', unitId: 'unit', user: { id: 'owner' } }
          : { item: { access: 'editor' }, live: { unitId: 'unit' } },
      ),
    );
    await vi.advanceTimersByTimeAsync(1000);
    expect(f.upgradeAccess).toHaveBeenCalledExactlyOnceWith('editor');
    expect(f.socket()).toBe(socket);
    expect(f.univer.createUnit).toHaveBeenCalledTimes(1);
    expect(f.reload).not.toHaveBeenCalled();
    expect(f.reloadPage).not.toHaveBeenCalled();
    if (downloaded) {
      expect(f.offline.upgradeAccess).toHaveBeenCalledWith('editor', 8, expect.any(Function));
      expect(f.offline.persist).toHaveBeenCalled();
      expect(f.offline.refreshClean).not.toHaveBeenCalled();
    }
    f.pending();
    f.metadata(async () =>
      Response.json(
        downloaded
          ? { access: 'viewer', unitId: 'unit', user: { id: 'owner' } }
          : { item: { access: 'viewer' }, live: { unitId: 'unit' } },
      ),
    );
    await vi.advanceTimersByTimeAsync(1000);
    expect(f.readonly).toHaveBeenCalled();
    expect(socket.readyState).toBe(3);
    expect(f.upgradeAccess).toHaveBeenCalledTimes(1);
  },
);

test('a prepared upgrade retries failed checkpoint persistence without remounting or enabling input early', async () => {
  const f = await fixture({ access: 'viewer', downloaded: true });
  f.offline.persist.mockRejectedValueOnce(new Error('Disk temporarily unavailable'));
  f.metadata(async () =>
    Response.json({ access: 'editor', unitId: 'unit', user: { id: 'owner' } }),
  );
  await vi.advanceTimersByTimeAsync(1000);
  expect(f.upgradeAccess).not.toHaveBeenCalled();
  expect(f.offline.bundle.access).toBe('editor');
  await vi.advanceTimersByTimeAsync(1000);
  expect(f.upgradeAccess).toHaveBeenCalledExactlyOnceWith('editor');
  expect(f.reload).not.toHaveBeenCalled();
  expect(f.offline.refreshClean).not.toHaveBeenCalled();
});

test.each(['guest', 'generation', 'account', 'synthetic viewer'] as const)(
  'an upgrade cannot bypass a %s fence',
  async (fence) => {
    const downloaded = fence === 'account' || fence === 'synthetic viewer';
    const f = await fixture({
      access: 'viewer',
      guest: fence === 'guest',
      downloaded,
      bundleAccess: fence === 'synthetic viewer' ? 'editor' : 'viewer',
    });
    f.metadata(async () =>
      Response.json(
        downloaded
          ? {
              access: 'editor',
              unitId: 'unit',
              user: { id: fence === 'account' ? 'other' : 'owner' },
            }
          : {
              item: { access: 'editor' },
              live: { unitId: fence === 'generation' ? 'replacement' : 'unit' },
            },
      ),
    );
    await vi.advanceTimersByTimeAsync(1000);
    expect(f.upgradeAccess).not.toHaveBeenCalled();
  },
);

test('maintenance arriving during a prepared upgrade never enables input', async () => {
  const f = await fixture({ access: 'viewer', downloaded: true, maintenanceEpoch: 'old' });
  let finish!: () => void;
  f.offline.upgradeAccess.mockImplementationOnce(async (_access, _revision, verify) => {
    await new Promise<void>((resolve) => {
      finish = resolve;
    });
    verify();
  });
  f.metadata(async () =>
    Response.json({ access: 'editor', unitId: 'unit', user: { id: 'owner' } }),
  );
  await vi.advanceTimersByTimeAsync(1000);
  f.maintenance('draining', 'old');
  finish();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.upgradeAccess).not.toHaveBeenCalled();
});

test('creation admission updates recovery actions and the original link after a native failure', async () => {
  const f = await fixture({ downloaded: true, canRecover: true });
  f.offline.creation = {
    createdAt: 1000,
    request: {
      version: 1,
      itemId: item,
      unitId: '55555555-5555-4555-8555-555555555555',
      kind: 'doc',
      name: 'Offline notes',
      parentId: null,
    },
  };
  f.pending();
  f.conflict();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.saves.at(-1)?.recovery).toMatchObject({
    phase: 'ready',
    creation: true,
    originalHref: '/',
  });
  expect(f.offline.publishRecovery).not.toHaveBeenCalled();

  // The creation receipt commits, but native edits still require recovery.
  f.offline.publishRecovery.mockRejectedValueOnce(new Error('Try the copy again.'));
  f.offline.creation = undefined;
  f.offline.onChange?.();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.saves.at(-1)?.recovery).toMatchObject({
    phase: 'failed',
    originalHref: `/?item=${item}`,
  });
  expect(f.saves.at(-1)?.recovery?.creation).toBeUndefined();
  f.handle.recover();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.publishRecovery).toHaveBeenCalledTimes(2);
  expect(f.saves.at(-1)?.recovery).toMatchObject({
    phase: 'created',
    originalHref: `/?item=${item}`,
    copyHref: `/?item=${f.copyItem.id}`,
  });
});

test('recovery freezes and drains before publication, then removes local work only after the durable response', async () => {
  const f = await fixture({ downloaded: true, canRecover: true, space: true });
  const order: string[] = [];
  let release!: () => void;
  const acknowledged = new Promise<void>((resolve) => {
    release = resolve;
  });
  const prepare = f.offline.prepareRecovery.getMockImplementation()!;
  const finish = f.offline.finishRecovery.getMockImplementation()!;
  f.readonly.mockImplementationOnce(async (preserve) => {
    expect(preserve).toBe(true);
    order.push('freeze');
  });
  f.offline.persist.mockImplementationOnce(async (capture) => {
    f.persisted.push(capture());
    order.push('drain');
  });
  f.offline.prepareRecovery.mockImplementationOnce(async (checkpoint) => {
    order.push('prepare');
    expect(checkpoint).toEqual(f.persisted[0]);
    return prepare(checkpoint);
  });
  f.offline.publishRecovery.mockImplementationOnce(async (request, signal) => {
    order.push('publish');
    expect(request).toEqual(f.recoveryRequest);
    expect(signal.aborted).toBe(false);
    await acknowledged;
    return f.copyItem;
  });
  f.offline.finishRecovery.mockImplementationOnce(async (recoveryId) => {
    order.push('cleanup');
    expect(f.client.disposed).toBe(false);
    expect(f.offline.pending).toBe(true);
    await finish(recoveryId);
  });
  f.pending();
  f.conflict();
  await vi.advanceTimersByTimeAsync(0);
  expect(order).toEqual(['freeze', 'drain', 'prepare', 'publish']);
  expect(f.saves.at(-1)?.recovery).toMatchObject({
    phase: 'creating',
    originalHref: `/spaces/${item}?item=${child}`,
  });
  expect(f.offline.finishRecovery).not.toHaveBeenCalled();
  expect(f.offline.pending).toBe(true);
  expect(f.client.disposed).toBe(false);
  f.handle.recover();
  f.handle.exportRecovery();
  f.handle.discardRecovery();
  f.offline.onChange?.();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.publishRecovery).toHaveBeenCalledOnce();
  expect(f.offline.exportSnapshot).not.toHaveBeenCalled();
  expect(f.offline.finishRecovery).not.toHaveBeenCalled();
  release();
  await vi.advanceTimersByTimeAsync(0);
  expect(order).toEqual(['freeze', 'drain', 'prepare', 'publish', 'cleanup']);
  expect(f.offline.finishRecovery).toHaveBeenCalledWith(f.recoveryRequest.recoveryId);
  expect(f.offline.pending).toBe(false);
  expect(f.client.disposed).toBe(true);
  expect(f.saves.at(-1)?.recovery).toMatchObject({
    phase: 'created',
    copyHref: `/?item=${f.copyItem.id}`,
    copyName: f.copyItem.name,
    originalHref: `/spaces/${item}?item=${child}`,
  });
  expect(f.offline.removeClean).not.toHaveBeenCalled();
  expect(f.reload).not.toHaveBeenCalled();
  f.handle.recover();
  f.offline.onChange?.();
  await vi.advanceTimersByTimeAsync(5000);
  expect(f.offline.publishRecovery).toHaveBeenCalledOnce();
  expect(f.offline.finishRecovery).toHaveBeenCalledOnce();
});

test('failed recovery retains the client and outbox, makes one automatic attempt, and retries the same stored request explicitly', async () => {
  const f = await fixture({ downloaded: true, canRecover: true });
  f.offline.publishRecovery.mockRejectedValueOnce(
    new Error('Recovery is temporarily unavailable.'),
  );
  f.pending();
  f.conflict();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.saves.at(-1)?.recovery).toMatchObject({
    phase: 'failed',
    message: 'Recovery is temporarily unavailable.',
  });
  expect(f.client.disposed).toBe(false);
  expect(f.offline.pending).toBe(true);
  expect(f.offline.finishRecovery).not.toHaveBeenCalled();
  f.offline.onChange?.();
  window.dispatchEvent(new Event('online'));
  await vi.advanceTimersByTimeAsync(5000);
  expect(f.offline.prepareRecovery).toHaveBeenCalledOnce();
  expect(f.offline.publishRecovery).toHaveBeenCalledOnce();
  f.handle.recover();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.publishRecovery).toHaveBeenCalledTimes(2);
  expect(f.offline.publishRecovery.mock.calls.map(([request]) => request)).toEqual([
    f.recoveryRequest,
    f.recoveryRequest,
  ]);
  expect(f.offline.finishRecovery).toHaveBeenCalledWith(f.recoveryRequest.recoveryId);
  expect(f.client.disposed).toBe(true);
  expect(f.offline.pending).toBe(false);
});

test.each([false, true])(
  'clean maintenance resume restarts the page with a new HTTP epoch (downloaded: %s)',
  async (downloaded) => {
    const baseEpoch = '55555555-5555-4555-8555-555555555555';
    const resumedEpoch = '66666666-6666-4666-8666-666666666666';
    const f = await fixture({ downloaded, maintenanceEpoch: baseEpoch });
    let releaseRefresh!: () => void;
    if (downloaded)
      f.offline.refreshClean.mockImplementationOnce(async (verify) => {
        await new Promise<void>((resolve) => {
          releaseRefresh = resolve;
        });
        verify();
      });
    f.maintenance('paused', resumedEpoch);
    await vi.advanceTimersByTimeAsync(0);
    expect(f.reloadPage).not.toHaveBeenCalled();
    f.maintenance('running', resumedEpoch);
    await vi.advanceTimersByTimeAsync(0);
    if (downloaded) {
      // Reopening before the clean device base commits would reload its old
      // epoch again. Navigation waits for that independent durable boundary.
      expect(f.offline.refreshClean).toHaveBeenCalledOnce();
      expect(f.reloadPage).not.toHaveBeenCalled();
      expect(f.client.disposed).toBe(false);
      releaseRefresh();
      await vi.advanceTimersByTimeAsync(0);
    }
    expect(f.readonly).toHaveBeenCalledWith(true);
    expect(f.reloadPage).toHaveBeenCalledOnce();
    expect(f.reload).not.toHaveBeenCalled();
    expect(f.client.disposed).toBe(true);
  },
);

test.each([
  [false, 'queued work'],
  [true, 'queued work'],
  [false, 'native input'],
  [true, 'native input'],
] as const)(
  'maintenance never restarts a page with %s downloaded and %s retained',
  async (downloaded, retained) => {
    const baseEpoch = '55555555-5555-4555-8555-555555555555';
    const f = await fixture({
      downloaded,
      maintenanceEpoch: baseEpoch,
      canRefresh: () => retained !== 'native input',
    });
    if (retained === 'queued work') f.pending();
    f.maintenance('paused', '66666666-6666-4666-8666-666666666666');
    await vi.advanceTimersByTimeAsync(0);
    f.maintenance('running', '66666666-6666-4666-8666-666666666666');
    await vi.advanceTimersByTimeAsync(0);
    expect(f.reloadPage).not.toHaveBeenCalled();
    expect(f.reload).not.toHaveBeenCalled();
    expect(f.offline.refreshClean).not.toHaveBeenCalled();
    expect(f.offline.bundle.maintenanceEpoch).toBe(baseEpoch);
    expect(f.client.disposed).toBe(false);
  },
);

test('automatic recovery retains its base epoch across pause and resume during asynchronous preparation', async () => {
  const baseEpoch = '55555555-5555-4555-8555-555555555555';
  const resumedEpoch = '66666666-6666-4666-8666-666666666666';
  const f = await fixture({ downloaded: true, canRecover: true, maintenanceEpoch: baseEpoch });
  let release!: () => void;
  const held = new Promise<void>((resolve) => {
    release = resolve;
  });
  const prepare = f.offline.prepareRecovery.getMockImplementation()!;
  f.offline.prepareRecovery.mockImplementationOnce(async (checkpoint) => {
    await held;
    return prepare(checkpoint);
  });
  f.offline.publishRecovery.mockRejectedValueOnce(
    new Error('The recovery intent has an old maintenance epoch.'),
  );
  f.pending();
  f.conflict();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.prepareRecovery).toHaveBeenCalledOnce();
  expect(f.offline.publishRecovery).not.toHaveBeenCalled();
  f.maintenance('paused', resumedEpoch);
  await vi.advanceTimersByTimeAsync(0);
  f.maintenance('running', resumedEpoch);
  await vi.advanceTimersByTimeAsync(0);
  release();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.publishRecovery).toHaveBeenCalledExactlyOnceWith(
    f.recoveryRequest,
    expect.any(AbortSignal),
    baseEpoch,
  );
  expect(f.offline.finishRecovery).not.toHaveBeenCalled();
  expect(f.offline.pending).toBe(true);
  expect(f.client.disposed).toBe(false);
  expect(f.saves.at(-1)?.recovery).toMatchObject({
    phase: 'failed',
    message: 'The recovery intent has an old maintenance epoch.',
  });
  f.offline.onChange?.();
  window.dispatchEvent(new Event('online'));
  await vi.advanceTimersByTimeAsync(5000);
  expect(f.offline.publishRecovery).toHaveBeenCalledOnce();
});

test('an explicit recovery retry captures the resumed epoch before preparation and cannot adopt a later resume', async () => {
  const baseEpoch = '55555555-5555-4555-8555-555555555555';
  const firstResume = '66666666-6666-4666-8666-666666666666';
  const secondResume = '77777777-7777-4777-8777-777777777777';
  const f = await fixture({ downloaded: true, canRecover: true, maintenanceEpoch: baseEpoch });
  f.offline.publishRecovery.mockRejectedValueOnce(
    new Error('The first copy attempt was unavailable.'),
  );
  f.offline.publishRecovery.mockImplementation(async (_request, _signal, epoch) => {
    if (epoch !== maintenance.status?.epoch)
      throw new Error('The recovery intent has an old maintenance epoch.');
    return f.copyItem;
  });
  f.pending();
  f.conflict();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.publishRecovery.mock.calls.map((call) => call[2])).toEqual([baseEpoch]);
  f.maintenance('paused', firstResume);
  await vi.advanceTimersByTimeAsync(0);
  // A click while paused has no authority to create a separate copy.
  f.handle.recover();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.publishRecovery).toHaveBeenCalledOnce();
  f.maintenance('running', firstResume);
  await vi.advanceTimersByTimeAsync(0);
  let release!: () => void;
  const held = new Promise<void>((resolve) => {
    release = resolve;
  });
  const prepare = f.offline.prepareRecovery.getMockImplementation()!;
  f.offline.prepareRecovery.mockImplementationOnce(async (checkpoint) => {
    await held;
    return prepare(checkpoint);
  });
  f.handle.recover();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.prepareRecovery).toHaveBeenCalledTimes(2);
  f.maintenance('paused', secondResume);
  await vi.advanceTimersByTimeAsync(0);
  f.maintenance('running', secondResume);
  await vi.advanceTimersByTimeAsync(0);
  release();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.publishRecovery.mock.calls.map((call) => call[2])).toEqual([
    baseEpoch,
    firstResume,
  ]);
  expect(f.offline.finishRecovery).not.toHaveBeenCalled();
  expect(f.offline.pending).toBe(true);
  expect(f.client.disposed).toBe(false);
  // A new user action can now authorize the exact retained copy in the current epoch.
  f.handle.recover();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.publishRecovery.mock.calls.map((call) => call[2])).toEqual([
    baseEpoch,
    firstResume,
    secondResume,
  ]);
  expect(f.offline.publishRecovery.mock.calls.map(([request]) => request)).toEqual([
    f.recoveryRequest,
    f.recoveryRequest,
    f.recoveryRequest,
  ]);
  expect(f.offline.finishRecovery).toHaveBeenCalledExactlyOnceWith(f.recoveryRequest.recoveryId);
  expect(f.offline.pending).toBe(false);
  expect(f.client.disposed).toBe(true);
});

test('failed recovery cleanup retains the exact request and retries the already-created copy', async () => {
  const f = await fixture({ downloaded: true, canRecover: true });
  f.offline.finishRecovery.mockRejectedValueOnce(new Error('Local recovery cleanup failed.'));
  f.pending();
  f.conflict();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.saves.at(-1)?.recovery).toMatchObject({
    phase: 'failed',
    message: 'Local recovery cleanup failed.',
  });
  expect(f.offline.recoveryRequest).toEqual(f.recoveryRequest);
  expect(f.offline.pending).toBe(true);
  expect(f.client.disposed).toBe(false);
  f.handle.recover();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.publishRecovery.mock.calls.map(([request]) => request)).toEqual([
    f.recoveryRequest,
    f.recoveryRequest,
  ]);
  expect(f.offline.finishRecovery.mock.calls).toEqual([
    [f.recoveryRequest.recoveryId],
    [f.recoveryRequest.recoveryId],
  ]);
  expect(f.saves.at(-1)?.recovery).toMatchObject({
    phase: 'created',
    copyHref: `/?item=${f.copyItem.id}`,
  });
  expect(f.offline.pending).toBe(false);
  expect(f.client.disposed).toBe(true);
});

test('explicit discard after a failed copy clears only local work and never republishes the request', async () => {
  const f = await fixture({ downloaded: true, canRecover: true });
  f.offline.publishRecovery.mockRejectedValueOnce(new Error('Copy permission denied.'));
  f.pending();
  f.conflict();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.finishRecovery).not.toHaveBeenCalled();
  const requests = f.requests.mock.calls.length;
  f.handle.discardRecovery();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.publishRecovery).toHaveBeenCalledOnce();
  expect(f.offline.prepareRecovery).toHaveBeenCalledOnce();
  expect(f.offline.finishRecovery).toHaveBeenCalledExactlyOnceWith();
  expect(f.requests.mock.calls).toHaveLength(requests);
  expect(f.offline.pending).toBe(false);
  expect(f.client.disposed).toBe(true);
  expect(f.saves.at(-1)?.recovery).toMatchObject({
    phase: 'discarded',
    originalHref: `/?item=${item}`,
  });
});

test('unfinished host input blocks automatic copy and every explicit recovery action until the input is dismissed', async () => {
  let unfinished = true;
  const f = await fixture({ downloaded: true, canRecover: true, canRefresh: () => !unfinished });
  f.pending();
  f.conflict();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.saves.at(-1)?.recovery?.phase).toBe('ready');
  expect(f.offline.prepareRecovery).not.toHaveBeenCalled();
  f.handle.recover();
  await vi.advanceTimersByTimeAsync(0);
  f.handle.exportRecovery();
  await vi.advanceTimersByTimeAsync(0);
  f.handle.discardRecovery();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.readonly).toHaveBeenCalledWith(true);
  expect(f.saves.at(-1)?.recovery?.message).toBe(
    'Copy or finish the unfinished input before recovering these changes.',
  );
  expect(f.offline.persist).not.toHaveBeenCalled();
  expect(f.offline.prepareRecovery).not.toHaveBeenCalled();
  expect(f.offline.publishRecovery).not.toHaveBeenCalled();
  expect(f.offline.exportSnapshot).not.toHaveBeenCalled();
  expect(f.offline.finishRecovery).not.toHaveBeenCalled();
  expect(downloadOfflineFile).not.toHaveBeenCalled();
  expect(f.offline.pending).toBe(true);
  expect(f.client.disposed).toBe(false);
  unfinished = false;
  f.handle.recover();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.publishRecovery).toHaveBeenCalledOnce();
  expect(f.saves.at(-1)?.recovery?.phase).toBe('created');
});

test('a failed local drain cannot publish a recovery snapshot or remove the pending outbox', async () => {
  const f = await fixture({ downloaded: true, canRecover: true });
  f.offline.persist.mockRejectedValueOnce(new Error('Device storage is full.'));
  f.pending();
  f.conflict();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.saves.at(-1)).toMatchObject({
    dirty: true,
    local: 'failed',
    recovery: { phase: 'failed', message: 'Device storage is full.' },
  });
  expect(f.offline.prepareRecovery).not.toHaveBeenCalled();
  expect(f.offline.publishRecovery).not.toHaveBeenCalled();
  expect(f.offline.finishRecovery).not.toHaveBeenCalled();
  expect(f.offline.pending).toBe(true);
  expect(f.client.disposed).toBe(false);
  f.handle.retry();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.persist).toHaveBeenCalledTimes(2);
  expect(f.offline.publishRecovery).not.toHaveBeenCalled();
  f.handle.recover();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.persist).toHaveBeenCalledTimes(3);
  expect(f.offline.publishRecovery).toHaveBeenCalledOnce();
  expect(f.saves.at(-1)?.recovery?.phase).toBe('created');
});

test('a session without recovery ownership never exposes or starts the copy workflow', async () => {
  const f = await fixture({ downloaded: true, canRecover: false });
  f.pending();
  f.conflict();
  await vi.advanceTimersByTimeAsync(0);
  f.handle.recover();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.saves.at(-1)?.recovery).toBeUndefined();
  expect(f.offline.prepareRecovery).not.toHaveBeenCalled();
  expect(f.offline.publishRecovery).not.toHaveBeenCalled();
  expect(f.offline.finishRecovery).not.toHaveBeenCalled();
  expect(f.offline.pending).toBe(true);
  expect(f.client.disposed).toBe(false);
});

test.each(['metadata', 'publication'] as const)(
  'a 401 from %s holds durable work for local export until the explicit sign-in action',
  async (source) => {
    const f = await fixture({ downloaded: true, canRecover: true });
    f.pending();
    if (source === 'metadata') {
      f.metadata(async () => Response.json({}, { status: 401 }));
      await vi.advanceTimersByTimeAsync(1000);
    } else {
      f.offline.publishRecovery.mockRejectedValueOnce(
        Object.assign(new Error('Your sign-in ended.'), { status: 401 }),
      );
      f.conflict();
      await vi.advanceTimersByTimeAsync(0);
    }
    expect(f.offline.endAuthentication).toHaveBeenCalledOnce();
    expect(f.saves.at(-1)).toMatchObject({
      retained: true,
      signInRequired: true,
      local: 'attention',
    });
    expect(f.saves.at(-1)?.recovery).toBeDefined();
    expect(f.signIn).not.toHaveBeenCalled();
    expect(f.client.disposed).toBe(false);
    expect(f.offline.pending).toBe(true);
    expect(f.offline.finishRecovery).not.toHaveBeenCalled();
    const publications = f.offline.publishRecovery.mock.calls.length;
    f.handle.exportRecovery();
    await vi.waitFor(() => expect(downloadOfflineFile).toHaveBeenCalledOnce());
    expect(downloadOfflineFile).toHaveBeenCalledWith(
      f.recoveryRequest.snapshot,
      'Offline notes (offline copy, 2026-10-27 14:35).univer.json',
    );
    expect(f.offline.publishRecovery).toHaveBeenCalledTimes(publications);
    expect(f.offline.finishRecovery).not.toHaveBeenCalled();
    expect(f.offline.pending).toBe(true);
    expect(f.client.disposed).toBe(false);
    expect(f.signIn).not.toHaveBeenCalled();
    f.handle.retry();
    await vi.advanceTimersByTimeAsync(0);
    expect(f.signIn).toHaveBeenCalledExactlyOnceWith('/sign-in');
    expect(f.client.disposed).toBe(true);
    expect(f.offline.pending).toBe(true);
    expect(f.offline.finishRecovery).not.toHaveBeenCalled();
  },
);

test.each(['freeze', 'drain', 'prepare', 'publish'] as const)(
  'account invalidation while recovery waits for %s fences every later publication and local cleanup',
  async (stage) => {
    const f = await fixture({ downloaded: true, canRecover: true });
    let release!: () => void;
    const held = new Promise<void>((resolve) => {
      release = resolve;
    });
    if (stage === 'freeze') f.readonly.mockImplementationOnce(() => held);
    if (stage === 'drain')
      f.offline.persist.mockImplementationOnce((capture) => {
        f.persisted.push(capture());
        return held;
      });
    if (stage === 'prepare')
      f.offline.prepareRecovery.mockImplementationOnce(async () => {
        await held;
        return f.recoveryRequest;
      });
    if (stage === 'publish')
      f.offline.publishRecovery.mockImplementationOnce(async () => {
        await held;
        return f.copyItem;
      });
    f.pending();
    f.conflict();
    await vi.advanceTimersByTimeAsync(0);
    expect(f.offline.finishRecovery).not.toHaveBeenCalled();
    const reports = f.saves.length;
    f.offline.current = false;
    release();
    await vi.advanceTimersByTimeAsync(0);
    expect(f.offline.publishRecovery).toHaveBeenCalledTimes(stage === 'publish' ? 1 : 0);
    expect(f.offline.finishRecovery).not.toHaveBeenCalled();
    expect(downloadOfflineFile).not.toHaveBeenCalled();
    expect(f.offline.pending).toBe(true);
    expect(f.signIn).not.toHaveBeenCalled();
    expect(f.saves).toHaveLength(reports);
    expect(f.reload).not.toHaveBeenCalled();
  },
);

test('a socket open is not room readiness or a durable save, and reconnect retains pending status', async () => {
  const f = await fixture();
  expect(new URL(f.socket().url).searchParams.get('afterRevision')).toBe('8');
  f.socket().open();
  expect(f.connections.at(-1)).toBe('reconnecting');
  expect(f.saves.at(-1)?.message).not.toBe('All changes saved.');
  f.socket().frame({
    type: 'resume',
    version: 1,
    unitId: 'unit',
    fromRevision: 8,
    revision: 8,
    edits: [],
  });
  expect(f.connections.at(-1)).toBe('online');
  expect(f.saves.at(-1)).toMatchObject({
    dirty: false,
    failed: false,
    message: 'All changes saved.',
  });
  f.pending();
  expect(f.saves.at(-1)).toMatchObject({ dirty: true, failed: false });
  f.socket().close();
  expect(f.saves.at(-1)).toMatchObject({ dirty: true, failed: true });
  await vi.advanceTimersByTimeAsync(300);
  expect(Socket.instances).toHaveLength(2);
  f.socket().open();
  f.socket().frame({
    type: 'resume',
    version: 1,
    unitId: 'unit',
    fromRevision: 8,
    revision: 9,
    edits: [],
  });
  expect(f.saves.at(-1)).toMatchObject({ dirty: true });
  f.socket().frame({
    type: 'ack',
    mutationId: 'sent',
    revision: 10,
    mutations: [],
    touched: { kind: 'doc' },
    hash: 'hash',
    duplicate: true,
  });
  expect(f.saves.at(-1)).toMatchObject({ dirty: false, failed: false });
});

test.each(['response', 'body'] as const)(
  'preparing a Space child during its metadata %s rechecks access without freezing the editor',
  async (stage) => {
    const f = await fixture({ preparing: true, space: true });
    f.socket().open();
    f.socket().frame({
      type: 'resume',
      version: 1,
      unitId: 'unit',
      fromRevision: 8,
      revision: 8,
      edits: [],
    });
    await vi.advanceTimersByTimeAsync(0);
    expect(f.saves.at(-1)?.message).toBe('All changes saved.');

    const metadata = { item: { access: 'editor' }, live: { unitId: 'unit' } };
    const response = Response.json(metadata);
    let release!: () => void;
    if (stage === 'response') {
      const held = new Promise<Response>((resolve) => {
        release = () => resolve(response);
      });
      f.metadata(() => held);
    } else {
      const held = new Promise<typeof metadata>((resolve) => {
        release = () => resolve(metadata);
      });
      vi.spyOn(response, 'json').mockImplementationOnce(() => held);
      f.metadata(async () => response);
    }
    await vi.advanceTimersByTimeAsync(1000);
    expect(f.requests.mock.calls.at(-1)?.[0]).toBe(`/api/spaces/${item}/items/${child}`);
    expect(f.requests.mock.calls.at(-1)?.[1]?.method).toBeUndefined();

    // Preparation activates the existing native binding through its real
    // event/persistence path while the ordinary metadata read is still held.
    f.offline.persist.mockImplementationOnce(async (capture) => {
      f.offline.enabled = true;
      f.offline.onChange?.();
      f.persisted.push(capture());
    });
    window.dispatchEvent(
      new CustomEvent('spinel-offline-prepared', { detail: { accountId: 'owner' } }),
    );
    await vi.advanceTimersByTimeAsync(0);
    expect(f.offline.reconcileAvailability).toHaveBeenCalledOnce();
    expect(f.offline.persist).toHaveBeenCalledOnce();
    expect(f.persisted[0]).toMatchObject({ sent: null, buffer: [] });
    expect(f.persisted[0].failure).toBeUndefined();

    let confirm!: (response: Response) => void;
    const confirmation = new Promise<Response>((resolve) => {
      confirm = resolve;
    });
    f.metadata(() => confirmation);
    const requests = f.requests.mock.calls.length;
    release();
    await vi.advanceTimersByTimeAsync(0);
    expect(f.requests).toHaveBeenCalledTimes(requests + 1);
    expect(f.requests.mock.calls.at(-1)).toEqual([
      `/api/spaces/${item}/items/${child}/collaboration`,
      expect.objectContaining({
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{}',
      }),
    ]);
    expect(f.readonly).not.toHaveBeenCalled();
    expect(f.offline.stopRemote).not.toHaveBeenCalled();
    expect(f.offline.refreshClean).not.toHaveBeenCalled();
    expect(f.offline.removeClean).not.toHaveBeenCalled();
    expect(f.client.state.resyncing).toBe(false);

    confirm(Response.json({ access: 'editor', unitId: 'unit', user: { id: 'owner' } }));
    await vi.advanceTimersByTimeAsync(0);
    expect(f.saves.at(-1)).toMatchObject({
      local: 'synced',
      failed: false,
      message: 'Synced. All changes are saved on the server and this device.',
    });
    expect(f.socket().readyState).toBe(Socket.OPEN);
    expect(f.reload).not.toHaveBeenCalled();

    // The obsolete response does not weaken the next real access denial or
    // allow it to delete an edit made after preparation completed.
    f.pending();
    f.metadata(async () => Response.json({}, { status: 403 }));
    await vi.advanceTimersByTimeAsync(1000);
    expect(f.saves.at(-1)).toMatchObject({ local: 'attention', retained: true });
    expect(f.client.state.resyncing).toBe(true);
    expect(f.readonly).toHaveBeenCalled();
    expect(f.offline.pending).toBe(true);
    expect(f.offline.removeClean).not.toHaveBeenCalled();
    expect(f.offline.refreshClean).not.toHaveBeenCalled();
  },
);

test('a clean downloaded base outside replay retention refreshes without retaining a failure', async () => {
  const f = await fixture({ downloaded: true });
  f.socket().open();
  f.socket().frame({ type: 'resync', reason: 'stale' });
  await vi.advanceTimersByTimeAsync(0);
  expect(f.readonly).toHaveBeenCalledOnce();
  expect(f.offline.persist).toHaveBeenCalledOnce();
  expect(f.offline.refreshClean).toHaveBeenCalledOnce();
  expect(f.client.received).toEqual([]);
  expect(f.client.disposed).toBe(true);
  expect(f.reload).toHaveBeenCalledWith('stale', true);
});

test.each([403, 404])(
  'verified %s removes a clean downloaded child after freezing and draining, without inventing edits',
  async (status) => {
    const f = await fixture({ downloaded: true, space: true });
    const order: string[] = [];
    f.readonly.mockImplementationOnce(async () => {
      order.push('freeze');
    });
    f.offline.persist.mockImplementationOnce(async (capture) => {
      f.persisted.push(capture());
      order.push('drain');
    });
    f.offline.removeClean.mockImplementationOnce(async (verify) => {
      verify();
      order.push('remove');
    });
    f.metadata(async () => Response.json({}, { status }));
    await vi.advanceTimersByTimeAsync(1000);
    expect(order).toEqual(['freeze', 'drain', 'remove']);
    expect(f.offline.refreshClean).not.toHaveBeenCalled();
    expect(f.client.state.resyncing).toBe(false);
    expect(f.client.disposed).toBe(true);
    expect(f.lock).toHaveBeenCalledOnce();
    expect(f.reload).not.toHaveBeenCalled();
    expect(f.requests.mock.calls.at(-1)?.[0]).toBe(
      `/api/spaces/${item}/items/${child}/collaboration`,
    );
  },
);

test.each([false, true])(
  'a 401 expires preparation and drains locally, retaining pending work before explicit sign-in (pending: %s)',
  async (pending) => {
    const f = await fixture({ downloaded: true });
    if (pending) f.pending();
    const order: string[] = [];
    f.readonly.mockImplementationOnce(async (preserveInput) => {
      expect(f.offline.stopAuthenticationHTTP).toHaveBeenCalledOnce();
      expect(preserveInput).toBe(true);
      order.push('freeze');
    });
    f.offline.persist.mockImplementationOnce(async (capture) => {
      f.persisted.push(capture());
      order.push('persist');
    });
    f.offline.endAuthentication.mockImplementationOnce(() => {
      order.push('expire');
    });
    f.metadata(async () => Response.json({}, { status: 401 }));
    await vi.advanceTimersByTimeAsync(1000);
    expect(order).toEqual(['expire', 'freeze', 'persist']);
    expect(f.offline.removeClean).not.toHaveBeenCalled();
    expect(f.offline.refreshClean).not.toHaveBeenCalled();
    expect(f.client.state.resyncing).toBe(false);
    expect(f.client.disposed).toBe(!pending);
    if (pending) {
      expect(f.offline.pending).toBe(true);
      expect(f.signIn).not.toHaveBeenCalled();
      expect(f.saves.at(-1)).toMatchObject({
        retained: true,
        signInRequired: true,
        local: 'attention',
      });
      f.handle.retry();
      await vi.advanceTimersByTimeAsync(0);
      expect(f.signIn).toHaveBeenCalledWith('/sign-in');
      expect(f.offline.pending).toBe(true);
      expect(f.client.disposed).toBe(true);
    } else expect(f.signIn).toHaveBeenCalledWith('/sign-in');
  },
);

test.each(['disk', 'recovery', 'host input', 'timeout'] as const)(
  'a 401 disables offline reopening but retains the visible editor after %s prevents a safe exit',
  async (failure) => {
    const f = await fixture({ downloaded: true, canRefresh: () => failure !== 'host input' });
    f.pending();
    if (failure === 'disk') f.offline.persist.mockRejectedValueOnce(new Error('Disk full'));
    if (failure === 'recovery') f.client.state.recoveryMissing = true;
    if (failure === 'timeout')
      f.offline.persist.mockImplementationOnce((capture) => {
        f.persisted.push(capture());
        return new Promise(() => {});
      });
    f.metadata(async () => Response.json({}, { status: 401 }));
    await vi.advanceTimersByTimeAsync(4001);
    expect(f.offline.endAuthentication).toHaveBeenCalledOnce();
    expect(f.offline.removeClean).not.toHaveBeenCalled();
    expect(f.client.disposed).toBe(false);
    expect(f.signIn).not.toHaveBeenCalled();
    expect(f.readonly).toHaveBeenCalledWith(true);
    expect(f.socket().readyState).toBe(3);
    if (failure === 'disk') {
      expect(f.saves.at(-1)).toMatchObject({ dirty: true, local: 'failed' });
      f.handle.retry();
      await vi.advanceTimersByTimeAsync(0);
      expect(f.signIn).toHaveBeenCalledWith('/sign-in');
      expect(f.client.disposed).toBe(true);
    }
  },
);

test('durable expired work exposes a sign-in handoff that still waits for unfinished host input', async () => {
  let unfinished = true;
  const f = await fixture({ downloaded: true, canRefresh: () => !unfinished });
  f.pending();
  f.metadata(async () => Response.json({}, { status: 401 }));
  await vi.advanceTimersByTimeAsync(1000);
  expect(f.saves.at(-1)).toMatchObject({
    dirty: false,
    local: 'attention',
    retained: true,
    signInRequired: true,
  });
  f.handle.retry();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.signIn).not.toHaveBeenCalled();
  unfinished = false;
  f.handle.retry();
  await vi.advanceTimersByTimeAsync(0);
  expect(f.signIn).toHaveBeenCalledOnce();
  expect(f.client.state.pending).toBe(true);
  expect(f.offline.removeClean).not.toHaveBeenCalled();
});

test('an account change during the 401 local drain cannot clear or redirect the new account', async () => {
  const f = await fixture({ downloaded: true });
  f.offline.persist.mockImplementationOnce(async (capture) => {
    f.persisted.push(capture());
    f.offline.current = false;
  });
  f.metadata(async () => Response.json({}, { status: 401 }));
  await vi.advanceTimersByTimeAsync(1000);
  expect(f.offline.endAuthentication).toHaveBeenCalledOnce();
  expect(f.signIn).not.toHaveBeenCalled();
});

test.each(['viewer', 'generation'] as const)(
  'a clean authorized %s change refreshes the download and reopens without a failure checkpoint',
  async (change) => {
    const f = await fixture({ downloaded: true });
    f.metadata(async () =>
      Response.json({
        access: change === 'viewer' ? 'viewer' : 'editor',
        unitId: change === 'generation' ? 'replacement' : 'unit',
        user: { id: 'owner' },
      }),
    );
    await vi.advanceTimersByTimeAsync(1000);
    expect(f.readonly).toHaveBeenCalledOnce();
    expect(f.offline.persist).toHaveBeenCalledOnce();
    expect(f.offline.refreshClean).toHaveBeenCalledOnce();
    expect(f.offline.removeClean).not.toHaveBeenCalled();
    expect(f.client.state.resyncing).toBe(false);
    expect(f.client.disposed).toBe(true);
    expect(f.reload).toHaveBeenCalledWith('stale', true);
    expect(f.lock).not.toHaveBeenCalled();
  },
);

test.each([false, true])(
  'an expected-account 409 never removes or replaces the prior account copy (pending: %s)',
  async (pending) => {
    const f = await fixture({ downloaded: true });
    if (pending) f.pending();
    f.metadata(async () => Response.json({}, { status: 409 }));
    await vi.advanceTimersByTimeAsync(1000);
    expect(f.offline.removeClean).not.toHaveBeenCalled();
    expect(f.offline.refreshClean).not.toHaveBeenCalled();
    expect(f.client.disposed).toBe(false);
    expect(f.client.state.resyncing).toBe(pending);
    expect(f.saves.at(-1)?.local).toBe('attention');
    expect(f.readonly).toHaveBeenCalled();
    expect(f.reload).not.toHaveBeenCalled();
    expect(f.lock).not.toHaveBeenCalled();
  },
);

test.each(['queue', 'durable queue', 'recovery', 'host input'] as const)(
  'access loss retains %s and does not delete or replace the downloaded copy',
  async (work) => {
    const f = await fixture({ downloaded: true, canRefresh: () => work !== 'host input' });
    if (work === 'queue') f.pending();
    if (work === 'durable queue') f.offline.pending = true;
    if (work === 'recovery') {
      f.client.state.recoveryMissing = true;
      f.client.options.onState(f.client.state);
    }
    f.metadata(async () => Response.json({}, { status: 404 }));
    await vi.advanceTimersByTimeAsync(1000);
    expect(f.offline.removeClean).not.toHaveBeenCalled();
    expect(f.offline.refreshClean).not.toHaveBeenCalled();
    expect(f.client.disposed).toBe(false);
    expect(f.client.state.resyncing).toBe(true);
    expect(f.saves.at(-1)?.local).toBe(work === 'recovery' ? 'failed' : 'attention');
    expect(f.readonly).toHaveBeenCalled();
  },
);

test.each(['freeze', 'drain', 'commit'] as const)(
  'an edit appearing during clean access-loss %s is retained instead of removed',
  async (stage) => {
    const f = await fixture({ downloaded: true });
    if (stage === 'freeze') f.readonly.mockImplementationOnce(async () => f.pending());
    if (stage === 'drain')
      f.offline.persist.mockImplementationOnce(async (capture) => {
        f.persisted.push(capture());
        f.pending();
      });
    if (stage === 'commit')
      f.offline.removeClean.mockImplementationOnce(async (verify) => {
        f.pending();
        verify();
      });
    f.metadata(async () => Response.json({}, { status: 403 }));
    await vi.advanceTimersByTimeAsync(1000);
    if (stage !== 'commit') expect(f.offline.removeClean).not.toHaveBeenCalled();
    expect(f.client.state.pending).toBe(true);
    expect(f.client.state.resyncing).toBe(true);
    expect(f.client.disposed).toBe(false);
    expect(f.lock).not.toHaveBeenCalled();
    expect(f.reload).not.toHaveBeenCalled();
  },
);

test('a failed clean removal shows attention without creating a permanent recovery checkpoint', async () => {
  const f = await fixture({ downloaded: true });
  f.offline.removeClean.mockRejectedValueOnce(new Error('Disk failure'));
  f.metadata(async () => Response.json({}, { status: 403 }));
  await vi.advanceTimersByTimeAsync(1000);
  expect(f.saves.at(-1)).toMatchObject({ local: 'attention', dirty: false, retained: false });
  expect(f.client.state.resyncing).toBe(false);
  expect(f.client.disposed).toBe(false);
  expect(f.lock).not.toHaveBeenCalled();
});

test('a stale clean queue cannot replace uncommitted host cell input or an image insertion', async () => {
  let inputFinished = false;
  const f = await fixture({ downloaded: true, canRefresh: () => inputFinished });
  f.socket().open();
  f.socket().frame({ type: 'resync', reason: 'stale' });
  await vi.advanceTimersByTimeAsync(300);
  expect(f.readonly).not.toHaveBeenCalled();
  expect(f.offline.refreshClean).not.toHaveBeenCalled();
  expect(f.reload).not.toHaveBeenCalled();
  expect(f.client.received).toEqual([]);
  // Finishing the native input normally creates pending queue work; that work
  // must take the conservative conflict path on the next stale response.
  inputFinished = true;
  f.pending();
  f.socket().open();
  f.socket().frame({ type: 'resync', reason: 'stale' });
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.refreshClean).not.toHaveBeenCalled();
  expect(f.client.received).toEqual([{ type: 'resync', reason: 'stale' }]);
});

test('a stale response never refreshes a downloaded document with pending local work', async () => {
  const f = await fixture({ downloaded: true });
  f.pending();
  f.socket().open();
  f.socket().frame({ type: 'resync', reason: 'stale' });
  await vi.advanceTimersByTimeAsync(0);
  expect(f.offline.refreshClean).not.toHaveBeenCalled();
  expect(f.client.received).toEqual([{ type: 'resync', reason: 'stale' }]);
  expect(f.reload).not.toHaveBeenCalled();
});

test.each(['count', 'bytes'] as const)(
  'incoming offline frames are bounded by %s before a stalled image read',
  async (limit) => {
    const f = await fixture({ downloaded: true });
    let release!: () => void;
    f.offline.prepareImages.mockImplementationOnce(
      () =>
        new Promise<void>((resolve) => {
          release = resolve;
        }),
    );
    f.socket().open();
    const stalled = f.socket();
    stalled.frame({
      type: 'resume',
      version: 1,
      unitId: 'unit',
      fromRevision: 8,
      revision: 8,
      edits: [],
    });
    await vi.advanceTimersByTimeAsync(0);
    const signal = f.offline.prepareImages.mock.calls[0]![1]!;
    if (limit === 'count') {
      for (let i = 0; i < 129; i++) stalled.frame({ type: 'edit', revision: i + 9, mutations: [] });
    } else stalled.onmessage?.({ data: 'x'.repeat(10 * 1024 * 1024 + 1) });
    expect(stalled.readyState).toBe(3);
    expect(signal.aborted).toBe(true);
    release();
    await vi.advanceTimersByTimeAsync(300);
    expect(f.client.received).toEqual([]);
    expect(f.offline.prepareImages).toHaveBeenCalledOnce();
    expect(Socket.instances).toHaveLength(2);
    expect(f.reload).not.toHaveBeenCalled();
  },
);

test('uncaptured visible recovery edits keep the navigation warning after a failure marker saves', async () => {
  const f = await fixture({ downloaded: true });
  f.client.options.onState({
    ...f.client.state,
    recoveryMissing: true,
    resyncing: true,
    localPersistence: 'saved',
  });
  expect(f.saves.at(-1)).toMatchObject({ dirty: true, failed: true, local: 'failed' });
  expect(f.saves.at(-1)?.message).toContain('Keep this tab open');
});

test.each(['saving', 'failed'] as const)(
  'attention never conceals a %s local checkpoint or its navigation warning',
  async (localPersistence) => {
    const f = await fixture({ downloaded: true });
    f.client.state = {
      ...f.client.state,
      pending: true,
      resyncing: true,
      localPersistence,
    };
    f.client.options.onState(f.client.state);
    expect(f.saves.at(-1)).toMatchObject({ dirty: true, failed: true, local: localPersistence });
    expect(f.saves.at(-1)?.message).toContain('attention');
    if (localPersistence === 'failed') {
      expect(f.saves.at(-1)?.message).toContain('Keep this tab open and retry saving');
      expect(f.saves.at(-1)?.message).not.toContain('saved device copy is retained');
    }
    f.client.state.localPersistence = 'saved';
    f.client.options.onState(f.client.state);
    expect(f.saves.at(-1)).toMatchObject({ dirty: false, failed: true, local: 'attention' });
  },
);

test('durable offline work retains an unavailable page without marking it unsaved', async () => {
  const f = await fixture({ downloaded: true, space: true });
  f.client.state = {
    ...f.client.state,
    pending: true,
    pendingMutations: 1,
    localPersistence: 'saved',
  };
  f.client.options.onState(f.client.state);
  expect(f.saves.at(-1)).toMatchObject({ dirty: false, retained: true, local: 'saved' });
  f.metadata(async () => Response.json({}, { status: 404 }));
  await vi.advanceTimersByTimeAsync(1000);
  expect(f.saves.at(-1)).toMatchObject({ dirty: false, retained: true, local: 'attention' });
  expect(f.readonly).toHaveBeenCalled();
  expect(f.client.disposed).toBe(false);
});

test('a clean downloaded copy has no retained-work flag and a completed queue clears it', async () => {
  const f = await fixture({ downloaded: true });
  expect(f.saves.at(-1)).toMatchObject({ dirty: false, retained: false });
  f.pending();
  expect(f.saves.at(-1)?.retained).toBe(true);
  f.client.state = {
    ...f.client.state,
    pending: false,
    pendingMutations: 0,
    localPersistence: 'saved',
  };
  f.offline.pending = false;
  f.client.options.onState(f.client.state);
  expect(f.saves.at(-1)).toMatchObject({ dirty: false, retained: false });
});

test('ordinary guest pending work keeps its original dirty behavior without offline retention', async () => {
  const f = await fixture({ guest: true, space: true });
  f.pending();
  expect(f.saves.at(-1)?.dirty).toBe(true);
  expect(f.saves.at(-1)?.retained).toBeUndefined();
});

test('pending work publishes before the readiness watcher or socket can start', async () => {
  let guarded = false;
  const f = await fixture({
    onInitialPending() {
      guarded = true;
    },
    beforeWatch() {
      expect(Socket.instances).toHaveLength(0);
      const client = native.clients.at(-1)!;
      client.state = { ...client.state, pending: true, pendingMutations: 1 };
      client.options.onState(client.state);
      expect(guarded).toBe(true);
      expect(Socket.instances).toHaveLength(0);
    },
  });
  expect(f.saves.at(-1)?.dirty).toBe(true);
});

test('initial access completes before capture or socket startup even when readiness is delayed', async () => {
  let release!: () => void;
  let applied = false;
  const loading = fixture({
    initializeAccess() {
      applied = true;
      return new Promise<void>((resolve) => {
        release = resolve;
      });
    },
  });
  await vi.advanceTimersByTimeAsync(0);
  expect(applied).toBe(true);
  expect(native.clients).toHaveLength(0);
  expect(Socket.instances).toHaveLength(0);
  release();
  const f = await loading;
  expect(native.clients).toHaveLength(1);
  expect(f.univer.createUnit).toHaveBeenCalledOnce();
});

test('Space guest socket, tickets and metadata stay in the exact root/child scope', async () => {
  const f = await fixture({ guest: true, space: true });
  const prefix = `/sync-api/guest-spaces/${item}/items/${child}`;
  expect(f.requests.mock.calls.slice(0, 2).every(([url]) => url.startsWith(prefix))).toBe(true);
  expect(new URL(f.socket().url).pathname).toBe(`${prefix}/socket`);
  f.metadata(async () => Response.json({}, { status: 403 }));
  await vi.advanceTimersByTimeAsync(1000);
  expect(f.dispatched.mock.calls.some(([event]) => event.type === 'spinel-guest-revoked')).toBe(
    true,
  );
  expect(f.socket().readyState).toBe(3);
});

test.each([false, true])(
  'a confirmed guest root ticket denial is terminal despite unreachable metadata (Space=%s)',
  async (space) => {
    const f = await fixture({ guest: true, space });
    f.pending();
    f.metadata(async () => {
      throw new TypeError('Network unavailable');
    });
    const request = f.requests.getMockImplementation()!;
    f.requests.mockImplementation(async (input, init) =>
      input.includes('/ticket?')
        ? Response.json({ code: 'guest-link-revoked' }, { status: 403 })
        : request(input, init),
    );
    f.socket().close();
    await vi.advanceTimersByTimeAsync(300);
    expect(
      f.dispatched.mock.calls.filter(([event]) => event.type === 'spinel-guest-revoked'),
    ).toHaveLength(1);
    expect(f.client.state.pending).toBe(true);
    expect(f.saves.at(-1)?.dirty).toBe(true);
    const requests = f.requests.mock.calls.length;
    await vi.advanceTimersByTimeAsync(5000);
    expect(f.requests).toHaveBeenCalledTimes(requests);
    expect(Socket.instances).toHaveLength(1);
  },
);

test.each(['unmarked', 'malformed', 'network'] as const)(
  '%s ticket failure with unreachable metadata preserves pending guest input',
  async (failure) => {
    const f = await fixture({ guest: true });
    f.pending();
    f.metadata(async () => {
      throw new TypeError('Network unavailable');
    });
    const request = f.requests.getMockImplementation()!;
    f.requests.mockImplementation(async (input, init) => {
      if (!input.includes('/ticket?')) return request(input, init);
      if (failure === 'network') throw new TypeError('Network unavailable');
      return failure === 'malformed'
        ? new Response('not JSON', { status: 403 })
        : Response.json({ error: 'This document is not available.' }, { status: 403 });
    });
    f.socket().close();
    await vi.advanceTimersByTimeAsync(2000);
    expect(f.dispatched.mock.calls.some(([event]) => event.type === 'spinel-guest-revoked')).toBe(
      false,
    );
    expect(f.client.state.pending).toBe(true);
    expect(f.saves.at(-1)?.dirty).toBe(true);
    expect(f.reload).not.toHaveBeenCalled();
  },
);

test.each(['departed', 'reconnected'] as const)(
  'a %s binding ignores an old guest denial body',
  async (change) => {
    const f = await fixture({ guest: true, space: true });
    f.pending();
    f.metadata(async () => {
      throw new TypeError('Network unavailable');
    });
    let release!: (body: unknown) => void;
    const response = Response.json({}, { status: 403 });
    vi.spyOn(response, 'json').mockImplementation(
      () =>
        new Promise((resolve) => {
          release = resolve;
        }),
    );
    const request = f.requests.getMockImplementation()!;
    let held = false;
    f.requests.mockImplementation(async (input, init) => {
      if (input.includes('/ticket?') && !held) {
        held = true;
        return response;
      }
      return request(input, init);
    });
    f.socket().close();
    await vi.advanceTimersByTimeAsync(300);
    expect(release).toBeDefined();
    if (change === 'departed') f.leave();
    else window.dispatchEvent(new Event('online'));
    await vi.advanceTimersByTimeAsync(300);
    const reports = f.saves.length;
    release({ code: 'guest-link-revoked' });
    await vi.advanceTimersByTimeAsync(0);
    expect(f.dispatched.mock.calls.some(([event]) => event.type === 'spinel-guest-revoked')).toBe(
      false,
    );
    expect(f.saves).toHaveLength(reports);
    expect(f.client.state.pending).toBe(true);
  },
);

test.each([false, true])(
  'a stalled socket or initial replay reconnects without clearing pending edits (opened=%s)',
  async (opened) => {
    const f = await fixture();
    f.pending();
    const stalled = f.socket();
    if (opened) stalled.open();
    await vi.advanceTimersByTimeAsync(15_300);
    expect(stalled.readyState).toBe(3);
    expect(Socket.instances).toHaveLength(2);
    expect(f.saves.at(-1)).toMatchObject({ dirty: true, failed: true });
    expect(new URL(f.socket().url).searchParams.get('afterRevision')).toBe('8');
    expect(f.reload).not.toHaveBeenCalled();
  },
);

test('a departed child’s late access denial cannot revoke the replacement guest or publish old status', async () => {
  const f = await fixture({ guest: true, space: true });
  let release!: (response: Response) => void;
  f.metadata(
    () =>
      new Promise((resolve) => {
        release = resolve;
      }),
  );
  await vi.advanceTimersByTimeAsync(1000);
  f.leave();
  const reports = f.saves.length;
  release(Response.json({}, { status: 403 }));
  await vi.advanceTimersByTimeAsync(0);
  expect(f.dispatched).not.toHaveBeenCalled();
  expect(f.saves).toHaveLength(reports);
});

test('membership disappears on disconnect, and disposal fences late socket and native callbacks', async () => {
  const f = await fixture();
  const updates: unknown[] = [];
  getSyncPresence(f.univer, 'unit')!.subscribe((state) => updates.push(state));
  f.socket().open();
  f.socket().frame({
    type: 'resume',
    version: 1,
    unitId: 'unit',
    fromRevision: 8,
    revision: 8,
    edits: [],
  });
  f.socket().frame({
    type: 'presence',
    selfId: 'me',
    members: [{ id: 'peer', name: 'Collaborator', avatar: '', selection: '0:0:1:TEXT::-1' }],
  });
  expect(updates.at(-1)).toMatchObject({ connected: true, members: [{ id: 'peer' }] });
  f.socket().close();
  expect(updates.at(-1)).toMatchObject({ connected: false, members: [] });
  f.handle.dispose();
  const reports = f.saves.length;
  f.client.options.onState({ ...f.client.state, connected: true, pending: false });
  f.socket().frame({
    type: 'resume',
    version: 1,
    unitId: 'unit',
    fromRevision: 8,
    revision: 8,
    edits: [],
  });
  await vi.advanceTimersByTimeAsync(30_000);
  expect(f.saves).toHaveLength(reports);
  expect(f.client.disposed).toBe(true);
  expect(getSyncPresence(f.univer, 'unit')).toBeUndefined();
  expect(Socket.instances).toHaveLength(1);
});

test('restore or role change keeps pending work unsaved and makes the editor readonly', async () => {
  const f = await fixture();
  f.pending();
  f.metadata(async () =>
    Response.json({ item: { access: 'editor' }, live: { unitId: 'replacement' } }),
  );
  await vi.advanceTimersByTimeAsync(1000);
  expect(f.readonly).toHaveBeenCalledOnce();
  expect(f.saves.at(-1)).toMatchObject({ dirty: true, failed: true });
  expect(f.saves.at(-1)?.message).toContain('restored');
  expect(f.socket().readyState).toBe(3);
  expect(f.reload).not.toHaveBeenCalled();
});
