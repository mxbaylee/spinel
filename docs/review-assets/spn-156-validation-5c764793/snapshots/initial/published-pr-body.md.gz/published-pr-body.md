Saved offline edits previously waited for their editor to reopen after the running file list reconnected. This adds one account-scoped replay owner for eligible downloaded Docs and Sheets, using the existing native sync client, authority checks and durable checkpoint path. Foreground editing or explicit device maintenance reserves priority and joins replay teardown before taking the actual item writer, including across tabs.

🚧 **Draft validation candidate; complete acceptance remains pending.** Exact candidate source `5c764793f03f7f885873d08d6eca0660cd401bf0`, base `c525aa933505d6e78b8fdd7a89940d87506d5cb3`, tree `d50abe8337f5855246e06511a5faf9e8bda7a138`. Actual SPN-157/full-groom main is integrated. Both independent exact-head revalidations are complete; the manager has verified the source and both exact-head PR receipts. Hosted publication is next; the draft remains unmergeable while acceptance is incomplete. No repaired-head hosted build/tested merge exists yet. Provisional ticket removal is not completion or merge permission.

## 🧭 Complete scope and decisions

The full **L, pre-launch** outcome retains editor-independent Doc/Sheet replay, exact account/item authority and revocation, exclusive writer ownership, persisted snapshot/outbox acknowledgement, exactly-once retry, interruption/recovery, separate-viewer content and a bounded installed-phone observation. Closed-app OS background execution, periodic polling, unrelated offline image/creation changes and iPhone acceptance remain outside this ticket.

[Original ticket](https://github.com/mxbaylee/spinel/blob/c525aa933505d6e78b8fdd7a89940d87506d5cb3/docs/todo/SPN-156.md), [canonical decisions and complete evidence](https://github.com/mxbaylee/spinel/blob/5c764793f03f7f885873d08d6eca0660cd401bf0/docs/implementation/SPN-156.md), [complete base/source diff](https://github.com/mxbaylee/spinel/compare/c525aa933505d6e78b8fdd7a89940d87506d5cb3...5c764793f03f7f885873d08d6eca0660cd401bf0).

All four personas informed the design. Owner gets durable delivery and foreground priority; Collaborator retains the existing account/access/revocation path and recoverable work; Operator gets bounded native concurrency and inspectable cleanup using existing components; Link guest receives no private replay owner or account store. Lost-ack attention remains conservative. Background replay cannot silently publish a recovery copy. This connects existing pending/saved/attention states; no new visual component, layout/theme change or routine screenshot matrix is introduced. Actual rendering and native interaction checks remain required. **Agent review only.**

## 🛠️ Repairs and retained first hosted failures

The original `40dee0d32cd3cce4bd9c1cbea74aeccdd1d83b47` validation remains failed. [Published original terminal archive](https://github.com/mxbaylee/spinel/tree/archive/spn-156-validation-40dee0d3-20261114/docs/review-assets/spn-156-validation-40dee0d3), immutable commit `3b496299a9f91ca797c5d80683aaede15660842a`, preserves source/base/tested-tree binding, all configured attempts and raw diagnostics. Original tested merge `eaaf75f393ab91d9fd1120cbff63c034b481bada` and application share tree `e5a4a18403609e80332137266365993a32abc93e`.

- **Cross-tab explicit discard exposed a product gap.** Original production-2 job `132380984914`, CI run `43572864010` attempt 1, retained authored 556/revision 1 with no submissions in both tabs, yet final discard met a nonexistent-editor busy refusal. Replay in the other tab held the real writer; the original same-tab stop map could not reach it. The repair adds a bounded shared replay admission gate and queued exclusive foreground priority using Web Locks and scoped storage events. Foreground queues before notifying, avoiding deadlock and replay reacquisition races, then joins quiet/persist/dispose. Live editors retain immediate nonblocking refusal. Wrong scope, stale requests, denied/missing transport, cancellation, timeout and cleanup failures remain fail-closed.
- **Quota and original-account recovery fixtures allowed legitimate replay before expecting pending state.** Every original attempt has a matching nonduplicate server acknowledgement and exact durable content: Sheet 552 or Doc “Kept through account exit 5581”, revision 2, empty pending buffer. This was not evidence of lost edits or partial quota transaction mutation. The fixtures now prove authored durable buffers and hold real native resume while HTTP/image access remains available; zero-submit/unchanged-server and original transaction, image, warning, account-isolation and offline-reopen assertions remain. The cross-tab discard fixture separately establishes a held real replay gate and pending content before explicit discard. All **nine failed attempts** remain retained. Production-2 artifact `14106362554`, ZIP SHA-256 `0c6bf77a4c817a1d2dc5843f7cd8b2a172947bdcc29f011fcd6cad4c643da8c8`, includes the reporter, screenshots, diagnostics and configured retry-1 traces. Frame arrays have no per-frame timestamp and failure cleanup did not retain a final server-database snapshot; neither is invented.
- **Native Desktop Chrome click was obstructed.** Run `43572863994` attempt 1, Chrome/macOS26 job `132380800458`, artifact `14105073087`, ZIP SHA-256 `c7887b140a624c9387eae654ca1a376cf0beee1e031739eeeba379acacf3b479`. Normal Sheet/Doc replay and conflict-Sheet checks completed before the protected-content warning covered the conflict Doc's Save details control. Browser 5058/driver 5054 exited; later conflict-Doc/storage-loss assertions were not completed. Safari/Firefox passed independently. Repair `def39e338f9aab57e11a940aa1622b5015f1f930` waits for the named control to be enabled, intersect the viewport and own its clipped center hit, then posts the same one native click under the unchanged 45-second deadline. No forced input, toast hiding, input retry or warning-cause repair is claimed.
- **Independent review found a denied-storage wrapper leak.** Epoch capture could throw after temporary-writer registration but before cleanup. Repair `16f4bb3bc9b850b3d51fdbbbd0e29f2ace459ca8` captures the fence before registration, retaining original refusal/no operation. Its actual-wrapper regression restores storage and requires replay reservation, actual editor lock admission, subsequent maintenance and empty final ownership. Exact original source fails directly at the reservation invariant before a blocked wait. Both original findings and the first actual-module failure remain preserved; historical numerical reports were moved outside blinded reviewer inputs without destroying their bytes.

Original successes are also retained with their original identity: sync-production job `132380984871` passed both new cases once on retry 0 (Doc+Sheet 10,042 ms; revoked edits 3,009 ms), within 100 passing cases. Artifact `14106192016`, ZIP SHA-256 `98133cc68ec42dc8b00258a21feda8e8e4d77f3bc2eb39c96bf66d0e0adc5830`, binds actual content/revisions, durable acknowledgement, second-viewer checks and file-list-only originating page; revoked work remained pending without submission/recovery-copy creation. Original Lib-remaining job `132380984700` ran the two actual native checkpoint cases successfully (137 ms), within 969 passed/3 skipped. Six original required gates passed; Playwright aggregate failed. These are **40de outcomes**, not current repaired-head acceptance.

## 🧪 Current source-bound verification

All **24 owned runtime/test blobs** at `5c764793` exactly match checked epoch-repair source `16f4bb3b` and prior candidate `d5a0bc7c`. Actual main `c525aa933505d6e78b8fdd7a89940d87506d5cb3` includes SPN-159, SPN-157’s full nineteen-obligation investigation and the full grooming reset. All 28 incoming paths from previous base87 are documentation/bookkeeping/evidence only; all 26 inherited records apart from the intentional counter/index resolutions remain byte-identical. The latest packaging preserves grade-free findings and raw check logs. All **117 dependency inputs** match this checkout, historical recorded hashes and the observed clean donor `5e72d33ac9cb3a86b3496345209493d6c86e469c`. Earlier `2204b8c4` is a historical comparison baseline, not the current donor. No install/shared dependency-cache mutation occurred.

- Current owner wrapper suite **20/20**, 7,051 ms / 949,920 KiB. Exact original ordering fails the new reservation assertion in 12 ms test time (guarded 2,218 ms / 972,288 KiB). Corrected/restored SHA-256 `c15b05c403522800a09fda143ab22ae27fcea3b8879d89c6c261f695d5ec01b7`; original `9f8b64735e82fdc61b7c08b3c150fdd8e58d0f58000ab0f0103aba545e9afd18`. [Wrapper evidence](https://github.com/mxbaylee/spinel/tree/5c764793f03f7f885873d08d6eca0660cd401bf0/docs/implementation/evidence/SPN-156/epoch-registration).
- Cross-tab gate-bypass negative fails both editor/maintenance real item-lock assertions directly in 6 ms test time. The corrected admission source was restored exactly. The first broad 184/186 result and repaired promotion-test-double owner are retained with their actual identities. A tiny Chromium `156.0.8078.4` platform case passed abort/callback exclusion/subsequent exclusive acquisition/final empty ownership (guarded 1,343 ms / 690,112 KiB), with no app/native startup. Both Node probes preserve the intermediate query observation and subsequent successful exclusive acquisition; no orphan ownership or substitute lock-manager model is claimed. [Cross-tab and platform evidence](https://github.com/mxbaylee/spinel/tree/5c764793f03f7f885873d08d6eca0660cd401bf0/docs/implementation/evidence/SPN-156/cross-tab-admission).
- Existing store transaction notification/error controls, real host/session cleanup cases and native checkpoint/content controls remain intact. Removing native restoration fails actual content; restoring old host cleanup fails its completion invariant; removing pointer hit readiness fails the covered-control assertion. Earlier failures and exact restorations remain in [maintained evidence](https://github.com/mxbaylee/spinel/tree/5c764793f03f7f885873d08d6eca0660cd401bf0/docs/implementation/evidence/SPN-156).
- Epoch-repair source typecheck passed **9,364 ms / 1,706,048 KiB**; relevant format/lint passed. Combined SPN-159 integration types passed **8,899 ms / 1,788,528 KiB**. Pinned Node 26.13.0, compiler 7.0.2 and `GOMEMLIMIT=640MiB GOGC=50 GOMAXPROCS=2` retained unchanged watchdog limits. Prior d5a0 documentation checks remain at their recorded identity. This integration passed index174 ms, canonical format257 ms/199,328 KiB, backlog144 ms and actual-base PR consistency388 ms/186,592 KiB on source16a6. Evidence JSON initially needed formatting (257 ms/197,632 KiB); its normalization and first failure are retained. Final format250 ms/201,376 KiB and PR374 ms/179,184 KiB passed at6d51349b; final5c764793 only explicitly retains six original ignored raw logs. Both reviewers subsequently passed actual-final-head PR checks; the manager independently verified those receipts without duplicating the CLI execution. Zero RSS in sub-200 ms receipts means no sample, not zero usage. No unchanged test/native/compiler/browser workload was repeated.

### 🔎 Independent exact-head reviews

Both independent nonimplementing reviewers assessed the complete original L
outcome at exact `5c764793f03f7f885873d08d6eca0660cd401bf0`, tree `d50abe8337f5855246e06511a5faf9e8bda7a138`, against actual `c525aa933505d6e78b8fdd7a89940d87506d5cb3`, using the
grade-free full outcome packet. Both recorded **100/100** with rubric **35 scope /
25 correctness / 20 regression / 10 operations / 10 maintainability**, no findings
and no actionable remaining review steps. **Agent review only.** The manager read
both complete reports and independently verified source identity and both exact-head
PR receipts; no redundant manager CLI execution was performed.

- Reviewer A `/root/spn156_blind_a`: exact-head backlog147 ms and PR376 ms /
  179,312 KiB passed. [Reserved immutable report](https://github.com/mxbaylee/spinel/blob/archive/spn-156-validation-5c764793-20261114/docs/review-assets/spn-156-validation-5c764793/spn156-blind-a-5c764793.md),
  SHA-256 `a542d137cded82c0f14d8a2169ec485b4ca69fd6f77bca747430a580a6b37d9d`.
- Reviewer B `/root/spn156_blind_b`: exact-head backlog142 ms and PR367 ms /
  179,152 KiB passed. [Reserved immutable report](https://github.com/mxbaylee/spinel/blob/archive/spn-156-validation-5c764793-20261114/docs/review-assets/spn-156-validation-5c764793/spn156-blind-b-5c764793.md),
  SHA-256 `2268c0c4f47628bab9f822d9226355cd4717f47230485688a7800e7369f79d93`.

The report links are reserved until the terminal archive is actually published;
exact report bytes and source/hash bindings are staged now. Both source checkouts
remained clean and ownership audits found no surviving workload or serial lock.
A review result never substitutes for hosted/phone acceptance or permits merge.

Historical technical verification remains source-bound to d5a0: reviewer A ran
187/187 six owner controls (9,826 ms / 1,049,280 KiB), 2/2 actual native checkpoint
controls (1,934 ms / 1,052,096 KiB), and 65/65 pointer controls (220 ms / 265,888 KiB).
Its first command was refused before spawning under elevated system pressure;
that first refusal remains recorded, without an invented raw log. Reviewer B ran
22/22 writer/native controls (7,590 ms / 831,744 KiB) and 65/65 pointer controls
(216 ms / 142,992 KiB). These results are applicable through exact source equality,
not relabelled as current-head executions. Both final ownership audits were empty.

All original numerical reports, including the withdrawn/nonqualifying16f4
assessment and prior findings, plus the complete d5a0 reports/root binding are
preserved byte-for-byte in external validation staging. They are excluded from
future blinded reviewer inputs; substantive findings, direct failures and repairs
remain in maintained grade-free evidence. Current completed reports and the manager’s source audit are now staged with
source/hash bindings. No report is silently replaced or removed from the archive.

## 🔎 Retained local attempts and actual acceptance still required

All six original native-app browser attempts remain preserved: (1) saved status preceded durable authored Doc content, fixed by a real-content precondition; (2) resource abort without result; (3) occupied 3105 port traced to a detached owned server and cleaned by exact PID/cwd/port; (4) smaller harness-only heap, resource abort; (5) reduced file-list preparation, resource abort before a case; (6) repaired production bundle but unchanged two-case attempt exceeded 2,097,152 KiB at **2,103,424 KiB / 10,938 ms** before assertions, revoked case unreached. Detached server 78389/PGID78361 was identified and cleaned; final listener/process audits were empty. No owner app was killed or bound raised.

Historical build `229e97684d404f9bd0908650f095055b2d4d4e11` passed 1,212 ms / 910,176 KiB, runtime `43c309cb3e283134`, entry `/assets/application-DjvUEl9z.js`, index SHA-256 `a991525f63faa5ef058362fed495af4d4f2ff54dfaecf53a9dc69088975d5768`. It is not the current repaired build. Eventual hosted evidence must bind its own application/head, tested merge/tree, build, selected plan, job, first attempt and cleanup.

Remaining current-source acceptance:

- **Sync-production:** both original native queued Doc+Sheet replay/peer-content and revoked-authority retention cases in `e2e/offline-editing.spec.ts`.
- **Production:** repaired quota atomicity, cross-tab explicit discard and original-account exit/recovery cases, with real authored checkpoints and retained warning/no-loss/authority assertions.
- **Native Desktop:** formerly obstructed control plus subsequent recovery/storage-loss assertions. Actual native Lib checkpoint execution and all selected app/shared/dependency owners remain in routing.
- **All seven current-head gates:** Backlog, Pull request, Lint, Typecheck, Unit tests, Playwright smoke, Lib tests. Selected missing/skipped/failed work cannot count as success.
- **Installed phone:** actual authorized repaired-build Home Screen launch, offline authorship, running file-list reconnect/foreground and peer-content observation, with exact device/browser/build/scenario provenance. No authorized device-control session is established. Earlier Pixel 10/latest Chrome symptom notes and the small Chromium platform probe do not satisfy this. It is an unavailable execution prerequisite, not a human product sign-off or provider gate; no pass or waiver is claimed.

## 📋 Conditional bookkeeping and durable records

Only SPN-156 is provisionally removed. Actual full grooming reset is preserved;
counter contains only provisional `156`, next ID **161**, grooming date
**2026-11-14**. Index is CLI-generated. Actual SPN-157 main and full grooming are
integrated; SPN-157 retains bounded non-recurrence with unknown historical cause,
not an invented causal fix. That acceptance does not satisfy this ticket’s
repaired-build installed-phone prerequisite. Current raw diff: **204 files,
+9,367/-126 text lines**; **24 TS/TSX files +2,013/-42**,
**180 documentation/evidence files +7,354/-84**, including 32
retained binary evidence files. Repository checker keeps normal exclusions.
[Input/source audit](https://github.com/mxbaylee/spinel/tree/5c764793f03f7f885873d08d6eca0660cd401bf0/docs/implementation/evidence/SPN-156/integration-c525aa93)
binds unchanged runtime evidence and all inherited records.

- [Published original failed validation](https://github.com/mxbaylee/spinel/tree/archive/spn-156-validation-40dee0d3-20261114/docs/review-assets/spn-156-validation-40dee0d3) remains immutable.
- [Reserved 5c764793 validation record](https://github.com/mxbaylee/spinel/tree/archive/spn-156-validation-5c764793-20261114/docs/review-assets/spn-156-validation-5c764793): tag `archive/spn-156-validation-5c764793-20261114`, not yet published. It must include all exact original/fresh review bytes, root binding, raw first failures and actual terminal source/build/run/job/case identities.
- [Reserved 5c764793 completion record](https://github.com/mxbaylee/spinel/tree/archive/spn-156-completion-5c764793-20261114/docs/review-assets/spn-156-completion-5c764793): tag `archive/spn-156-completion-5c764793-20261114`, not yet published and not evidence of completion.

A **verified published terminal record** supersedes only its corresponding initial pending statuses. An absent/incomplete/unverified record is never a pass. Hosted success cannot resolve the separate installed-phone prerequisite. If the candidate changes, review/archive identities follow the actual head; old results are not relabelled. After an accepted squash merge, recheck ticket-created refs, exact heads, active PR ownership and unique history before preserving required evidence and removing obsolete branches. No cleanup completion is claimed before that audit.
