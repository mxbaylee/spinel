# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: doc-responsiveness.spec.ts >> mobile sustained native typing plain-3
- Location: e2e/doc-responsiveness.spec.ts:316:5

# Error details

```
Error: Incomplete diagnostic trace
```

# Test source

```ts
  649 |         const drainWitness = sealedNative?.drainWitness as DocDrainWitness | null | undefined;
  650 |         evidence.drainWitness = drainWitness;
  651 |         expect(drainWitness).toBeTruthy();
  652 |         expect(drainWitness!.invalidated).toBe(false);
  653 |         expect(drainWitness!.invalidations).toEqual([]);
  654 |         expect(drainWitness!.epoch).toBe(drainArm!.epoch);
  655 |         expect(drainWitness!.generation).toBe(drainArm!.generation);
  656 |         expect(drainWitness!.unitId).toBe(native.unitId);
  657 |         expect(drainWitness!.timeOrigin).toBe(input.timeOrigin);
  658 |         expect(drainWitness!.expectedCompletedStates).toBe(expectedInputCount);
  659 |         expect(drainWitness!.completedStates).toBe(expectedInputCount);
  660 |         expect(drainWitness!.lastCompletedStateAt!).toBeGreaterThanOrEqual(input.keydownAt.at(-1)!);
  661 |         expect(drainWitness!.firstEmpty).toBeTruthy();
  662 |         expect(drainWitness!.firstEmpty).toEqual(native.drainWitness?.firstEmpty);
  663 |         expect(drainWitness!.firstEmpty!.observedAt).toBeGreaterThanOrEqual(
  664 |           drainWitness!.lastCompletedStateAt!,
  665 |         );
  666 |         expect(drainWitness!.firstEmpty!.pending).toEqual({ history: 0, collaboration: 0 });
  667 |         expect(drainWitness!.firstEmpty!.history).toEqual(native.history);
  668 |         expect(drainWitness!.firstEmpty!.highWater).toEqual(native.highWater);
  669 |         expect(drainWitness!.sealedAt!).toBeGreaterThanOrEqual(preUndoIntegrity.observedAt);
  670 |         const historyProgress: Record<string, unknown> = { phase: 'not-started' };
  671 |         evidence.undoRedoObservation = historyProgress;
  672 |         const undoRedo = await verifyUndoRedo(
  673 |           f,
  674 |           preUndoIntegrity,
  675 |           sample === 'plain-1',
  676 |           reloadObservers,
  677 |           clockOrigins,
  678 |           historyProgress,
  679 |         );
  680 |         evidence.undoRedo = undoRedo;
  681 |         expect(drainWitness!.sealedAt!).toBeLessThanOrEqual(undoRedo.beforeUndoAt);
  682 |         await expect
  683 |           .poll(async () => (await f.read()).body!.dataStream)
  684 |           .toBe(undoRedo.outcome === 'passed' ? expectedText : '\r\n');
  685 |         await Promise.all([online(f.page), online(f.other)]);
  686 |         expect(f.errors).toEqual([]);
  687 |         expect(input.keydownAt).toHaveLength(expectedInputCount);
  688 |         expect(input.keyToFrameMs).toHaveLength(expectedInputCount);
  689 |         evidence.correctness =
  690 |           undoRedo.outcome === 'passed'
  691 |             ? 'exact saved/live peer text, sender/peer selections, undo/redo and Online passed'
  692 |             : 'baseline redo refused at capacity; exact prior typing and Undo verified; recovered saved empty state';
  693 |         // Schema 4 retains the strict baseline history outcome and separately
  694 |         // observes capacity/idle work. Drain acceptance now uses the preregistered
  695 |         // browser-local witness; the unchanged late-read scalar remains descriptive.
  696 |         if (!baseline) {
  697 |           expect(native.highWater.history).toBeLessThanOrEqual(DOC_RESPONSIVENESS_GROUP_LIMIT);
  698 |           expect(native.highWater.collaboration).toBeLessThanOrEqual(
  699 |             DOC_RESPONSIVENESS_GROUP_LIMIT,
  700 |           );
  701 |           expect(capacityFlushes.length).toBeGreaterThan(0);
  702 |           for (const entry of native.flushes) {
  703 |             expect(['capacity', 'idle']).toContain(entry.reason);
  704 |             expect(Number.isInteger(entry.history) && entry.history >= 0).toBe(true);
  705 |             expect(Number.isInteger(entry.collaboration) && entry.collaboration >= 0).toBe(true);
  706 |             const pending = Math.max(entry.history, entry.collaboration);
  707 |             expect(pending).toBeGreaterThan(0);
  708 |             expect(pending).toBeLessThanOrEqual(DOC_RESPONSIVENESS_GROUP_LIMIT);
  709 |             if (entry.reason === 'capacity') expect(pending).toBe(DOC_RESPONSIVENESS_GROUP_LIMIT);
  710 |             if (entry.reason === 'idle') {
  711 |               expect(Number.isFinite(entry.quietForMs)).toBe(true);
  712 |               expect(entry.quietForMs!).toBeGreaterThanOrEqual(300);
  713 |             }
  714 |           }
  715 |           if (!profiled) {
  716 |             expect(frame.p95).toBeLessThanOrEqual(budgets[preset].inputP95Ms);
  717 |             expect(longTasks.max).toBeLessThanOrEqual(budgets[preset].longTaskMaxMs);
  718 |             // Idle samples must never dilute the registered capacity distribution.
  719 |             expect(capacityFlush!.p95).toBeLessThanOrEqual(budgets[preset].flushP95Ms);
  720 |             expect(capacityFlush!.max).toBeLessThanOrEqual(budgets[preset].flushMaxMs);
  721 |             if (idleFlush) {
  722 |               expect(idleFlush.p95).toBeLessThanOrEqual(budgets[preset].flushP95Ms);
  723 |               expect(idleFlush.max).toBeLessThanOrEqual(budgets[preset].flushMaxMs);
  724 |             }
  725 |             expect(flushMaximum!).toBeLessThanOrEqual(budgets[preset].flushMaxMs);
  726 |             expect(localDrainMs).not.toBeNull();
  727 |             expect(localDrainMs!).toBeLessThanOrEqual(1000);
  728 |           }
  729 |         }
  730 |         const finalReloads = await readReloads(reloadObservers);
  731 |         completeReloadObservation(finalReloads);
  732 |         expect(finalReloads.reloads).toEqual(undoRedo.reloads);
  733 |         evidence.reloadObservers = finalReloads.status;
  734 |         evidence.completed = true;
  735 |       } finally {
  736 |         let diagnosticError: unknown;
  737 |         try {
  738 |         if (finishInput)
  739 |           evidence.partialInput = await finishInput().catch((error) => ({ error: String(error) }));
  740 |         if (profiling) {
  741 |           const result = await cdp.send('Profiler.stop').catch(() => null);
  742 |           if (result)
  743 |             evidence.profileSha256 = await retainProfile(result.profile, profilerClock, info);
  744 |         }
  745 |         if (finishTrace) {
  746 |           try {
  747 |             evidence.traceClockEnd = await f.page.evaluate(() => performance.mark('spn071-clock-end').startTime);
  748 |             evidence.diagnosticTrace = await finishTrace();
> 749 |             if (!(evidence.diagnosticTrace as { complete: boolean }).complete) diagnosticError = new Error('Incomplete diagnostic trace');
      |                                                                                                  ^ Error: Incomplete diagnostic trace
  750 |           } catch (error) { diagnosticError = error; evidence.diagnosticTraceError = String(error); }
  751 |         }
  752 |         evidence.errors = f.errors;
  753 |         evidence.finalNative = await readDocResponsiveness(f.page).catch(() => null);
  754 |         if (reloadObservers) {
  755 |           const finalReloads = await readReloads(reloadObservers).catch(() => null);
  756 |           if (finalReloads) {
  757 |             evidence.reloadObservers = finalReloads.status;
  758 |             evidence.finalReloads = finalReloads.reloads;
  759 |           }
  760 |           await Promise.all([reloadObservers.sender.dispose(), reloadObservers.peer.dispose()]);
  761 |         }
  762 |         await writeFile(info.outputPath('spn108-metrics.json'), JSON.stringify(evidence, null, 2));
  763 |         } finally {
  764 |           await cdp.detach().catch(() => {});
  765 |           await f.close();
  766 |         }
  767 |         if (diagnosticError) throw diagnosticError;
  768 |       }
  769 |     });
  770 | 
  771 | /** Only the separate continuation case reads native state at its final key's first frame. */
  772 | async function observeContinuationFrame(page: Page, unitId: string) {
  773 |   const handle = await page.evaluateHandle(
  774 |     ({ unitId, expectedKeys }) => {
  775 |       const installedAt = performance.now();
  776 |       let keyCount = 0;
  777 |       let frame: number | undefined;
  778 |       let result: {
  779 |         keyAt: number;
  780 |         frameAt: number;
  781 |         readStartedAt: number;
  782 |         readReturnedAt: number;
  783 |         responses: number;
  784 |         snapshot: DocResponsivenessEvidence | null;
  785 |       } | null = null;
  786 |       const keydown = (event: KeyboardEvent) => {
  787 |         if (
  788 |           !(event.target instanceof Element) ||
  789 |           !event.target.matches('[contenteditable="true"][data-u-comp="editor"]')
  790 |         )
  791 |           return;
  792 |         keyCount++;
  793 |         if (keyCount !== expectedKeys) return;
  794 |         const keyAt = performance.now();
  795 |         frame = requestAnimationFrame(() => {
  796 |           frame = undefined;
  797 |           const frameAt = performance.now();
  798 |           let snapshot: DocResponsivenessEvidence | null = null;
  799 |           let responses = 0;
  800 |           const read = (event: Event) => {
  801 |             const evidence = (event as CustomEvent<DocResponsivenessEvidence>).detail;
  802 |             if (evidence?.unitId !== unitId) return;
  803 |             responses++;
  804 |             snapshot = evidence;
  805 |           };
  806 |           window.addEventListener('spinel-doc-responsiveness-evidence', read);
  807 |           const readStartedAt = performance.now();
  808 |           try {
  809 |             window.dispatchEvent(
  810 |               new CustomEvent('spinel-doc-responsiveness-read', { detail: { includeText: true } }),
  811 |             );
  812 |           } finally {
  813 |             window.removeEventListener('spinel-doc-responsiveness-evidence', read);
  814 |             result = {
  815 |               keyAt,
  816 |               frameAt,
  817 |               readStartedAt,
  818 |               readReturnedAt: performance.now(),
  819 |               responses,
  820 |               snapshot,
  821 |             };
  822 |           }
  823 |         });
  824 |       };
  825 |       document.addEventListener('keydown', keydown, { capture: true, passive: true });
  826 |       return {
  827 |         read: () => ({ installedAt, unitId, expectedKeys, keyCount, result }),
  828 |         dispose() {
  829 |           document.removeEventListener('keydown', keydown, true);
  830 |           if (frame !== undefined) cancelAnimationFrame(frame);
  831 |         },
  832 |       };
  833 |     },
  834 |     { unitId, expectedKeys: expectedInputCount + 1 },
  835 |   );
  836 |   return {
  837 |     read: () => handle.evaluate((value) => value.read()),
  838 |     async dispose() {
  839 |       await handle.evaluate((value) => value.dispose()).catch(() => {});
  840 |       await handle.dispose();
  841 |     },
  842 |   };
  843 | }
  844 | 
  845 | for (const preset of ['desktop', 'mobile'] as const)
  846 |   test(`${preset} resumes native typing after a quiet pause`, async ({
  847 |     browser,
  848 |     baseURL,
  849 |   }, info) => {
```