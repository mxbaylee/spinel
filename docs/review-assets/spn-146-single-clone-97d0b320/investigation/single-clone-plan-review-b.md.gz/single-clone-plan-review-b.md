# 🔎 SPN-146 single-clone plan — independent B scope review

**Disposition: supported for preparing an exact bounded scratch proposal, not for execution or production admission.** This is a distinct source-supported ownership/copy question. The failed 97d runtime criterion and its consumed allowance remain failed and closed; a local semantic/work result cannot repair that result or authorize another runtime attempt.

I read `SPN-146-single-clone.md`, the current Docs patch's fully qualified prefix/tail branches and guards, and the installed pinned public Core implementations of `ActionIterator.next`, the public body slicer and `TextX.push`. No implementation, test, browser, converter or other experiment was run.

## 🧩 Mechanism and precise boundary

The observed duplicate-copy premise is concrete. For the admitted length-one insert, `ActionIterator.next(1)` reconstructs the action using the full `getBodySliceForSplitTextXAction(body,0,1,false)` result and then calls `Tools.deepClone`. `TextX.push` immediately deep-clones its input before inspecting/merging it into the accumulator. The public slicer is a named Core export. Removing the first clone while retaining the same reconstruction and native push therefore tests a specific redundant-copy hypothesis, rather than replacing the public normalizer with handwritten concatenation.

Keep the **body spread itself**, the original action spread, explicit length and the slicer's exact arguments/defaults. Do not replace the action with a reduced `{t,len,body}` object: admitted own fields such as `valueRangeId` must survive. The insert-only guard is essential: the installed iterator includes additional REPLACE-retain paragraph handling that this proposed shortcut must never subsume. The native Enter action, prefix<4 null fold, first absolute retain, prefix/Enter and final head/tail joins, inverse/delete paths and every unsupported fallback remain untouched. Tiny-prefix cases can still have a changed tail; distinguish those affected phases from a genuinely unchanged path.

The final push still owns its input clone before any native merge. That makes the direction plausible, not proven equivalent: cloning can normalize object graphs, aliasing, property descriptors and prototypes. Two clones and one clone cannot be assumed idempotent for every admitted shape. The existing full plain-data/descriptor guard remains mandatory. No private accumulator manipulation, raw borrowed publication or deferred clone is justified.

## 🧪 Required falsification in the exact script

The proposed four retained pairs × two manager formats × current97/prototype = maximum16 flushes is appropriately narrow. Before admitting it, the concrete script should demonstrate these boundaries:

- Pin current97 whole-module bytes, exact public Core/import resolution and the four input pairs. Verify the public slicer's ES lexical import and CJS namespace binding in complete modules; injected helper contexts alone would repeat the rejected418 blind spot. If both manager formats use ES Core in a same-realm fixture, disclose it and do not call that CJS-Core execution.
- Preserve original raw forward/inverse/publication values and ordering, own-property/undefined/descriptor/prototype shape, combined input/output alias graph, unchanged inputs and distinct-call/output ownership. Raw reference sinks must inspect before serialization can erase the very alias difference being tested. Use the existing meaningful native semantic oracles as well as current97 parity.
- Count the actual direct slicer calls. A wrapper around only the old iterator path could falsely report fewer body slices. Bind instrumentation to the executed callable in both variants, reconcile calls with affected leaves, and retain full per-phase counters. Success requires the prescribed strict deep-clone/allocation reduction in each changed phase, not merely fewer iterator objects or an aggregate hiding a regression. Do not claim that normalization disappeared.
- Append the attempted variant/phase before calling it; retain partial raw publication or explicit unavailability on first failure. Preserve primary failure across evidence persistence and fixture cleanup. Retain bounded proof bytes and complete owned cleanup with the same serial60-second/2GiB/normal-pressure limit. A resource abort or failed semantic hypothesis closes this allowance; no repair-and-rerun follows automatically.

No new reusable framework is needed. Adapt the already reviewed finite raw-reference fixture and ownership-proof machinery. A completed successful narrow test would support only the separately reviewed broader matrix already named in the plan: metadata/undefined/empty fields, shared styles and markers, repeated normalization and calls, input/output mutation, prefix3/4, unequal caches and untouched malformed/accessor/idle/remote/pre-Undo behavior. Those are essential semantic boundaries before production; their absence is not a reason to prematurely expand this first16-flush question into another application run.

## ⚖️ Scope, personas and limits

This question stays within SPN-146's XL native composition investigation and is different from the exhausted qualification-scan reuse and linear assembly runtime experiments. It isolates one extra clone in the current assembly path. It does not establish historical pause causality, elapsed native benefit, Linux headroom or satisfaction of the fixed all-comparison runtime criterion. The current97 outcome of13/16 passing comparisons remains insufficient even if every local clone counter improves.

Owner and Collaborator require exact authored content, style, undo and independent ownership; neither tolerates a faster aliasing bug. Operator benefits from a small source-explained falsification with bounded resources and retained failure, not another speculative profiling loop. Link guest authority is untouched and remains enforced by existing access paths. No separate product feature, new dependency, persistent cache, threshold relaxation, moved window or automatic runtime renewal is warranted.

**Next boundary:** prepare the exact scratch script and submit it for independent inspection. This review supplies no execution allowance, production patch approval, source grade or device/runtime permission.
