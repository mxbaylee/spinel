import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root='/Users/mxbaylee/projects/spinel-spn-146',hash=(s:string)=>createHash('sha256').update(s).digest('hex');
let s=await readFile('/tmp/spn146-investigation/linear-prefix-broad.ts','utf8');if(hash(s)!=='7ef166e3848b0e12264fc3fec2e594ccb9b5ccd0090a4d79c3d0a363de5cb7ee')throw Error('prior-broad-source-changed');
const probe=await readFile('/tmp/spn146-investigation/single-clone.ts','utf8');if(hash(probe)!=='67596c25eb1738293945418d0915a47f6ecdd289d1c6d8ffc2f1799544aaefb7')throw Error('probe-source-changed');
const prototype=probe.slice(probe.indexOf('function prototype(source:string,format:Format){'),probe.indexOf('function instrument(source:string){'));
const start=s.indexOf('function linearTail(source:string,format:Format){'),end=s.indexOf('function prepareDocsPatch(source:string,format:Format){',start);if(start<0||end<start)throw Error('prototype-target');s=s.slice(0,start)+prototype+s.slice(end);
s=s.replace('const result=basePrepareDocsPatch(source,format),tailOnly=linearTail(result.patched,format),candidate=prefixPrototype(tailOnly,format);','const result=basePrepareDocsPatch(source,format),tailOnly=result.patched,candidate=prototype(tailOnly,format);');
s=s.replaceAll('linear-prefix-broad','single-clone-broad').replaceAll('8b6828196266f1fac6c46e2cc16b16321db72cf7','97d0b3203fbddc673d5a9bc729410949eb875523');
s=s.replaceAll('110890e889ac362b22a4c38bafd1ebb4e7cf82e8107d4524bdb86ff7fe6bd7c3','4b30f509d7426d43b5314f7d32422e0ca94830320d441712b6eed142af2b8dd5').replaceAll('58edceea5e1fb66ff1a83ec0a92707cf6f8d741aab87eb922d9c7e021f99207d','4ade808be25d9aed4122d1ab254a07802c89065c06cac42f9dec60fe2f2d286f');
s=s.replaceAll('8cad4e5eb989281b840632a74f5654c15dc4db7be11f38c38d4390250f065901',hash(await readFile(root+'/scripts/dependencies/patch-univer-docs.test.ts','utf8'))).replaceAll('81bd730d7975fb0d176e3657a740218a9131fce1a52e4af9665ce61334b784a8',hash(await readFile(root+'/scripts/dependencies/patch-univer-docs.ts','utf8')));
s=s.replaceAll('/Users/mxbaylee/projects/spinel/node_modules/',root+'/node_modules/');
s=s.replace("import * as core from '@univerjs/core';",`import * as core from '${root}/node_modules/@univerjs/core/lib/es/index.js';`);
s=s.replace("fileURLToPath(import.meta.resolve('@univerjs/core'))",`fileURLToPath(new URL('file://${root}/node_modules/@univerjs/core/lib/es/index.js'))`);
s=s.replace('let recent:any[]=[];','let recent:any[]=[];let activeCounts:Record<string,number>|undefined;');
const context='const contextCore = { ...core, Inject: () => () => {}, Optional: () => () => {} };';if(s.split(context).length!==2)throw Error('context-target');s=s.replace(context,"const contextCore = { ...core, getBodySliceForSplitTextXAction: (...args: Parameters<typeof core.getBodySliceForSplitTextXAction>) => { if(activeCounts)activeCounts.bodySlices++; return core.getBodySliceForSplitTextXAction(...args); }, Inject: () => () => {}, Optional: () => () => {} };");
const counts='const counts = { textCompose: 0, iteratorNext: 0, bodySlices: 0, cloneVisits: 0, allocations: 0 };';if(s.split(counts).length!==2)throw Error('counts-target');s=s.replace(counts,counts+'\n  activeCounts=counts;');s=s.replace('    core.TextX.compose = compose;','    activeCounts=undefined;\n    core.TextX.compose = compose;');
s=s.replace('const eligible=length-position>4&&position>=4;','const eligible=length-position>4;');
s=s.replace("if(!eligible)assert.deepEqual(after.counts,before.counts,'Unadmitted or tiny head retains exact primitive work');\n  else for(const counter of ['textCompose','iteratorNext','bodySlices','allocations'] as const)assert.ok(after.counts[counter]<before.counts[counter],'Eligible prefix reduces work '+counter);", "if(!eligible)assert.deepEqual(after.counts,before.counts,'Unadmitted group retains exact primitive work');\n  else { for(const counter of ['cloneVisits','iteratorNext','allocations'] as const)assert.ok(after.counts[counter]<before.counts[counter],'Qualified clone removal reduces work '+counter); for(const counter of ['textCompose','bodySlices'] as const)assert.equal(after.counts[counter],before.counts[counter],'Actual normalization/composition work unchanged'); }");
s=s.replace('prefix isolation, boundaries and normalization ownership','single-clone boundaries, normalization and shared ownership');
// Extend the two existing custom groups, without introducing extra top-level tests.
const shared=String.raw`
 for(const position of [3,4]) {
  const color={rgb:'#123456'},shared={bl:1,cl:color,ul:{s:1,cl:color}};
  const scenario=paragraphSequence(position,16,core.UpdateDocsAttributeType.REPLACE,7,(body,enter)=>{if(!enter)body.textRuns![0].ts=shared;});
  const before=flush(currentPatched,scenario.states,scenario.states,true),after=flush(patched,scenario.states,scenario.states,true);
  assertNativePreservation(before,after,scenario,format+'/shared-style/'+position);
  assert.deepEqual(ownDataShape({input:scenario.states,output:after}),ownDataShape({input:scenario.states,output:before}),'Shared input style graphs retain exact output ownership');
  const inputShape=ownDataShape(scenario.states),expected=structuredClone(after);
  ((after.changes[0].redoState.actions as any)[1].e.find((v:any)=>v.t==='i')).body.textRuns[0].ts.cl.rgb='#ffffff';
  assert.deepEqual(ownDataShape(scenario.states),inputShape,'Output style mutation cannot change shared input');
  assert.deepEqual(flush(patched,scenario.states,scenario.states,true),expected,'Later calls do not reuse mutated shared styles');
 }
`;
const insertion='}});\nconst began=performance.now();';if(s.split(insertion).length!==2)throw Error('custom-boundary-target');s=s.replace(insertion,shared+insertion);
await writeFile('/tmp/spn146-investigation/single-clone-broad.ts',s,{flag:'wx'});console.log(hash(s));
