# 🔎 SPN-146 single-clone retained outcome — reviewer B

**The finite lower-layer question passed on all16 attempted flushes.** The result supports preparing the separately reviewed broader semantic matrix. It does not establish native elapsed-time benefit, satisfy the failed97d runtime criterion, admit production changes or authorize another runtime attempt.

## Evidence and actual result

I inspected `single-clone-result.json`, log, watchdog and the previously reviewed script, and independently hashed the script and all16 retained V8 proof files. I did not replay the fixture or deserialize/re-execute native operations. Script SHA remains `67596c25eb1738293945418d0915a47f6ecdd289d1c6d8ffc2f1799544aaefb7`; source is `97d0b3203fbddc673d5a9bc729410949eb875523`. The prototype identities are ES `d77c290c1ac30aba9dad723e61dd88b9d0a0c867f9c29173dafc989f37234de2` and CJS `948d12004209a969b98c5a89e030f00167a995fa190278fb67999ef443806103`.

The report records16 attempted/16 completed flushes, complete:true, no cleanup failures, and1,529,904 proof bytes. The outer guard passed in1,349 ms, peak324,416 KiB, pressure1. The610.704 ms body elapsed value is accounting, not a controlled performance comparison. ES/CJS labels describe manager regions; both execute ES Core, as explicitly recorded.

All eight current/prototype pairs have equal raw proof hashes and equal recorded descriptor/prototype/alias-graph fingerprints. The independently read proof-file hashes match those paired identities:544 `5d3a6933…`,672 `3aff6389…`,1440 `82775316…`,1984 `64ead44e…`, identical in both manager formats. Descriptor and true prototype/reference checks were performed in memory by the admitted script; V8 bytes alone do not independently prove every descriptor or prototype identity.

Each history and collaboration phase has one qualified-branch hit and satisfies all prescribed counter checks. Per-phase allocations are544 **1,978→1,730**,672 **2,150→1,902**,1440 **3,354→3,106**,1984 **1,680→1,456**, in both formats. Clone visits fall respectively4,157→3,630;4,517→3,990;7,037→6,510;3,541→3,065. Iterator calls fall150→119;170→139;310→279;119→91. Actual slice counts remain81,85,113,75 and native composition counts remain10,12,26,8, respectively. Thus the result removes measured copying without falsely counting the retained direct public slicing as eliminated work. The aggregate allocation pairs reported by the parent are consistent with these two phases.

The executed semantic claim remains exact raw publication/order, input nonmutation and ownership parity on the four captured pairs. The runner did not reconstruct an independent original document for fresh sequential/applied-snapshot acceptance. No new assertion about the old historical pauses follows.

## Next semantic question

The proposed existing16-group/1,862-flush broader matrix is a justified next preparation step, provided its exact generated script is reviewed before execution. It should compare **current97 linear assembly versus this single-clone prototype**, preserving the original independent native/applied-snapshot oracles where available. Merely rerunning the older prefix matrix without changing its comparator and work oracle would not answer the new question.

Keep direct-slicer accounting on both variant contexts. Changed insert phases should have equal actual slice/composition counts and reduced cloning; do not retain an obsolete assertion demanding fewer slices. Unsupported routes and the tiny-prefix head construction must remain exact. A tiny-prefix group's qualifying tail still changes, so whole-group equality is not the right negative for that head boundary.

Most discriminating cases remain own-undefined and empty metadata, repeated public normalization, shared style graphs, action fields/markers, input-to-output and inter-output aliasing, descriptor/prototype shape, mutation after publication and repeated independent calls. Preserve prefix3/4, unequal caches, malformed/accessor input rejection and idle/remote/pre-Undo owners. Apply full document-state oracles in that broader fixture rather than describing raw current-parity as independent semantics. Actual complete-module import/require and installer/upgrade/missing-binding controls remain necessary before a production candidate.

No additional generic fixture framework or profiling is justified by this result. Reuse the admitted partial-publication, primary-error and cleanup ownership machinery; fix a finite maximum and stop on the first semantic/resource failure. This report supports preparing that concrete matrix, not executing it without its exact-script review.

**Disposition:** retain this successful local work/semantics result separately. Production remains unchanged,97d's13/16 hosted qualification remains failed, and all prior runtime/window allowances stay consumed. No browser, converter, device or new runtime experiment is admitted here.
