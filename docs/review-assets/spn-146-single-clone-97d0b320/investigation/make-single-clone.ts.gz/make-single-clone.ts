import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root='/Users/mxbaylee/projects/spinel-spn-146';
const sha=(s:string)=>createHash('sha256').update(s).digest('hex');
let s=await readFile('/tmp/spn146-investigation/linear-prefix.ts','utf8');
if(sha(s)!=='eb7857629500a4b3dacec76073db2e3ebb71af69892d8903351f4f98d0f4a727')throw Error('prior-diagnostic-source-changed');
const sourceHashes={fixture:sha(await readFile(root+'/scripts/dependencies/patch-univer-docs.test.ts','utf8')),patch:sha(await readFile(root+'/scripts/dependencies/patch-univer-docs.ts','utf8'))};
s=s.replace(/const expectedSourceHashes=.*?;/,'const expectedSourceHashes='+JSON.stringify(sourceHashes)+';');
s=s.replaceAll('/Users/mxbaylee/projects/spinel/node_modules/',root+'/node_modules/');
s=s.replace("import * as core from '@univerjs/core';",`import * as core from '${root}/node_modules/@univerjs/core/lib/es/index.js';`);
s=s.replace("fileURLToPath(import.meta.resolve('@univerjs/core'))",`fileURLToPath(new URL('file://${root}/node_modules/@univerjs/core/lib/es/index.js'))`);
s=s.replaceAll('linear-prefix','single-clone').replaceAll('8b6828196266f1fac6c46e2cc16b16321db72cf7','97d0b3203fbddc673d5a9bc729410949eb875523');
s=s.replace("scope:'Tail fixed; one normalization/push per fully qualified prefix leaf; tiny-head exact negative; no runtime acceptance.'","scope:'Remove only duplicate pre-push clone of an admitted normalized leaf; retain actual slice accounting and native final ownership; no runtime acceptance.'");
const start=s.indexOf('function prototype(source:string,format:Format){'),end=s.indexOf('function instrument(source:string){',start);
if(start<0||end<start)throw Error('prototype-markers');
const prototype=String.raw`function prototype(source:string,format:Format){
 const prefix=format==='es'?'':'_univerjs_core.';
 const anchor='function composeDocStateActions(states, key) {';
 const helper='function normalizeDocInsertLeaf(leaf) {\n\treturn { ...leaf, len: 1, body: { ...'+prefix+'getBodySliceForSplitTextXAction(leaf.body, 0, 1, false) } };\n}\n';
 assert.equal(source.split(anchor).length,2);source=source.replace(anchor,helper+anchor);
 for(const leaf of ['leaf','edits[edits.length - 1]']){
  const before='new '+prefix+'ActionIterator(['+leaf+']).next(1)';assert.equal(source.split(before).length,2);
  source=source.replace(before,'normalizeDocInsertLeaf('+leaf+')');
 }
 if(format==='es'){
  const before='import { ActionIterator, AlignTypeH,';
  assert.equal(source.split(before).length,2);
  source=source.replace(before,'import { ActionIterator, getBodySliceForSplitTextXAction, AlignTypeH,');
 }
 return source;
}
`;
s=s.slice(0,start)+prototype+s.slice(end);
s=s.replace("const current=prototype(old,format);","const current=old;");
s=s.replaceAll('prefixPrototype(current,format)','prototype(current,format)');
s=s.replaceAll('110890e889ac362b22a4c38bafd1ebb4e7cf82e8107d4524bdb86ff7fe6bd7c3','4b30f509d7426d43b5314f7d32422e0ca94830320d441712b6eed142af2b8dd5').replaceAll('58edceea5e1fb66ff1a83ec0a92707cf6f8d741aab87eb922d9c7e021f99207d','4ade808be25d9aed4122d1ab254a07802c89065c06cac42f9dec60fe2f2d286f');
s=s.replace("eligible:prefixIndex>=4","eligible:true");
const before="const contextCore = { ...core, Inject: () => () => {}, Optional: () => () => {} };";
if(s.split(before).length!==2)throw Error('core-context');
s=s.replace(before,"const contextCore = { ...core, getBodySliceForSplitTextXAction: (...args: Parameters<typeof core.getBodySliceForSplitTextXAction>) => { activeCounts.bodySlices++; return core.getBodySliceForSplitTextXAction(...args); }, Inject: () => () => {}, Optional: () => () => {} };");
const criterion=s.indexOf("    if(row.eligible)for(const key of ['textCompose','iteratorNext','bodySlices','allocations'])");
const criterionEnd=s.indexOf('\n   }\n  }\n }',criterion);
if(criterion<0||criterionEnd<criterion)throw Error('criterion-markers');
s=s.slice(0,criterion)+String.raw`    for(const key of ['cloneVisits','allocations','iteratorNext'])
     assert.ok(next.phases[phase].counts[key]<old.phases[phase].counts[key],format+'/'+pair.completed+'/'+old.phases[phase].phase+'/'+key+': strict removed-clone work reduction');
    for(const key of ['textCompose','bodySlices'])assert.equal(next.phases[phase].counts[key],old.phases[phase].counts[key],'Native composition and actual normalization counts stay equal');`+s.slice(criterionEnd);
s=s.replace(" report.sourceHashes=expectedSourceHashes;"," report.sourceHashes=expectedSourceHashes;\n assert.equal(typeof core.getBodySliceForSplitTextXAction,'function');");
await writeFile('/tmp/spn146-investigation/single-clone.ts',s,{flag:'wx'});console.log(sha(s));
